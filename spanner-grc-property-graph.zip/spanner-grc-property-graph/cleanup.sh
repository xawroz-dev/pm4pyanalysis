#!/bin/bash
set -e

# ==============================================================================
# Complete Teardown & Cleanup Script for Spanner GRC Property Graph
# Cleans up Containers, Volumes, Spanner Databases, Schema, and Generated Data
# ==============================================================================

echo "=================================================================="
echo "⚠️  Spanner GRC Knowledge Graph: Complete Environment Cleanup"
echo "=================================================================="

# 1. Teardown Podman / Docker Containers & Volumes
echo "1. Stopping and removing Spanner Omni containers and volumes..."
if command -v podman >/dev/null 2>&1; then
  echo "   [Podman] Removing container 'spanner-omni' and volume 'spanner-omni-data'..."
  podman rm -f spanner-omni >/dev/null 2>&1 || true
  podman rm -f grc-graph-app >/dev/null 2>&1 || true
  podman rm -f spanner-init >/dev/null 2>&1 || true
  podman volume rm spanner-omni-data >/dev/null 2>&1 || true
fi

if command -v docker >/dev/null 2>&1; then
  echo "   [Docker] Stopping docker-compose services and removing volumes..."
  docker compose down -v >/dev/null 2>&1 || true
  docker rm -f spanner-omni >/dev/null 2>&1 || true
  docker volume rm spanner-omni-data >/dev/null 2>&1 || true
fi

# 2. Run Python Artifact Cleanup
echo "2. Cleaning generated data artifacts and temporary files..."
if [ -d ".venv" ]; then
  source .venv/bin/activate
  PYTHONPATH=. python credit_refund_demo/clean_all_data.py || true
else
  python3 credit_refund_demo/clean_all_data.py || true
fi

# 3. Clean Pytest & Python Cache Files
echo "3. Removing __pycache__ and test caches..."
find . -type d -name "__pycache__" -exec rm -rf {} + >/dev/null 2>&1 || true
find . -type d -name ".pytest_cache" -exec rm -rf {} + >/dev/null 2>&1 || true

echo "=================================================================="
echo "✓ All containers, volumes, Spanner tables, and data files DELETED."
echo "To re-initialize cleanly at any time, run:"
echo "   ./docker/run_spanner_omni_podman.sh"
echo "   PYTHONPATH=. python credit_refund_demo/load_all_data.py"
echo "   PYTHONPATH=. python credit_refund_demo/run_demo.py"
echo "=================================================================="
