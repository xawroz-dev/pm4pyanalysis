"""Cloud Spanner / Spanner Omni DDL Generator for Enterprise GRC Property Graph."""
from typing import List


def generate_spanner_ddl(graph_name: str = "EnterpriseGRCGraph", embedding_dim: int = 768) -> str:
    """Generate complete Cloud Spanner / Spanner Omni DDL script.
    
    Includes:
    1. Node Tables (Document, Chunk, Process, Policy, Risk, Control, Market, System)
    2. Edge Tables (with Foreign Keys & Edge properties)
    3. Vector Index (TREE_AH, COSINE distance)
    4. Full-Text Search Index
    5. Property Graph Definition with NODE TABLES and EDGE TABLES
    """
    ddl_statements = [
        "-- ==========================================================================",
        "-- Cloud Spanner / Spanner Omni Property Graph & Vector DDL",
        "-- Enterprise Governance, Risk, Compliance (GRC) Knowledge Graph",
        "-- ==========================================================================",
        "",
        "-- --------------------------------------------------------------------------",
        "-- 1. NODE TABLES",
        "-- --------------------------------------------------------------------------",
        """CREATE TABLE Document (
    id STRING(128) NOT NULL,
    title STRING(512) NOT NULL,
    source_type STRING(64) NOT NULL,
    uploaded_at TIMESTAMP NOT NULL,
    raw_text STRING(MAX) NOT NULL
) PRIMARY KEY (id);""",

        f"""CREATE TABLE Chunk (
    id STRING(128) NOT NULL,
    document_id STRING(128) NOT NULL,
    chunk_index INT64 NOT NULL,
    content STRING(MAX) NOT NULL,
    token_count INT64 NOT NULL,
    embedding ARRAY<FLOAT64>
) PRIMARY KEY (id),
  INTERLEAVE IN PARENT Document ON DELETE CASCADE;""",

        """CREATE TABLE Process (
    id STRING(128) NOT NULL,
    name STRING(256) NOT NULL,
    category STRING(64) NOT NULL,
    description STRING(MAX) NOT NULL,
    owner_department STRING(128) NOT NULL,
    chunk_id STRING(128) NOT NULL
) PRIMARY KEY (id);""",

        """CREATE TABLE Policy (
    id STRING(128) NOT NULL,
    name STRING(256) NOT NULL,
    regulatory_framework STRING(128) NOT NULL,
    description STRING(MAX) NOT NULL,
    version STRING(32) NOT NULL,
    effective_date STRING(32) NOT NULL,
    chunk_id STRING(128) NOT NULL
) PRIMARY KEY (id);""",

        """CREATE TABLE Risk (
    id STRING(128) NOT NULL,
    name STRING(256) NOT NULL,
    category STRING(64) NOT NULL,
    severity STRING(32) NOT NULL,
    description STRING(MAX) NOT NULL,
    impact_score FLOAT64 NOT NULL,
    chunk_id STRING(128) NOT NULL
) PRIMARY KEY (id);""",

        """CREATE TABLE Control (
    id STRING(128) NOT NULL,
    name STRING(256) NOT NULL,
    control_type STRING(64) NOT NULL,
    description STRING(MAX) NOT NULL,
    frequency STRING(64) NOT NULL,
    effectiveness STRING(32) NOT NULL,
    chunk_id STRING(128) NOT NULL
) PRIMARY KEY (id);""",

        """CREATE TABLE Market (
    id STRING(128) NOT NULL,
    name STRING(256) NOT NULL,
    region STRING(64) NOT NULL,
    currency STRING(16) NOT NULL,
    jurisdiction STRING(128) NOT NULL,
    chunk_id STRING(128) NOT NULL
) PRIMARY KEY (id);""",

        """CREATE TABLE System (
    id STRING(128) NOT NULL,
    name STRING(256) NOT NULL,
    tier STRING(64) NOT NULL,
    cloud_provider STRING(64) NOT NULL,
    description STRING(MAX) NOT NULL,
    chunk_id STRING(128) NOT NULL
) PRIMARY KEY (id);""",

        "",
        "-- --------------------------------------------------------------------------",
        "-- 2. EDGE TABLES",
        "-- --------------------------------------------------------------------------",
        """CREATE TABLE DocumentHasChunk (
    document_id STRING(128) NOT NULL,
    chunk_id STRING(128) NOT NULL,
    CONSTRAINT FK_DocHasChunk_Doc FOREIGN KEY (document_id) REFERENCES Document (id),
    CONSTRAINT FK_DocHasChunk_Chunk FOREIGN KEY (chunk_id) REFERENCES Chunk (id)
) PRIMARY KEY (document_id, chunk_id);""",

        """CREATE TABLE ProcessHasRisk (
    process_id STRING(128) NOT NULL,
    risk_id STRING(128) NOT NULL,
    inherent_risk_level STRING(32) NOT NULL,
    chunk_id STRING(128) NOT NULL,
    CONSTRAINT FK_ProcHasRisk_Proc FOREIGN KEY (process_id) REFERENCES Process (id),
    CONSTRAINT FK_ProcHasRisk_Risk FOREIGN KEY (risk_id) REFERENCES Risk (id)
) PRIMARY KEY (process_id, risk_id);""",

        """CREATE TABLE ControlMitigatesRisk (
    control_id STRING(128) NOT NULL,
    risk_id STRING(128) NOT NULL,
    mitigation_percentage FLOAT64 NOT NULL,
    chunk_id STRING(128) NOT NULL,
    CONSTRAINT FK_CtrlMitRisk_Ctrl FOREIGN KEY (control_id) REFERENCES Control (id),
    CONSTRAINT FK_CtrlMitRisk_Risk FOREIGN KEY (risk_id) REFERENCES Risk (id)
) PRIMARY KEY (control_id, risk_id);""",

        """CREATE TABLE PolicyGovernsProcess (
    policy_id STRING(128) NOT NULL,
    process_id STRING(128) NOT NULL,
    compliance_status STRING(64) NOT NULL,
    chunk_id STRING(128) NOT NULL,
    CONSTRAINT FK_PolGovProc_Pol FOREIGN KEY (policy_id) REFERENCES Policy (id),
    CONSTRAINT FK_PolGovProc_Proc FOREIGN KEY (process_id) REFERENCES Process (id)
) PRIMARY KEY (policy_id, process_id);""",

        """CREATE TABLE ProcessOperatesInMarket (
    process_id STRING(128) NOT NULL,
    market_id STRING(128) NOT NULL,
    volume_tier STRING(64) NOT NULL,
    chunk_id STRING(128) NOT NULL,
    CONSTRAINT FK_ProcOpMkt_Proc FOREIGN KEY (process_id) REFERENCES Process (id),
    CONSTRAINT FK_ProcOpMkt_Mkt FOREIGN KEY (market_id) REFERENCES Market (id)
) PRIMARY KEY (process_id, market_id);""",

        """CREATE TABLE SystemSupportsProcess (
    system_id STRING(128) NOT NULL,
    process_id STRING(128) NOT NULL,
    criticality STRING(64) NOT NULL,
    chunk_id STRING(128) NOT NULL,
    CONSTRAINT FK_SysSuppProc_Sys FOREIGN KEY (system_id) REFERENCES System (id),
    CONSTRAINT FK_SysSuppProc_Proc FOREIGN KEY (process_id) REFERENCES Process (id)
) PRIMARY KEY (system_id, process_id);""",

        """CREATE TABLE ControlAppliesToSystem (
    control_id STRING(128) NOT NULL,
    system_id STRING(128) NOT NULL,
    automation_level STRING(64) NOT NULL,
    chunk_id STRING(128) NOT NULL,
    CONSTRAINT FK_CtrlAppSys_Ctrl FOREIGN KEY (control_id) REFERENCES Control (id),
    CONSTRAINT FK_CtrlAppSys_Sys FOREIGN KEY (system_id) REFERENCES System (id)
) PRIMARY KEY (control_id, system_id);""",

        """CREATE TABLE ChunkMentionsProcess (
    chunk_id STRING(128) NOT NULL,
    process_id STRING(128) NOT NULL,
    CONSTRAINT FK_ChunkProc_Chunk FOREIGN KEY (chunk_id) REFERENCES Chunk (id),
    CONSTRAINT FK_ChunkProc_Proc FOREIGN KEY (process_id) REFERENCES Process (id)
) PRIMARY KEY (chunk_id, process_id);""",

        """CREATE TABLE ChunkMentionsRisk (
    chunk_id STRING(128) NOT NULL,
    risk_id STRING(128) NOT NULL,
    CONSTRAINT FK_ChunkRisk_Chunk FOREIGN KEY (chunk_id) REFERENCES Chunk (id),
    CONSTRAINT FK_ChunkRisk_Risk FOREIGN KEY (risk_id) REFERENCES Risk (id)
) PRIMARY KEY (chunk_id, risk_id);""",

        """CREATE TABLE ChunkMentionsControl (
    chunk_id STRING(128) NOT NULL,
    control_id STRING(128) NOT NULL,
    CONSTRAINT FK_ChunkCtrl_Chunk FOREIGN KEY (chunk_id) REFERENCES Chunk (id),
    CONSTRAINT FK_ChunkCtrl_Ctrl FOREIGN KEY (control_id) REFERENCES Control (id)
) PRIMARY KEY (chunk_id, control_id);""",

        """CREATE TABLE ChunkMentionsPolicy (
    chunk_id STRING(128) NOT NULL,
    policy_id STRING(128) NOT NULL,
    CONSTRAINT FK_ChunkPol_Chunk FOREIGN KEY (chunk_id) REFERENCES Chunk (id),
    CONSTRAINT FK_ChunkPol_Pol FOREIGN KEY (policy_id) REFERENCES Policy (id)
) PRIMARY KEY (chunk_id, policy_id);""",

        """CREATE TABLE ChunkMentionsMarket (
    chunk_id STRING(128) NOT NULL,
    market_id STRING(128) NOT NULL,
    CONSTRAINT FK_ChunkMkt_Chunk FOREIGN KEY (chunk_id) REFERENCES Chunk (id),
    CONSTRAINT FK_ChunkMkt_Mkt FOREIGN KEY (market_id) REFERENCES Market (id)
) PRIMARY KEY (chunk_id, market_id);""",

        """CREATE TABLE ChunkMentionsSystem (
    chunk_id STRING(128) NOT NULL,
    system_id STRING(128) NOT NULL,
    CONSTRAINT FK_ChunkSys_Chunk FOREIGN KEY (chunk_id) REFERENCES Chunk (id),
    CONSTRAINT FK_ChunkSys_Sys FOREIGN KEY (system_id) REFERENCES System (id)
) PRIMARY KEY (chunk_id, system_id);""",

        "",
        "-- --------------------------------------------------------------------------",
        "-- 3. VECTOR INDEX & FULL TEXT SEARCH INDEX",
        "-- --------------------------------------------------------------------------",
        f"""CREATE VECTOR INDEX ChunkVectorIndex ON Chunk(embedding(vector_length=>{embedding_dim}, distance_type=>'COSINE'))
OPTIONS (index_type = 'TREE_AH');""",

        """CREATE SEARCH INDEX ChunkSearchIndex ON Chunk(content);""",

        "",
        "-- --------------------------------------------------------------------------",
        f"-- 4. SPANNER PROPERTY GRAPH DEFINITION ({graph_name})",
        "-- --------------------------------------------------------------------------",
        f"""CREATE PROPERTY GRAPH {graph_name}
  NODE TABLES (
    Document,
    Chunk,
    Process,
    Policy,
    Risk,
    Control,
    Market,
    System
  )
  EDGE TABLES (
    DocumentHasChunk
      SOURCE KEY (document_id) REFERENCES Document (id)
      DESTINATION KEY (chunk_id) REFERENCES Chunk (id)
      LABEL HAS_CHUNK,
    ProcessHasRisk
      SOURCE KEY (process_id) REFERENCES Process (id)
      DESTINATION KEY (risk_id) REFERENCES Risk (id)
      LABEL HAS_RISK
      PROPERTIES (inherent_risk_level, chunk_id),
    ControlMitigatesRisk
      SOURCE KEY (control_id) REFERENCES Control (id)
      DESTINATION KEY (risk_id) REFERENCES Risk (id)
      LABEL MITIGATES_RISK
      PROPERTIES (mitigation_percentage, chunk_id),
    PolicyGovernsProcess
      SOURCE KEY (policy_id) REFERENCES Policy (id)
      DESTINATION KEY (process_id) REFERENCES Process (id)
      LABEL GOVERNS_PROCESS
      PROPERTIES (compliance_status, chunk_id),
    ProcessOperatesInMarket
      SOURCE KEY (process_id) REFERENCES Process (id)
      DESTINATION KEY (market_id) REFERENCES Market (id)
      LABEL OPERATES_IN_MARKET
      PROPERTIES (volume_tier, chunk_id),
    SystemSupportsProcess
      SOURCE KEY (system_id) REFERENCES System (id)
      DESTINATION KEY (process_id) REFERENCES Process (id)
      LABEL SUPPORTS_PROCESS
      PROPERTIES (criticality, chunk_id),
    ControlAppliesToSystem
      SOURCE KEY (control_id) REFERENCES Control (id)
      DESTINATION KEY (system_id) REFERENCES System (id)
      LABEL APPLIES_TO_SYSTEM
      PROPERTIES (automation_level, chunk_id),
    ChunkMentionsProcess
      SOURCE KEY (chunk_id) REFERENCES Chunk (id)
      DESTINATION KEY (process_id) REFERENCES Process (id)
      LABEL MENTIONS_PROCESS,
    ChunkMentionsRisk
      SOURCE KEY (chunk_id) REFERENCES Chunk (id)
      DESTINATION KEY (risk_id) REFERENCES Risk (id)
      LABEL MENTIONS_RISK,
    ChunkMentionsControl
      SOURCE KEY (chunk_id) REFERENCES Chunk (id)
      DESTINATION KEY (control_id) REFERENCES Control (id)
      LABEL MENTIONS_CONTROL,
    ChunkMentionsPolicy
      SOURCE KEY (chunk_id) REFERENCES Chunk (id)
      DESTINATION KEY (policy_id) REFERENCES Policy (id)
      LABEL MENTIONS_POLICY,
    ChunkMentionsMarket
      SOURCE KEY (chunk_id) REFERENCES Chunk (id)
      DESTINATION KEY (market_id) REFERENCES Market (id)
      LABEL MENTIONS_MARKET,
    ChunkMentionsSystem
      SOURCE KEY (chunk_id) REFERENCES Chunk (id)
      DESTINATION KEY (system_id) REFERENCES System (id)
      LABEL MENTIONS_SYSTEM
  );"""
    ]
    return "\n\n".join(ddl_statements)


def export_ddl_file(output_path: str = "spanner_schema.sql") -> None:
    ddl = generate_spanner_ddl()
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(ddl)


if __name__ == "__main__":
    print(generate_spanner_ddl())
