"""Unified Single-Query Hybrid Search Templates for Google Cloud Spanner / Spanner Omni.

This module provides the SQL + GQL query definitions that combine:
- Vector Search (`COSINE_DISTANCE`, `APPROX_COSINE_DISTANCE`)
- Full-Text Search (`SEARCH()`)
- Property Graph Traversal (`GRAPH_TABLE(EnterpriseGRCGraph MATCH ...)` / `GRAPH MATCH`)
in single atomic queries.
"""

from typing import Dict, Any


# ==============================================================================
# 1. VECTOR-TO-GRAPH: Semantic Search -> Graph Expansion (Single Query)
# ==============================================================================
QUERY_VECTOR_TO_GRAPH_SQL = """
-- =============================================================================
-- PATTERN 1: VECTOR-TO-GRAPH (Single Query)
-- Description: Retrieve chunks semantically closest to the user's prompt via
--              COSINE_DISTANCE, then in the same query traverse the Spanner
--              Property Graph to find connected Processes, Policies, Risks,
--              Controls, and affected Markets.
-- =============================================================================
WITH TopChunks AS (
  SELECT
    id AS chunk_id,
    document_id,
    content AS chunk_snippet,
    COSINE_DISTANCE(embedding, @query_vector) AS vector_distance
  FROM Chunk
  WHERE COSINE_DISTANCE(embedding, @query_vector) < @similarity_threshold
  ORDER BY vector_distance ASC
  LIMIT @top_k
)
SELECT
  c.chunk_id,
  c.chunk_snippet,
  ROUND(c.vector_distance, 4) AS distance,
  g.process_name,
  g.process_category,
  g.governing_policy,
  g.regulatory_framework,
  g.risk_name,
  g.risk_severity,
  g.mitigating_control,
  g.control_effectiveness,
  g.target_market,
  g.supporting_system
FROM TopChunks c
CROSS JOIN GRAPH_TABLE(
  EnterpriseGRCGraph
  MATCH (ch:Chunk WHERE ch.id = c.chunk_id)-[:MENTIONS_PROCESS]->(p:Process)
        -[:HAS_RISK]->(r:Risk)
        <-[:MITIGATES_RISK]-(ctrl:Control)
        , (p)<-[:GOVERNS_PROCESS]-(pol:Policy)
        , (p)-[:OPERATES_IN_MARKET]->(m:Market)
        , (s:System)-[:SUPPORTS_PROCESS]->(p)
  COLUMNS (
    p.name AS process_name,
    p.category AS process_category,
    pol.name AS governing_policy,
    pol.regulatory_framework AS regulatory_framework,
    r.name AS risk_name,
    r.severity AS risk_severity,
    ctrl.name AS mitigating_control,
    ctrl.effectiveness AS control_effectiveness,
    m.name AS target_market,
    s.name AS supporting_system
  )
) AS g
ORDER BY distance ASC, g.risk_severity DESC;
"""


# ==============================================================================
# 2. GRAPH-TO-VECTOR: Graph Traversal -> Semantic Ranking (Single Query)
# ==============================================================================
QUERY_GRAPH_TO_VECTOR_SQL = """
-- =============================================================================
-- PATTERN 2: GRAPH-TO-VECTOR (Single Query)
-- Description: Start with a specific regulatory Policy or Market entity, traverse
--              the graph to locate all governed Processes, their critical Risks,
--              and IT Systems, then retrieve all grounded text chunks and rank
--              them by vector similarity against a specific incident inquiry.
-- =============================================================================
WITH PolicyGraphPaths AS (
  SELECT * FROM GRAPH_TABLE(
    EnterpriseGRCGraph
    MATCH (pol:Policy WHERE pol.regulatory_framework = @regulatory_framework)
          -[:GOVERNS_PROCESS]->(p:Process)
          -[:HAS_RISK]->(r:Risk WHERE r.severity IN ('HIGH', 'CRITICAL'))
          <-[:MITIGATES_RISK]-(ctrl:Control)
          , (s:System)-[:SUPPORTS_PROCESS]->(p)
          , (ch:Chunk)-[:MENTIONS_RISK]->(r)
    COLUMNS (
      pol.name AS policy_name,
      pol.regulatory_framework AS framework,
      p.name AS process_name,
      r.name AS risk_name,
      r.severity AS risk_severity,
      ctrl.name AS control_name,
      ctrl.control_type AS control_type,
      s.name AS system_name,
      s.cloud_provider AS cloud_provider,
      ch.id AS chunk_id,
      ch.content AS chunk_text,
      ch.embedding AS chunk_embedding
    )
  )
)
SELECT
  policy_name,
  framework,
  process_name,
  risk_name,
  risk_severity,
  control_name,
  system_name,
  chunk_id,
  chunk_text,
  ROUND(COSINE_DISTANCE(chunk_embedding, @incident_vector), 4) AS incident_semantic_distance
FROM PolicyGraphPaths
ORDER BY incident_semantic_distance ASC
LIMIT @top_k;
"""


# ==============================================================================
# 3. FULL-TEXT SEARCH TO GRAPH: Keyword Filter -> Graph Blast Radius (Single Query)
# ==============================================================================
QUERY_FTS_TO_GRAPH_SQL = """
-- =============================================================================
-- PATTERN 3: FULL-TEXT SEARCH (FTS) TO GRAPH (Single Query)
-- Description: Use Spanner's SEARCH() full-text search index on Chunk content
--              to find keyword hits (e.g. 'sanctions breach' or 'failover timeout'),
--              and in the same query traverse the graph to compute the compliance
--              blast radius (affected processes, markets, and failing controls).
-- =============================================================================
WITH SearchHits AS (
  SELECT
    id AS chunk_id,
    content AS chunk_snippet,
    SCORE(ChunkSearchIndex, @search_query) AS fts_score
  FROM Chunk
  WHERE SEARCH(content, @search_query)
  ORDER BY fts_score DESC
  LIMIT @top_k
)
SELECT
  s.chunk_id,
  ROUND(s.fts_score, 2) AS search_score,
  g.process_name,
  g.risk_name,
  g.risk_severity,
  g.control_name,
  g.market_name,
  g.jurisdiction,
  g.system_name
FROM SearchHits s
CROSS JOIN GRAPH_TABLE(
  EnterpriseGRCGraph
  MATCH (ch:Chunk WHERE ch.id = s.chunk_id)-[:MENTIONS_PROCESS]->(p:Process)
        -[:HAS_RISK]->(r:Risk)
        <-[:MITIGATES_RISK]-(ctrl:Control)
        , (p)-[:OPERATES_IN_MARKET]->(m:Market)
        , (sys:System)-[:SUPPORTS_PROCESS]->(p)
  COLUMNS (
    p.name AS process_name,
    r.name AS risk_name,
    r.severity AS risk_severity,
    ctrl.name AS control_name,
    m.name AS market_name,
    m.jurisdiction AS jurisdiction,
    sys.name AS system_name
  )
) AS g
ORDER BY s.fts_score DESC;
"""


# ==============================================================================
# 4. 3-WAY HYBRID: Vector + Full-Text + Graph Deep Context (Single Query)
# ==============================================================================
QUERY_3WAY_HYBRID_SQL = """
-- =============================================================================
-- PATTERN 4: 3-WAY HYBRID (Vector + Full-Text Search + Multi-Hop Graph)
-- Description: Blends normalized reciprocal rank fusion / cosine distance with
--              FTS keyword score, and simultaneously pulls full 2-hop graph
--              context for LLM RAG synthesis.
-- =============================================================================
WITH HybridScoredChunks AS (
  SELECT
    id AS chunk_id,
    content AS chunk_snippet,
    COSINE_DISTANCE(embedding, @query_vector) AS vec_distance,
    IF(SEARCH(content, @search_query), 1.0, 0.0) AS keyword_match
  FROM Chunk
  WHERE COSINE_DISTANCE(embedding, @query_vector) < @similarity_threshold
     OR SEARCH(content, @search_query)
  ORDER BY (0.7 * (1.0 - COSINE_DISTANCE(embedding, @query_vector)) + 0.3 * IF(SEARCH(content, @search_query), 1.0, 0.0)) DESC
  LIMIT @top_k
)
SELECT
  h.chunk_id,
  h.chunk_snippet,
  ROUND(h.vec_distance, 4) AS vec_distance,
  h.keyword_match,
  g.policy_name,
  g.process_name,
  g.risk_name,
  g.control_name,
  g.market_name,
  g.system_name
FROM HybridScoredChunks h
LEFT JOIN GRAPH_TABLE(
  EnterpriseGRCGraph
  MATCH (ch:Chunk WHERE ch.id = h.chunk_id)
        -[:MENTIONS_PROCESS|MENTIONS_RISK|MENTIONS_CONTROL]->(entity)
        -[*1..2]-(connected)
  COLUMNS (
    entity.name AS entity_name,
    connected.name AS connected_name
  )
) AS g ON TRUE;
"""


SAMPLE_QUERIES = {
    "vector_to_graph": {
        "title": "Vector-to-Graph: Semantic Query -> Risk & Control Topology",
        "description": "Searches for semantically relevant text chunks using embedding distance and immediately walks the connected processes, risks, mitigating controls, and regulatory frameworks.",
        "sql": QUERY_VECTOR_TO_GRAPH_SQL,
    },
    "graph_to_vector": {
        "title": "Graph-to-Vector: Policy/Market Traversal -> Ranked Evidence Chunks",
        "description": "Traverses from a specific regulation (e.g. DORA) down to critical risks and systems, ranking all grounded evidence chunks by cosine distance against an incident prompt.",
        "sql": QUERY_GRAPH_TO_VECTOR_SQL,
    },
    "fts_to_graph": {
        "title": "Full-Text Search to Graph: Keyword Filtering -> Impact Radius",
        "description": "Executes full-text SEARCH() on chunk text and traces the blast radius across processes, markets, and IT infrastructure.",
        "sql": QUERY_FTS_TO_GRAPH_SQL,
    },
    "three_way_hybrid": {
        "title": "3-Way Hybrid: Vector + Keyword + Multi-Hop Graph Traversal",
        "description": "Combines vector similarity and full-text keyword matching to seed multi-hop graph expansion for rich RAG context generation.",
        "sql": QUERY_3WAY_HYBRID_SQL,
    },
}
