"""Schema definitions for Nodes, Edges, and Graph Containers in Spanner Property Graph."""
from __future__ import annotations
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field


# ==========================================
# 1. NODE SCHEMAS
# ==========================================

class Document(BaseModel):
    """Source document containing processes, policies, risks, controls, etc."""
    id: str = Field(..., description="Unique document ID (e.g. 'doc-cross-border-001')")
    title: str = Field(..., description="Document title")
    source_type: str = Field(default="POLICY_STANDARD", description="Type: POLICY_STANDARD, SOP, REGULATION, AUDIT_REPORT")
    uploaded_at: str = Field(default="2026-08-19T00:00:00Z", description="ISO 8601 upload timestamp")
    raw_text: str = Field(..., description="Full raw document content")


class Chunk(BaseModel):
    """Granular text chunk with vector embeddings for hybrid search."""
    id: str = Field(..., description="Unique chunk ID (e.g. 'chunk-doc1-001')")
    document_id: str = Field(..., description="Parent document foreign key")
    chunk_index: int = Field(..., description="0-indexed order of chunk in document")
    content: str = Field(..., description="Chunk text content")
    token_count: int = Field(default=0, description="Approximate token count")
    embedding: List[float] = Field(default_factory=list, description="768-dimensional float embedding vector")


class Process(BaseModel):
    """Business, operational, or technical process."""
    id: str = Field(..., description="Unique process ID (e.g. 'proc-settlement-realtime')")
    name: str = Field(..., description="Process name")
    category: str = Field(..., description="Category: PAYMENTS, TRADING, CLOUD_OPS, COMPLIANCE, AI_SERVICE")
    description: str = Field(..., description="Detailed description of process")
    owner_department: str = Field(..., description="Department responsible (e.g. 'Treasury Operations')")
    chunk_id: str = Field(..., description="Originating chunk ID for grounding")


class Policy(BaseModel):
    """Regulatory framework, corporate standard, or governance rule."""
    id: str = Field(..., description="Unique policy ID (e.g. 'pol-dora-resilience')")
    name: str = Field(..., description="Policy name")
    regulatory_framework: str = Field(..., description="Framework: DORA, SEC_RULE_15C3_5, EU_AI_ACT, AMLD6, SOC2")
    description: str = Field(..., description="Policy requirements and governance guidelines")
    version: str = Field(default="v2.1", description="Policy version")
    effective_date: str = Field(default="2026-01-01", description="Effective date")
    chunk_id: str = Field(..., description="Originating chunk ID for grounding")


class Risk(BaseModel):
    """Identified operational, financial, cyber, or compliance risk."""
    id: str = Field(..., description="Unique risk ID (e.g. 'risk-aml-sanction-breach')")
    name: str = Field(..., description="Risk name")
    category: str = Field(..., description="Category: FINANCIAL_CRIME, SYSTEM_OUTAGE, MARKET_MANIPULATION, AI_HALLUCINATION, CYBERSECURITY")
    severity: str = Field(default="HIGH", description="Severity: LOW, MEDIUM, HIGH, CRITICAL")
    description: str = Field(..., description="Risk narrative and threat scenario")
    impact_score: float = Field(default=8.5, description="Impact score on 1-10 scale")
    chunk_id: str = Field(..., description="Originating chunk ID for grounding")


class Control(BaseModel):
    """Preventative, detective, or corrective control mitigating risks."""
    id: str = Field(..., description="Unique control ID (e.g. 'ctrl-realtime-sanction-screener')")
    name: str = Field(..., description="Control name")
    control_type: str = Field(default="PREVENTATIVE", description="Type: PREVENTATIVE, DETECTIVE, CORRECTIVE")
    description: str = Field(..., description="Control mechanism and enforcement procedure")
    frequency: str = Field(default="CONTINUOUS_REAL_TIME", description="Frequency: CONTINUOUS_REAL_TIME, DAILY, HOURLY, TRANSACTIONAL")
    effectiveness: str = Field(default="HIGH", description="Effectiveness: HIGH, MEDIUM, LOW")
    chunk_id: str = Field(..., description="Originating chunk ID for grounding")


class Market(BaseModel):
    """Jurisdiction, geographic zone, or financial market where processes operate."""
    id: str = Field(..., description="Unique market ID (e.g. 'mkt-eu-sepa')")
    name: str = Field(..., description="Market name (e.g. 'EU / SEPA Zone')")
    region: str = Field(..., description="Region: EMEA, NORTH_AMERICA, APAC, GLOBAL")
    currency: str = Field(default="EUR", description="Primary currency: EUR, USD, GBP, MULTI")
    jurisdiction: str = Field(..., description="Legal jurisdiction: EUROPEAN_UNION, UNITED_STATES, UK, GLOBAL")
    chunk_id: str = Field(..., description="Originating chunk ID for grounding")


class System(BaseModel):
    """Software application, cloud service, or IT infrastructure supporting processes."""
    id: str = Field(..., description="Unique system ID (e.g. 'sys-swift-gateway-prod')")
    name: str = Field(..., description="System name")
    tier: str = Field(default="TIER_1_MISSION_CRITICAL", description="Tier: TIER_1_MISSION_CRITICAL, TIER_2, TIER_3")
    cloud_provider: str = Field(default="GCP", description="Cloud/Host: GCP, AWS, ON_PREM, HYBRID")
    description: str = Field(..., description="System role and architecture")
    chunk_id: str = Field(..., description="Originating chunk ID for grounding")


# ==========================================
# 2. EDGE SCHEMAS
# ==========================================

class DocumentHasChunk(BaseModel):
    """Document -> Chunk relationship."""
    document_id: str
    chunk_id: str


class ProcessHasRisk(BaseModel):
    """Process -> Risk relationship with risk exposure level."""
    process_id: str
    risk_id: str
    inherent_risk_level: str = "HIGH"
    chunk_id: str


class ControlMitigatesRisk(BaseModel):
    """Control -> Risk relationship with mitigation efficacy."""
    control_id: str
    risk_id: str
    mitigation_percentage: float = 95.0
    chunk_id: str


class PolicyGovernsProcess(BaseModel):
    """Policy -> Process relationship."""
    policy_id: str
    process_id: str
    compliance_status: str = "MANDATORY_COMPLIANT"
    chunk_id: str


class ProcessOperatesInMarket(BaseModel):
    """Process -> Market relationship."""
    process_id: str
    market_id: str
    volume_tier: str = "TIER_1_HIGH_VOLUME"
    chunk_id: str


class SystemSupportsProcess(BaseModel):
    """System -> Process relationship."""
    system_id: str
    process_id: str
    criticality: str = "CRITICAL_PATH"
    chunk_id: str


class ControlAppliesToSystem(BaseModel):
    """Control -> System relationship."""
    control_id: str
    system_id: str
    automation_level: str = "AUTOMATED_API"
    chunk_id: str


# Chunk Provenance Mention Edges
class ChunkMentionsProcess(BaseModel):
    chunk_id: str
    process_id: str


class ChunkMentionsRisk(BaseModel):
    chunk_id: str
    risk_id: str


class ChunkMentionsControl(BaseModel):
    chunk_id: str
    control_id: str


class ChunkMentionsPolicy(BaseModel):
    chunk_id: str
    policy_id: str


class ChunkMentionsMarket(BaseModel):
    chunk_id: str
    market_id: str


class ChunkMentionsSystem(BaseModel):
    chunk_id: str
    system_id: str


# ==========================================
# 3. EXTRACTION & GRAPH CONTAINER
# ==========================================

class ExtractionResult(BaseModel):
    """LLM Structured Extraction Output for a single document chunk."""
    processes: List[Process] = Field(default_factory=list)
    policies: List[Policy] = Field(default_factory=list)
    risks: List[Risk] = Field(default_factory=list)
    controls: List[Control] = Field(default_factory=list)
    markets: List[Market] = Field(default_factory=list)
    systems: List[System] = Field(default_factory=list)

    process_has_risk: List[ProcessHasRisk] = Field(default_factory=list)
    control_mitigates_risk: List[ControlMitigatesRisk] = Field(default_factory=list)
    policy_governs_process: List[PolicyGovernsProcess] = Field(default_factory=list)
    process_operates_in_market: List[ProcessOperatesInMarket] = Field(default_factory=list)
    system_supports_process: List[SystemSupportsProcess] = Field(default_factory=list)
    control_applies_to_system: List[ControlAppliesToSystem] = Field(default_factory=list)


class KnowledgeGraphData(BaseModel):
    """Complete in-memory / relational container for the entire Spanner Property Graph."""
    documents: List[Document] = Field(default_factory=list)
    chunks: List[Chunk] = Field(default_factory=list)
    processes: List[Process] = Field(default_factory=list)
    policies: List[Policy] = Field(default_factory=list)
    risks: List[Risk] = Field(default_factory=list)
    controls: List[Control] = Field(default_factory=list)
    markets: List[Market] = Field(default_factory=list)
    systems: List[System] = Field(default_factory=list)

    # Edges
    document_has_chunk: List[DocumentHasChunk] = Field(default_factory=list)
    process_has_risk: List[ProcessHasRisk] = Field(default_factory=list)
    control_mitigates_risk: List[ControlMitigatesRisk] = Field(default_factory=list)
    policy_governs_process: List[PolicyGovernsProcess] = Field(default_factory=list)
    process_operates_in_market: List[ProcessOperatesInMarket] = Field(default_factory=list)
    system_supports_process: List[SystemSupportsProcess] = Field(default_factory=list)
    control_applies_to_system: List[ControlAppliesToSystem] = Field(default_factory=list)

    # Chunk Mentions
    chunk_mentions_process: List[ChunkMentionsProcess] = Field(default_factory=list)
    chunk_mentions_risk: List[ChunkMentionsRisk] = Field(default_factory=list)
    chunk_mentions_control: List[ChunkMentionsControl] = Field(default_factory=list)
    chunk_mentions_policy: List[ChunkMentionsPolicy] = Field(default_factory=list)
    chunk_mentions_market: List[ChunkMentionsMarket] = Field(default_factory=list)
    chunk_mentions_system: List[ChunkMentionsSystem] = Field(default_factory=list)

    def stats(self) -> Dict[str, int]:
        return {
            "documents": len(self.documents),
            "chunks": len(self.chunks),
            "processes": len(self.processes),
            "policies": len(self.policies),
            "risks": len(self.risks),
            "controls": len(self.controls),
            "markets": len(self.markets),
            "systems": len(self.systems),
            "total_nodes": (
                len(self.documents) + len(self.chunks) + len(self.processes) +
                len(self.policies) + len(self.risks) + len(self.controls) +
                len(self.markets) + len(self.systems)
            ),
            "total_edges": (
                len(self.document_has_chunk) + len(self.process_has_risk) +
                len(self.control_mitigates_risk) + len(self.policy_governs_process) +
                len(self.process_operates_in_market) + len(self.system_supports_process) +
                len(self.control_applies_to_system) + len(self.chunk_mentions_process) +
                len(self.chunk_mentions_risk) + len(self.chunk_mentions_control) +
                len(self.chunk_mentions_policy) + len(self.chunk_mentions_market) +
                len(self.chunk_mentions_system)
            )
        }
