#!/usr/bin/env python3
"""Cleanup Script: Tears down Spanner Property Graph tables, indexes, and generated data artifacts."""
import os
import sys
import argparse
from rich.console import Console
from rich.panel import Panel

from engine.spanner_client import SpannerOmniClient


def clean_all_data(include_db: bool = False):
    console = Console()
    console.print(Panel.fit(
        "[bold red]Spanner GRC Property Graph Teardown & Cleanup[/bold red]\n"
        "[dim]Drops Spanner Property Graph, Vector Indexes, Tables, and removes generated artifacts[/dim]",
        border_style="red"
    ))

    # 1. Spanner Omni / Cloud Spanner Cleanup
    console.print("[bold yellow]1. Checking Spanner Omni Connection for Table/Graph Teardown...[/bold yellow]")
    client = SpannerOmniClient()
    connected = client.connect()

    if connected and client.database:
        console.print("[bold red]Executing Drop Schema Statements on Spanner...[/bold red]")
        drop_sql_path = os.path.join(os.path.dirname(__file__), "..", "drop_schema.sql")
        if os.path.exists(drop_sql_path):
            with open(drop_sql_path, "r", encoding="utf-8") as f:
                drop_statements = [s.strip() for s in f.read().split(";") if s.strip() and not s.strip().startswith("--")]
            try:
                op = client.database.update_ddl(drop_statements)
                op.result()
                console.print("[bold green]✓ Dropped Property Graph, Vector/Search Indexes, and all 16 Node & Edge tables in Spanner.[/bold green]")
            except Exception as e:
                console.print(f"[yellow]Warning during DDL teardown: {e}[/yellow]")
    else:
        console.print("[dim]Spanner Omni not running or in dry-run mode. Local schema state reset.[/dim]")

    # 2. Clean local generated artifacts
    console.print("[bold yellow]2. Removing Generated Data Artifacts & Caches...[/bold yellow]")
    current_dir = os.path.dirname(os.path.abspath(__file__))
    root_dir = os.path.abspath(os.path.join(current_dir, ".."))

    files_to_clean = [
        os.path.join(current_dir, "data.json"),
        os.path.join(current_dir, "insert_data.sql"),
        os.path.join(root_dir, "spanner_schema.sql"),
    ]

    for f_path in files_to_clean:
        if os.path.exists(f_path):
            os.remove(f_path)
            console.print(f"  • Removed [cyan]{os.path.basename(f_path)}[/cyan]")

    console.print(Panel(
        "[bold green]✓ Teardown & Cleanup Completed Successfully![/bold green]\n"
        "To rebuild everything cleanly at any time, run:\n"
        "  [white]PYTHONPATH=. python credit_refund_demo/load_all_data.py[/white]\n"
        "  [white]PYTHONPATH=. python credit_refund_demo/run_demo.py[/white]",
        border_style="green"
    ))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Clean and delete all Spanner tables, graph, and data")
    parser.add_argument("--include-db", action="store_true", help="Also drop Spanner database")
    args = parser.parse_args()
    clean_all_data(args.include_db)
