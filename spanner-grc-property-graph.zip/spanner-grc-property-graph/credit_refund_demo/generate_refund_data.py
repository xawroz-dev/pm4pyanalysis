"""Generates expanded insertable Spanner SQL data and JSON for Credit Refund Knowledge Graph."""
import os
import json
from typing import List, Dict, Any
from models.schema import (
    Document,
    Chunk,
    Process,
    Policy,
    Risk,
    Control,
    Market,
    System,
    DocumentHasChunk,
    ProcessHasRisk,
    ControlMitigatesRisk,
    PolicyGovernsProcess,
    ProcessOperatesInMarket,
    SystemSupportsProcess,
    ControlAppliesToSystem,
    ChunkMentionsProcess,
    ChunkMentionsRisk,
    ChunkMentionsControl,
    ChunkMentionsPolicy,
    ChunkMentionsMarket,
    ChunkMentionsSystem,
    KnowledgeGraphData,
)
from pipeline.chunker import DocumentChunker
from pipeline.embedder import VectorEmbedder


def build_credit_refund_kg() -> KnowledgeGraphData:
    """Builds comprehensive Credit Refund Knowledge Graph with rich test nodes, embeddings, and edges."""
    current_dir = os.path.dirname(os.path.abspath(__file__))
    doc_path = os.path.join(current_dir, "credit_refund_document.md")
    with open(doc_path, "r", encoding="utf-8") as f:
        raw_text = f.read()

    doc_id = "doc-credit-refund-001"
    doc = Document(
        id=doc_id,
        title="Credit Card Dispute, Chargeback & Customer Refund Operating Standard",
        source_type="SOP_POLICY",
        uploaded_at="2026-08-19T14:30:00Z",
        raw_text=raw_text
    )

    chunker = DocumentChunker(target_chunk_size_words=100, overlap_words=20)
    embedder = VectorEmbedder(dimension=768)

    chunks = chunker.chunk_document(doc)
    for c in chunks:
        c.embedding = embedder.embed_text(c.content)

    c0 = chunks[0].id if len(chunks) > 0 else "chunk_0"
    c1 = chunks[1].id if len(chunks) > 1 else c0
    c2 = chunks[2].id if len(chunks) > 2 else c1
    c3 = chunks[3].id if len(chunks) > 3 else c2
    c4 = chunks[4].id if len(chunks) > 4 else c3
    c5 = chunks[5].id if len(chunks) > 5 else c4

    # --- 1. PROCESSES ---
    processes = [
        Process(
            id="proc-credit-refund",
            name="Credit Card Dispute & Customer Refund Processing",
            category="REFUND_OPERATIONS",
            description="End-to-end orchestration of customer transaction reversals, billing dispute adjudication, and merchandise return refunds.",
            owner_department="Treasury & Merchant Services Division",
            chunk_id=c0
        ),
        Process(
            id="proc-instant-chargeback",
            name="Instant Provisional Account Crediting",
            category="DISPUTE_SETTLEMENT",
            description="Automated posting of temporary provisional credit into cardholder accounts during pending chargeback investigations.",
            owner_department="Consumer Banking Operations",
            chunk_id=c0
        ),
        Process(
            id="proc-merchant-settlement",
            name="Merchant Settlement & Escrow Reconciliation",
            category="SETTLEMENT",
            description="Daily reconciliation of merchant escrow accounts against customer refund clawbacks and chargeback reserves.",
            owner_department="Merchant Risk & Settlement",
            chunk_id=c0
        ),
        Process(
            id="proc-fraud-dispute-investigation",
            name="Fraud Dispute Forensic Investigation",
            category="FRAUD_INVESTIGATION",
            description="Forensic investigation cross-referencing cardholder device fingerprints, geolocation, and merchant behavioral telemetry.",
            owner_department="Financial Crime & Fraud Intelligence",
            chunk_id=c0
        ),
        Process(
            id="proc-merchant-payout-freeze",
            name="Merchant Payout Freeze & Risk Escalation",
            category="MERCHANT_RISK",
            description="Automated suspension of merchant settlement disbursements upon detection of high chargeback rates or fraudulent spikes.",
            owner_department="Merchant Underwriting & Risk",
            chunk_id=c0
        )
    ]

    # --- 2. POLICIES ---
    policies = [
        Policy(
            id="pol-reg-e-cfpb",
            name="CFPB Regulation E Electronic Fund Transfers Policy",
            regulatory_framework="CFPB_REGULATION_E",
            description="Mandates strict 10-day provisional credit timelines and written investigation disclosures for card disputes.",
            version="v3.1",
            effective_date="2026-01-01",
            chunk_id=c1
        ),
        Policy(
            id="pol-pci-dss-v4",
            name="PCI-DSS v4.0 Refund Tokenization Standard",
            regulatory_framework="PCI_DSS_V4",
            description="Mandates masking Primary Account Numbers (PANs) and using cryptographic tokens during refund messaging.",
            version="v4.0.1",
            effective_date="2025-03-31",
            chunk_id=c1
        ),
        Policy(
            id="pol-visa-core-rules",
            name="Visa Core Rules & Dispute Management Standard",
            regulatory_framework="VISA_CORE_RULES",
            description="Governs allocation of chargeback liability, pre-arbitration timeframes, and merchant evidence submission.",
            version="v2026.1",
            effective_date="2026-04-15",
            chunk_id=c1
        ),
        Policy(
            id="pol-mastercard-dispute-guide",
            name="Mastercard Chargeback Resolution Guide",
            regulatory_framework="MASTERCARD_DISPUTE_GUIDE",
            description="Enforces reason code adjudication, second presentment standards, and collaboration network rules.",
            version="v2025.4",
            effective_date="2025-11-01",
            chunk_id=c1
        )
    ]

    # --- 3. RISKS ---
    risks = [
        Risk(
            id="risk-duplicate-refund-fraud",
            name="Duplicate Refund Disbursement Fraud",
            category="FINANCIAL_FRAUD",
            severity="CRITICAL",
            description="Fraudulent actor concurrently issues merchant return and bank dispute to collect double payout on single authorization.",
            impact_score=9.6,
            chunk_id=c2
        ),
        Risk(
            id="risk-friendly-fraud-first-party",
            name="First-Party Friendly Fraud & Buyer Deception",
            category="CONSUMER_FRAUD",
            severity="HIGH",
            description="Legitimate cardholders deceitfully claim non-receipt of items after consuming digital goods or delivered merchandise.",
            impact_score=8.8,
            chunk_id=c2
        ),
        Risk(
            id="risk-account-takeover-disbursement",
            name="Unauthorized Account Takeover Credit Diversion",
            category="CYBER_FRAUD",
            severity="HIGH",
            description="Compromised cardholder credentials divert approved refunds to unauthorized third-party prepaid cards.",
            impact_score=8.9,
            chunk_id=c2
        ),
        Risk(
            id="risk-merchant-chargeback-insolvency",
            name="Merchant Negative Balance & Chargeback Insolvency",
            category="CREDIT_RISK",
            severity="HIGH",
            description="Merchant goes bankrupt before reserve deductions can recoup massive volume of customer refund chargebacks.",
            impact_score=8.4,
            chunk_id=c2
        ),
        Risk(
            id="risk-card-testing-charge-storm",
            name="Card Testing Charge Storm & Velocity Flooding",
            category="BOTNET_ATTACK",
            severity="HIGH",
            description="Automated botnets generate thousands of rapid micro-charges and refunds to test validity of stolen card numbers.",
            impact_score=8.6,
            chunk_id=c2
        )
    ]

    # --- 4. CONTROLS ---
    controls = [
        Control(
            id="ctrl-dual-auth-threshold",
            name="Automated Dual-Authorization Refund Threshold Control",
            control_type="PREVENTATIVE",
            description="Mandatory secondary cryptographic approval required for all single refund claims exceeding $1,000.",
            frequency="TRANSACTIONAL",
            effectiveness="HIGH",
            chunk_id=c3
        ),
        Control(
            id="ctrl-velocity-anomaly-screener",
            name="Real-Time Velocity Anomaly Screener",
            control_type="PREVENTATIVE",
            description="Automated inline rule engine blocking cards receiving >3 refund credits in a rolling 2-hour window.",
            frequency="CONTINUOUS_REAL_TIME",
            effectiveness="HIGH",
            chunk_id=c3
        ),
        Control(
            id="ctrl-biometric-3ds-stepup",
            name="Biometric 3D-Secure Step-Up Authentication",
            control_type="PREVENTATIVE",
            description="Prompts cardholders with FIDO2 biometrics prior to authorizing high-value refund diversions or payee updates.",
            frequency="TRANSACTIONAL",
            effectiveness="HIGH",
            chunk_id=c3
        ),
        Control(
            id="ctrl-ai-synthetic-id-detector",
            name="AI Synthetic Identity & Device Reputation Filter",
            control_type="PREVENTATIVE",
            description="Real-time machine learning model analyzing device integrity, browser fingerprint spoofing, and IP velocity.",
            frequency="CONTINUOUS_REAL_TIME",
            effectiveness="HIGH",
            chunk_id=c3
        ),
        Control(
            id="ctrl-merchant-escrow-withholding",
            name="Automated Merchant Escrow Withholding Throttler",
            control_type="PREVENTATIVE",
            description="Dynamically increases escrow reserve withholdings when monthly merchant chargeback ratios exceed 1.0%.",
            frequency="DAILY",
            effectiveness="HIGH",
            chunk_id=c3
        ),
        Control(
            id="ctrl-daily-gl-reconciliation",
            name="Automated Daily General Ledger Refund Reconciliation",
            control_type="DETECTIVE",
            description="End-of-day mathematical balancing between acquirer settlement receipts and core banking ledger debits.",
            frequency="DAILY",
            effectiveness="HIGH",
            chunk_id=c3
        )
    ]

    # --- 5. MARKETS ---
    markets = [
        Market(
            id="mkt-us-retail-credit",
            name="US Consumer Retail Credit Market",
            region="NORTH_AMERICA",
            currency="USD",
            jurisdiction="UNITED_STATES",
            chunk_id=c4
        ),
        Market(
            id="mkt-eu-ecommerce-refunds",
            name="EU Cross-Border eCommerce Market",
            region="EMEA",
            currency="EUR",
            jurisdiction="EUROPEAN_UNION",
            chunk_id=c4
        ),
        Market(
            id="mkt-apac-crossborder-refunds",
            name="APAC Cross-Border Digital Commerce Market",
            region="APAC",
            currency="SGD",
            jurisdiction="SINGAPORE_APAC",
            chunk_id=c4
        )
    ]

    # --- 6. SYSTEMS ---
    systems = [
        System(
            id="sys-refund-orchestration-svc",
            name="Refund Orchestration Microservice",
            tier="TIER_1_MISSION_CRITICAL",
            cloud_provider="GCP (GKE cluster us-east4 Northern Virginia)",
            description="Spring Boot microservice orchestrating dispute intake, token masking, and acquirer refund routing.",
            chunk_id=c5
        ),
        System(
            id="sys-core-ledger-ledgerx",
            name="Core LedgerX Settlement Engine",
            tier="TIER_1_MISSION_CRITICAL",
            cloud_provider="GCP (Cloud Spanner Multi-Region us-central1 & us-east1)",
            description="Distributed ledger ensuring double-entry debit and credit atomicity for refund transactions.",
            chunk_id=c5
        ),
        System(
            id="sys-fraud-shield-ai",
            name="FraudShield AI Anomaly Detector",
            tier="TIER_2",
            cloud_provider="AWS (EKS cluster us-east-1 N. Virginia)",
            description="Machine learning inference service calculating sub-20ms fraud propensity scores on refund requests.",
            chunk_id=c5
        ),
        System(
            id="sys-dispute-portal-web",
            name="Dispute Resolution Portal",
            tier="TIER_2",
            cloud_provider="GCP (Cloud Run us-central1)",
            description="Customer and merchant facing portal for submitting dispute evidence and tracking provisional credits.",
            chunk_id=c5
        ),
        System(
            id="sys-biocatch-telemetry-gateway",
            name="BioCatch Behavioral Telemetry Gateway",
            tier="TIER_2",
            cloud_provider="AWS (CloudFront & Lambda@Edge)",
            description="Edge biometric collector analyzing mouse dynamics, touchscreen velocity, and session anomalies.",
            chunk_id=c5
        )
    ]

    # --- 7. EDGES & TOPOLOGY ---
    kg = KnowledgeGraphData(
        documents=[doc],
        chunks=chunks,
        processes=processes,
        policies=policies,
        risks=risks,
        controls=controls,
        markets=markets,
        systems=systems
    )

    for c in chunks:
        kg.document_has_chunk.append(DocumentHasChunk(document_id=doc.id, chunk_id=c.id))

    # Process -> Risk
    kg.process_has_risk.extend([
        ProcessHasRisk(process_id="proc-credit-refund", risk_id="risk-duplicate-refund-fraud", inherent_risk_level="CRITICAL", chunk_id=c2),
        ProcessHasRisk(process_id="proc-credit-refund", risk_id="risk-friendly-fraud-first-party", inherent_risk_level="HIGH", chunk_id=c2),
        ProcessHasRisk(process_id="proc-credit-refund", risk_id="risk-account-takeover-disbursement", inherent_risk_level="HIGH", chunk_id=c2),
        ProcessHasRisk(process_id="proc-instant-chargeback", risk_id="risk-friendly-fraud-first-party", inherent_risk_level="HIGH", chunk_id=c2),
        ProcessHasRisk(process_id="proc-instant-chargeback", risk_id="risk-duplicate-refund-fraud", inherent_risk_level="CRITICAL", chunk_id=c2),
        ProcessHasRisk(process_id="proc-merchant-settlement", risk_id="risk-merchant-chargeback-insolvency", inherent_risk_level="HIGH", chunk_id=c2),
        ProcessHasRisk(process_id="proc-fraud-dispute-investigation", risk_id="risk-card-testing-charge-storm", inherent_risk_level="HIGH", chunk_id=c2),
        ProcessHasRisk(process_id="proc-merchant-payout-freeze", risk_id="risk-merchant-chargeback-insolvency", inherent_risk_level="HIGH", chunk_id=c2),
    ])

    # Control -> Risk
    kg.control_mitigates_risk.extend([
        ControlMitigatesRisk(control_id="ctrl-dual-auth-threshold", risk_id="risk-duplicate-refund-fraud", mitigation_percentage=98.0, chunk_id=c3),
        ControlMitigatesRisk(control_id="ctrl-velocity-anomaly-screener", risk_id="risk-duplicate-refund-fraud", mitigation_percentage=95.5, chunk_id=c3),
        ControlMitigatesRisk(control_id="ctrl-velocity-anomaly-screener", risk_id="risk-card-testing-charge-storm", mitigation_percentage=97.0, chunk_id=c3),
        ControlMitigatesRisk(control_id="ctrl-biometric-3ds-stepup", risk_id="risk-account-takeover-disbursement", mitigation_percentage=96.0, chunk_id=c3),
        ControlMitigatesRisk(control_id="ctrl-ai-synthetic-id-detector", risk_id="risk-friendly-fraud-first-party", mitigation_percentage=91.5, chunk_id=c3),
        ControlMitigatesRisk(control_id="ctrl-ai-synthetic-id-detector", risk_id="risk-account-takeover-disbursement", mitigation_percentage=94.0, chunk_id=c3),
        ControlMitigatesRisk(control_id="ctrl-merchant-escrow-withholding", risk_id="risk-merchant-chargeback-insolvency", mitigation_percentage=95.0, chunk_id=c3),
        ControlMitigatesRisk(control_id="ctrl-daily-gl-reconciliation", risk_id="risk-merchant-chargeback-insolvency", mitigation_percentage=94.0, chunk_id=c3),
    ])

    # Policy -> Process
    kg.policy_governs_process.extend([
        PolicyGovernsProcess(policy_id="pol-reg-e-cfpb", process_id="proc-credit-refund", compliance_status="MANDATORY_COMPLIANT", chunk_id=c1),
        PolicyGovernsProcess(policy_id="pol-reg-e-cfpb", process_id="proc-instant-chargeback", compliance_status="MANDATORY_COMPLIANT", chunk_id=c1),
        PolicyGovernsProcess(policy_id="pol-pci-dss-v4", process_id="proc-credit-refund", compliance_status="MANDATORY_COMPLIANT", chunk_id=c1),
        PolicyGovernsProcess(policy_id="pol-visa-core-rules", process_id="proc-credit-refund", compliance_status="MANDATORY_COMPLIANT", chunk_id=c1),
        PolicyGovernsProcess(policy_id="pol-visa-core-rules", process_id="proc-fraud-dispute-investigation", compliance_status="MANDATORY_COMPLIANT", chunk_id=c1),
        PolicyGovernsProcess(policy_id="pol-mastercard-dispute-guide", process_id="proc-credit-refund", compliance_status="MANDATORY_COMPLIANT", chunk_id=c1),
        PolicyGovernsProcess(policy_id="pol-mastercard-dispute-guide", process_id="proc-merchant-payout-freeze", compliance_status="MANDATORY_COMPLIANT", chunk_id=c1),
    ])

    # Process -> Market
    kg.process_operates_in_market.extend([
        ProcessOperatesInMarket(process_id="proc-credit-refund", market_id="mkt-us-retail-credit", volume_tier="TIER_1_HIGH_VOLUME", chunk_id=c4),
        ProcessOperatesInMarket(process_id="proc-credit-refund", market_id="mkt-eu-ecommerce-refunds", volume_tier="TIER_1_HIGH_VOLUME", chunk_id=c4),
        ProcessOperatesInMarket(process_id="proc-credit-refund", market_id="mkt-apac-crossborder-refunds", volume_tier="TIER_2_GROWTH", chunk_id=c4),
        ProcessOperatesInMarket(process_id="proc-instant-chargeback", market_id="mkt-us-retail-credit", volume_tier="TIER_1_HIGH_VOLUME", chunk_id=c4),
        ProcessOperatesInMarket(process_id="proc-merchant-settlement", market_id="mkt-us-retail-credit", volume_tier="TIER_1_HIGH_VOLUME", chunk_id=c4),
        ProcessOperatesInMarket(process_id="proc-merchant-settlement", market_id="mkt-eu-ecommerce-refunds", volume_tier="TIER_1_HIGH_VOLUME", chunk_id=c4),
    ])

    # System -> Process
    kg.system_supports_process.extend([
        SystemSupportsProcess(system_id="sys-refund-orchestration-svc", process_id="proc-credit-refund", criticality="CRITICAL_PATH", chunk_id=c5),
        SystemSupportsProcess(system_id="sys-refund-orchestration-svc", process_id="proc-instant-chargeback", criticality="CRITICAL_PATH", chunk_id=c5),
        SystemSupportsProcess(system_id="sys-core-ledger-ledgerx", process_id="proc-credit-refund", criticality="CRITICAL_PATH", chunk_id=c5),
        SystemSupportsProcess(system_id="sys-core-ledger-ledgerx", process_id="proc-instant-chargeback", criticality="CRITICAL_PATH", chunk_id=c5),
        SystemSupportsProcess(system_id="sys-core-ledger-ledgerx", process_id="proc-merchant-settlement", criticality="CRITICAL_PATH", chunk_id=c5),
        SystemSupportsProcess(system_id="sys-fraud-shield-ai", process_id="proc-credit-refund", criticality="REAL_TIME_GUARD", chunk_id=c5),
        SystemSupportsProcess(system_id="sys-fraud-shield-ai", process_id="proc-fraud-dispute-investigation", criticality="REAL_TIME_GUARD", chunk_id=c5),
        SystemSupportsProcess(system_id="sys-dispute-portal-web", process_id="proc-credit-refund", criticality="USER_FACING", chunk_id=c5),
        SystemSupportsProcess(system_id="sys-biocatch-telemetry-gateway", process_id="proc-fraud-dispute-investigation", criticality="TELEMETRY_FEED", chunk_id=c5),
    ])

    # Control -> System
    kg.control_applies_to_system.extend([
        ControlAppliesToSystem(control_id="ctrl-dual-auth-threshold", system_id="sys-refund-orchestration-svc", automation_level="AUTOMATED_INLINE", chunk_id=c3),
        ControlAppliesToSystem(control_id="ctrl-velocity-anomaly-screener", system_id="sys-fraud-shield-ai", automation_level="AUTOMATED_INLINE", chunk_id=c3),
        ControlAppliesToSystem(control_id="ctrl-biometric-3ds-stepup", system_id="sys-dispute-portal-web", automation_level="AUTOMATED_STEP_UP", chunk_id=c3),
        ControlAppliesToSystem(control_id="ctrl-ai-synthetic-id-detector", system_id="sys-biocatch-telemetry-gateway", automation_level="AUTOMATED_STREAM", chunk_id=c3),
        ControlAppliesToSystem(control_id="ctrl-merchant-escrow-withholding", system_id="sys-core-ledger-ledgerx", automation_level="SCHEDULED_RESERVE", chunk_id=c3),
        ControlAppliesToSystem(control_id="ctrl-daily-gl-reconciliation", system_id="sys-core-ledger-ledgerx", automation_level="BATCH_RECONCILIATION", chunk_id=c3),
    ])

    # Chunk mentions
    for p in processes:
        kg.chunk_mentions_process.append(ChunkMentionsProcess(chunk_id=p.chunk_id, process_id=p.id))
    for r in risks:
        kg.chunk_mentions_risk.append(ChunkMentionsRisk(chunk_id=r.chunk_id, risk_id=r.id))
    for c in controls:
        kg.chunk_mentions_control.append(ChunkMentionsControl(chunk_id=c.chunk_id, control_id=c.id))
    for pol in policies:
        kg.chunk_mentions_policy.append(ChunkMentionsPolicy(chunk_id=pol.chunk_id, policy_id=pol.id))
    for m in markets:
        kg.chunk_mentions_market.append(ChunkMentionsMarket(chunk_id=m.chunk_id, market_id=m.id))
    for s in systems:
        kg.chunk_mentions_system.append(ChunkMentionsSystem(chunk_id=s.chunk_id, system_id=s.id))

    return kg


def export_sql_inserts(kg: KnowledgeGraphData, output_file: str):
    """Exports SQL INSERT statements for Google Cloud Spanner / Spanner Omni."""
    lines = [
        "-- ==========================================================================",
        "-- Spanner SQL Insert Data: Credit Card Refund Knowledge Graph & Vectors",
        "-- ==========================================================================",
        ""
    ]

    for d in kg.documents:
        escaped_text = d.raw_text.replace("'", "''")
        lines.append(
            f"INSERT INTO Document (id, title, source_type, uploaded_at, raw_text) "
            f"VALUES ('{d.id}', '{d.title}', '{d.source_type}', TIMESTAMP '{d.uploaded_at}', '{escaped_text}');"
        )

    for c in kg.chunks:
        escaped_content = c.content.replace("'", "''")
        embed_str = "[" + ", ".join(f"{x:.6f}" for x in c.embedding) + "]"
        lines.append(
            f"INSERT INTO Chunk (id, document_id, chunk_index, content, token_count, embedding) "
            f"VALUES ('{c.id}', '{c.document_id}', {c.chunk_index}, '{escaped_content}', {c.token_count}, ARRAY<FLOAT64>{embed_str});"
        )

    for p in kg.processes:
        lines.append(
            f"INSERT INTO Process (id, name, category, description, owner_department, chunk_id) "
            f"VALUES ('{p.id}', '{p.name}', '{p.category}', '{p.description.replace('\'', '\'\'')}', '{p.owner_department}', '{p.chunk_id}');"
        )

    for pol in kg.policies:
        lines.append(
            f"INSERT INTO Policy (id, name, regulatory_framework, description, version, effective_date, chunk_id) "
            f"VALUES ('{pol.id}', '{pol.name}', '{pol.regulatory_framework}', '{pol.description.replace('\'', '\'\'')}', '{pol.version}', '{pol.effective_date}', '{pol.chunk_id}');"
        )

    for r in kg.risks:
        lines.append(
            f"INSERT INTO Risk (id, name, category, severity, description, impact_score, chunk_id) "
            f"VALUES ('{r.id}', '{r.name}', '{r.category}', '{r.severity}', '{r.description.replace('\'', '\'\'')}', {r.impact_score}, '{r.chunk_id}');"
        )

    for c in kg.controls:
        lines.append(
            f"INSERT INTO Control (id, name, control_type, description, frequency, effectiveness, chunk_id) "
            f"VALUES ('{c.id}', '{c.name}', '{c.control_type}', '{c.description.replace('\'', '\'\'')}', '{c.frequency}', '{c.effectiveness}', '{c.chunk_id}');"
        )

    for m in kg.markets:
        lines.append(
            f"INSERT INTO Market (id, name, region, currency, jurisdiction, chunk_id) "
            f"VALUES ('{m.id}', '{m.name}', '{m.region}', '{m.currency}', '{m.jurisdiction}', '{m.chunk_id}');"
        )

    for s in kg.systems:
        lines.append(
            f"INSERT INTO System (id, name, tier, cloud_provider, description, chunk_id) "
            f"VALUES ('{s.id}', '{s.name}', '{s.tier}', '{s.cloud_provider}', '{s.description.replace('\'', '\'\'')}', '{s.chunk_id}');"
        )

    lines.append("\n-- Edges")
    for e in kg.document_has_chunk:
        lines.append(f"INSERT INTO DocumentHasChunk (document_id, chunk_id) VALUES ('{e.document_id}', '{e.chunk_id}');")
    for e in kg.process_has_risk:
        lines.append(f"INSERT INTO ProcessHasRisk (process_id, risk_id, inherent_risk_level, chunk_id) VALUES ('{e.process_id}', '{e.risk_id}', '{e.inherent_risk_level}', '{e.chunk_id}');")
    for e in kg.control_mitigates_risk:
        lines.append(f"INSERT INTO ControlMitigatesRisk (control_id, risk_id, mitigation_percentage, chunk_id) VALUES ('{e.control_id}', '{e.risk_id}', {e.mitigation_percentage}, '{e.chunk_id}');")
    for e in kg.policy_governs_process:
        lines.append(f"INSERT INTO PolicyGovernsProcess (policy_id, process_id, compliance_status, chunk_id) VALUES ('{e.policy_id}', '{e.process_id}', '{e.compliance_status}', '{e.chunk_id}');")
    for e in kg.process_operates_in_market:
        lines.append(f"INSERT INTO ProcessOperatesInMarket (process_id, market_id, volume_tier, chunk_id) VALUES ('{e.process_id}', '{e.market_id}', '{e.volume_tier}', '{e.chunk_id}');")
    for e in kg.system_supports_process:
        lines.append(f"INSERT INTO SystemSupportsProcess (system_id, process_id, criticality, chunk_id) VALUES ('{e.system_id}', '{e.process_id}', '{e.criticality}', '{e.chunk_id}');")
    for e in kg.control_applies_to_system:
        lines.append(f"INSERT INTO ControlAppliesToSystem (control_id, system_id, automation_level, chunk_id) VALUES ('{e.control_id}', '{e.system_id}', '{e.automation_level}', '{e.chunk_id}');")

    for e in kg.chunk_mentions_process:
        lines.append(f"INSERT INTO ChunkMentionsProcess (chunk_id, process_id) VALUES ('{e.chunk_id}', '{e.process_id}');")
    for e in kg.chunk_mentions_risk:
        lines.append(f"INSERT INTO ChunkMentionsRisk (chunk_id, risk_id) VALUES ('{e.chunk_id}', '{e.risk_id}');")
    for e in kg.chunk_mentions_control:
        lines.append(f"INSERT INTO ChunkMentionsControl (chunk_id, control_id) VALUES ('{e.chunk_id}', '{e.control_id}');")
    for e in kg.chunk_mentions_policy:
        lines.append(f"INSERT INTO ChunkMentionsPolicy (chunk_id, policy_id) VALUES ('{e.chunk_id}', '{e.policy_id}');")
    for e in kg.chunk_mentions_market:
        lines.append(f"INSERT INTO ChunkMentionsMarket (chunk_id, market_id) VALUES ('{e.chunk_id}', '{e.market_id}');")
    for e in kg.chunk_mentions_system:
        lines.append(f"INSERT INTO ChunkMentionsSystem (chunk_id, system_id) VALUES ('{e.chunk_id}', '{e.system_id}');")

    with open(output_file, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))


if __name__ == "__main__":
    kg = build_credit_refund_kg()
    current_dir = os.path.dirname(os.path.abspath(__file__))
    sql_file = os.path.join(current_dir, "insert_data.sql")
    json_file = os.path.join(current_dir, "data.json")

    export_sql_inserts(kg, sql_file)
    with open(json_file, "w", encoding="utf-8") as f:
        f.write(kg.model_dump_json(indent=2))

    stats = kg.stats()
    print(f"Generated Expanded Credit Refund dataset: {stats['total_nodes']} nodes, {stats['total_edges']} edges.")
    print(f"Saved SQL to: {sql_file}")
    print(f"Saved JSON to: {json_file}")
