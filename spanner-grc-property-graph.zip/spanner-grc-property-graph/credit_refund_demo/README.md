# Credit Card Refund: Single-Query Graph & Vector Hybrid Search

This module provides a realistic, end-to-end dataset and demonstration of **Cloud Spanner / Spanner Omni Property Graph** combined with **Vector Search (`COSINE_DISTANCE`)** and **Full-Text Search (`SEARCH()`)** for the **Credit Card Dispute & Customer Refund Processing** domain.

---

## 📁 Files in this Folder

| File | Description |
|---|---|
| [`load_all_data.py`](./load_all_data.py) | **⭐ All-in-One Data Loader**: Ingests chunks, 768-dim embeddings, nodes, and edges in one command into Spanner Omni or local engine. |
| [`credit_refund_document.md`](./credit_refund_document.md) | Source SOP & Policy text covering 5 core processes, CFPB Reg E, Visa/Mastercard rules, 5 fraud threat scenarios, 6 controls, and 5 systems. |
| [`insert_data.sql`](./insert_data.sql) | Directly executable Spanner SQL `INSERT INTO ...` statements for all 37 Node and Edge tables with 768-dimensional `ARRAY<FLOAT64>` embeddings. |
| [`data.json`](./data.json) | Complete structured JSON export (37 nodes, 80 edges, vector embeddings). |
| [`queries.sql`](./queries.sql) | Clean, progressive single-query hybrid search patterns ready for Google Cloud Spanner / Spanner Omni. |
| [`generate_refund_data.py`](./generate_refund_data.py) | Script that parses, chunks, embeds, and builds the full dataset. |
| [`run_demo.py`](./run_demo.py) | Interactive Rich CLI demonstration executing and explaining all 7 search patterns step-by-step. |

---

## 🔍 Progressive Hybrid Query Patterns

### 1. Pure Vector Search (`COSINE_DISTANCE` with `ML.PREDICT`)
```sql
SELECT id AS chunk_id, content AS chunk_snippet,
  COSINE_DISTANCE(embedding, (SELECT embeddings.values FROM ML.PREDICT(MODEL DescriptionModel, (SELECT "customer requesting reimbursement for disputed charge or returned merchandise" AS content)))) AS distance
FROM Chunk ORDER BY distance ASC LIMIT 3;
```

### 2. Vector Search as Graph Entry Point (Vector-to-Graph)
```sql
GRAPH EnterpriseGRCGraph
MATCH (p:Process)-[:HAS_RISK]->(r:Risk)<-[:MITIGATES_RISK]-(ctrl:Control)
WHERE p.chunk_id IN (
  SELECT id FROM (
    SELECT id, COSINE_DISTANCE(embedding, @query_vector) AS distance
    FROM Chunk ORDER BY distance ASC LIMIT 3
  )
)
RETURN p.name AS process, r.name AS risk, r.severity AS risk_severity, ctrl.name AS mitigating_control;
```

### 3. Full-Text Search (FTS) for Tokens
```sql
SELECT id, name, category, severity, description
FROM Risk
WHERE SEARCH(description, 'duplicate OR fraud');
```

### 4. Full-Text Search as Graph Entry Point (FTS-to-Graph)
```sql
GRAPH EnterpriseGRCGraph
MATCH (p:Process)-[:HAS_RISK]->(r:Risk)<-[:MITIGATES_RISK]-(ctrl:Control)
WHERE r.id IN (
  SELECT id FROM Risk
  WHERE SEARCH(description, 'duplicate OR fraud')
)
RETURN p.name AS process, r.name AS risk, ctrl.name AS mitigating_control, ctrl.control_type;
```

### 5. Aggregate Risk Exposure by Search Entry Point (`COUNT`, `AVG`, `MAX`)
```sql
GRAPH EnterpriseGRCGraph
MATCH (p:Process)-[:HAS_RISK]->(r:Risk)
WHERE p.id IN (
  SELECT id FROM Process
  WHERE SEARCH(description, 'refund OR dispute')
)
RETURN p.name AS process, COUNT(r.id) AS total_risks, AVG(r.impact_score) AS avg_risk_impact
GROUP BY process;
```

### 6. Graph-to-Vector (Process Systems & Cloud Deployment Lookup)
```sql
WITH ProcessSystems AS (
  SELECT * FROM GRAPH_TABLE(
    EnterpriseGRCGraph
    MATCH (p:Process WHERE p.id = 'proc-credit-refund')<-[:SUPPORTS_PROCESS]-(s:System),
          (ch:Chunk)-[:MENTIONS_SYSTEM]->(s)
    COLUMNS (p.name AS process_name, s.name AS system_name, s.cloud_provider AS deployment_location, ch.id AS chunk_id, ch.embedding AS chunk_embedding)
  )
)
SELECT process_name, system_name, deployment_location, chunk_id,
       ROUND(COSINE_DISTANCE(chunk_embedding, @infra_query_vector), 4) AS distance
FROM ProcessSystems ORDER BY distance ASC;
```

### 7. Multi-Hop System Interconnection Search (`System1 -> Process <- System2`)
```sql
GRAPH EnterpriseGRCGraph
MATCH (sys1:System)-[:SUPPORTS_PROCESS]->(p:Process)<-[:SUPPORTS_PROCESS]-(sys2:System)
WHERE sys1.id IN (
  SELECT id FROM System
  WHERE SEARCH(cloud_provider, 'GCP OR Kubernetes')
)
RETURN sys1.name AS PrimarySystem, sys1.cloud_provider AS PrimaryDeployment, p.name AS SharedProcess, sys2.name AS InterconnectedSystem;
```

---

## 🚀 Easy Execution

```bash
cd /Users/user/.gemini/antigravity/scratch/spanner-grc-property-graph
source .venv/bin/activate

# 1. Load all data (chunks, embeddings, nodes, edges)
PYTHONPATH=. python credit_refund_demo/load_all_data.py

# 2. Run interactive step-by-step demo explaining each search pattern
PYTHONPATH=. python credit_refund_demo/run_demo.py
```
