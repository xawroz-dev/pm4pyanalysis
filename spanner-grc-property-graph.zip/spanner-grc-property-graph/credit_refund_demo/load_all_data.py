#!/usr/bin/env python3
"""All-in-One Data Loader: Loads Graph, Chunks, 768-dim Embeddings, Nodes, and Edges in one command."""
import os
import sys
import argparse
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from credit_refund_demo.generate_refund_data import build_credit_refund_kg, export_sql_inserts
from engine.spanner_client import SpannerOmniClient
from models.ddl_generator import generate_spanner_ddl, export_ddl_file


def load_all_data(target: str = "auto"):
    console = Console()
    console.print(Panel.fit(
        "[bold cyan]Credit Refund Knowledge Graph All-in-One Loader[/bold cyan]\n"
        "[dim]Loads Document Chunks (768-dim Vector Embeddings), Nodes & Edges into Spanner Property Graph[/dim]",
        border_style="cyan"
    ))

    # 1. Build in-memory graph with embeddings and provenance
    console.print("[bold yellow]1. Building Knowledge Graph with 768-dim Vector Embeddings & Provenance...[/bold yellow]")
    kg = build_credit_refund_kg()
    stats = kg.stats()

    # Export SQL and JSON artifacts
    current_dir = os.path.dirname(os.path.abspath(__file__))
    sql_file = os.path.join(current_dir, "insert_data.sql")
    json_file = os.path.join(current_dir, "data.json")
    export_sql_inserts(kg, sql_file)
    with open(json_file, "w", encoding="utf-8") as f:
        f.write(kg.model_dump_json(indent=2))

    table = Table(title="Generated Dataset Breakdown", show_header=True)
    table.add_column("Node Table", style="cyan")
    table.add_column("Count", justify="right", style="bold green")
    table.add_column("Edge Table", style="blue")
    table.add_column("Count", justify="right", style="bold cyan")

    table.add_row("Document", str(len(kg.documents)), "DocumentHasChunk", str(len(kg.document_has_chunk)))
    table.add_row("Chunk (Vector Indexed)", str(len(kg.chunks)), "ProcessHasRisk", str(len(kg.process_has_risk)))
    table.add_row("Process", str(len(kg.processes)), "ControlMitigatesRisk", str(len(kg.control_mitigates_risk)))
    table.add_row("Policy", str(len(kg.policies)), "PolicyGovernsProcess", str(len(kg.policy_governs_process)))
    table.add_row("Risk", str(len(kg.risks)), "ProcessOperatesInMarket", str(len(kg.process_operates_in_market)))
    table.add_row("Control", str(len(kg.controls)), "SystemSupportsProcess", str(len(kg.system_supports_process)))
    table.add_row("Market", str(len(kg.markets)), "ControlAppliesToSystem", str(len(kg.control_applies_to_system)))
    table.add_row("System", str(len(kg.systems)), "ChunkMentions* (Grounding)", str(len(kg.chunk_mentions_process) + len(kg.chunk_mentions_risk) + len(kg.chunk_mentions_control)))

    console.print(table)
    console.print(f"📊 [bold green]Total Nodes:[/bold green] {stats['total_nodes']} | [bold cyan]Total Edges:[/bold cyan] {stats['total_edges']}\n")

    # 2. Deploy to Spanner Omni / Cloud Spanner if client available
    console.print("[bold yellow]2. Checking Spanner Omni Connection...[/bold yellow]")
    client = SpannerOmniClient()
    connected = client.connect()

    if connected:
        console.print("[bold green]✓ Connected to Spanner Omni! Applying DDL Schema & Inserting Data...[/bold green]")
        client.deploy_schema()
        client.insert_graph_data(kg)
        console.print("[bold green]✓ All nodes, vector chunks, and edges inserted into Spanner Omni successfully.[/bold green]")
    else:
        console.print("[bold yellow]ℹ Running in Standalone / In-Memory Mode.[/bold yellow]")
        console.print(f"  • Insert SQL generated: [cyan]{sql_file}[/cyan]")
        console.print(f"  • JSON Graph data generated: [cyan]{json_file}[/cyan]")
        console.print("  • To load into Spanner Omni: [white]podman exec -i spanner-omni ...[/white] or [white]docker compose up[/white]")

    console.print(Panel(
        "[bold green]✓ Loading Complete![/bold green]\n"
        "You can now run the hybrid search demo:\n"
        "  [white]PYTHONPATH=. python credit_refund_demo/run_demo.py[/white]",
        border_style="green"
    ))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Load Credit Refund Knowledge Graph into Spanner Omni / Local Engine")
    parser.add_argument("--target", default="auto", choices=["auto", "spanner", "local"], help="Target environment")
    args = parser.parse_args()
    load_all_data(args.target)
