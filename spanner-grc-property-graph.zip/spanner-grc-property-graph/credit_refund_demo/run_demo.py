#!/usr/bin/env python3
"""Interactive End-to-End Demonstration for Credit Refund Knowledge Graph Hybrid Search in Cloud Spanner.

This script clearly displays:
1. The exact Search Input (Text prompt or Token keywords).
2. The Vector Representation details (Original text, 768 dimensions preview, distance metric).
3. Plain-English explanations of how each search operates under the hood in Spanner.
4. The exact Spanner SQL / GQL query executed.
5. Formatted tabular results and business insights.
"""

import os
import sys

from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.syntax import Syntax
from rich import box

from credit_refund_demo.generate_refund_data import build_credit_refund_kg
from engine.local_simulator import SpannerLocalGraphSimulator
from pipeline.embedder import VectorEmbedder


def print_vector_details(console: Console, text: str, vec: list[float]):
    """Helper to display vector embedding preview and metadata."""
    preview_dims = ", ".join(f"{x:+.4f}" for x in vec[:5]) + f", ... [{len(vec)} total dimensions]"
    v_table = Table(box=box.SIMPLE, show_header=False, pad_edge=False)
    v_table.add_column("Property", style="cyan", width=24)
    v_table.add_column("Value", style="white")
    v_table.add_row("Vectorized Input Text:", f"[bold yellow]\"{text}\"[/bold yellow]")
    v_table.add_row("Embedding Model:", "[green]text-embedding-004 (768-dimensional float)[/green]")
    v_table.add_row("Vector Values Preview:", f"[dim]{preview_dims}[/dim]")
    v_table.add_row("Distance Metric:", "[magenta]COSINE_DISTANCE(u, v) = 1.0 - (u · v) / (||u|| * ||v||)[/magenta]")
    console.print(Panel(v_table, title="[bold cyan]🔢 Vector Embedding Representation[/bold cyan]", box=box.ROUNDED))


def run_credit_refund_demo():
    console = Console()
    console.print(Panel.fit(
        "[bold cyan]Google Cloud Spanner / Spanner Omni Hybrid Search Engine[/bold cyan]\n"
        "[bold white]Domain: Credit Card Dispute, Chargeback & Customer Refund Intelligence[/bold white]\n"
        "[dim]Comprehensive Demonstration of Single-Query Vector, Full-Text, and Graph Search[/dim]",
        box=box.DOUBLE,
        border_style="cyan"
    ))

    # 1. Build Knowledge Graph
    kg = build_credit_refund_kg()
    embedder = VectorEmbedder(dimension=768)
    simulator = SpannerLocalGraphSimulator(data=kg, embedder=embedder)
    stats = kg.stats()

    console.print(f"[bold green]✓ Loaded Knowledge Graph:[/bold green] {stats['total_nodes']} nodes, {stats['total_edges']} edges, {len(kg.chunks)} vector chunks.\n")

    # ==========================================================================
    # STEP 1: PURE VECTOR SEARCH
    # ==========================================================================
    console.print(Panel(
        "[bold yellow]STEP 1: Pure Vector Search (Semantic Similarity via Cosine Distance)[/bold yellow]\n\n"
        "[bold cyan]🔍 What is Happening:[/bold cyan]\n"
        "1. The user provides a natural language query describing a refund operation in plain English.\n"
        "2. Spanner uses [green]ML.PREDICT[/green] to convert the query into a 768-dimensional dense vector.\n"
        "3. Spanner calculates [magenta]COSINE_DISTANCE[/magenta] between the query vector and all chunk embeddings in the database.\n"
        "4. Chunks with the lowest distance (highest semantic similarity) are ranked and returned.",
        box=box.ROUNDED
    ))

    prompt_1 = "customer requesting reimbursement for disputed charge or returned merchandise"
    vec_1 = embedder.embed_text(prompt_1)
    print_vector_details(console, prompt_1, vec_1)

    console.print("[bold]Spanner SQL Query:[/bold]")
    q1_sql = """SELECT
  id AS chunk_id,
  content AS chunk_snippet,
  COSINE_DISTANCE(
    embedding,
    (SELECT embeddings.values
     FROM ML.PREDICT(
       MODEL DescriptionModel,
       (SELECT "customer requesting reimbursement for disputed charge or returned merchandise" AS content)
     )
    )
  ) AS distance
FROM Chunk
ORDER BY distance ASC
LIMIT 3;"""
    console.print(Syntax(q1_sql, "sql", theme="monokai", line_numbers=False))

    scored_chunks = [(c, embedder.cosine_distance(vec_1, c.embedding)) for c in kg.chunks]
    scored_chunks.sort(key=lambda x: x[1])

    t1 = Table(box=box.HEAVY_EDGE, title="Top 3 Semantically Matching Document Chunks")
    t1.add_column("Chunk ID", style="cyan", no_wrap=True)
    t1.add_column("Cosine Distance", justify="right", style="green")
    t1.add_column("Similarity Score", justify="right", style="yellow")
    t1.add_column("Chunk Text Preview", style="white")

    for ch, dist in scored_chunks[:3]:
        t1.add_row(ch.id, f"{dist:.4f}", f"{(1.0 - dist):.4f}", ch.content[:110] + "...")
    console.print(t1)
    console.print("[dim green]💡 Insight: The vector search successfully matched Chunk 0 (which defines Credit Card Dispute & Customer Refund Processing) with 0.0000 distance.[/dim green]\n")

    # ==========================================================================
    # STEP 2: VECTOR SEARCH AS GRAPH ENTRY POINT (Vector-to-Graph)
    # ==========================================================================
    console.print(Panel(
        "[bold yellow]STEP 2: Vector Search as Graph Entry Point (Vector-to-Graph)[/bold yellow]\n\n"
        "[bold cyan]🔍 What is Happening:[/bold cyan]\n"
        "1. Instead of running vector search in Python and then making separate database calls, Spanner does it all in [bold green]ONE SINGLE QUERY[/bold green].\n"
        "2. The vector distance subquery runs inside [cyan]WHERE p.chunk_id IN (SELECT ...)[/cyan] to find the relevant Process node.\n"
        "3. Simultaneously, Spanner's GQL engine traverses the graph: [magenta](Process)-[:HAS_RISK]->(Risk)<-[:MITIGATES_RISK]-(Control)[/magenta].\n"
        "4. This instantly links the semantic prompt to organizational risks and mitigating controls.",
        box=box.ROUNDED
    ))

    print_vector_details(console, prompt_1, vec_1)

    console.print("[bold]Spanner Unified GQL Query:[/bold]")
    q2_sql = """GRAPH EnterpriseGRCGraph
MATCH (p:Process)-[:HAS_RISK]->(r:Risk)<-[:MITIGATES_RISK]-(ctrl:Control)
WHERE p.chunk_id IN (
  SELECT id FROM (
    SELECT id, COSINE_DISTANCE(
      embedding,
      (SELECT embeddings.values
       FROM ML.PREDICT(
         MODEL DescriptionModel,
         (SELECT "customer requesting reimbursement for disputed charge or returned merchandise" AS content)
       )
      )
    ) AS distance
    FROM Chunk
    ORDER BY distance ASC
    LIMIT 3
  )
)
RETURN
  p.name AS process,
  r.name AS risk,
  r.severity AS risk_severity,
  ctrl.name AS mitigating_control,
  ctrl.effectiveness AS control_effectiveness;"""
    console.print(Syntax(q2_sql, "sql", theme="monokai", line_numbers=False))

    res_2 = simulator.query_vector_to_graph(query_text=prompt_1, top_k=2, similarity_threshold=0.85)

    t2 = Table(box=box.HEAVY_EDGE, title="Vector-to-Graph Single Query Result")
    t2.add_column("Governed Process", style="bold white")
    t2.add_column("Discovered Risk", style="red")
    t2.add_column("Severity", style="bold red")
    t2.add_column("Mitigating Control", style="yellow")
    t2.add_column("Effectiveness", style="green")

    for r in res_2["records"][:3]:
        t2.add_row(
            r["process_name"],
            r["risk_name"],
            r["risk_severity"],
            r["mitigating_control"],
            r["control_effectiveness"]
        )
    console.print(t2)
    console.print("[dim green]💡 Insight: One single query translated customer dispute text directly into Critical Duplicate Refund Fraud risk and its Dual-Authorization control.[/dim green]\n")

    # ==========================================================================
    # STEP 3: FULL-TEXT SEARCH (FTS) FOR TOKENS
    # ==========================================================================
    console.print(Panel(
        "[bold yellow]STEP 3: Full-Text Search (FTS) for Specific Tokens[/bold yellow]\n\n"
        "[bold cyan]🔍 What is Happening:[/bold cyan]\n"
        "1. Uses Spanner's native [cyan]SEARCH(description, 'duplicate OR fraud')[/cyan] full-text search index.\n"
        "2. Performs tokenization, stemming, and BM25 relevance scoring directly in the database engine.\n"
        "3. Returns exact keyword matches without needing vector embeddings.",
        box=box.ROUNDED
    ))

    search_tokens = "duplicate OR fraud"
    console.print(f"[bold]Search Token Query:[/bold] [italic yellow]'{search_tokens}'[/italic yellow]")

    console.print("[bold]Spanner SQL Query:[/bold]")
    q3_sql = """SELECT id, name, category, severity, description
FROM Risk
WHERE SEARCH(description, 'duplicate OR fraud');"""
    console.print(Syntax(q3_sql, "sql", theme="monokai", line_numbers=False))

    fts_risks = [r for r in kg.risks if "duplicate" in r.description.lower() or "fraud" in r.description.lower()]

    t3 = Table(box=box.HEAVY_EDGE, title="Full-Text Search Results on Risk Table")
    t3.add_column("Risk ID", style="cyan")
    t3.add_column("Risk Name", style="bold white")
    t3.add_column("Category", style="magenta")
    t3.add_column("Severity", style="red")
    t3.add_column("Impact Score", justify="right", style="green")

    for r in fts_risks[:3]:
        t3.add_row(r.id, r.name, r.category, r.severity, str(r.impact_score))
    console.print(t3)
    console.print("[dim green]💡 Insight: Quickly retrieves high-severity fraud risks containing the exact terms 'duplicate' or 'fraud'.[/dim green]\n")

    # ==========================================================================
    # STEP 4: FULL-TEXT SEARCH AS GRAPH ENTRY POINT (FTS-to-Graph)
    # ==========================================================================
    console.print(Panel(
        "[bold yellow]STEP 4: Full-Text Search as Graph Entry Point (FTS-to-Graph)[/bold yellow]\n\n"
        "[bold cyan]🔍 What is Happening:[/bold cyan]\n"
        "1. Spanner uses the FTS index to find risks matching [cyan]'duplicate OR fraud'[/cyan].\n"
        "2. In the [bold green]same single query[/bold green], it feeds those risk IDs into GQL: [magenta]MATCH (Process)-[:HAS_RISK]->(Risk)<-[:MITIGATES_RISK]-(Control)[/magenta].\n"
        "3. This reveals which processes are vulnerable and what controls enforce compliance.",
        box=box.ROUNDED
    ))

    console.print(f"[bold]Search Tokens:[/bold] [italic yellow]'{search_tokens}'[/italic yellow]")

    console.print("[bold]Spanner Unified GQL Query:[/bold]")
    q4_sql = """GRAPH EnterpriseGRCGraph
MATCH (p:Process)-[:HAS_RISK]->(r:Risk)<-[:MITIGATES_RISK]-(ctrl:Control)
WHERE r.id IN (
  SELECT id FROM Risk
  WHERE SEARCH(description, 'duplicate OR fraud')
)
RETURN
  p.name AS process,
  r.name AS risk,
  r.severity AS risk_severity,
  ctrl.name AS mitigating_control,
  ctrl.control_type AS control_type;"""
    console.print(Syntax(q4_sql, "sql", theme="monokai", line_numbers=False))

    t4 = Table(box=box.HEAVY_EDGE, title="FTS-to-Graph Traversal Output")
    t4.add_column("Impacted Process", style="white")
    t4.add_column("Matched Risk", style="red")
    t4.add_column("Severity", style="bold red")
    t4.add_column("Enforced Control", style="yellow")
    t4.add_column("Control Type", style="cyan")

    for r_node in fts_risks[:3]:
        for edge in kg.process_has_risk:
            if edge.risk_id == r_node.id:
                p_node = simulator.proc_by_id.get(edge.process_id)
                ctrl_ids = simulator.risk_to_ctrls.get(r_node.id, [])
                c_node = simulator.ctrl_by_id.get(ctrl_ids[0]) if ctrl_ids else None
                if p_node and c_node:
                    t4.add_row(p_node.name, r_node.name, r_node.severity, c_node.name, c_node.control_type)
    console.print(t4)
    console.print("[dim green]💡 Insight: FTS entry point shows that Duplicate Refund Fraud impacts both Dispute Processing & Instant Crediting, mitigated by Dual-Auth & Velocity controls.[/dim green]\n")

    # ==========================================================================
    # STEP 5: AGGREGATE RISK IMPACT BY SEARCH ENTRY POINT
    # ==========================================================================
    console.print(Panel(
        "[bold yellow]STEP 5: Statistical Risk Aggregation by Search Entry Point (COUNT, AVG, MAX)[/bold yellow]\n\n"
        "[bold cyan]🔍 What is Happening:[/bold cyan]\n"
        "1. Spanner searches for processes matching [cyan]'refund OR dispute'[/cyan].\n"
        "2. Traverses graph paths to all connected risks.\n"
        "3. Computes statistical aggregates ([cyan]COUNT, AVG, MAX[/cyan]) across the graph paths in a single execution.",
        box=box.ROUNDED
    ))

    agg_tokens = "refund OR dispute"
    console.print(f"[bold]Search Tokens:[/bold] [italic yellow]'{agg_tokens}'[/italic yellow]")

    console.print("[bold]Spanner Aggregation GQL Query:[/bold]")
    q5_sql = """GRAPH EnterpriseGRCGraph
MATCH (p:Process)-[:HAS_RISK]->(r:Risk)
WHERE p.id IN (
  SELECT id FROM Process
  WHERE SEARCH(description, 'refund OR dispute')
)
RETURN
  p.name AS process,
  COUNT(r.id) AS total_risks,
  AVG(r.impact_score) AS avg_risk_impact,
  MAX(r.impact_score) AS max_risk_impact
GROUP BY process;"""
    console.print(Syntax(q5_sql, "sql", theme="monokai", line_numbers=False))

    t5 = Table(box=box.HEAVY_EDGE, title="Aggregated Risk Statistics by Process")
    t5.add_column("Process Name", style="bold white")
    t5.add_column("Total Risks", justify="right", style="cyan")
    t5.add_column("Avg Impact Score", justify="right", style="yellow")
    t5.add_column("Max Impact Score", justify="right", style="bold red")

    matching_procs = [p for p in kg.processes if "refund" in p.description.lower() or "dispute" in p.description.lower()]
    for p in matching_procs:
        p_risks = [simulator.risk_by_id[e.risk_id] for e in kg.process_has_risk if e.process_id == p.id and e.risk_id in simulator.risk_by_id]
        if p_risks:
            total_r = len(p_risks)
            avg_imp = sum(r.impact_score for r in p_risks) / total_r
            max_imp = max(r.impact_score for r in p_risks)
            t5.add_row(p.name, str(total_r), f"{avg_imp:.2f}", f"{max_imp:.2f}")
    console.print(t5)
    console.print("[dim green]💡 Insight: High-level management metrics computed directly from graph relationships and keyword filtering.[/dim green]\n")

    # ==========================================================================
    # STEP 6: GRAPH-TO-VECTOR (System Deployment & Infrastructure Lookup)
    # ==========================================================================
    console.print(Panel(
        "[bold yellow]STEP 6: Graph-to-Vector (Process Systems & Cloud Deployment Lookup)[/bold yellow]\n\n"
        "[bold cyan]🔍 What is Happening:[/bold cyan]\n"
        "1. Starts with a known Graph entity: Process [cyan]'proc-credit-refund'[/cyan].\n"
        "2. Traverses graph to find all supporting IT Systems and where each is deployed (GCP GKE us-east4, Multi-region Spanner, AWS EKS).\n"
        "3. In the [bold green]same query[/bold green], retrieves connected architecture text chunks and ranks them by cosine similarity against an infrastructure prompt.",
        box=box.ROUNDED
    ))

    target_proc_id = "proc-credit-refund"
    infra_prompt = "High availability multi-region Spanner cluster and Kubernetes cluster deployment"
    infra_vec = embedder.embed_text(infra_prompt)

    console.print(f"[bold]Target Graph Node:[/bold] Process ID [cyan]'{target_proc_id}'[/cyan] (Credit Card Dispute & Customer Refund Processing)")
    print_vector_details(console, infra_prompt, infra_vec)

    console.print("[bold]Spanner Hybrid SQL + GQL Query:[/bold]")
    q6_sql = """WITH ProcessSystems AS (
  SELECT * FROM GRAPH_TABLE(
    EnterpriseGRCGraph
    MATCH (p:Process WHERE p.id = 'proc-credit-refund')<-[:SUPPORTS_PROCESS]-(s:System),
          (ch:Chunk)-[:MENTIONS_SYSTEM]->(s)
    COLUMNS (
      p.name AS process_name,
      s.name AS system_name,
      s.tier AS system_tier,
      s.cloud_provider AS deployment_location,
      ch.id AS chunk_id,
      ch.content AS chunk_text,
      ch.embedding AS chunk_embedding
    )
  )
)
SELECT
  process_name,
  system_name,
  system_tier,
  deployment_location,
  chunk_id,
  ROUND(COSINE_DISTANCE(chunk_embedding, @infra_query_vector), 4) AS distance
FROM ProcessSystems
ORDER BY distance ASC;"""
    console.print(Syntax(q6_sql, "sql", theme="monokai", line_numbers=False))

    sys_records = []
    for edge in kg.system_supports_process:
        if edge.process_id == target_proc_id:
            sys_node = simulator.sys_by_id.get(edge.system_id)
            if sys_node:
                grounded_chunks = [simulator.chunk_by_id[m.chunk_id] for m in kg.chunk_mentions_system if m.system_id == sys_node.id and m.chunk_id in simulator.chunk_by_id]
                for ch in grounded_chunks:
                    dist = embedder.cosine_distance(infra_vec, ch.embedding)
                    sys_records.append({
                        "system_name": sys_node.name,
                        "system_tier": sys_node.tier,
                        "cloud_deployment": sys_node.cloud_provider,
                        "distance": dist,
                        "chunk_snippet": ch.content[:100] + "..."
                    })

    sys_records.sort(key=lambda x: x["distance"])

    t6 = Table(box=box.HEAVY_EDGE, title="Graph Traversal -> System Deployment Locations & Evidence")
    t6.add_column("Supporting System", style="bold cyan")
    t6.add_column("Tier", style="magenta")
    t6.add_column("Cloud Deployment Location", style="bold green")
    t6.add_column("Semantic Distance", justify="right", style="green")

    for r in sys_records:
        t6.add_row(r["system_name"], r["system_tier"], r["cloud_deployment"], f"{r['distance']:.4f}")
    console.print(t6)
    console.print("[dim green]💡 Insight: Graph traversed from the business process down to exact cloud hosts: GCP us-east4, Cloud Spanner Multi-Region, and AWS EKS.[/dim green]\n")

    # ==========================================================================
    # STEP 7: MULTI-HOP SYSTEM INTERCONNECTION SEARCH
    # ==========================================================================
    console.print(Panel(
        "[bold yellow]STEP 7: Multi-Hop Interconnected Systems Search (System1 -> Process <- System2)[/bold yellow]\n\n"
        "[bold cyan]🔍 What is Happening:[/bold cyan]\n"
        "1. Uses FTS to find primary systems containing [cyan]'GCP OR Kubernetes'[/cyan].\n"
        "2. Traverses [magenta](sys1:System)-[:SUPPORTS_PROCESS]->(p:Process)<-[:SUPPORTS_PROCESS]-(sys2:System)[/magenta].\n"
        "3. Discovers interconnected systems (e.g. FraudShield on AWS) that share critical processing pipelines with GCP services.\n"
        "4. This mirrors the [italic]Email-Device-Email[/italic] identity graph resolution pattern.",
        box=box.ROUNDED
    ))

    sys_tokens = "GCP OR Kubernetes"
    console.print(f"[bold]Search Tokens:[/bold] [italic yellow]'{sys_tokens}'[/italic yellow]")

    console.print("[bold]Spanner Multi-Hop GQL Query:[/bold]")
    q7_sql = """GRAPH EnterpriseGRCGraph
MATCH (sys1:System)-[:SUPPORTS_PROCESS]->(p:Process)<-[:SUPPORTS_PROCESS]-(sys2:System)
WHERE sys1.id IN (
  SELECT id FROM System
  WHERE SEARCH(cloud_provider, 'GCP OR Kubernetes')
)
RETURN
  sys1.name AS PrimarySystem,
  sys1.cloud_provider AS PrimaryDeployment,
  p.name AS SharedProcess,
  sys2.name AS InterconnectedSystem,
  sys2.cloud_provider AS InterconnectedDeployment;"""
    console.print(Syntax(q7_sql, "sql", theme="monokai", line_numbers=False))

    t7 = Table(box=box.HEAVY_EDGE, title="Multi-Hop Interconnected Systems Output")
    t7.add_column("Primary System", style="cyan")
    t7.add_column("Primary Cloud Deployment", style="green")
    t7.add_column("Shared Process", style="white")
    t7.add_column("Interconnected System", style="yellow")
    t7.add_column("Interconnected Deployment", style="magenta")

    gcp_systems = [s for s in kg.systems if "GCP" in s.cloud_provider or "Kubernetes" in s.cloud_provider]
    for s1 in gcp_systems[:2]:
        procs = [e.process_id for e in kg.system_supports_process if e.system_id == s1.id]
        for p_id in procs:
            p_node = simulator.proc_by_id.get(p_id)
            other_sys = [simulator.sys_by_id[e.system_id] for e in kg.system_supports_process if e.process_id == p_id and e.system_id != s1.id and e.system_id in simulator.sys_by_id]
            for s2 in other_sys[:2]:
                t7.add_row(s1.name, s1.cloud_provider, p_node.name if p_node else "N/A", s2.name, s2.cloud_provider)

    console.print(t7)
    console.print("[dim green]💡 Insight: Graph revealed that GCP Refund Orchestration shares critical dispute processing with FraudShield AI on AWS.[/dim green]\n")

    # Final Banner
    console.print(Panel(
        "[bold green]✓ All 7 Spanner Hybrid Search Patterns Executed and Explained Successfully![/bold green]\n"
        "Ready to run in your local environment or Spanner Omni container:\n"
        " • [cyan]credit_refund_demo/load_all_data.py[/cyan] (All-in-one loader)\n"
        " • [cyan]credit_refund_demo/insert_data.sql[/cyan] (Insertable SQL data)\n"
        " • [cyan]credit_refund_demo/queries.sql[/cyan] (Production SQL + GQL queries)",
        border_style="green"
    ))


if __name__ == "__main__":
    run_credit_refund_demo()
