-- =============================================================================
-- Google Cloud Spanner / Spanner Omni Hybrid Query Catalog: Credit Refund Domain
-- Simple, Progressive Query Patterns for Vector, Full-Text, and Graph Search
-- =============================================================================

-- =============================================================================
-- 1. PURE VECTOR SEARCH (Cosine Distance with ML.PREDICT)
-- Find top 3 closest chunks matching a natural language process description:
-- =============================================================================
SELECT
  id AS chunk_id,
  content AS chunk_snippet,
  COSINE_DISTANCE(
    embedding,
    (SELECT embeddings.values
     FROM ML.PREDICT(
       MODEL DescriptionModel,
       (SELECT "customer requesting reimbursement for disputed charge or returned merchandise" AS content)
     )
    )
  ) AS distance
FROM Chunk
ORDER BY distance ASC
LIMIT 3;


-- =============================================================================
-- 2. VECTOR SEARCH AS GRAPH ENTRY POINT (Vector-to-Graph)
-- Use the vector search result as the entry point to traverse the Spanner Graph:
-- =============================================================================
GRAPH EnterpriseGRCGraph
MATCH (p:Process)-[:HAS_RISK]->(r:Risk)<-[:MITIGATES_RISK]-(ctrl:Control)
WHERE p.chunk_id IN (
  SELECT id FROM (
    SELECT id, COSINE_DISTANCE(
      embedding,
      (SELECT embeddings.values
       FROM ML.PREDICT(
         MODEL DescriptionModel,
         (SELECT "customer requesting reimbursement for disputed charge or returned merchandise" AS content)
       )
      )
    ) AS distance
    FROM Chunk
    ORDER BY distance ASC
    LIMIT 3
  )
)
RETURN
  p.name AS process,
  r.name AS risk,
  r.severity AS risk_severity,
  ctrl.name AS mitigating_control,
  ctrl.effectiveness AS control_effectiveness;


-- =============================================================================
-- 3. FULL-TEXT SEARCH (FTS) FOR SPECIFIC TOKENS
-- Find risks containing tokens 'duplicate OR fraud' using the SEARCH() index:
-- =============================================================================
SELECT id, name, category, severity, description
FROM Risk
WHERE SEARCH(description, 'duplicate OR fraud');


-- =============================================================================
-- 4. FULL-TEXT SEARCH AS GRAPH ENTRY POINT (FTS-to-Graph)
-- Use the keyword search tokens to enter the graph and trace mitigating controls:
-- =============================================================================
GRAPH EnterpriseGRCGraph
MATCH (p:Process)-[:HAS_RISK]->(r:Risk)<-[:MITIGATES_RISK]-(ctrl:Control)
WHERE r.id IN (
  SELECT id FROM Risk
  WHERE SEARCH(description, 'duplicate OR fraud')
)
RETURN
  p.name AS process,
  r.name AS risk,
  r.severity AS risk_severity,
  ctrl.name AS mitigating_control,
  ctrl.control_type AS control_type;


-- =============================================================================
-- 5. AGGREGATE RISK IMPACT BY SEARCH ENTRY POINT
-- Sum and average the risk scores for processes matching 'refund OR dispute':
-- =============================================================================
GRAPH EnterpriseGRCGraph
MATCH (p:Process)-[:HAS_RISK]->(r:Risk)
WHERE p.id IN (
  SELECT id FROM Process
  WHERE SEARCH(description, 'refund OR dispute')
)
RETURN
  p.name AS process,
  COUNT(r.id) AS total_risks,
  AVG(r.impact_score) AS avg_risk_impact,
  MAX(r.impact_score) AS max_risk_impact
GROUP BY process;


-- =============================================================================
-- 6. GRAPH-TO-VECTOR (System Deployment Lookup & Evidence Ranking)
-- Traverse from Process to supporting Systems to inspect where they are deployed,
-- and rank grounded text chunks by cosine similarity to an infrastructure query:
-- =============================================================================
WITH ProcessSystems AS (
  SELECT * FROM GRAPH_TABLE(
    EnterpriseGRCGraph
    MATCH (p:Process WHERE p.id = 'proc-credit-refund')<-[:SUPPORTS_PROCESS]-(s:System),
          (ch:Chunk)-[:MENTIONS_SYSTEM]->(s)
    COLUMNS (
      p.name AS process_name,
      s.name AS system_name,
      s.tier AS system_tier,
      s.cloud_provider AS deployment_location,
      ch.id AS chunk_id,
      ch.content AS chunk_text,
      ch.embedding AS chunk_embedding
    )
  )
)
SELECT
  process_name,
  system_name,
  system_tier,
  deployment_location,
  chunk_id,
  ROUND(COSINE_DISTANCE(chunk_embedding, @infra_query_vector), 4) AS distance
FROM ProcessSystems
ORDER BY distance ASC;


-- =============================================================================
-- 7. MULTI-HOP INTERCONNECTED SYSTEMS SEARCH (System1 -> Process <- System2)
-- Find all systems that share a critical process with Kubernetes/Spanner services:
-- (Similar to Email-Device-Email identity resolution pattern)
-- =============================================================================
GRAPH EnterpriseGRCGraph
MATCH (sys1:System)-[:SUPPORTS_PROCESS]->(p:Process)<-[:SUPPORTS_PROCESS]-(sys2:System)
WHERE sys1.id IN (
  SELECT id FROM System
  WHERE SEARCH(cloud_provider, 'GCP OR Kubernetes OR Spanner')
)
RETURN
  sys1.name AS PrimarySystem,
  sys1.cloud_provider AS PrimaryDeployment,
  p.name AS SharedProcess,
  sys2.name AS InterconnectedSystem,
  sys2.cloud_provider AS InterconnectedDeployment;
