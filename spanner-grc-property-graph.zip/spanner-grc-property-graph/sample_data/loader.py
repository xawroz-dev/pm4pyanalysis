"""Loader utility for loading sample GRC documents."""
import os
import glob
from typing import List, Optional
from models.schema import Document


def load_sample_documents(docs_dir: Optional[str] = None) -> List[Document]:
    """Load all markdown documents from the sample_data/docs directory."""
    if docs_dir is None:
        current_dir = os.path.dirname(os.path.abspath(__file__))
        docs_dir = os.path.join(current_dir, "docs")

    doc_files = glob.glob(os.path.join(docs_dir, "*.md"))
    documents = []

    for file_path in sorted(doc_files):
        filename = os.path.basename(file_path)
        doc_id = f"doc_{filename.replace('.md', '')}"
        with open(file_path, "r", encoding="utf-8") as f:
            content = f.read()

        # Extract title from first H1 header
        lines = content.strip().split("\n")
        title = lines[0].replace("#", "").strip() if lines else filename

        documents.append(
            Document(
                id=doc_id,
                title=title,
                source_type="GOVERNANCE_STANDARD",
                uploaded_at="2026-08-19T12:00:00Z",
                raw_text=content
            )
        )

    return documents


if __name__ == "__main__":
    docs = load_sample_documents()
    print(f"Loaded {len(docs)} sample documents:")
    for d in docs:
        print(f" - [{d.id}] {d.title} ({len(d.raw_text)} chars)")
