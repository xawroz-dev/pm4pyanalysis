"""Sample data package."""
from sample_data.loader import load_sample_documents

__all__ = ["load_sample_documents"]
