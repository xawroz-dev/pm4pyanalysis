"""Unit tests for ingestion pipeline, chunking, embedding, extraction, and DDL generation."""
import pytest
from models.schema import Document
from models.ddl_generator import generate_spanner_ddl
from pipeline.chunker import DocumentChunker
from pipeline.embedder import VectorEmbedder
from pipeline.extractor import LLMExtractor
from pipeline.ingest import IngestionPipeline
from sample_data.loader import load_sample_documents


def test_chunker_basic():
    chunker = DocumentChunker(target_chunk_size_words=50, overlap_words=10)
    sample_text = " ".join([f"word{i}" for i in range(120)])
    chunks = chunker.chunk_text("doc_test_1", sample_text)
    
    assert len(chunks) >= 2
    assert chunks[0].document_id == "doc_test_1"
    assert chunks[0].chunk_index == 0
    assert chunks[0].token_count > 0
    assert "word0" in chunks[0].content


def test_vector_embedder():
    embedder = VectorEmbedder(dimension=768)
    vec1 = embedder.embed_text("Sanctions screening and AML violation risk in payments")
    vec2 = embedder.embed_text("Real-time OFAC sanctions screening API for SEPA transfers")
    vec3 = embedder.embed_text("Kubernetes cluster failover and DORA operational resilience")

    assert len(vec1) == 768
    assert len(vec2) == 768
    assert len(vec3) == 768

    dist_related = embedder.cosine_distance(vec1, vec2)
    dist_unrelated = embedder.cosine_distance(vec1, vec3)

    assert dist_related < dist_unrelated
    assert 0.0 <= dist_related <= 2.0


def test_llm_extractor_grounding():
    chunker = DocumentChunker()
    sample_text = (
        "The Cross-Border Real-Time Settlement process is governed by the AMLD6 Anti-Money Laundering Policy. "
        "The critical risk is Sanctions Evasion & Illicit Funds Transfer, which is mitigated by the Real-Time OFAC & PEP Sanction API Screener. "
        "The process runs on SWIFT Enterprise Gateway in the European Union (SEPA Zone)."
    )
    chunks = chunker.chunk_text("doc_sample", sample_text)
    extractor = LLMExtractor()
    res = extractor.extract_from_chunk(chunks[0])

    assert len(res.processes) > 0
    assert len(res.policies) > 0
    assert len(res.risks) > 0
    assert len(res.controls) > 0
    assert len(res.markets) > 0
    assert len(res.systems) > 0

    # Verify chunk grounding
    for p in res.processes:
        assert p.chunk_id == chunks[0].id
    for r in res.risks:
        assert r.chunk_id == chunks[0].id
    for edge in res.process_has_risk:
        assert edge.chunk_id == chunks[0].id


def test_ingestion_pipeline_end_to_end():
    docs = load_sample_documents()
    assert len(docs) >= 4

    pipeline = IngestionPipeline()
    kg = pipeline.process_documents(docs)
    stats = kg.stats()

    assert stats["documents"] == len(docs)
    assert stats["chunks"] >= 4
    assert stats["processes"] >= 4
    assert stats["policies"] >= 4
    assert stats["risks"] >= 4
    assert stats["controls"] >= 4
    assert stats["markets"] >= 3
    assert stats["systems"] >= 4
    assert stats["total_edges"] > 20


def test_spanner_ddl_generation():
    ddl = generate_spanner_ddl(graph_name="EnterpriseGRCGraph", embedding_dim=768)
    assert "CREATE PROPERTY GRAPH EnterpriseGRCGraph" in ddl
    assert "CREATE VECTOR INDEX ChunkVectorIndex ON Chunk" in ddl
    assert "CREATE SEARCH INDEX ChunkSearchIndex ON Chunk" in ddl
    assert "ProcessHasRisk" in ddl
    assert "ControlMitigatesRisk" in ddl
    assert "PolicyGovernsProcess" in ddl
