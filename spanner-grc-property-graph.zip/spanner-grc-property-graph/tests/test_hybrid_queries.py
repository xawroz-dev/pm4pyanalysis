"""Unit tests for Unified Spanner Single-Query Hybrid Search Patterns."""
import pytest
from sample_data.loader import load_sample_documents
from pipeline.ingest import IngestionPipeline
from engine.local_simulator import SpannerLocalGraphSimulator


@pytest.fixture(scope="module")
def simulator():
    docs = load_sample_documents()
    pipeline = IngestionPipeline()
    kg = pipeline.process_documents(docs)
    return SpannerLocalGraphSimulator(data=kg)


def test_vector_to_graph_query(simulator):
    """Test Pattern 1: Vector Search -> Graph Traversal in single query."""
    query = "What preventative controls mitigate money laundering and OFAC sanctions violations?"
    res = simulator.query_vector_to_graph(query_text=query, top_k=3, similarity_threshold=0.85)

    assert res["query_type"] == "VECTOR_TO_GRAPH"
    assert res["matches_count"] > 0
    
    first_record = res["records"][0]
    assert "chunk_snippet" in first_record
    assert "vector_distance" in first_record
    assert "process_name" in first_record
    assert "governing_policy" in first_record
    assert "risk_name" in first_record
    assert "mitigating_control" in first_record
    assert "target_market" in first_record
    assert "supporting_system" in first_record
    assert first_record["vector_distance"] < 0.85


def test_graph_to_vector_query(simulator):
    """Test Pattern 2: Graph Traversal -> Vector Semantic Ranking in single query."""
    regulatory_framework = "DORA"
    incident_query = "Cloud data center region failure during peak payment volume"
    res = simulator.query_graph_to_vector(
        regulatory_framework=regulatory_framework,
        incident_query=incident_query,
        top_k=5
    )

    assert res["query_type"] == "GRAPH_TO_VECTOR"
    assert res["regulatory_framework"] == "DORA"
    assert res["matches_count"] > 0

    first = res["records"][0]
    assert first["regulatory_framework"] == "DORA"
    assert "Multi-Region Cloud Infrastructure Outage" in first["risk_name"]
    assert "incident_semantic_distance" in first
    assert "chunk_text" in first


def test_fts_to_graph_query(simulator):
    """Test Pattern 3: Full-Text Search (FTS) Keyword Filter -> Graph Blast Radius."""
    search_term = "kill switch"
    res = simulator.query_fts_to_graph(search_term=search_term, top_k=3)

    assert res["query_type"] == "FTS_TO_GRAPH"
    assert res["matches_count"] > 0
    first = res["records"][0]
    assert "UltraFlow" in first["system_name"] or "Algorithmic" in first["process_name"]
    assert "Errant Algorithmic" in first["risk_name"]
    assert "Pre-Trade Sub-Millisecond Kill Switch" in first["control_name"]


def test_three_way_hybrid_query(simulator):
    """Test Pattern 4: 3-Way Hybrid (Vector + Keyword + Multi-Hop Graph)."""
    query_text = "Generative AI conversational banking agent privacy governance"
    search_keyword = "hallucination"
    res = simulator.query_three_way_hybrid(
        query_text=query_text,
        search_keyword=search_keyword,
        top_k=3
    )

    assert res["query_type"] == "THREE_WAY_HYBRID"
    assert res["matches_count"] > 0
    first = res["records"][0]
    assert "GenAI" in first["risk_name"] or "Generative AI" in first["process_name"]
    assert "hybrid_score" in first
    assert first["hybrid_score"] > 0.4
