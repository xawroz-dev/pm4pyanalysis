"""Unit tests for Credit Refund Knowledge Graph and Single-Query Hybrid Search."""
import pytest
from credit_refund_demo.generate_refund_data import build_credit_refund_kg
from engine.local_simulator import SpannerLocalGraphSimulator
from pipeline.embedder import VectorEmbedder


@pytest.fixture(scope="module")
def refund_simulator():
    kg = build_credit_refund_kg()
    embedder = VectorEmbedder(dimension=768)
    return SpannerLocalGraphSimulator(data=kg, embedder=embedder)


def test_credit_refund_vector_to_graph(refund_simulator):
    """Test Pattern 1: Semantic process description -> Process Node -> Associated Risks & Controls."""
    prompt = "customer requesting reimbursement for disputed charge or returned merchandise"
    res = refund_simulator.query_vector_to_graph(query_text=prompt, top_k=2, similarity_threshold=0.85)

    assert res["query_type"] == "VECTOR_TO_GRAPH"
    assert res["matches_count"] > 0

    first = res["records"][0]
    assert "Credit Card Dispute" in first["process_name"] or "Refund" in first["process_name"]
    assert "Duplicate Refund" in first["risk_name"] or "Unauthorized" in first["risk_name"]
    assert "Dual-Authorization" in first["mitigating_control"] or "Velocity" in first["mitigating_control"]
    assert first["vector_distance"] < 0.85


def test_credit_refund_graph_to_vector_system_deployment(refund_simulator):
    """Test Pattern 2: Graph Traversal from Process to Systems -> Cloud Deployment Location & Vector Ranking."""
    infra_query = "High availability multi-region Spanner cluster and Kubernetes cluster deployment"
    kg = refund_simulator.data
    embedder = refund_simulator.embedder
    infra_vec = embedder.embed_text(infra_query)

    sys_records = []
    for edge in kg.system_supports_process:
        if edge.process_id == "proc-credit-refund":
            sys = refund_simulator.sys_by_id.get(edge.system_id)
            assert sys is not None
            # Verify deployment cloud info is populated
            assert "GCP" in sys.cloud_provider or "AWS" in sys.cloud_provider
            
            grounded_chunks = [
                refund_simulator.chunk_by_id[m.chunk_id]
                for m in kg.chunk_mentions_system
                if m.system_id == sys.id and m.chunk_id in refund_simulator.chunk_by_id
            ]
            for ch in grounded_chunks:
                dist = embedder.cosine_distance(infra_vec, ch.embedding)
                sys_records.append({
                    "system_name": sys.name,
                    "cloud_provider": sys.cloud_provider,
                    "distance": dist
                })

    assert len(sys_records) > 0
    sys_names = [r["system_name"] for r in sys_records]
    assert "Refund Orchestration Microservice" in sys_names
    assert "Core LedgerX Settlement Engine" in sys_names


def test_credit_refund_fts_to_graph(refund_simulator):
    """Test Pattern 3: Full-Text Search on 'duplicate refund' -> Graph Blast Radius."""
    res = refund_simulator.query_fts_to_graph(search_term="duplicate refund", top_k=2)

    assert res["query_type"] == "FTS_TO_GRAPH"
    assert res["matches_count"] > 0
    first = res["records"][0]
    assert "Duplicate Refund" in first["risk_name"] or "Refund" in first["process_name"]


def test_credit_refund_sql_export():
    """Verify that insert_data.sql contains all necessary Spanner DML statements."""
    from credit_refund_demo.generate_refund_data import export_sql_inserts, build_credit_refund_kg
    import tempfile

    kg = build_credit_refund_kg()
    with tempfile.NamedTemporaryFile(suffix=".sql", delete=False) as f:
        export_sql_inserts(kg, f.name)
        with open(f.name, "r") as sql_f:
            content = sql_f.read()

    assert "INSERT INTO Document" in content
    assert "INSERT INTO Chunk" in content
    assert "ARRAY<FLOAT64>" in content
    assert "INSERT INTO Process" in content
    assert "INSERT INTO Risk" in content
    assert "INSERT INTO Control" in content
    assert "INSERT INTO System" in content
    assert "INSERT INTO ProcessHasRisk" in content
    assert "INSERT INTO ControlMitigatesRisk" in content
