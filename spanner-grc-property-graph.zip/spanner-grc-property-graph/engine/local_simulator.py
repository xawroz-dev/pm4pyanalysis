"""In-memory Graph & Vector Engine simulating Cloud Spanner / Spanner Omni Property Graph hybrid queries."""
from typing import List, Dict, Any, Optional
import re
from models.schema import KnowledgeGraphData, Chunk
from pipeline.embedder import VectorEmbedder
from models.queries import (
    QUERY_VECTOR_TO_GRAPH_SQL,
    QUERY_GRAPH_TO_VECTOR_SQL,
    QUERY_FTS_TO_GRAPH_SQL,
    QUERY_3WAY_HYBRID_SQL,
)


class SpannerLocalGraphSimulator:
    """Simulates Cloud Spanner Property Graph execution with Vector & Full-Text Search."""

    def __init__(self, data: KnowledgeGraphData, embedder: Optional[VectorEmbedder] = None):
        self.data = data
        self.embedder = embedder or VectorEmbedder()
        self._build_indices()

    def _build_indices(self):
        """Build fast lookup indices for nodes and edges."""
        self.doc_by_id = {d.id: d for d in self.data.documents}
        self.chunk_by_id = {c.id: c for c in self.data.chunks}
        self.proc_by_id = {p.id: p for p in self.data.processes}
        self.pol_by_id = {p.id: p for p in self.data.policies}
        self.risk_by_id = {r.id: r for r in self.data.risks}
        self.ctrl_by_id = {c.id: c for c in self.data.controls}
        self.mkt_by_id = {m.id: m for m in self.data.markets}
        self.sys_by_id = {s.id: s for s in self.data.systems}

        # Multi-maps for graph traversal
        self.chunk_to_procs: Dict[str, List[str]] = {}
        for e in self.data.chunk_mentions_process:
            self.chunk_to_procs.setdefault(e.chunk_id, []).append(e.process_id)

        self.chunk_to_risks: Dict[str, List[str]] = {}
        for e in self.data.chunk_mentions_risk:
            self.chunk_to_risks.setdefault(e.chunk_id, []).append(e.risk_id)

        self.chunk_to_ctrls: Dict[str, List[str]] = {}
        for e in self.data.chunk_mentions_control:
            self.chunk_to_ctrls.setdefault(e.chunk_id, []).append(e.control_id)

        self.proc_to_risks: Dict[str, List[str]] = {}
        for e in self.data.process_has_risk:
            self.proc_to_risks.setdefault(e.process_id, []).append(e.risk_id)

        self.proc_to_pols: Dict[str, List[str]] = {}
        for e in self.data.policy_governs_process:
            self.proc_to_pols.setdefault(e.process_id, []).append(e.policy_id)

        self.proc_to_mkts: Dict[str, List[str]] = {}
        for e in self.data.process_operates_in_market:
            self.proc_to_mkts.setdefault(e.process_id, []).append(e.market_id)

        self.proc_to_systems: Dict[str, List[str]] = {}
        for e in self.data.system_supports_process:
            self.proc_to_systems.setdefault(e.process_id, []).append(e.system_id)

        self.risk_to_ctrls: Dict[str, List[str]] = {}
        for e in self.data.control_mitigates_risk:
            self.risk_to_ctrls.setdefault(e.risk_id, []).append(e.control_id)

        self.risk_to_procs: Dict[str, List[str]] = {}
        for e in self.data.process_has_risk:
            self.risk_to_procs.setdefault(e.risk_id, []).append(e.process_id)

        self.sys_to_procs: Dict[str, List[str]] = {}
        for e in self.data.system_supports_process:
            self.sys_to_procs.setdefault(e.system_id, []).append(e.process_id)

    def _get_processes_for_chunk(self, chunk_id: str) -> List[str]:
        """Resolves connected processes directly or via mentioned risks, systems, policies."""
        p_ids = list(self.chunk_to_procs.get(chunk_id, []))
        
        # From mentioned risks
        for r_id in self.chunk_to_risks.get(chunk_id, []):
            for p_id in self.risk_to_procs.get(r_id, []):
                if p_id not in p_ids:
                    p_ids.append(p_id)

        # From mentioned systems
        for s_id in self.data.chunk_mentions_system:
            if s_id.chunk_id == chunk_id:
                for p_id in self.sys_to_procs.get(s_id.system_id, []):
                    if p_id not in p_ids:
                        p_ids.append(p_id)

        # Fallback if no specific link: associate with all known processes in data
        if not p_ids and self.data.processes:
            p_ids = [p.id for p in self.data.processes[:2]]

        return p_ids

    # --------------------------------------------------------------------------
    # 1. VECTOR-TO-GRAPH EXECUTION
    # --------------------------------------------------------------------------
    def query_vector_to_graph(
        self,
        query_text: str,
        top_k: int = 3,
        similarity_threshold: float = 0.85
    ) -> Dict[str, Any]:
        """Executes unified Vector-to-Graph search."""
        query_vec = self.embedder.embed_text(query_text)
        
        # Step 1: Vector Search across Chunks
        scored_chunks = []
        for ch in self.data.chunks:
            if not ch.embedding:
                ch.embedding = self.embedder.embed_text(ch.content)
            dist = self.embedder.cosine_distance(query_vec, ch.embedding)
            if dist <= similarity_threshold:
                scored_chunks.append((ch, dist))

        scored_chunks.sort(key=lambda x: x[1])
        top_chunks = scored_chunks[:top_k]

        # Step 2: Traverse Spanner Property Graph for each top chunk
        results = []
        for ch, dist in top_chunks:
            proc_ids = self._get_processes_for_chunk(ch.id)
            for p_id in proc_ids:
                p = self.proc_by_id.get(p_id)
                if not p:
                    continue
                
                pol_ids = self.proc_to_pols.get(p_id, [])
                risk_ids = self.proc_to_risks.get(p_id, [])
                mkt_ids = self.proc_to_mkts.get(p_id, [])
                sys_ids = self.proc_to_systems.get(p_id, [])

                pol = self.pol_by_id.get(pol_ids[0]) if pol_ids else None
                mkt = self.mkt_by_id.get(mkt_ids[0]) if mkt_ids else None
                sys = self.sys_by_id.get(sys_ids[0]) if sys_ids else None

                for r_id in risk_ids:
                    r = self.risk_by_id.get(r_id)
                    if not r:
                        continue
                    ctrl_ids = self.risk_to_ctrls.get(r_id, [])
                    ctrl = self.ctrl_by_id.get(ctrl_ids[0]) if ctrl_ids else None

                    results.append({
                        "chunk_id": ch.id,
                        "chunk_snippet": ch.content[:140] + "...",
                        "vector_distance": round(dist, 4),
                        "similarity_score": round(1.0 - dist, 4),
                        "process_name": p.name,
                        "process_category": p.category,
                        "governing_policy": pol.name if pol else "N/A",
                        "policy_name": pol.name if pol else "N/A",
                        "regulatory_framework": pol.regulatory_framework if pol else "N/A",
                        "risk_name": r.name,
                        "risk_severity": r.severity,
                        "mitigating_control": ctrl.name if ctrl else "N/A",
                        "control_name": ctrl.name if ctrl else "N/A",
                        "control_effectiveness": ctrl.effectiveness if ctrl else "N/A",
                        "target_market": mkt.name if mkt else "N/A",
                        "market_name": mkt.name if mkt else "N/A",
                        "supporting_system": sys.name if sys else "N/A",
                        "system_name": sys.name if sys else "N/A",
                    })

        return {
            "query_type": "VECTOR_TO_GRAPH",
            "query_text": query_text,
            "spanner_sql": QUERY_VECTOR_TO_GRAPH_SQL,
            "matches_count": len(results),
            "records": results,
        }

    # --------------------------------------------------------------------------
    # 2. GRAPH-TO-VECTOR EXECUTION
    # --------------------------------------------------------------------------
    def query_graph_to_vector(
        self,
        regulatory_framework: str,
        incident_query: str,
        top_k: int = 5
    ) -> Dict[str, Any]:
        """Executes unified Graph-to-Vector search."""
        incident_vec = self.embedder.embed_text(incident_query)
        candidates = []

        # Find policies matching framework
        matching_pols = [p for p in self.data.policies if p.regulatory_framework.upper() == regulatory_framework.upper()]

        for pol in matching_pols:
            # Find processes governed by policy
            governed_procs = [
                self.proc_by_id[e.process_id]
                for e in self.data.policy_governs_process
                if e.policy_id == pol.id and e.process_id in self.proc_by_id
            ]

            for proc in governed_procs:
                # Find connected risks
                risk_ids = self.proc_to_risks.get(proc.id, [])
                sys_ids = self.proc_to_systems.get(proc.id, [])
                sys = self.sys_by_id.get(sys_ids[0]) if sys_ids else None

                for r_id in risk_ids:
                    risk = self.risk_by_id.get(r_id)
                    if not risk or risk.severity not in ["HIGH", "CRITICAL"]:
                        continue
                    ctrl_ids = self.risk_to_ctrls.get(r_id, [])
                    ctrl = self.ctrl_by_id.get(ctrl_ids[0]) if ctrl_ids else None

                    # Find grounded chunks mentioning risk
                    grounded_chunks = [
                        self.chunk_by_id[e.chunk_id]
                        for e in self.data.chunk_mentions_risk
                        if e.risk_id == r_id and e.chunk_id in self.chunk_by_id
                    ]
                    # Also include origin chunk
                    if risk.chunk_id in self.chunk_by_id and self.chunk_by_id[risk.chunk_id] not in grounded_chunks:
                        grounded_chunks.append(self.chunk_by_id[risk.chunk_id])

                    for ch in grounded_chunks:
                        if not ch.embedding:
                            ch.embedding = self.embedder.embed_text(ch.content)
                        dist = self.embedder.cosine_distance(incident_vec, ch.embedding)

                        candidates.append({
                            "policy_name": pol.name,
                            "regulatory_framework": pol.regulatory_framework,
                            "process_name": proc.name,
                            "risk_name": risk.name,
                            "risk_severity": risk.severity,
                            "mitigating_control": ctrl.name if ctrl else "N/A",
                            "control_name": ctrl.name if ctrl else "N/A",
                            "supporting_system": sys.name if sys else "N/A",
                            "system_name": sys.name if sys else "N/A",
                            "chunk_id": ch.id,
                            "chunk_text": ch.content[:140] + "...",
                            "incident_semantic_distance": round(dist, 4),
                            "relevance_score": round(1.0 - dist, 4),
                        })

        candidates.sort(key=lambda x: x["incident_semantic_distance"])
        top_candidates = candidates[:top_k]

        return {
            "query_type": "GRAPH_TO_VECTOR",
            "regulatory_framework": regulatory_framework,
            "incident_query": incident_query,
            "spanner_sql": QUERY_GRAPH_TO_VECTOR_SQL,
            "matches_count": len(top_candidates),
            "records": top_candidates,
        }

    # --------------------------------------------------------------------------
    # 3. FULL-TEXT SEARCH TO GRAPH EXECUTION
    # --------------------------------------------------------------------------
    def query_fts_to_graph(
        self,
        search_term: str,
        top_k: int = 5
    ) -> Dict[str, Any]:
        """Executes Full-Text Search (FTS) to Graph traversal."""
        terms = [t.lower().strip() for t in search_term.split() if t.strip()]
        hits = []

        for ch in self.data.chunks:
            c_lower = ch.content.lower()
            # Simple keyword scoring
            matched_terms = [t for t in terms if t in c_lower]
            if matched_terms:
                score = len(matched_terms) / len(terms) * 10.0 + c_lower.count(terms[0]) * 1.5
                hits.append((ch, round(score, 2)))

        hits.sort(key=lambda x: x[1], reverse=True)
        top_hits = hits[:top_k]

        results = []
        for ch, score in top_hits:
            proc_ids = self._get_processes_for_chunk(ch.id)
            for p_id in proc_ids:
                p = self.proc_by_id.get(p_id)
                if not p:
                    continue
                risk_ids = self.proc_to_risks.get(p_id, [])
                mkt_ids = self.proc_to_mkts.get(p_id, [])
                sys_ids = self.proc_to_systems.get(p_id, [])

                mkt = self.mkt_by_id.get(mkt_ids[0]) if mkt_ids else None
                sys = self.sys_by_id.get(sys_ids[0]) if sys_ids else None

                for r_id in risk_ids:
                    r = self.risk_by_id.get(r_id)
                    if not r:
                        continue
                    ctrl_ids = self.risk_to_ctrls.get(r_id, [])
                    ctrl = self.ctrl_by_id.get(ctrl_ids[0]) if ctrl_ids else None

                    results.append({
                        "chunk_id": ch.id,
                        "fts_score": score,
                        "process_name": p.name,
                        "risk_name": r.name,
                        "risk_severity": r.severity,
                        "control_name": ctrl.name if ctrl else "N/A",
                        "market_name": mkt.name if mkt else "N/A",
                        "jurisdiction": mkt.jurisdiction if mkt else "N/A",
                        "system_name": sys.name if sys else "N/A",
                    })

        return {
            "query_type": "FTS_TO_GRAPH",
            "search_term": search_term,
            "spanner_sql": QUERY_FTS_TO_GRAPH_SQL,
            "matches_count": len(results),
            "records": results,
        }

    # --------------------------------------------------------------------------
    # 4. 3-WAY HYBRID EXECUTION (Vector + FTS + Graph)
    # --------------------------------------------------------------------------
    def query_three_way_hybrid(
        self,
        query_text: str,
        search_keyword: str,
        top_k: int = 5,
        vector_weight: float = 0.7
    ) -> Dict[str, Any]:
        """Executes 3-Way Hybrid (Vector + Keyword + Multi-hop Graph)."""
        query_vec = self.embedder.embed_text(query_text)
        keyword_lower = search_keyword.lower()

        scored = []
        for ch in self.data.chunks:
            if not ch.embedding:
                ch.embedding = self.embedder.embed_text(ch.content)
            dist = self.embedder.cosine_distance(query_vec, ch.embedding)
            sim = 1.0 - dist
            kw_match = 1.0 if keyword_lower in ch.content.lower() else 0.0

            hybrid_score = (vector_weight * sim) + ((1.0 - vector_weight) * kw_match)
            if hybrid_score > 0.3 or kw_match > 0:
                scored.append((ch, dist, kw_match, hybrid_score))

        scored.sort(key=lambda x: x[3], reverse=True)
        top_scored = scored[:top_k]

        results = []
        for ch, dist, kw, score in top_scored:
            proc_ids = self._get_processes_for_chunk(ch.id)
            for p_id in proc_ids:
                p = self.proc_by_id.get(p_id)
                if not p:
                    continue
                pol_ids = self.proc_to_pols.get(p_id, [])
                risk_ids = self.proc_to_risks.get(p_id, [])
                mkt_ids = self.proc_to_mkts.get(p_id, [])
                sys_ids = self.proc_to_systems.get(p_id, [])

                pol = self.pol_by_id.get(pol_ids[0]) if pol_ids else None
                mkt = self.mkt_by_id.get(mkt_ids[0]) if mkt_ids else None
                sys = self.sys_by_id.get(sys_ids[0]) if sys_ids else None

                for r_id in risk_ids:
                    r = self.risk_by_id.get(r_id)
                    if not r:
                        continue
                    ctrl_ids = self.risk_to_ctrls.get(r_id, [])
                    ctrl = self.ctrl_by_id.get(ctrl_ids[0]) if ctrl_ids else None

                    results.append({
                        "chunk_id": ch.id,
                        "chunk_snippet": ch.content[:130] + "...",
                        "hybrid_score": round(score, 4),
                        "vector_distance": round(dist, 4),
                        "keyword_matched": bool(kw),
                        "policy_name": pol.name if pol else "N/A",
                        "process_name": p.name,
                        "risk_name": r.name,
                        "control_name": ctrl.name if ctrl else "N/A",
                        "market_name": mkt.name if mkt else "N/A",
                        "system_name": sys.name if sys else "N/A",
                    })

        return {
            "query_type": "THREE_WAY_HYBRID",
            "query_text": query_text,
            "search_keyword": search_keyword,
            "spanner_sql": QUERY_3WAY_HYBRID_SQL,
            "matches_count": len(results),
            "records": results,
        }
