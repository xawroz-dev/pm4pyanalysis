"""Production Google Cloud Spanner / Spanner Omni Client for Property Graph & Vector Search."""
import os
from typing import List, Dict, Any, Optional
from models.schema import KnowledgeGraphData
from models.ddl_generator import generate_spanner_ddl


class SpannerOmniClient:
    """Client for deploying schema and executing Graph & Vector queries on Cloud Spanner / Spanner Omni."""

    def __init__(
        self,
        project_id: Optional[str] = None,
        instance_id: Optional[str] = None,
        database_id: Optional[str] = None,
    ):
        self.project_id = project_id or os.getenv("SPANNER_PROJECT_ID", "demo-grc-spanner")
        self.instance_id = instance_id or os.getenv("SPANNER_INSTANCE_ID", "grc-instance")
        self.database_id = database_id or os.getenv("SPANNER_DATABASE_ID", "grc-db")
        self.client = None
        self.instance = None
        self.database = None
        self._connected = False

    def connect(self) -> bool:
        """Attempts connection to Google Cloud Spanner instance."""
        try:
            from google.cloud import spanner
            self.client = spanner.Client(project=self.project_id)
            self.instance = self.client.instance(self.instance_id)
            self.database = self.instance.database(self.database_id)
            self._connected = True
            print(f"[SpannerClient] Connected to Spanner: {self.project_id}/{self.instance_id}/{self.database_id}")
            return True
        except Exception as e:
            print(f"[SpannerClient] Running in dry-run mode (No GCP Spanner credentials: {e})")
            self._connected = False
            return False

    def deploy_schema(self, graph_name: str = "EnterpriseGRCGraph") -> str:
        """Deploys DDL schema to Spanner or returns DDL in dry-run mode."""
        ddl_script = generate_spanner_ddl(graph_name=graph_name)
        if self._connected and self.database:
            print("[SpannerClient] Executing DDL update on Cloud Spanner...")
            # Split DDL by double newlines or statements
            statements = [s.strip() for s in ddl_script.split(";") if s.strip() and not s.strip().startswith("--")]
            op = self.database.update_ddl(statements)
            op.result()
            print("[SpannerClient] DDL deployment completed successfully.")
        else:
            print("[SpannerClient] [Dry-Run] DDL statements generated for Cloud Spanner / Spanner Omni.")
        return ddl_script

    def insert_graph_data(self, data: KnowledgeGraphData) -> Dict[str, int]:
        """Inserts all nodes and edges into Spanner tables using mutations or DML."""
        stats = data.stats()
        if self._connected and self.database:
            def _insert_tx(transaction):
                # Batch insert Document
                if data.documents:
                    transaction.insert_or_update(
                        'Document',
                        columns=['id', 'title', 'source_type', 'uploaded_at', 'raw_text'],
                        values=[[d.id, d.title, d.source_type, d.uploaded_at, d.raw_text] for d in data.documents]
                    )
                # Batch insert Chunk
                if data.chunks:
                    transaction.insert_or_update(
                        'Chunk',
                        columns=['id', 'document_id', 'chunk_index', 'content', 'token_count', 'embedding'],
                        values=[[c.id, c.document_id, c.chunk_index, c.content, c.token_count, c.embedding] for c in data.chunks]
                    )
                # Batch insert Process
                if data.processes:
                    transaction.insert_or_update(
                        'Process',
                        columns=['id', 'name', 'category', 'description', 'owner_department', 'chunk_id'],
                        values=[[p.id, p.name, p.category, p.description, p.owner_department, p.chunk_id] for p in data.processes]
                    )
                # Batch insert Policy
                if data.policies:
                    transaction.insert_or_update(
                        'Policy',
                        columns=['id', 'name', 'regulatory_framework', 'description', 'version', 'effective_date', 'chunk_id'],
                        values=[[p.id, p.name, p.regulatory_framework, p.description, p.version, p.effective_date, p.chunk_id] for p in data.policies]
                    )
                # Batch insert Risk
                if data.risks:
                    transaction.insert_or_update(
                        'Risk',
                        columns=['id', 'name', 'category', 'severity', 'description', 'impact_score', 'chunk_id'],
                        values=[[r.id, r.name, r.category, r.severity, r.description, r.impact_score, r.chunk_id] for r in data.risks]
                    )
                # Batch insert Control
                if data.controls:
                    transaction.insert_or_update(
                        'Control',
                        columns=['id', 'name', 'control_type', 'description', 'frequency', 'effectiveness', 'chunk_id'],
                        values=[[c.id, c.name, c.control_type, c.description, c.frequency, c.effectiveness, c.chunk_id] for c in data.controls]
                    )
                # Batch insert Market
                if data.markets:
                    transaction.insert_or_update(
                        'Market',
                        columns=['id', 'name', 'region', 'currency', 'jurisdiction', 'chunk_id'],
                        values=[[m.id, m.name, m.region, m.currency, m.jurisdiction, m.chunk_id] for m in data.markets]
                    )
                # Batch insert System
                if data.systems:
                    transaction.insert_or_update(
                        'System',
                        columns=['id', 'name', 'tier', 'cloud_provider', 'description', 'chunk_id'],
                        values=[[s.id, s.name, s.tier, s.cloud_provider, s.description, s.chunk_id] for s in data.systems]
                    )
                # Batch insert Edges
                if data.process_has_risk:
                    transaction.insert_or_update(
                        'ProcessHasRisk',
                        columns=['process_id', 'risk_id', 'inherent_risk_level', 'chunk_id'],
                        values=[[e.process_id, e.risk_id, e.inherent_risk_level, e.chunk_id] for e in data.process_has_risk]
                    )
                if data.control_mitigates_risk:
                    transaction.insert_or_update(
                        'ControlMitigatesRisk',
                        columns=['control_id', 'risk_id', 'mitigation_percentage', 'chunk_id'],
                        values=[[e.control_id, e.risk_id, e.mitigation_percentage, e.chunk_id] for e in data.control_mitigates_risk]
                    )
                if data.policy_governs_process:
                    transaction.insert_or_update(
                        'PolicyGovernsProcess',
                        columns=['policy_id', 'process_id', 'compliance_status', 'chunk_id'],
                        values=[[e.policy_id, e.process_id, e.compliance_status, e.chunk_id] for e in data.policy_governs_process]
                    )
                if data.process_operates_in_market:
                    transaction.insert_or_update(
                        'ProcessOperatesInMarket',
                        columns=['process_id', 'market_id', 'volume_tier', 'chunk_id'],
                        values=[[e.process_id, e.market_id, e.volume_tier, e.chunk_id] for e in data.process_operates_in_market]
                    )
                if data.system_supports_process:
                    transaction.insert_or_update(
                        'SystemSupportsProcess',
                        columns=['system_id', 'process_id', 'criticality', 'chunk_id'],
                        values=[[e.system_id, e.process_id, e.criticality, e.chunk_id] for e in data.system_supports_process]
                    )

            self.database.run_in_transaction(_insert_tx)
            print(f"[SpannerClient] Successfully inserted {stats['total_nodes']} nodes and {stats['total_edges']} edges into Spanner.")
        else:
            print(f"[SpannerClient] [Dry-Run] Staged {stats['total_nodes']} nodes and {stats['total_edges']} edges for insertion.")

        return stats

    def execute_hybrid_query(self, sql_query: str, params: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Executes a SQL + GQL query against Cloud Spanner."""
        if self._connected and self.database:
            with self.database.snapshot() as snapshot:
                results = snapshot.execute_sql(sql_query, params=params)
                rows = [dict(row) for row in results]
                return rows
        else:
            print("[SpannerClient] [Dry-Run] Executing against simulated in-memory Spanner engine.")
            return []
