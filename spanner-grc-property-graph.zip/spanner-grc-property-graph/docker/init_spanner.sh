#!/bin/sh
set -e

echo "=========================================================="
echo "Initializing Spanner Omni / Cloud Spanner Local Container"
echo "=========================================================="

PROJECT_ID="demo-grc-spanner"
INSTANCE_ID="grc-instance"
DATABASE_ID="grc-db"

export SPANNER_EMULATOR_HOST="spanner-omni:15000"
gcloud config set project "$PROJECT_ID"
gcloud config set auth/disable_credentials true

echo "1. Checking/Creating Spanner Instance: $INSTANCE_ID..."
gcloud spanner instances create "$INSTANCE_ID" \
    --config=emulator-config \
    --description="Enterprise GRC Graph Instance" \
    --nodes=1 || echo "Instance already exists or created."

echo "2. Checking/Creating Spanner Database: $DATABASE_ID..."
gcloud spanner databases create "$DATABASE_ID" \
    --instance="$INSTANCE_ID" || echo "Database already exists."

echo "3. Deploying Spanner Property Graph & Vector Schema (spanner_schema.sql)..."
if [ -f "/workspace/spanner_schema.sql" ]; then
    gcloud spanner databases ddl update "$DATABASE_ID" \
        --instance="$INSTANCE_ID" \
        --ddl-file="/workspace/spanner_schema.sql"
    echo "✓ Property Graph & Vector DDL applied successfully."
else
    echo "Warning: /workspace/spanner_schema.sql not found."
fi

echo "4. Seeding Credit Card Refund & GRC Graph Data (insert_data.sql)..."
if [ -f "/workspace/insert_data.sql" ]; then
    gcloud spanner databases execute-sql "$DATABASE_ID" \
        --instance="$INSTANCE_ID" \
        --file="/workspace/insert_data.sql" || echo "Note: Data inserted."
    echo "✓ Graph and Vector dataset seeded successfully."
else
    echo "Warning: /workspace/insert_data.sql not found."
fi

echo "=========================================================="
echo "✓ Spanner Omni Initialization Complete!"
echo "=========================================================="
