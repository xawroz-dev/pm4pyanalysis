#!/bin/bash
set -e

# ==============================================================================
# Run Google Spanner Omni (Official Self-Managed Distributed Engine) with Docker
# ==============================================================================

IMAGE="us-docker.pkg.dev/spanner-omni/images/spanner-omni:2026.r1-beta.2"
CONTAINER_NAME="spanner-omni"
VOLUME_NAME="spanner-omni-data"

echo "=================================================================="
echo "Starting Google Spanner Omni (Single-Server Container)"
echo "Image: $IMAGE"
echo "=================================================================="

# 1. Create persistent Docker volume
echo "1. Creating Docker volume: $VOLUME_NAME..."
docker volume create $VOLUME_NAME >/dev/null 2>&1 || true

# 2. Stop and remove existing container if running
docker rm -f $CONTAINER_NAME >/dev/null 2>&1 || true

# 3. Start Spanner Omni container
echo "2. Launching Spanner Omni container on ports 15000 (gRPC) & 15026 (Admin Console)..."
docker run -d \
  --name $CONTAINER_NAME \
  -v "${VOLUME_NAME}:/spanner" \
  -p 15000:15000 \
  -p 15026:15026 \
  $IMAGE \
  start-single-server

echo "3. Waiting for Spanner Omni to initialize on port 15000..."
until nc -z localhost 15000 2>/dev/null; do
  echo "   Waiting for Spanner Omni gRPC endpoint..."
  sleep 2
done

echo "✓ Spanner Omni is UP and listening on localhost:15000 (Admin Console: http://localhost:15026)"

# 4. Optional: Bootstrap Instance, Database, Schema, and Data
echo "4. Bootstrapping Instance & Database via gcloud..."
export SPANNER_EMULATOR_HOST="localhost:15000"
gcloud config set auth/disable_credentials true >/dev/null 2>&1 || true
gcloud config set project demo-grc-spanner >/dev/null 2>&1 || true

gcloud spanner instances create grc-instance \
    --config=emulator-config \
    --description="Enterprise GRC Instance" \
    --nodes=1 || true

gcloud spanner databases create grc-db --instance=grc-instance || true

if [ -f "spanner_schema.sql" ]; then
    echo "5. Applying Property Graph & Vector DDL (spanner_schema.sql)..."
    gcloud spanner databases ddl update grc-db \
        --instance=grc-instance \
        --ddl-file=spanner_schema.sql
    echo "✓ Schema applied."
fi

if [ -f "credit_refund_demo/insert_data.sql" ]; then
    echo "6. Seeding Credit Refund Graph & Vector Data (insert_data.sql)..."
    gcloud spanner databases execute-sql grc-db \
        --instance=grc-instance \
        --file=credit_refund_demo/insert_data.sql || true
    echo "✓ Data seeded."
fi

echo "=================================================================="
echo "✓ Spanner Omni Ready! Connect your client to: localhost:15000"
echo "=================================================================="
