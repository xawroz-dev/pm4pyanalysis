-- =============================================================================
-- Cloud Spanner / Spanner Omni Teardown DDL
-- Drops Property Graph, Indexes, Edge Tables, and Node Tables in Reverse Order
-- =============================================================================

-- 1. Drop Property Graph Definition
DROP PROPERTY GRAPH IF EXISTS EnterpriseGRCGraph;

-- 2. Drop Indexes
DROP SEARCH INDEX IF EXISTS ChunkSearchIndex;
DROP VECTOR INDEX IF EXISTS ChunkVectorIndex;

-- 3. Drop Edge Tables
DROP TABLE IF EXISTS ChunkMentionsSystem;
DROP TABLE IF EXISTS ChunkMentionsMarket;
DROP TABLE IF EXISTS ChunkMentionsPolicy;
DROP TABLE IF EXISTS ChunkMentionsControl;
DROP TABLE IF EXISTS ChunkMentionsRisk;
DROP TABLE IF EXISTS ChunkMentionsProcess;
DROP TABLE IF EXISTS ControlAppliesToSystem;
DROP TABLE IF EXISTS SystemSupportsProcess;
DROP TABLE IF EXISTS ProcessOperatesInMarket;
DROP TABLE IF EXISTS PolicyGovernsProcess;
DROP TABLE IF EXISTS ControlMitigatesRisk;
DROP TABLE IF EXISTS ProcessHasRisk;
DROP TABLE IF EXISTS DocumentHasChunk;

-- 4. Drop Node Tables
DROP TABLE IF EXISTS System;
DROP TABLE IF EXISTS Market;
DROP TABLE IF EXISTS Control;
DROP TABLE IF EXISTS Risk;
DROP TABLE IF EXISTS Policy;
DROP TABLE IF EXISTS Process;
DROP TABLE IF EXISTS Chunk;
DROP TABLE IF EXISTS Document;
