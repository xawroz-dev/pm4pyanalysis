# Sample Queries: Enterprise GRC Spanner Property Graph

This document provides a catalog of sample queries for Google Cloud Spanner / Spanner Omni, illustrating standard SQL queries, GQL Property Graph traversals, Vector search with `COSINE_DISTANCE`, Full-Text search with `SEARCH()`, and **unified single-query hybrid search patterns**.

---

## 1. Basic Node & Relational Lookups

### Show all Governed Processes
```sql
SELECT id, name, category, owner_department, chunk_id
FROM Process
ORDER BY category;
```

### Show Critical Risks and their Origin Chunks
```sql
SELECT id, name, severity, impact_score, chunk_id
FROM Risk
WHERE severity = 'CRITICAL'
ORDER BY impact_score DESC;
```

---

## 2. Standard GQL Graph Traversals

### Trace Process to Risks and Mitigating Controls
```sql
GRAPH EnterpriseGRCGraph
MATCH (p:Process)-[:HAS_RISK]->(r:Risk)<-[:MITIGATES_RISK]-(c:Control)
RETURN p.name AS process_name, r.name AS risk_name, r.severity AS severity, c.name AS control_name, c.effectiveness AS effectiveness
ORDER BY p.name;
```

### Trace Regulatory Policy to Governed Processes & Supporting Systems
```sql
GRAPH EnterpriseGRCGraph
MATCH (pol:Policy)-[:GOVERNS_PROCESS]->(p:Process)<-[:SUPPORTS_PROCESS]-(s:System)
WHERE pol.regulatory_framework = 'DORA'
RETURN pol.name AS policy, p.name AS process, s.name AS system, s.cloud_provider AS cloud_provider;
```

### Find Processes Operating in the European Union (SEPA) Market
```sql
GRAPH EnterpriseGRCGraph
MATCH (p:Process)-[:OPERATES_IN_MARKET]->(m:Market {jurisdiction: 'EUROPEAN_UNION'})
RETURN p.name AS process, p.category AS category, m.name AS market, m.currency AS currency;
```

---

## 3. Unified Single-Query Hybrid Search Patterns

### Pattern 1: Vector-to-Graph (Semantic Search -> Graph Expansion)
Finds chunks semantically closest to the user's inquiry using `COSINE_DISTANCE`, and in the **same query** traverses the Spanner Property Graph to retrieve connected Processes, Policies, Risks, Controls, and Markets.

```sql
WITH TopChunks AS (
  SELECT
    id AS chunk_id,
    document_id,
    content AS chunk_snippet,
    COSINE_DISTANCE(embedding, @query_vector) AS vector_distance
  FROM Chunk
  WHERE COSINE_DISTANCE(embedding, @query_vector) < 0.85
  ORDER BY vector_distance ASC
  LIMIT 5
)
SELECT
  c.chunk_id,
  c.chunk_snippet,
  ROUND(c.vector_distance, 4) AS distance,
  g.process_name,
  g.process_category,
  g.governing_policy,
  g.regulatory_framework,
  g.risk_name,
  g.risk_severity,
  g.mitigating_control,
  g.control_effectiveness,
  g.target_market,
  g.supporting_system
FROM TopChunks c
CROSS JOIN GRAPH_TABLE(
  EnterpriseGRCGraph
  MATCH (ch:Chunk WHERE ch.id = c.chunk_id)-[:MENTIONS_PROCESS]->(p:Process)
        -[:HAS_RISK]->(r:Risk)
        <-[:MITIGATES_RISK]-(ctrl:Control)
        , (p)<-[:GOVERNS_PROCESS]-(pol:Policy)
        , (p)-[:OPERATES_IN_MARKET]->(m:Market)
        , (s:System)-[:SUPPORTS_PROCESS]->(p)
  COLUMNS (
    p.name AS process_name,
    p.category AS process_category,
    pol.name AS governing_policy,
    pol.regulatory_framework AS regulatory_framework,
    r.name AS risk_name,
    r.severity AS risk_severity,
    ctrl.name AS mitigating_control,
    ctrl.effectiveness AS control_effectiveness,
    m.name AS target_market,
    s.name AS supporting_system
  )
) AS g
ORDER BY distance ASC, g.risk_severity DESC;
```

---

### Pattern 2: Graph-to-Vector (Regulatory Traversal -> Semantic Evidence Ranking)
Traverses the graph starting from a regulatory policy (e.g. `DORA`), finds all connected processes and critical risks, then retrieves grounded document chunks and ranks them by cosine similarity against an operational incident prompt in a single query.

```sql
WITH PolicyGraphPaths AS (
  SELECT * FROM GRAPH_TABLE(
    EnterpriseGRCGraph
    MATCH (pol:Policy WHERE pol.regulatory_framework = @regulatory_framework)
          -[:GOVERNS_PROCESS]->(p:Process)
          -[:HAS_RISK]->(r:Risk WHERE r.severity IN ('HIGH', 'CRITICAL'))
          <-[:MITIGATES_RISK]-(ctrl:Control)
          , (s:System)-[:SUPPORTS_PROCESS]->(p)
          , (ch:Chunk)-[:MENTIONS_RISK]->(r)
    COLUMNS (
      pol.name AS policy_name,
      pol.regulatory_framework AS framework,
      p.name AS process_name,
      r.name AS risk_name,
      r.severity AS risk_severity,
      ctrl.name AS control_name,
      s.name AS system_name,
      ch.id AS chunk_id,
      ch.content AS chunk_text,
      ch.embedding AS chunk_embedding
    )
  )
)
SELECT
  policy_name,
  framework,
  process_name,
  risk_name,
  risk_severity,
  control_name,
  system_name,
  chunk_id,
  chunk_text,
  ROUND(COSINE_DISTANCE(chunk_embedding, @incident_vector), 4) AS incident_semantic_distance
FROM PolicyGraphPaths
ORDER BY incident_semantic_distance ASC
LIMIT 10;
```

---

### Pattern 3: Full-Text Search (FTS) to Graph
Uses Spanner's full-text `SEARCH()` index on chunk text to locate keywords (e.g., `'kill switch'`) and immediately computes the compliance and infrastructure blast radius across processes and markets.

```sql
WITH SearchHits AS (
  SELECT
    id AS chunk_id,
    content AS chunk_snippet,
    SCORE(ChunkSearchIndex, @search_query) AS fts_score
  FROM Chunk
  WHERE SEARCH(content, @search_query)
  ORDER BY fts_score DESC
  LIMIT 5
)
SELECT
  s.chunk_id,
  ROUND(s.fts_score, 2) AS search_score,
  g.process_name,
  g.risk_name,
  g.risk_severity,
  g.control_name,
  g.market_name,
  g.jurisdiction,
  g.system_name
FROM SearchHits s
CROSS JOIN GRAPH_TABLE(
  EnterpriseGRCGraph
  MATCH (ch:Chunk WHERE ch.id = s.chunk_id)-[:MENTIONS_PROCESS]->(p:Process)
        -[:HAS_RISK]->(r:Risk)
        <-[:MITIGATES_RISK]-(ctrl:Control)
        , (p)-[:OPERATES_IN_MARKET]->(m:Market)
        , (sys:System)-[:SUPPORTS_PROCESS]->(p)
  COLUMNS (
    p.name AS process_name,
    r.name AS risk_name,
    r.severity AS risk_severity,
    ctrl.name AS control_name,
    m.name AS market_name,
    m.jurisdiction AS jurisdiction,
    sys.name AS system_name
  )
) AS g
ORDER BY s.fts_score DESC;
```

---

### Pattern 4: 3-Way Hybrid (Vector + Keyword + Multi-Hop Graph)
Blends vector cosine similarity and full-text keyword matching in SQL, and expands the 2-hop graph neighborhood for LLM RAG synthesis.

```sql
WITH HybridScoredChunks AS (
  SELECT
    id AS chunk_id,
    content AS chunk_snippet,
    COSINE_DISTANCE(embedding, @query_vector) AS vec_distance,
    IF(SEARCH(content, @search_query), 1.0, 0.0) AS keyword_match
  FROM Chunk
  WHERE COSINE_DISTANCE(embedding, @query_vector) < 0.85
     OR SEARCH(content, @search_query)
  ORDER BY (0.7 * (1.0 - COSINE_DISTANCE(embedding, @query_vector)) + 0.3 * IF(SEARCH(content, @search_query), 1.0, 0.0)) DESC
  LIMIT 5
)
SELECT
  h.chunk_id,
  h.chunk_snippet,
  ROUND(h.vec_distance, 4) AS vec_distance,
  h.keyword_match,
  g.policy_name,
  g.process_name,
  g.risk_name,
  g.control_name,
  g.market_name,
  g.system_name
FROM HybridScoredChunks h
LEFT JOIN GRAPH_TABLE(
  EnterpriseGRCGraph
  MATCH (ch:Chunk WHERE ch.id = h.chunk_id)
        -[:MENTIONS_PROCESS|MENTIONS_RISK|MENTIONS_CONTROL]->(entity)
        -[*1..2]-(connected)
  COLUMNS (
    entity.name AS entity_name,
    connected.name AS connected_name
  )
) AS g ON TRUE;
```
