#!/usr/bin/env python3
"""Interactive End-to-End CLI Demonstration of Spanner GRC Property Graph with Single-Query Hybrid Search.

Demonstrates:
1. Ingestion of GRC documents (Payments, Cloud Resilience, Algo Trading, GenAI)
2. Chunking & 768-dimensional Vector Embeddings
3. Structured LLM Entity & Relationship Extraction with Chunk Grounding
4. Execution of Unified Single-Query Hybrid Search Patterns:
   - Pattern 1: Vector-to-Graph (Semantic Search -> Graph Expansion)
   - Pattern 2: Graph-to-Vector (Policy/Market Traversal -> Ranked Evidence Chunks)
   - Pattern 3: Full-Text Search to Graph (Keyword Filter -> Graph Blast Radius)
   - Pattern 4: 3-Way Hybrid (Vector + Keyword + Multi-hop Graph)
"""

import sys
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.syntax import Syntax
from rich import box

from sample_data.loader import load_sample_documents
from pipeline.ingest import IngestionPipeline
from engine.local_simulator import SpannerLocalGraphSimulator
from models.ddl_generator import generate_spanner_ddl, export_ddl_file


def run_demo():
    console = Console()
    console.print(Panel.fit(
        "[bold cyan]Cloud Spanner / Spanner Omni Property Graph & Vector Hybrid Search[/bold cyan]\n"
        "[dim]Enterprise Governance, Risk, Compliance (GRC) Knowledge Retrieval System[/dim]",
        box=box.DOUBLE,
        border_style="cyan"
    ))

    # --------------------------------------------------------------------------
    # 1. DOCUMENT LOADING & INGESTION
    # --------------------------------------------------------------------------
    with console.status("[bold green]Loading GRC documents and executing Ingestion Pipeline...[/bold green]"):
        documents = load_sample_documents()
        pipeline = IngestionPipeline()
        kg = pipeline.process_documents(documents)
        simulator = SpannerLocalGraphSimulator(data=kg)
        export_ddl_file("spanner_schema.sql")

    # Document Table
    doc_table = Table(title="Uploaded Governance Documents", box=box.ROUNDED, show_header=True)
    doc_table.add_column("Document ID", style="cyan", no_wrap=True)
    doc_table.add_column("Title", style="bold white")
    doc_table.add_column("Source Type", style="magenta")
    doc_table.add_column("Size", justify="right", style="green")

    for d in kg.documents:
        doc_table.add_row(d.id, d.title, d.source_type, f"{len(d.raw_text)} chars")
    console.print(doc_table)
    console.print()

    # Graph Topology Stats
    stats = kg.stats()
    stats_table = Table(title="Spanner Property Graph Ingestion Summary", box=box.ROUNDED)
    stats_table.add_column("Node Table", style="yellow")
    stats_table.add_column("Node Count", justify="right", style="bold green")
    stats_table.add_column("Edge Table / Relationship", style="blue")
    stats_table.add_column("Edge Count", justify="right", style="bold cyan")

    node_data = [
        ("Document", stats["documents"]),
        ("Chunk (Vector Indexed)", stats["chunks"]),
        ("Process", stats["processes"]),
        ("Policy", stats["policies"]),
        ("Risk", stats["risks"]),
        ("Control", stats["controls"]),
        ("Market", stats["markets"]),
        ("System", stats["systems"]),
    ]
    edge_data = [
        ("DocumentHasChunk", len(kg.document_has_chunk)),
        ("ProcessHasRisk", len(kg.process_has_risk)),
        ("ControlMitigatesRisk", len(kg.control_mitigates_risk)),
        ("PolicyGovernsProcess", len(kg.policy_governs_process)),
        ("ProcessOperatesInMarket", len(kg.process_operates_in_market)),
        ("SystemSupportsProcess", len(kg.system_supports_process)),
        ("ControlAppliesToSystem", len(kg.control_applies_to_system)),
        ("ChunkMentionsEntity (Provenance)", len(kg.chunk_mentions_process) + len(kg.chunk_mentions_risk) + len(kg.chunk_mentions_control)),
    ]

    for (nt, nc), (et, ec) in zip(node_data, edge_data):
        stats_table.add_row(nt, str(nc), et, str(ec))

    console.print(stats_table)
    console.print(f"[bold green]Total Graph Nodes:[/bold green] {stats['total_nodes']}  |  [bold cyan]Total Graph Edges:[/bold cyan] {stats['total_edges']}\n")

    # --------------------------------------------------------------------------
    # PATTERN 1: VECTOR-TO-GRAPH
    # --------------------------------------------------------------------------
    console.print(Panel(
        "[bold yellow]Pattern 1: Vector-to-Graph (Semantic Search -> Graph Expansion in Single Query)[/bold yellow]\n"
        "[dim]Seed query uses COSINE_DISTANCE on chunk vectors to find top matches, then traverses graph in the same query to find connected risks, controls, policies, and markets.[/dim]",
        box=box.SQUARE
    ))

    prompt_1 = "What preventative controls mitigate money laundering and OFAC sanctions violations?"
    console.print(f"[bold]User Prompt:[/bold] '{prompt_1}'")
    
    res_1 = simulator.query_vector_to_graph(prompt_1, top_k=2)
    
    t1 = Table(box=box.HEAVY_EDGE)
    t1.add_column("Chunk ID", style="cyan", no_wrap=True)
    t1.add_column("Vector Dist", justify="right", style="green")
    t1.add_column("Governed Process", style="white")
    t1.add_column("Policy / Standard", style="magenta")
    t1.add_column("Identified Risk", style="red")
    t1.add_column("Mitigating Control", style="yellow")
    t1.add_column("Target Market", style="blue")

    for r in res_1["records"]:
        t1.add_row(
            r["chunk_id"],
            str(r["vector_distance"]),
            r["process_name"],
            f"{r['governing_policy']}\n({r['regulatory_framework']})",
            f"{r['risk_name']}\n[bold red][{r['risk_severity']}][/bold red]",
            f"{r['mitigating_control']}\n[bold green][{r['control_effectiveness']}][/bold green]",
            r["target_market"]
        )
    console.print(t1)
    console.print()

    # --------------------------------------------------------------------------
    # PATTERN 2: GRAPH-TO-VECTOR
    # --------------------------------------------------------------------------
    console.print(Panel(
        "[bold yellow]Pattern 2: Graph-to-Vector (Graph Traversal -> Vector Semantic Ranking in Single Query)[/bold yellow]\n"
        "[dim]Starts by filtering the graph on regulatory framework 'DORA', traverses down to High/Critical risks and IT systems, and ranks grounded evidence chunks by cosine distance against an operational incident query.[/dim]",
        box=box.SQUARE
    ))

    framework_2 = "DORA"
    incident_prompt_2 = "Catastrophic cloud data center region failure during peak payment volume"
    console.print(f"[bold]Target Policy Framework:[/bold] '{framework_2}'  |  [bold]Incident Query:[/bold] '{incident_prompt_2}'")

    res_2 = simulator.query_graph_to_vector(regulatory_framework=framework_2, incident_query=incident_prompt_2, top_k=2)

    t2 = Table(box=box.HEAVY_EDGE)
    t2.add_column("Policy", style="magenta")
    t2.add_column("Governed Process", style="white")
    t2.add_column("Critical Risk", style="red")
    t2.add_column("Mitigating Control", style="yellow")
    t2.add_column("Supporting System", style="blue")
    t2.add_column("Semantic Dist", justify="right", style="green")
    t2.add_column("Grounded Chunk Evidence", style="dim white")

    for r in res_2["records"]:
        t2.add_row(
            r["policy_name"],
            r["process_name"],
            r["risk_name"],
            r["mitigating_control"],
            r["system_name"],
            str(r["incident_semantic_distance"]),
            r["chunk_text"]
        )
    console.print(t2)
    console.print()

    # --------------------------------------------------------------------------
    # PATTERN 3: FULL-TEXT SEARCH (FTS) TO GRAPH
    # --------------------------------------------------------------------------
    console.print(Panel(
        "[bold yellow]Pattern 3: Full-Text Search to Graph (Keyword Match -> Blast Radius Traversal)[/bold yellow]\n"
        "[dim]Uses Spanner's SEARCH() full-text search index on Chunk content for keyword 'kill switch' and instantly computes the blast radius across processes, markets, and IT infrastructure.[/dim]",
        box=box.SQUARE
    ))

    search_kw = "kill switch"
    console.print(f"[bold]Search Query:[/bold] '{search_kw}'")
    res_3 = simulator.query_fts_to_graph(search_term=search_kw, top_k=2)

    t3 = Table(box=box.HEAVY_EDGE)
    t3.add_column("Chunk ID", style="cyan", no_wrap=True)
    t3.add_column("FTS Score", justify="right", style="green")
    t3.add_column("Process", style="white")
    t3.add_column("Risk Addressed", style="red")
    t3.add_column("Enforced Control", style="yellow")
    t3.add_column("Operating Market", style="blue")
    t3.add_column("Execution System", style="magenta")

    for r in res_3["records"]:
        t3.add_row(
            r["chunk_id"],
            str(r["fts_score"]),
            r["process_name"],
            r["risk_name"],
            r["control_name"],
            r["market_name"],
            r["system_name"]
        )
    console.print(t3)
    console.print()

    # --------------------------------------------------------------------------
    # PATTERN 4: 3-WAY HYBRID (Vector + Keyword + Multi-Hop Graph)
    # --------------------------------------------------------------------------
    console.print(Panel(
        "[bold yellow]Pattern 4: 3-Way Hybrid (Vector + Keyword Match + Multi-Hop Graph Expansion)[/bold yellow]\n"
        "[dim]Blends semantic vector similarity and keyword filtering, then traverses multi-hop graph paths for comprehensive context synthesis.[/dim]",
        box=box.SQUARE
    ))

    prompt_4 = "Generative AI conversational banking agent privacy governance"
    kw_4 = "hallucination"
    console.print(f"[bold]Semantic Query:[/bold] '{prompt_4}'  |  [bold]Keyword:[/bold] '{kw_4}'")

    res_4 = simulator.query_three_way_hybrid(query_text=prompt_4, search_keyword=kw_4, top_k=2)

    t4 = Table(box=box.HEAVY_EDGE)
    t4.add_column("Chunk ID", style="cyan", no_wrap=True)
    t4.add_column("Hybrid Score", justify="right", style="green")
    t4.add_column("Vec Dist", justify="right", style="dim green")
    t4.add_column("Keyword Matched", justify="center", style="yellow")
    t4.add_column("Governing Policy", style="magenta")
    t4.add_column("Process & Risk", style="white")
    t4.add_column("Mitigating Control", style="yellow")

    for r in res_4["records"]:
        t4.add_row(
            r["chunk_id"],
            str(r["hybrid_score"]),
            str(r["vector_distance"]),
            "✓ YES" if r["keyword_matched"] else "✗ NO",
            r["policy_name"],
            f"{r['process_name']}\n-> [red]{r['risk_name']}[/red]",
            r["control_name"]
        )
    console.print(t4)
    console.print()

    # Print DDL summary
    console.print(Panel(
        "[bold green]Spanner DDL & Schema Export Ready[/bold green]\n"
        "[dim]The complete Cloud Spanner / Spanner Omni Property Graph DDL has been exported to [bold cyan]spanner_schema.sql[/bold cyan].[/dim]\n"
        "To deploy on Google Cloud Spanner:\n"
        "  1. [white]gcloud spanner databases create grc-db --instance=grc-instance[/white]\n"
        "  2. [white]gcloud spanner databases ddl update grc-db --instance=grc-instance --ddl-file=spanner_schema.sql[/white]",
        border_style="green"
    ))


if __name__ == "__main__":
    run_demo()
