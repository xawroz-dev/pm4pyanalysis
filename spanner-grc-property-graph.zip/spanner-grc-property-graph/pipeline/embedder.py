"""Vector Embedder producing 768-dimensional embeddings for Spanner Vector Search."""
import math
import hashlib
import numpy as np
from typing import List, Union


class VectorEmbedder:
    """Generates 768-dimensional normalized embedding vectors for Spanner Vector Search."""

    def __init__(self, dimension: int = 768):
        self.dimension = dimension

    def _hash_token_to_features(self, token: str) -> np.ndarray:
        """Projects a word/token to a deterministic dense vector in dim space."""
        vec = np.zeros(self.dimension, dtype=np.float32)
        # Use multiple hash seeds to distribute across 768 dimensions
        for seed in range(4):
            h = hashlib.sha256(f"{seed}_{token}".encode("utf-8")).hexdigest()
            # Pick 6 indices per seed
            for j in range(6):
                sub = h[j*4:(j+1)*4]
                idx = int(sub, 16) % self.dimension
                val = (int(h[(j+1)*4:(j+2)*4], 16) % 1000) / 500.0 - 1.0
                vec[idx] += val
        return vec

    def embed_text(self, text: str) -> List[float]:
        """Embed a single text string into a 768-dimensional unit vector."""
        if not text or not text.strip():
            # Return zero unit vector
            vec = np.zeros(self.dimension, dtype=np.float32)
            vec[0] = 1.0
            return vec.tolist()

        words = [w.lower().strip(".,!?;:()[]\"'") for w in text.split() if w.strip()]
        if not words:
            vec = np.zeros(self.dimension, dtype=np.float32)
            vec[0] = 1.0
            return vec.tolist()

        accum = np.zeros(self.dimension, dtype=np.float32)
        
        # Domain concept weighting for high semantic fidelity
        concept_weights = {
            "swift": 3.0, "sepa": 3.0, "payment": 2.5, "settlement": 2.5, "aml": 3.0, "sanction": 3.0,
            "cloud": 2.5, "kubernetes": 2.5, "outage": 3.0, "resilience": 2.5, "failover": 3.0, "dora": 3.5,
            "trading": 2.5, "algo": 2.5, "mifid": 3.0, "sec": 2.5, "latency": 2.5, "market": 2.0,
            "ai": 2.5, "genai": 3.0, "hallucination": 3.5, "guardrail": 3.0, "control": 2.0, "risk": 2.0,
            "policy": 2.0, "compliance": 2.0, "process": 1.5, "system": 1.5
        }

        for w in words:
            w_feat = self._hash_token_to_features(w)
            weight = concept_weights.get(w, 1.0)
            accum += w_feat * weight

        # Also add character 3-grams for morphology and subword robustness
        for w in words:
            if len(w) >= 3:
                for k in range(len(w) - 2):
                    ngram = w[k:k+3]
                    accum += self._hash_token_to_features(f"ng_{ngram}") * 0.3

        # L2 Normalize
        norm = np.linalg.norm(accum)
        if norm > 0:
            accum = accum / norm
        else:
            accum[0] = 1.0

        return [round(float(x), 6) for x in accum.tolist()]

    def embed_batch(self, texts: List[str]) -> List[List[float]]:
        """Embed a list of text strings."""
        return [self.embed_text(t) for t in texts]

    @staticmethod
    def cosine_distance(vec_a: List[float], vec_b: List[float]) -> float:
        """Compute cosine distance between two vectors: 1.0 - CosineSimilarity."""
        a = np.array(vec_a, dtype=np.float32)
        b = np.array(vec_b, dtype=np.float32)
        norm_a = np.linalg.norm(a)
        norm_b = np.linalg.norm(b)
        if norm_a == 0 or norm_b == 0:
            return 1.0
        similarity = float(np.dot(a, b) / (norm_a * norm_b))
        # Clamp similarity to [-1.0, 1.0] to prevent precision drift
        similarity = max(-1.0, min(1.0, similarity))
        return round(1.0 - similarity, 6)
