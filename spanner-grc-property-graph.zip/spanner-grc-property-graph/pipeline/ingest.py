"""Ingestion Pipeline orchestrating Document -> Chunking -> Embedding -> Extraction -> Graph Assembly."""
from typing import List, Dict, Optional, Any
from models.schema import (
    Document,
    Chunk,
    Process,
    Policy,
    Risk,
    Control,
    Market,
    System,
    DocumentHasChunk,
    ProcessHasRisk,
    ControlMitigatesRisk,
    PolicyGovernsProcess,
    ProcessOperatesInMarket,
    SystemSupportsProcess,
    ControlAppliesToSystem,
    ChunkMentionsProcess,
    ChunkMentionsRisk,
    ChunkMentionsControl,
    ChunkMentionsPolicy,
    ChunkMentionsMarket,
    ChunkMentionsSystem,
    KnowledgeGraphData,
)
from pipeline.chunker import DocumentChunker
from pipeline.embedder import VectorEmbedder
from pipeline.extractor import LLMExtractor


class IngestionPipeline:
    """End-to-End Ingestion Pipeline for Spanner Property Graph."""

    def __init__(
        self,
        chunker: Optional[DocumentChunker] = None,
        embedder: Optional[VectorEmbedder] = None,
        extractor: Optional[LLMExtractor] = None,
    ):
        self.chunker = chunker or DocumentChunker()
        self.embedder = embedder or VectorEmbedder()
        self.extractor = extractor or LLMExtractor()

    def process_documents(self, documents: List[Document]) -> KnowledgeGraphData:
        """Process a list of Documents and assemble the complete KnowledgeGraphData."""
        kg = KnowledgeGraphData()

        # Dictionaries for deduplicating nodes by ID
        doc_map: Dict[str, Document] = {}
        chunk_map: Dict[str, Chunk] = {}
        proc_map: Dict[str, Process] = {}
        pol_map: Dict[str, Policy] = {}
        risk_map: Dict[str, Risk] = {}
        ctrl_map: Dict[str, Control] = {}
        mkt_map: Dict[str, Market] = {}
        sys_map: Dict[str, System] = {}

        for doc in documents:
            doc_map[doc.id] = doc
            chunks = self.chunker.chunk_document(doc)

            for ch in chunks:
                # 1. Generate 768-dim embedding
                ch.embedding = self.embedder.embed_text(ch.content)
                chunk_map[ch.id] = ch

                # 2. Add Document -> Chunk edge
                kg.document_has_chunk.append(
                    DocumentHasChunk(document_id=doc.id, chunk_id=ch.id)
                )

                # 3. Extract entities & relations from chunk
                extraction = self.extractor.extract_from_chunk(ch)

                # 4. Register and deduplicate extracted nodes
                for p in extraction.processes:
                    proc_map[p.id] = p
                    kg.chunk_mentions_process.append(
                        ChunkMentionsProcess(chunk_id=ch.id, process_id=p.id)
                    )

                for pol in extraction.policies:
                    pol_map[pol.id] = pol
                    kg.chunk_mentions_policy.append(
                        ChunkMentionsPolicy(chunk_id=ch.id, policy_id=pol.id)
                    )

                for r in extraction.risks:
                    risk_map[r.id] = r
                    kg.chunk_mentions_risk.append(
                        ChunkMentionsRisk(chunk_id=ch.id, risk_id=r.id)
                    )

                for c in extraction.controls:
                    ctrl_map[c.id] = c
                    kg.chunk_mentions_control.append(
                        ChunkMentionsControl(chunk_id=ch.id, control_id=c.id)
                    )

                for m in extraction.markets:
                    mkt_map[m.id] = m
                    kg.chunk_mentions_market.append(
                        ChunkMentionsMarket(chunk_id=ch.id, market_id=m.id)
                    )

                for s in extraction.systems:
                    sys_map[s.id] = s
                    kg.chunk_mentions_system.append(
                        ChunkMentionsSystem(chunk_id=ch.id, system_id=s.id)
                    )

                # 5. Append extracted domain edges
                kg.process_has_risk.extend(extraction.process_has_risk)
                kg.control_mitigates_risk.extend(extraction.control_mitigates_risk)
                kg.policy_governs_process.extend(extraction.policy_governs_process)
                kg.process_operates_in_market.extend(extraction.process_operates_in_market)
                kg.system_supports_process.extend(extraction.system_supports_process)
                kg.control_applies_to_system.extend(extraction.control_applies_to_system)

        # Populate deduplicated lists in KnowledgeGraphData
        kg.documents = list(doc_map.values())
        kg.chunks = list(chunk_map.values())
        kg.processes = list(proc_map.values())
        kg.policies = list(pol_map.values())
        kg.risks = list(risk_map.values())
        kg.controls = list(ctrl_map.values())
        kg.markets = list(mkt_map.values())
        kg.systems = list(sys_map.values())

        # Deduplicate domain edges
        kg.process_has_risk = self._dedup_edges(kg.process_has_risk, lambda e: (e.process_id, e.risk_id))
        kg.control_mitigates_risk = self._dedup_edges(kg.control_mitigates_risk, lambda e: (e.control_id, e.risk_id))
        kg.policy_governs_process = self._dedup_edges(kg.policy_governs_process, lambda e: (e.policy_id, e.process_id))
        kg.process_operates_in_market = self._dedup_edges(kg.process_operates_in_market, lambda e: (e.process_id, e.market_id))
        kg.system_supports_process = self._dedup_edges(kg.system_supports_process, lambda e: (e.system_id, e.process_id))
        kg.control_applies_to_system = self._dedup_edges(kg.control_applies_to_system, lambda e: (e.control_id, e.system_id))

        kg.chunk_mentions_process = self._dedup_edges(kg.chunk_mentions_process, lambda e: (e.chunk_id, e.process_id))
        kg.chunk_mentions_risk = self._dedup_edges(kg.chunk_mentions_risk, lambda e: (e.chunk_id, e.risk_id))
        kg.chunk_mentions_control = self._dedup_edges(kg.chunk_mentions_control, lambda e: (e.chunk_id, e.control_id))
        kg.chunk_mentions_policy = self._dedup_edges(kg.chunk_mentions_policy, lambda e: (e.chunk_id, e.policy_id))
        kg.chunk_mentions_market = self._dedup_edges(kg.chunk_mentions_market, lambda e: (e.chunk_id, e.market_id))
        kg.chunk_mentions_system = self._dedup_edges(kg.chunk_mentions_system, lambda e: (e.chunk_id, e.system_id))

        return kg

    @staticmethod
    def _dedup_edges(edge_list: List[Any], key_fn) -> List[Any]:
        seen = set()
        deduped = []
        for item in edge_list:
            k = key_fn(item)
            if k not in seen:
                seen.add(k)
                deduped.append(item)
        return deduped
