"""Document Chunker with token estimation, paragraph-aware splitting, and overlap."""
import re
from typing import List, Tuple
from models.schema import Document, Chunk


class DocumentChunker:
    """Splits documents into coherent chunks with overlap and metadata."""

    def __init__(self, target_chunk_size_words: int = 150, overlap_words: int = 30):
        self.target_chunk_size_words = target_chunk_size_words
        self.overlap_words = overlap_words

    def chunk_text(self, document_id: str, text: str) -> List[Chunk]:
        """Split raw text into structured Chunks with IDs and indices."""
        # Normalize linebreaks and whitespace
        clean_text = text.strip()
        if not clean_text:
            return []

        # Split into paragraphs/sections
        sections = re.split(r'\n\s*\n', clean_text)
        words: List[str] = []
        for s in sections:
            w = s.strip().split()
            if w:
                words.extend(w)

        if not words:
            return []

        chunks: List[Chunk] = []
        chunk_idx = 0
        step = max(1, self.target_chunk_size_words - self.overlap_words)
        
        for i in range(0, len(words), step):
            chunk_word_list = words[i:i + self.target_chunk_size_words]
            chunk_content = " ".join(chunk_word_list)
            
            chunk_id = f"chunk_{document_id}_{chunk_idx:03d}"
            # Approximate token count (1 word ~= 1.3 tokens)
            token_count = int(len(chunk_word_list) * 1.3)

            chunks.append(
                Chunk(
                    id=chunk_id,
                    document_id=document_id,
                    chunk_index=chunk_idx,
                    content=chunk_content,
                    token_count=token_count,
                    embedding=[]
                )
            )
            chunk_idx += 1

            if i + self.target_chunk_size_words >= len(words):
                break

        return chunks

    def chunk_document(self, document: Document) -> List[Chunk]:
        """Convenience method to chunk a Document model."""
        return self.chunk_text(document.id, document.raw_text)
