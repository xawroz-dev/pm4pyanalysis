"""Streamlit Interactive Visual Dashboard for Spanner GRC Property Graph & Vector Hybrid Search."""
import streamlit as st
import pandas as pd
import json

from sample_data.loader import load_sample_documents
from models.schema import Document
from pipeline.ingest import IngestionPipeline
from engine.local_simulator import SpannerLocalGraphSimulator
from models.ddl_generator import generate_spanner_ddl, export_ddl_file
from models.queries import (
    QUERY_VECTOR_TO_GRAPH_SQL,
    QUERY_GRAPH_TO_VECTOR_SQL,
    QUERY_FTS_TO_GRAPH_SQL,
    QUERY_3WAY_HYBRID_SQL,
)

st.set_page_config(
    page_title="Spanner Graph & Vector GRC System",
    page_icon="🕸️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for styling
st.markdown("""
<style>
    .main-header { font-size: 2.2rem; font-weight: 700; color: #1a73e8; margin-bottom: 0.2rem; }
    .sub-header { font-size: 1.1rem; color: #5f6368; margin-bottom: 1.5rem; }
    .card { background-color: #f8f9fa; border-radius: 8px; padding: 1rem; border: 1px solid #dadce0; margin-bottom: 1rem; }
    .metric-badge { background-color: #e8f0fe; color: #1a73e8; font-weight: 600; padding: 0.2rem 0.6rem; border-radius: 4px; }
</style>
""", unsafe_allow_html=True)


@st.cache_resource
def get_pipeline_and_data():
    """Initializes the ingestion pipeline with default sample documents."""
    docs = load_sample_documents()
    pipeline = IngestionPipeline()
    kg = pipeline.process_documents(docs)
    simulator = SpannerLocalGraphSimulator(data=kg)
    export_ddl_file("spanner_schema.sql")
    return pipeline, kg, simulator


pipeline, default_kg, default_simulator = get_pipeline_and_data()

# Session State for dynamic documents
if "custom_docs" not in st.session_state:
    st.session_state.custom_docs = []
    st.session_state.kg = default_kg
    st.session_state.simulator = default_simulator

# ------------------------------------------------------------------------------
# SIDEBAR
# ------------------------------------------------------------------------------
with st.sidebar:
    st.image("https://www.gstatic.com/images/branding/product/2x/google_cloud_64dp.png", width=50)
    st.title("Spanner Graph Engine")
    st.markdown("---")
    
    st.subheader("📁 Ingestion & Documents")
    uploaded_file = st.file_uploader("Upload GRC Document (Markdown/Text)", type=["md", "txt"])
    if uploaded_file is not None:
        file_content = uploaded_file.read().decode("utf-8")
        doc_id = f"doc_custom_{uploaded_file.name.replace('.md', '').replace('.txt', '')}"
        
        # Avoid duplicate additions
        if not any(d.id == doc_id for d in st.session_state.custom_docs):
            new_doc = Document(
                id=doc_id,
                title=uploaded_file.name,
                source_type="CUSTOM_UPLOAD",
                uploaded_at="2026-08-19T00:00:00Z",
                raw_text=file_content
            )
            st.session_state.custom_docs.append(new_doc)
            # Re-process pipeline
            all_docs = load_sample_documents() + st.session_state.custom_docs
            st.session_state.kg = pipeline.process_documents(all_docs)
            st.session_state.simulator = SpannerLocalGraphSimulator(data=st.session_state.kg)
            st.success(f"Ingested '{uploaded_file.name}'!")

    kg = st.session_state.kg
    simulator = st.session_state.simulator
    stats = kg.stats()

    st.markdown("### 📊 Knowledge Graph Stats")
    col_s1, col_s2 = st.columns(2)
    with col_s1:
        st.metric("Documents", stats["documents"])
        st.metric("Processes", stats["processes"])
        st.metric("Risks", stats["risks"])
        st.metric("Markets", stats["markets"])
    with col_s2:
        st.metric("Chunks (Vectors)", stats["chunks"])
        st.metric("Policies", stats["policies"])
        st.metric("Controls", stats["controls"])
        st.metric("Systems", stats["systems"])

    st.markdown(f"**Total Nodes:** `{stats['total_nodes']}` | **Total Edges:** `{stats['total_edges']}`")
    st.markdown("---")
    st.markdown("💡 **Architecture Reference:** [maguec/SpannerPropertyGraph](https://github.com/maguec/SpannerPropertyGraph)")


# ------------------------------------------------------------------------------
# MAIN CONTENT
# ------------------------------------------------------------------------------
st.markdown('<div class="main-header">🕸️ Enterprise GRC Spanner Property Graph</div>', unsafe_allow_html=True)
st.markdown('<div class="sub-header">Unified Single-Query Hybrid Search: Combining Vector Search (COSINE_DISTANCE), Full-Text Search (SEARCH), and GQL Graph Traversals in Google Cloud Spanner / Spanner Omni</div>', unsafe_allow_html=True)

tab_queries, tab_graph, tab_docs, tab_ddl = st.tabs([
    "🔍 Single-Query Hybrid Search",
    "🌐 Graph Topology & Explorer",
    "📄 Documents & Chunk Grounding",
    "📜 Cloud Spanner DDL Schema"
])

# ==============================================================================
# TAB 1: HYBRID QUERY EXPLORER
# ==============================================================================
with tab_queries:
    st.subheader("Unified Hybrid Query Engine")
    st.markdown("""
    Execute single atomic queries that combine **Vector Search**, **Full-Text Keyword Search**, and **Property Graph Traversals** without intermediate application-layer hops.
    """)

    query_mode = st.radio(
        "Select Hybrid Search Pattern:",
        [
            "Pattern 1: Vector-to-Graph (Semantic Search -> Graph Expansion)",
            "Pattern 2: Graph-to-Vector (Policy/Market Traversal -> Ranked Evidence Chunks)",
            "Pattern 3: Full-Text Search to Graph (Keyword Match -> Blast Radius Traversal)",
            "Pattern 4: 3-Way Hybrid (Vector + Keyword + Multi-Hop Graph Expansion)"
        ],
        index=0
    )

    st.markdown("---")

    # --------------------------------------------------------------------------
    # PATTERN 1: VECTOR-TO-GRAPH
    # --------------------------------------------------------------------------
    if "Pattern 1" in query_mode:
        st.markdown("### 1️⃣ Vector-to-Graph Search")
        st.info("Finds chunks closest to user prompt via `COSINE_DISTANCE(embedding, @query_vector)` and in the same query traverses connected Processes, Policies, Risks, Controls, and Markets.")
        
        sample_prompts = [
            "What preventative controls mitigate money laundering and OFAC sanctions violations?",
            "How do we prevent errant trading algorithms from flooding exchanges?",
            "What disaster recovery mechanisms exist for multi-cloud container outages?",
            "How is generative AI customer data privacy and hallucination controlled?"
        ]
        selected_prompt = st.selectbox("Choose a sample prompt or write your own:", sample_prompts)
        user_prompt = st.text_input("Semantic Query Prompt:", value=selected_prompt)
        
        col_p1, col_p2 = st.columns([1, 1])
        with col_p1:
            top_k = st.slider("Top K Chunks", min_value=1, max_value=5, value=2, key="v2g_k")
        with col_p2:
            sim_threshold = st.slider("Similarity Threshold (Max Cosine Distance)", min_value=0.1, max_value=1.0, value=0.85, step=0.05, key="v2g_t")

        if st.button("🚀 Run Vector-to-Graph Query", type="primary"):
            res = simulator.query_vector_to_graph(query_text=user_prompt, top_k=top_k, similarity_threshold=sim_threshold)
            
            st.success(f"Retrieved {len(res['records'])} interconnected graph paths from top vector matches.")
            
            if res["records"]:
                df = pd.DataFrame(res["records"])
                display_cols = [
                    "chunk_id", "vector_distance", "process_name", "governing_policy",
                    "risk_name", "risk_severity", "mitigating_control", "control_effectiveness",
                    "target_market", "supporting_system"
                ]
                st.dataframe(df[display_cols], use_container_width=True)

            with st.expander("👁️ View Spanner SQL + GQL Query executed"):
                st.code(QUERY_VECTOR_TO_GRAPH_SQL, language="sql")

    # --------------------------------------------------------------------------
    # PATTERN 2: GRAPH-TO-VECTOR
    # --------------------------------------------------------------------------
    elif "Pattern 2" in query_mode:
        st.markdown("### 2️⃣ Graph-to-Vector Search")
        st.info("Traverses from a specific regulatory Policy framework down to high-severity Risks and IT Systems, then retrieves and ranks all grounded text chunks by semantic similarity against an incident prompt.")

        col_g1, col_g2 = st.columns([1, 2])
        with col_g1:
            frameworks = ["DORA", "AMLD6", "SEC_RULE_15C3_5", "EU_AI_ACT"]
            selected_fw = st.selectbox("Select Target Regulatory Framework:", frameworks, index=0)
            top_k = st.slider("Top K Ranked Evidence Chunks", min_value=1, max_value=5, value=3, key="g2v_k")
        with col_g2:
            incident_samples = [
                "Catastrophic cloud data center region failure during peak payment volume",
                "Unauthorized illicit funds routing through intermediary correspondent accounts",
                "High-frequency algorithmic pricing spike breaching exchange volatility bands",
                "Conversational chatbot leaking customer account numbers in responses"
            ]
            incident_input = st.selectbox("Incident Prompt / Evidence Query:", incident_samples)

        if st.button("🚀 Run Graph-to-Vector Query", type="primary"):
            res = simulator.query_graph_to_vector(
                regulatory_framework=selected_fw,
                incident_query=incident_input,
                top_k=top_k
            )

            st.success(f"Traversed {selected_fw} framework graph topology and ranked {len(res['records'])} grounded evidence chunks.")

            if res["records"]:
                df = pd.DataFrame(res["records"])
                display_cols = [
                    "policy_name", "process_name", "risk_name", "risk_severity",
                    "mitigating_control", "supporting_system", "incident_semantic_distance",
                    "chunk_id", "chunk_text"
                ]
                st.dataframe(df[display_cols], use_container_width=True)

            with st.expander("👁️ View Spanner SQL + GQL Query executed"):
                st.code(QUERY_GRAPH_TO_VECTOR_SQL, language="sql")

    # --------------------------------------------------------------------------
    # PATTERN 3: FULL-TEXT SEARCH TO GRAPH
    # --------------------------------------------------------------------------
    elif "Pattern 3" in query_mode:
        st.markdown("### 3️⃣ Full-Text Search (FTS) to Graph")
        st.info("Uses Spanner's `SEARCH()` index on chunk text to locate keyword hits and simultaneously computes the compliance blast radius across processes, markets, and IT infrastructure.")

        sample_keywords = ["kill switch", "sanctions breach", "cloud outage", "hallucination", "sepa settlement"]
        selected_kw = st.selectbox("Select or enter search terms:", sample_keywords)
        fts_query = st.text_input("Full-Text Search Term:", value=selected_kw)
        top_k = st.slider("Top K Search Hits", min_value=1, max_value=5, value=3, key="fts_k")

        if st.button("🚀 Run FTS-to-Graph Query", type="primary"):
            res = simulator.query_fts_to_graph(search_term=fts_query, top_k=top_k)

            st.success(f"Matched {len(res['records'])} graph paths matching keyword '{fts_query}'.")

            if res["records"]:
                df = pd.DataFrame(res["records"])
                st.dataframe(df, use_container_width=True)

            with st.expander("👁️ View Spanner SQL + GQL Query executed"):
                st.code(QUERY_FTS_TO_GRAPH_SQL, language="sql")

    # --------------------------------------------------------------------------
    # PATTERN 4: 3-WAY HYBRID
    # --------------------------------------------------------------------------
    elif "Pattern 4" in query_mode:
        st.markdown("### 4️⃣ 3-Way Hybrid (Vector + Keyword + Multi-Hop Graph)")
        st.info("Fuses vector similarity scores with exact keyword matches and performs a 2-hop graph expansion for rich RAG context generation.")

        col_h1, col_h2 = st.columns(2)
        with col_h1:
            vec_prompt = st.text_input("Vector Prompt:", value="Generative AI conversational banking agent privacy governance")
        with col_h2:
            kw_term = st.text_input("Keyword Filter:", value="hallucination")

        top_k = st.slider("Top K Candidates", min_value=1, max_value=5, value=3, key="h3_k")

        if st.button("🚀 Run 3-Way Hybrid Query", type="primary"):
            res = simulator.query_three_way_hybrid(
                query_text=vec_prompt,
                search_keyword=kw_term,
                top_k=top_k
            )

            st.success(f"Retrieved {len(res['records'])} hybrid scored and graph-expanded records.")

            if res["records"]:
                df = pd.DataFrame(res["records"])
                st.dataframe(df, use_container_width=True)

            with st.expander("👁️ View Spanner SQL + GQL Query executed"):
                st.code(QUERY_3WAY_HYBRID_SQL, language="sql")


# ==============================================================================
# TAB 2: GRAPH TOPOLOGY EXPLORER
# ==============================================================================
with tab_graph:
    st.subheader("Graph Topology & Entity Explorer")
    
    node_type = st.selectbox(
        "Select Entity Type to Inspect:",
        ["Processes", "Policies", "Risks", "Controls", "Markets", "Systems"]
    )

    if node_type == "Processes":
        df = pd.DataFrame([p.model_dump() for p in kg.processes])
        st.dataframe(df, use_container_width=True)
    elif node_type == "Policies":
        df = pd.DataFrame([p.model_dump() for p in kg.policies])
        st.dataframe(df, use_container_width=True)
    elif node_type == "Risks":
        df = pd.DataFrame([r.model_dump() for r in kg.risks])
        st.dataframe(df, use_container_width=True)
    elif node_type == "Controls":
        df = pd.DataFrame([c.model_dump() for c in kg.controls])
        st.dataframe(df, use_container_width=True)
    elif node_type == "Markets":
        df = pd.DataFrame([m.model_dump() for m in kg.markets])
        st.dataframe(df, use_container_width=True)
    elif node_type == "Systems":
        df = pd.DataFrame([s.model_dump() for s in kg.systems])
        st.dataframe(df, use_container_width=True)

    st.markdown("### 🔗 Relationships Table (Edges)")
    edge_type = st.selectbox(
        "Select Edge Relationship to Inspect:",
        ["ProcessHasRisk", "ControlMitigatesRisk", "PolicyGovernsProcess", "ProcessOperatesInMarket", "SystemSupportsProcess", "ControlAppliesToSystem"]
    )
    if edge_type == "ProcessHasRisk":
        df_e = pd.DataFrame([e.model_dump() for e in kg.process_has_risk])
        st.dataframe(df_e, use_container_width=True)
    elif edge_type == "ControlMitigatesRisk":
        df_e = pd.DataFrame([e.model_dump() for e in kg.control_mitigates_risk])
        st.dataframe(df_e, use_container_width=True)
    elif edge_type == "PolicyGovernsProcess":
        df_e = pd.DataFrame([e.model_dump() for e in kg.policy_governs_process])
        st.dataframe(df_e, use_container_width=True)
    elif edge_type == "ProcessOperatesInMarket":
        df_e = pd.DataFrame([e.model_dump() for e in kg.process_operates_in_market])
        st.dataframe(df_e, use_container_width=True)
    elif edge_type == "SystemSupportsProcess":
        df_e = pd.DataFrame([e.model_dump() for e in kg.system_supports_process])
        st.dataframe(df_e, use_container_width=True)
    elif edge_type == "ControlAppliesToSystem":
        df_e = pd.DataFrame([e.model_dump() for e in kg.control_applies_to_system])
        st.dataframe(df_e, use_container_width=True)


# ==============================================================================
# TAB 3: DOCUMENTS & CHUNK GROUNDING
# ==============================================================================
with tab_docs:
    st.subheader("Document Ingestion & Chunk Grounding Provenance")
    st.markdown("Every extracted entity and relationship retains strict foreign key grounding to its source `chunk_id`.")

    for d in kg.documents:
        with st.expander(f"📄 [{d.id}] {d.title}"):
            st.markdown(f"**Source Type:** `{d.source_type}` | **Uploaded:** `{d.uploaded_at}`")
            st.text_area("Raw Text Content:", value=d.raw_text, height=180, key=f"raw_{d.id}")
            
            # Show chunks for this document
            doc_chunks = [c for c in kg.chunks if c.document_id == d.id]
            st.markdown(f"**Generated Chunks ({len(doc_chunks)}):**")
            for c in doc_chunks:
                st.markdown(f"- **`{c.id}`** (Tokens: {c.token_count}, Embedding Dim: {len(c.embedding)}):")
                st.info(c.content)


# ==============================================================================
# TAB 4: SPANNER DDL SCHEMA
# ==============================================================================
with tab_ddl:
    st.subheader("Cloud Spanner / Spanner Omni DDL Schema")
    st.markdown("Generated Property Graph DDL including Node Tables, Edge Tables, Vector Indexes, and Full-Text Search Indexes.")
    
    ddl_content = generate_spanner_ddl(graph_name="EnterpriseGRCGraph", embedding_dim=768)
    st.download_button("📥 Download spanner_schema.sql", ddl_content, file_name="spanner_schema.sql", mime="text/plain")
    st.code(ddl_content, language="sql")
