# Enterprise GRC Spanner Property Graph

An Enterprise Knowledge Graph and Governance, Risk, and Compliance (GRC) intelligence platform powered by **Google Cloud Spanner / Spanner Omni Property Graph** with **Unified Single-Query Vector & Graph Search**.

Modeled after and extending [maguec/SpannerPropertyGraph](https://github.com/maguec/SpannerPropertyGraph).

---

## 🌟 Key Capabilities

1. **Structured Document Ingestion & Chunk Grounding**:
   - Automated semantic chunking and 768-dimensional vector embedding generation.
   - LLM-powered entity and relationship extraction for GRC domains:
     - **Nodes**: `Document`, `Chunk`, `Process`, `Policy`, `Risk`, `Control`, `Market`, `System`.
     - **Edges**: `HAS_CHUNK`, `HAS_RISK`, `MITIGATES_RISK`, `GOVERNS_PROCESS`, `OPERATES_IN_MARKET`, `SUPPORTS_PROCESS`, `APPLIES_TO_SYSTEM`, `MENTIONS_*`.
   - **Strict Provenance**: Every entity and relationship is linked to its originating `chunk_id` for explainable grounding.

2. **Unified Single-Query Hybrid Search Patterns**:
   Execute combined SQL, GQL, Full-Text Search, and Vector Distance operations in **a single atomic query pass** without application-level roundtrips:
   - **Vector-to-Graph**: Semantic vector search finds top matching chunks (`COSINE_DISTANCE`), then simultaneously walks the graph to uncover governed processes, risks, mitigating controls, and affected markets.
   - **Graph-to-Vector**: Traverses from a regulatory policy or market down to critical risks and systems, ranking grounded evidence chunks by cosine similarity to an incident query.
   - **Full-Text Search (FTS) to Graph**: Uses Spanner's `SEARCH()` full-text index on chunks and computes the blast radius across processes, markets, and IT infrastructure.
   - **3-Way Hybrid**: Blends vector similarity with keyword matching and expands multi-hop graph paths for rich RAG synthesis.

3. **Dual Execution Engine**:
   - **Google Cloud Spanner / Spanner Omni Client**: Production client for deploying DDL (`spanner_schema.sql`), inserting node/edge mutations, and executing live SQL+GQL queries.
   - **In-Memory Simulator**: Instant local execution engine allowing offline experimentation and testing with zero cloud credentials required.

---

## 🏗️ Architecture & Graph Schema

```
 [Document] ──(HAS_CHUNK)──> [Chunk (Vector Indexed)]
                                 │
                   (MENTIONS_*)  │ (Provenanced Grounding)
                                 ▼
      [Policy] ──(GOVERNS_PROCESS)──> [Process] ──(OPERATES_IN_MARKET)──> [Market]
                                         │   ▲
                             (HAS_RISK)  │   │ (SUPPORTS_PROCESS)
                                         ▼   │
                                      [Risk] [System]
                                         ▲      ▲
                      (MITIGATES_RISK)   │      │ (APPLIES_TO_SYSTEM)
                                      [Control] ─┘
```

---

## 🚀 Quickstart

### Option A: Run Spanner Omni with Podman (or Docker)
To run Spanner Omni with **Podman**:

```bash
# 1. Launch Spanner Omni with Podman, apply DDL schema, and seed data:
./docker/run_spanner_omni_podman.sh
```
Or with `podman compose`:
```bash
podman compose up --build
```
- **Spanner Omni gRPC API**: `localhost:15000`
- **Spanner Omni Admin Console**: `http://localhost:15026`
- **Streamlit Visual Dashboard**: `http://localhost:8501`

---

### Option B: Run with Docker Compose
```bash
docker compose up --build
# Or standalone:
./docker/run_spanner_omni.sh
```

---

### Option B: Local Python Environment
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

### 1. Run the Interactive CLI Demo
```bash
python demo_hybrid_queries.py
```

### 2. Run the Credit Refund Hybrid Search Demo
```bash
PYTHONPATH=. python credit_refund_demo/run_demo.py
```

### 3. Run the Visual Streamlit Dashboard
```bash
streamlit run app.py
```

### 4. Run Automated Test Suite
```bash
pytest -v
```

---

## 📂 Project Structure

```
spanner-grc-property-graph/
├── models/
│   ├── schema.py              # Pydantic schema for Nodes, Edges, and Graph Containers
│   ├── ddl_generator.py       # Cloud Spanner / Spanner Omni DDL generator
│   └── queries.py             # Spanner Hybrid SQL + GQL single-query templates
├── pipeline/
│   ├── chunker.py             # Document chunking with token counts & overlap
│   ├── embedder.py            # 768-dim vector embeddings & cosine distance
│   ├── extractor.py           # LLM entity & relation extractor with chunk grounding
│   └── ingest.py              # End-to-end ingestion pipeline orchestrator
├── engine/
│   ├── local_simulator.py     # In-memory Spanner Property Graph & Vector simulator
│   └── spanner_client.py      # Production Google Cloud Spanner / Spanner Omni client
├── sample_data/
│   ├── loader.py              # Sample document loader
│   └── docs/
│       ├── cross_border_payments.md           # SWIFT/SEPA Real-Time Settlements & AML
│       ├── cloud_infrastructure_resilience.md # Multi-Cloud K8s & DORA Resilience
│       ├── algorithmic_trading_governance.md  # SEC 15c3-5 Market Access & Kill Switch
│       └── genai_banking_assistant.md         # EU AI Act & Trustworthy GenAI Banking
├── tests/
│   ├── test_pipeline.py       # Unit tests for chunking, embedding, extraction, DDL
│   └── test_hybrid_queries.py # Integration tests for all hybrid query patterns
├── demo_hybrid_queries.py     # Executable CLI demonstration
├── app.py                     # Streamlit visual dashboard
├── spanner_schema.sql         # Exported Cloud Spanner Property Graph DDL
├── SampleQueries.md           # Catalog of SQL + GQL hybrid queries
└── requirements.txt           # Project dependencies
```

---

## 🧹 Complete Teardown & Cleanup

To delete all Spanner tables, graph definitions, vector indexes, Podman/Docker containers, volumes, and generated data artifacts:

```bash
# Total environment cleanup (Containers, Volumes, Tables, and Artifacts):
./cleanup.sh

# Or clean only Python data artifacts and Spanner schema:
PYTHONPATH=. python credit_refund_demo/clean_all_data.py
```

1. **Create Spanner Instance & Database**:
   ```bash
   gcloud spanner instances create grc-instance \
       --config=regional-us-central1 \
       --description="Enterprise GRC Instance" \
       --nodes=1

   gcloud spanner databases create grc-db --instance=grc-instance
   ```

2. **Apply Property Graph & Vector DDL**:
   ```bash
   gcloud spanner databases ddl update grc-db \
       --instance=grc-instance \
       --ddl-file=spanner_schema.sql
   ```

3. **Query Spanner Graph with Vector Search**:
   See [`SampleQueries.md`](./SampleQueries.md) for full query scripts.
