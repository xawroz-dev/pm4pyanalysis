"""Neo4j persistence for the governed enterprise process graph.

The graph stores business meaning and artifact provenance. Chunk text and
embeddings stay in Qdrant. Direct business relationships retain compact evidence
ID lists, so technical assertion nodes never clutter the enterprise graph.
"""

import json
import re
import uuid
from typing import Any

from neo4j import AsyncDriver, AsyncGraphDatabase

from app.domain.models import ExtractionResult, JourneyBatch, ParsedDocument, TextChunk
from app.domain.ontology import ID_KEYS, ONTOLOGY_VERSION, NodeType
from app.services.parsing import parse_bpmn_structure

ENTITY_NAMESPACE = uuid.UUID("3bf6d5a5-e4e0-4e86-83bb-a992619ddf57")


def canonical_id(node_type: NodeType, name: str) -> str:
    normalized = re.sub(r"[^a-z0-9]+", "-", name.casefold()).strip("-")
    suffix = str(uuid.uuid5(ENTITY_NAMESPACE, f"{node_type.value}:{name.casefold()}"))[:8]
    return f"{node_type.value.casefold()}:{normalized[:60]}:{suffix}"


def evidence_chunk_ids(
    evidence: str, target_ref: str, chunks: list[TextChunk], limit: int = 3
) -> list[str]:
    """Resolve extracted evidence to deterministic chunks without creating arbitrary mentions."""
    evidence_normalized = re.sub(r"\s+", " ", evidence).strip().casefold()
    target_normalized = target_ref.strip().casefold()
    if evidence_normalized.startswith(
        ("declared parent process:", "declared dependency:")
    ):
        return [chunk.chunk_id for chunk in chunks if chunk.chunk_kind == "metadata"][:limit]
    if evidence_normalized.startswith("declared in metadata:"):
        return [
            chunk.chunk_id
            for chunk in chunks
            if chunk.chunk_kind == "metadata"
            and evidence_normalized in re.sub(r"\s+", " ", chunk.text).casefold()
        ][:limit]

    exact: list[str] = []
    target_matches: list[str] = []
    for chunk in chunks:
        chunk_text = re.sub(r"\s+", " ", chunk.text).casefold()
        if evidence_normalized and evidence_normalized in chunk_text:
            exact.append(chunk.chunk_id)
        elif target_normalized and target_normalized in chunk_text:
            target_matches.append(chunk.chunk_id)
    return (exact or target_matches)[:limit]


class Neo4jRepository:
    def __init__(self, uri: str, user: str, password: str):
        self.driver: AsyncDriver = AsyncGraphDatabase.driver(uri, auth=(user, password))

    async def close(self) -> None:
        await self.driver.close()

    async def ping(self) -> bool:
        await self.driver.verify_connectivity()
        return True

    async def initialize(self) -> None:
        constraints = [
            ("Process", "process_id"),
            ("Document", "document_id"),
            ("DocumentVersion", "document_version_id"),
            ("BPMNModel", "bpmn_id"),
            ("Activity", "activity_id"),
            ("Journey", "journey_id"),
            ("Variant", "variant_id"),
            ("Market", "market_id"),
            ("BusinessUnit", "business_unit_id"),
            ("Control", "control_id"),
            ("System", "system_id"),
        ]
        async with self.driver.session() as session:
            for label, key in constraints:
                await session.run(
                    f"CREATE CONSTRAINT {label.lower()}_{key} IF NOT EXISTS "
                    f"FOR (n:{label}) REQUIRE n.{key} IS UNIQUE"
                )
            await session.run("CREATE INDEX process_name IF NOT EXISTS FOR (n:Process) ON (n.name)")
            await session.run(
                "CREATE INDEX document_version_checksum IF NOT EXISTS "
                "FOR (n:DocumentVersion) ON (n.checksum)"
            )

    async def get_current_version(self, document_id: str) -> dict[str, Any] | None:
        records, _, _ = await self.driver.execute_query(
            """
            MATCH (d:Document {document_id: $document_id})
            OPTIONAL MATCH (d)-[:HAS_VERSION]->(v:DocumentVersion {active: true})
            RETURN d.current_version_id AS document_version_id, v.checksum AS checksum
            """,
            document_id=document_id,
            routing_="r",
        )
        if not records or records[0]["document_version_id"] is None:
            return None
        return records[0].data()

    async def stage_document_version(
        self,
        document: ParsedDocument,
        document_id: str,
        document_version_id: str,
        vector_chunk_count: int,
    ) -> None:
        """Stage immutable artifact metadata before the cross-store activation switch."""
        metadata = document.metadata
        await self.driver.execute_query(
            """
            MERGE (p:Process {process_id: $process_id})
            ON CREATE SET p.created_at = datetime()
            SET p.name = $process_name, p.description = $description, p.owner = $owner,
                p.status = $process_status, p.criticality = $criticality, p.tags = $tags,
                p.ontology_version = $ontology_version, p.updated_at = datetime()
            MERGE (d:Document {document_id: $document_id})
            ON CREATE SET d.created_at = datetime()
            SET d.title = $title, d.document_type = $document_type,
                d.source_uri = $source_uri, d.original_filename = $original_filename,
                d.updated_at = datetime()
            MERGE (v:DocumentVersion {document_version_id: $document_version_id})
            ON CREATE SET v.created_at = datetime()
            SET v.name = $title + ' v' + $version,
                v.document_id = $document_id, v.version = $version,
                v.effective_date = $effective_date, v.classification = $classification,
                v.checksum = $checksum, v.media_type = $media_type,
                v.vector_chunk_count = $vector_chunk_count,
                v.status = 'STAGED', v.active = false, v.updated_at = datetime()
            MERGE (p)-[:HAS_DOCUMENT]->(d)
            MERGE (d)-[:HAS_VERSION]->(v)
            """,
            process_id=metadata.process.process_id,
            process_name=metadata.process.name,
            description=metadata.process.description,
            owner=metadata.process.owner,
            process_status=metadata.process.status,
            criticality=metadata.process.criticality,
            tags=metadata.process.tags,
            ontology_version=ONTOLOGY_VERSION,
            document_id=document_id,
            title=metadata.title,
            document_type=metadata.document_type,
            source_uri=metadata.source_uri,
            original_filename=document.original_filename,
            document_version_id=document_version_id,
            version=metadata.version or "unversioned",
            effective_date=(
                metadata.effective_date.isoformat() if metadata.effective_date else None
            ),
            classification=metadata.classification,
            checksum=document.checksum,
            media_type=document.media_type,
            vector_chunk_count=vector_chunk_count,
        )

    async def mark_version_failed(self, document_version_id: str, error: str) -> None:
        await self.driver.execute_query(
            """
            MATCH (v:DocumentVersion {document_version_id: $document_version_id})
            SET v.status = 'FAILED', v.active = false,
                v.error = left($error, 1000), v.updated_at = datetime()
            """,
            document_version_id=document_version_id,
            error=error,
        )

    async def upsert_extraction(
        self,
        process_id: str,
        document_version_id: str,
        extraction: ExtractionResult,
        chunks: list[TextChunk],
    ) -> tuple[int, int]:
        entity_lookup: dict[tuple[NodeType, str], str] = {}
        for entity in extraction.entities:
            node_id = entity.external_id or canonical_id(entity.entity_type, entity.canonical_name)
            entity_lookup[(entity.entity_type, entity.canonical_name.casefold())] = node_id
            if entity.external_id:
                entity_lookup[(entity.entity_type, entity.external_id.casefold())] = node_id
            label = entity.entity_type.value
            id_key = ID_KEYS[entity.entity_type]
            await self.driver.execute_query(
                f"""
                MERGE (n:{label} {{{id_key}: $node_id}})
                ON CREATE SET n.created_at = datetime()
                SET n.name = $name, n.description = coalesce($description, n.description),
                    n.aliases = $aliases, n.updated_at = datetime(),
                    n.ontology_version = $ontology_version
                """,
                node_id=node_id,
                name=entity.canonical_name,
                description=entity.description,
                aliases=entity.aliases,
                ontology_version=ONTOLOGY_VERSION,
            )

        facts: list[dict[str, Any]] = []
        for relationship in extraction.relationships:
            relationship.validate_ontology()
            source_id = entity_lookup.get(
                (relationship.source_type, relationship.source_ref.casefold())
            )
            target_id = entity_lookup.get(
                (relationship.target_type, relationship.target_ref.casefold())
            )
            if not source_id or not target_id:
                continue
            supporting_chunks = evidence_chunk_ids(
                relationship.evidence, relationship.target_ref, chunks
            )
            if not supporting_chunks:
                continue
            facts.append(
                {
                    "source_id": source_id,
                    "predicate": relationship.relationship_type.value,
                    "target_type": relationship.target_type.value,
                    "target_id": target_id,
                    "confidence": relationship.confidence,
                    "evidence": relationship.evidence,
                    "supporting_chunk_ids": supporting_chunks,
                }
            )
        await self.driver.execute_query(
            """
            MATCH (v:DocumentVersion {document_version_id: $document_version_id})
            SET v.extracted_facts_json = $facts_json,
                v.extracted_fact_count = size($facts),
                v.updated_at = datetime()
            """,
            document_version_id=document_version_id,
            facts_json=json.dumps(facts),
            facts=facts,
        )
        return len(extraction.entities), len(facts)

    async def activate_document_version(self, document_id: str, document_version_id: str) -> None:
        records, _, _ = await self.driver.execute_query(
            """
            MATCH (d:Document {document_id: $document_id})
            MATCH (d)-[:HAS_VERSION]->(selected:DocumentVersion {
                document_version_id: $document_version_id
            })
            OPTIONAL MATCH (d)-[:HAS_VERSION]->(other:DocumentVersion)
            WHERE other <> selected
            SET other.active = false,
                other.status = CASE
                    WHEN other.status = 'FAILED' THEN other.status ELSE 'SUPERSEDED'
                END,
                other.updated_at = datetime()
            SET d.current_version_id = selected.document_version_id,
                d.updated_at = datetime(),
                selected.active = true,
                selected.status = 'ACTIVE',
                selected.activated_at = datetime(),
                selected.updated_at = datetime()
            RETURN selected.document_version_id AS document_version_id
            """,
            document_id=document_id,
            document_version_id=document_version_id,
        )
        if not records:
            raise ValueError(f"Cannot activate missing version {document_version_id}")
        await self.refresh_business_relationships()

    async def rollback_document_version(
        self,
        document_id: str,
        failed_version_id: str,
        previous_version_id: str | None,
        error: str,
    ) -> None:
        await self.mark_version_failed(failed_version_id, error)
        if previous_version_id:
            await self.activate_document_version(document_id, previous_version_id)
        else:
            await self.driver.execute_query(
                """
                MATCH (d:Document {document_id: $document_id})
                REMOVE d.current_version_id
                """,
                document_id=document_id,
            )
            await self.refresh_business_relationships()

    async def refresh_business_relationships(self) -> None:
        """Rebuild direct governed edges from facts stored on active versions."""
        rows = await self.query(
            """
            MATCH (v:DocumentVersion {active: true})
            WHERE v.extracted_facts_json IS NOT NULL
            RETURN v.document_version_id AS version_id,
                   v.classification AS classification,
                   v.extracted_facts_json AS facts_json
            """,
            {},
        )
        aggregated: dict[tuple[str, str, str, str], dict[str, Any]] = {}
        for row in rows:
            for fact in json.loads(row["facts_json"]):
                key = (
                    fact["source_id"],
                    fact["predicate"],
                    fact["target_type"],
                    fact["target_id"],
                )
                item = aggregated.setdefault(
                    key,
                    {
                        "confidence": 0.0,
                        "evidence_version_ids": [],
                        "supporting_chunk_ids": [],
                        "evidence_snippets": [],
                        "classifications": [],
                    },
                )
                item["confidence"] = max(item["confidence"], fact["confidence"])
                item["evidence_version_ids"].append(row["version_id"])
                item["supporting_chunk_ids"].extend(fact["supporting_chunk_ids"])
                item["evidence_snippets"].append(fact["evidence"])
                item["classifications"].append(row["classification"])
        await self.driver.execute_query(
            """
            MATCH (:Process)-[r:HAS_SUBPROCESS|DEPENDS_ON|OPERATES_IN|OWNED_BY|
                               GOVERNED_BY|USES_SYSTEM]->()
            DELETE r
            """
        )
        for (source_id, predicate, target_type, target_id), evidence in aggregated.items():
            target_node_type = NodeType(target_type)
            target_label = target_node_type.value
            target_key = ID_KEYS[target_node_type]
            await self.driver.execute_query(
                f"""
                MATCH (p:Process {{process_id: $source_id}})
                MATCH (t:{target_label} {{{target_key}: $target_id}})
                MERGE (p)-[r:{predicate}]->(t)
                SET r.evidence_count = size($evidence_version_ids),
                    r.confidence = $confidence,
                    r.evidence_version_ids = $evidence_version_ids,
                    r.supporting_chunk_ids = $supporting_chunk_ids,
                    r.evidence_snippets = $evidence_snippets,
                    r.classifications = $classifications
                """,
                source_id=source_id,
                target_id=target_id,
                confidence=evidence["confidence"],
                evidence_version_ids=sorted(set(evidence["evidence_version_ids"])),
                supporting_chunk_ids=sorted(set(evidence["supporting_chunk_ids"])),
                evidence_snippets=list(dict.fromkeys(evidence["evidence_snippets"]))[:10],
                classifications=sorted(set(evidence["classifications"])),
            )

    async def retrieval_scope(
        self,
        process_id: str,
        allowed_classifications: list[str],
        include_descendants: bool = False,
    ) -> list[str]:
        process_match = (
            "MATCH (:Process {process_id: $process_id})-[:HAS_SUBPROCESS*0..5]->(scope:Process)"
            if include_descendants
            else "MATCH (scope:Process {process_id: $process_id})"
        )
        records = await self.query(
            f"""
            {process_match}
            MATCH (scope)-[:HAS_DOCUMENT]->(:Document)
                  -[:HAS_VERSION]->(v:DocumentVersion {{active: true}})
            WHERE v.classification IN $allowed_classifications
            RETURN DISTINCT v.document_version_id AS document_version_id
            ORDER BY document_version_id
            """,
            {
                "process_id": process_id,
                "allowed_classifications": allowed_classifications,
            },
        )
        return [row["document_version_id"] for row in records]

    async def evidence_lineage(
        self,
        document_version_id: str,
        chunk_id: str,
        allowed_classifications: list[str],
    ) -> dict[str, Any] | None:
        """Resolve a vector chunk reference back to its governed graph evidence."""
        rows = await self.query(
            """
            MATCH (p:Process)-[:HAS_DOCUMENT]->(d:Document)-[:HAS_VERSION]->
                  (v:DocumentVersion {document_version_id: $document_version_id})
            WHERE v.classification IN $allowed_classifications
            OPTIONAL MATCH (source:Process)
              -[fact:HAS_SUBPROCESS|DEPENDS_ON|OPERATES_IN|OWNED_BY|
                     GOVERNED_BY|USES_SYSTEM]->(target)
            WHERE $chunk_id IN coalesce(fact.supporting_chunk_ids, [])
              AND $document_version_id IN coalesce(fact.evidence_version_ids, [])
            RETURN p.process_id AS process_id, p.name AS process_name,
                   d.document_id AS document_id, d.title AS document_title,
                   v.document_version_id AS document_version_id, v.version AS version,
                   v.classification AS classification, v.active AS version_active,
                   $chunk_id AS chunk_id,
                   collect(CASE WHEN fact IS NULL THEN null ELSE {
                       source_process: source.name,
                       predicate: type(fact),
                       target_type: labels(target)[0],
                       target_name: target.name,
                       confidence: fact.confidence
                   } END) AS facts
            """,
            {
                "chunk_id": chunk_id,
                "document_version_id": document_version_id,
                "allowed_classifications": allowed_classifications,
            },
        )
        return rows[0] if rows else None

    async def referenced_chunk_ids(self, process_id: str) -> list[str]:
        """Return vector IDs referenced by governed relationships.

        Other active vector chunks may provide narrative RAG context and are not
        expected to appear in this set.
        """
        rows = await self.query(
            """
            MATCH (:Process {process_id: $process_id})
                  -[:HAS_SUBPROCESS*0..5]->(scope:Process)
            MATCH (scope)
                  -[r:HAS_SUBPROCESS|DEPENDS_ON|OPERATES_IN|OWNED_BY|
                       GOVERNED_BY|USES_SYSTEM]->()
            UNWIND coalesce(r.supporting_chunk_ids, []) AS chunk_id
            RETURN DISTINCT chunk_id
            ORDER BY chunk_id
            """,
            {"process_id": process_id},
        )
        return [row["chunk_id"] for row in rows]

    async def active_version_ids(self, process_id: str) -> list[str]:
        return await self.retrieval_scope(
            process_id,
            ["public", "internal", "confidential", "restricted"],
            include_descendants=True,
        )

    async def upsert_bpmn(
        self,
        document: ParsedDocument,
        document_id: str,
        document_version_id: str,
        raw_content: bytes,
    ) -> tuple[int, int]:
        structure = parse_bpmn_structure(raw_content)
        bpmn_id = f"bpmn:{document_version_id}"
        process_id = document.metadata.process.process_id
        await self.driver.execute_query(
            """
            MATCH (p:Process {process_id: $process_id})
            MATCH (v:DocumentVersion {document_version_id: $document_version_id})
            MERGE (b:BPMNModel {bpmn_id: $bpmn_id})
            ON CREATE SET b.created_at = datetime()
            SET b.name = $name, b.bpmn_process_id = $bpmn_process_id,
                b.source_document_id = $document_id,
                b.source_document_version_id = $document_version_id,
                b.checksum = $checksum, b.updated_at = datetime()
            MERGE (p)-[:MODELED_BY]->(b)
            MERGE (v)-[:REPRESENTED_BY]->(b)
            """,
            process_id=process_id,
            document_version_id=document_version_id,
            bpmn_id=bpmn_id,
            name=structure["name"] or document.metadata.title,
            bpmn_process_id=structure["bpmn_process_id"],
            document_id=document_id,
            checksum=document.checksum,
        )
        for activity in structure["activities"]:
            activity_id = f"{bpmn_id}:{activity['activity_id']}"
            await self.driver.execute_query(
                """
                MATCH (b:BPMNModel {bpmn_id: $bpmn_id})
                MERGE (a:Activity {activity_id: $activity_id})
                SET a.bpmn_element_id = $element_id, a.name = $name,
                    a.activity_type = $activity_type, a.updated_at = datetime()
                MERGE (b)-[:DEFINES_ACTIVITY]->(a)
                """,
                bpmn_id=bpmn_id,
                activity_id=activity_id,
                element_id=activity["activity_id"],
                name=activity["name"],
                activity_type=activity["activity_type"],
            )
        for flow in structure["flows"]:
            await self.driver.execute_query(
                """
                MATCH (a:Activity {activity_id: $source_id})
                MATCH (b:Activity {activity_id: $target_id})
                MERGE (a)-[r:NEXT_ACTIVITY {bpmn_id: $bpmn_id, flow_id: $flow_id}]->(b)
                SET r.name = $name
                """,
                source_id=f"{bpmn_id}:{flow['source_id']}",
                target_id=f"{bpmn_id}:{flow['target_id']}",
                bpmn_id=bpmn_id,
                flow_id=flow["flow_id"],
                name=flow["name"],
            )
        return len(structure["activities"]), len(structure["flows"])

    async def upsert_journeys(self, batch: JourneyBatch) -> dict[str, int]:
        process = batch.process
        await self.driver.execute_query(
            """
            MERGE (p:Process {process_id: $process_id})
            ON CREATE SET p.created_at = datetime()
            SET p.name = $name, p.description = $description, p.updated_at = datetime(),
                p.ontology_version = $ontology_version
            """,
            process_id=process.process_id,
            name=process.name,
            description=process.description,
            ontology_version=ONTOLOGY_VERSION,
        )
        variants: set[str] = set()
        event_count = 0
        for journey in batch.journeys:
            variants.add(journey.variant_id)
            duration_seconds = (
                (journey.ended_at - journey.started_at).total_seconds()
                if journey.ended_at
                else None
            )
            activity_ids = [event.activity_id for event in journey.events]
            await self.driver.execute_query(
                """
                MATCH (p:Process {process_id: $process_id})
                MERGE (v:Variant {variant_id: $variant_id})
                SET v.name = $variant_name,
                    v.process_id = $process_id, v.activity_ids = $activity_ids,
                    v.updated_at = datetime()
                MERGE (j:Journey {journey_id: $journey_id})
                SET j.name = $journey_name,
                    j.started_at = datetime($started_at),
                    j.ended_at = CASE WHEN $ended_at IS NULL THEN null ELSE datetime($ended_at) END,
                    j.duration_seconds = $duration_seconds, j.outcome = $outcome,
                    j.attributes_json = $attributes_json, j.events_json = $events_json,
                    j.updated_at = datetime()
                MERGE (p)-[:HAS_VARIANT]->(v)
                MERGE (p)-[:HAS_JOURNEY]->(j)
                MERGE (j)-[:FOLLOWS_VARIANT]->(v)
                """,
                process_id=process.process_id,
                variant_id=f"{process.process_id}:{journey.variant_id}",
                variant_name=journey.variant_id,
                journey_id=f"{process.process_id}:{journey.journey_id}",
                journey_name=journey.journey_id,
                activity_ids=activity_ids,
                started_at=journey.started_at.isoformat(),
                ended_at=journey.ended_at.isoformat() if journey.ended_at else None,
                duration_seconds=duration_seconds,
                outcome=journey.outcome,
                attributes_json=json.dumps(journey.attributes),
                events_json=json.dumps([event.model_dump(mode="json") for event in journey.events]),
            )
            event_count += len(journey.events)
        return {"journeys": len(batch.journeys), "variants": len(variants), "events": event_count}

    async def query(self, cypher: str, parameters: dict[str, Any]) -> list[dict[str, Any]]:
        records, _, _ = await self.driver.execute_query(
            cypher, parameters_=parameters, routing_="r"
        )
        return [record.data() for record in records]

    async def subgraph(
        self, process_id: str, allowed_classifications: list[str]
    ) -> list[dict[str, Any]]:
        graph = await self.visualization(process_id, allowed_classifications, view="overview")
        return graph["edges"]

    async def list_processes(self) -> list[dict[str, Any]]:
        return await self.query(
            """
            MATCH (p:Process)
            OPTIONAL MATCH (parent:Process)-[:HAS_SUBPROCESS]->(p)
            OPTIONAL MATCH (p)-[:HAS_DOCUMENT]->(d:Document)
            OPTIONAL MATCH (p)-[:HAS_JOURNEY]->(j:Journey)
            RETURN p.process_id AS process_id, p.name AS name,
                   p.description AS description, p.owner AS owner,
                   p.criticality AS criticality,
                   parent.process_id AS parent_process_id,
                   parent.name AS parent_process_name,
                   count(DISTINCT d) AS document_count,
                   count(DISTINCT j) AS journey_count
            ORDER BY p.name
            """,
            {},
        )

    async def entity_catalog(self) -> list[dict[str, Any]]:
        """Return the governed vocabulary used by the LLM entity linker."""
        return await self.query(
            """
            MATCH (n)
            WHERE n:Process OR n:Market OR n:Control OR n:System OR n:BusinessUnit
            RETURN labels(n)[0] AS entity_type,
                   coalesce(n.process_id, n.market_id, n.control_id,
                            n.system_id, n.business_unit_id) AS entity_id,
                   n.name AS name, coalesce(n.aliases, []) AS aliases
            ORDER BY entity_type, name
            """,
            {},
        )

    async def visualization(
        self,
        process_id: str,
        allowed_classifications: list[str],
        view: str = "overview",
    ) -> dict[str, Any]:
        """Return graph-shaped JSON for the browser UI.

        The view is intentionally bounded; enterprise UIs should never issue an
        unconstrained whole-database traversal for every page load.
        """
        parameters = {
            "process_id": process_id,
            "allowed_classifications": allowed_classifications,
        }
        rows = await self.query(
            """
            MATCH (:Process {process_id: $process_id})
                  -[:HAS_SUBPROCESS*0..5]->(p:Process)
            MATCH (p)-[r:HAS_SUBPROCESS|DEPENDS_ON|OPERATES_IN|OWNED_BY|
                         GOVERNED_BY|USES_SYSTEM|HAS_DOCUMENT|MODELED_BY|
                         HAS_JOURNEY|HAS_VARIANT]->(n)
            WHERE (n:Document AND EXISTS {
                    MATCH (n)-[:HAS_VERSION]->(v:DocumentVersion {active: true})
                    WHERE v.classification IN $allowed_classifications
                  })
               OR (NOT n:Document AND
                   (r.classifications IS NULL OR
                    any(level IN r.classifications
                        WHERE level IN $allowed_classifications)))
            RETURN p.process_id AS source_id, labels(p)[0] AS source_label,
                   p.name AS source_name, properties(p) AS source_properties,
                   type(r) AS relationship, properties(r) AS relationship_properties,
                   coalesce(n.process_id, n.document_id, n.bpmn_id, n.journey_id, n.variant_id,
                            n.market_id, n.business_unit_id, n.control_id, n.system_id)
                     AS target_id,
                   labels(n)[0] AS target_label,
                   coalesce(n.name, n.title, n.journey_id, n.variant_id) AS target_name,
                   properties(n) AS target_properties
            ORDER BY relationship, target_name
            LIMIT 500
            """,
            parameters,
        )

        nodes: dict[str, dict[str, Any]] = {}
        edges: dict[str, dict[str, Any]] = {}
        self._merge_visual_rows(nodes, edges, rows)

        if view in {"evidence", "all"}:
            evidence_rows = await self.query(
                """
                MATCH (:Process {process_id: $process_id})
                      -[:HAS_SUBPROCESS*0..5]->(p:Process)
                MATCH (p)-[:HAS_DOCUMENT]->(d:Document)
                      -[version_rel:HAS_VERSION]->(v:DocumentVersion {active: true})
                WHERE v.classification IN $allowed_classifications
                RETURN d.document_id AS document_id, d.title AS document_name,
                       properties(d) AS document_properties,
                       type(version_rel) AS version_relationship,
                       v.document_version_id AS version_id,
                       coalesce(v.version, v.document_version_id) AS version_name,
                       properties(v) AS version_properties
                ORDER BY document_name, version_name
                LIMIT 500
                """,
                parameters,
            )
            for row in evidence_rows:
                self._add_node(
                    nodes,
                    row["document_id"],
                    "Document",
                    row["document_name"],
                    row["document_properties"],
                )
                self._add_node(
                    nodes,
                    row["version_id"],
                    "DocumentVersion",
                    row["version_name"],
                    row["version_properties"],
                )
                self._add_edge(
                    edges,
                    row["document_id"],
                    row["version_id"],
                    row["version_relationship"],
                    {},
                )

        if view in {"execution", "all"}:
            execution_rows = await self.query(
                """
                MATCH (:Process {process_id: $process_id})
                      -[:HAS_SUBPROCESS*0..5]->(p:Process)
                MATCH (p)-[:MODELED_BY]->(b:BPMNModel)
                      -[:DEFINES_ACTIVITY]->(a:Activity)
                OPTIONAL MATCH (a)-[flow:NEXT_ACTIVITY]->(next:Activity)
                RETURN b.bpmn_id AS model_id, b.name AS model_name,
                       properties(b) AS model_properties,
                       a.activity_id AS activity_id, a.name AS activity_name,
                       properties(a) AS activity_properties,
                       next.activity_id AS next_id, next.name AS next_name,
                       properties(next) AS next_properties,
                       properties(flow) AS flow_properties
                ORDER BY model_name, activity_name
                LIMIT 500
                """,
                parameters,
            )
            for row in execution_rows:
                self._add_node(
                    nodes,
                    row["model_id"],
                    "BPMNModel",
                    row["model_name"],
                    row["model_properties"],
                )
                self._add_node(
                    nodes,
                    row["activity_id"],
                    "Activity",
                    row["activity_name"],
                    row["activity_properties"],
                )
                self._add_edge(
                    edges,
                    row["model_id"],
                    row["activity_id"],
                    "DEFINES_ACTIVITY",
                    {},
                )
                if row["next_id"]:
                    self._add_node(
                        nodes,
                        row["next_id"],
                        "Activity",
                        row["next_name"],
                        row["next_properties"],
                    )
                    self._add_edge(
                        edges,
                        row["activity_id"],
                        row["next_id"],
                        "NEXT_ACTIVITY",
                        row["flow_properties"],
                    )

        return {
            "process_id": process_id,
            "view": view,
            "nodes": list(nodes.values()),
            "edges": list(edges.values()),
        }

    def _merge_visual_rows(
        self,
        nodes: dict[str, dict[str, Any]],
        edges: dict[str, dict[str, Any]],
        rows: list[dict[str, Any]],
    ) -> None:
        for row in rows:
            self._add_node(
                nodes,
                row["source_id"],
                row["source_label"],
                row["source_name"],
                row["source_properties"],
            )
            self._add_node(
                nodes,
                row["target_id"],
                row["target_label"],
                row["target_name"],
                row["target_properties"],
            )
            self._add_edge(
                edges,
                row["source_id"],
                row["target_id"],
                row["relationship"],
                row["relationship_properties"],
            )

    @staticmethod
    def _add_node(
        nodes: dict[str, dict[str, Any]],
        node_id: str | None,
        label: str | None,
        name: str | None,
        properties: dict[str, Any] | None,
    ) -> None:
        if not node_id:
            return
        nodes[node_id] = {
            "id": node_id,
            "label": label or "Unknown",
            "name": name or node_id,
            "properties": json.loads(json.dumps(properties or {}, default=str)),
        }

    @staticmethod
    def _add_edge(
        edges: dict[str, dict[str, Any]],
        source: str | None,
        target: str | None,
        relationship: str | None,
        properties: dict[str, Any] | None,
    ) -> None:
        if not source or not target or not relationship:
            return
        edge_id = f"{source}|{relationship}|{target}"
        edges[edge_id] = {
            "id": edge_id,
            "source": source,
            "target": target,
            "relationship": relationship,
            "properties": json.loads(json.dumps(properties or {}, default=str)),
        }
