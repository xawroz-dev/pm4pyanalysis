from datetime import UTC, date, datetime
from typing import Any, Literal

from pydantic import BaseModel, Field, field_validator

from app.domain.ontology import ONTOLOGY_VERSION, NodeType, RelationshipType, validate_relationship


def utc_now() -> datetime:
    return datetime.now(UTC)


class ProcessMetadata(BaseModel):
    process_id: str = Field(min_length=1, max_length=120)
    name: str = Field(min_length=1, max_length=300)
    description: str = ""
    owner: str | None = None
    status: Literal["draft", "active", "retired", "unknown"] = "unknown"
    criticality: Literal["low", "medium", "high", "critical", "unknown"] = "unknown"
    tags: list[str] = Field(default_factory=list, max_length=50)
    parent_process_id: str | None = None
    parent_process_name: str | None = None


class ProcessReference(BaseModel):
    process_id: str = Field(min_length=1, max_length=120)
    name: str = Field(min_length=1, max_length=300)


class DocumentMetadata(BaseModel):
    document_id: str | None = None
    title: str = Field(min_length=1, max_length=500)
    document_type: Literal["sop", "policy", "process", "bpmn", "other"]
    version: str | None = None
    effective_date: date | None = None
    source_uri: str | None = None
    classification: Literal["public", "internal", "confidential", "restricted"] = "internal"
    process: ProcessMetadata
    markets: list[str] = Field(default_factory=list)
    business_units: list[str] = Field(default_factory=list)
    controls: list[str] = Field(default_factory=list)
    systems: list[str] = Field(default_factory=list)
    depends_on_processes: list[ProcessReference] = Field(default_factory=list)
    extra: dict[str, Any] = Field(default_factory=dict)


class ExtractedEntity(BaseModel):
    entity_type: NodeType
    canonical_name: str = Field(min_length=1, max_length=300)
    external_id: str | None = None
    description: str | None = None
    aliases: list[str] = Field(default_factory=list, max_length=20)
    confidence: float = Field(ge=0, le=1)
    evidence: str = Field(min_length=1, max_length=600)

    @field_validator("entity_type")
    @classmethod
    def only_domain_entities(cls, value: NodeType) -> NodeType:
        if value not in {
            NodeType.PROCESS,
            NodeType.MARKET,
            NodeType.BUSINESS_UNIT,
            NodeType.CONTROL,
            NodeType.SYSTEM,
        }:
            raise ValueError("LLM extraction may only create governed process entities")
        return value


class ExtractedRelationship(BaseModel):
    source_type: NodeType
    source_ref: str
    relationship_type: RelationshipType
    target_type: NodeType
    target_ref: str
    confidence: float = Field(ge=0, le=1)
    evidence: str = Field(min_length=1, max_length=600)

    def validate_ontology(self) -> None:
        validate_relationship(self.source_type, self.relationship_type, self.target_type)


class ExtractionResult(BaseModel):
    ontology_version: str = ONTOLOGY_VERSION
    entities: list[ExtractedEntity] = Field(default_factory=list, max_length=200)
    relationships: list[ExtractedRelationship] = Field(default_factory=list, max_length=300)
    warnings: list[str] = Field(default_factory=list)


class ParsedDocument(BaseModel):
    metadata: DocumentMetadata
    text: str
    checksum: str
    media_type: str
    original_filename: str


class TextChunk(BaseModel):
    chunk_id: str
    document_id: str
    document_version_id: str
    process_id: str
    ordinal: int
    chunk_kind: Literal["metadata", "content"] = "content"
    text: str
    content_hash: str
    title: str
    source_filename: str
    document_type: str
    classification: str
    section: str | None = None
    char_start: int | None = None
    char_end: int | None = None
    page_start: int | None = None
    page_end: int | None = None
    active: bool = False
    metadata: dict[str, Any] = Field(default_factory=dict)


class IngestionResult(BaseModel):
    ingestion_id: str
    status: Literal["created", "updated", "skipped"]
    process_id: str
    document_id: str
    document_version_id: str
    checksum: str
    chunks_indexed: int
    facts_extracted: int = 0
    entities_upserted: int
    relationships_upserted: int
    warnings: list[str] = Field(default_factory=list)
    completed_at: datetime = Field(default_factory=utc_now)


class JourneyEvent(BaseModel):
    activity_id: str
    activity_name: str
    timestamp: datetime
    system: str | None = None
    business_unit: str | None = None


class JourneyInput(BaseModel):
    journey_id: str
    variant_id: str
    started_at: datetime
    ended_at: datetime | None = None
    outcome: str | None = None
    attributes: dict[str, str | int | float | bool | None] = Field(default_factory=dict)
    events: list[JourneyEvent] = Field(min_length=1)


class JourneyBatch(BaseModel):
    process: ProcessMetadata
    journeys: list[JourneyInput] = Field(min_length=1, max_length=10000)


class ChatRequest(BaseModel):
    question: str = Field(min_length=2, max_length=4000)
    process_id: str | None = None
    conversation_id: str | None = None
    top_k: int = Field(default=6, ge=1, le=20)
    classification_clearance: Literal["public", "internal", "confidential", "restricted"] = (
        "restricted"
    )


class Citation(BaseModel):
    document_id: str
    document_version_id: str
    chunk_id: str
    title: str
    source_filename: str
    section: str | None = None
    page_start: int | None = None
    excerpt: str
    score: float


class ChatResponse(BaseModel):
    answer: str
    intent: str
    process_id: str | None
    citations: list[Citation]
    graph_facts: list[dict[str, Any]]
    retrieval: dict[str, Any]


class EntityMention(BaseModel):
    entity_type: Literal["Process", "Market", "Control", "System", "BusinessUnit"]
    text: str
    resolved_id: str | None = None
    resolved_name: str | None = None


class RetrievalPlan(BaseModel):
    use_graph: bool
    intent: Literal[
        "rag_only",
        "process_overview",
        "process_hierarchy",
        "impact_analysis",
        "controls",
        "systems",
        "ownership",
        "markets",
        "documents",
        "bpmn_flow",
        "variants",
        "journeys",
    ]
    entities: list[EntityMention] = Field(default_factory=list, max_length=20)
    rationale: str = Field(max_length=500)
    planner: Literal["llm", "offline_fallback"]


class AnswerResult(BaseModel):
    answer: str
    citations: list[Citation]
    graph_facts: list[dict[str, Any]] = Field(default_factory=list)
    retrieval: dict[str, Any]


class ComparisonResponse(BaseModel):
    question: str
    process_id: str | None
    plan: RetrievalPlan
    rag_only: AnswerResult
    hybrid: AnswerResult


class OpenExtractionEntity(BaseModel):
    label: str
    name: str


class OpenExtractionRelationship(BaseModel):
    source: str
    relationship: str
    target: str


class OpenExtractionResult(BaseModel):
    entities: list[OpenExtractionEntity] = Field(default_factory=list)
    relationships: list[OpenExtractionRelationship] = Field(default_factory=list)


class NoiseComparison(BaseModel):
    constrained_entity_types: list[str]
    constrained_relationship_types: list[str]
    open_entity_types: list[str]
    open_relationship_types: list[str]
    open_entity_type_count: int
    open_relationship_type_count: int
    normalization_examples: list[dict[str, str]]
