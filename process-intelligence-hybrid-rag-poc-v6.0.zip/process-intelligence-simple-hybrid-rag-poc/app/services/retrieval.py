"""LLM-planned hybrid retrieval for the governed process ontology.

The model chooses an intent and extracts entity mentions with a strict schema.
Application code resolves those mentions against the graph and executes only
reviewed, parameterized query templates. It never executes model-written Cypher.
"""

import re
from typing import Any

from app.config import Settings
from app.domain.models import ChatRequest, Citation, EntityMention, RetrievalPlan
from app.repositories.neo4j import Neo4jRepository
from app.repositories.vector import CLASSIFICATION_ACCESS, QdrantRepository
from app.services.llm import Embedder, LLMService, retrieval_plan_schema

GRAPH_ENTITY_TYPES = {"Process", "Market", "Control", "System", "BusinessUnit"}


GRAPH_QUERIES: dict[str, str] = {
    "process_overview": """
        MATCH (p:Process {process_id: $process_id})
        OPTIONAL MATCH (p)-[r:HAS_SUBPROCESS|DEPENDS_ON|OPERATES_IN|OWNED_BY|
                              GOVERNED_BY|USES_SYSTEM]->(entity)
        WHERE r IS NULL OR r.classifications IS NULL OR
              any(level IN r.classifications WHERE level IN $allowed_classifications)
        RETURN p.process_id AS process_id, p.name AS process,
               p.description AS description, p.criticality AS criticality,
               type(r) AS relationship, labels(entity)[0] AS entity_type,
               entity.name AS entity,
               r.evidence_version_ids AS evidence_version_ids,
               r.supporting_chunk_ids AS evidence_chunk_ids
        ORDER BY relationship, entity
    """,
    "process_hierarchy": """
        MATCH (selected:Process {process_id: $process_id})
        OPTIONAL MATCH parent_path=(ancestor:Process)-[:HAS_SUBPROCESS*1..5]->(selected)
        OPTIONAL MATCH child_path=(selected)-[:HAS_SUBPROCESS*1..5]->(descendant:Process)
        RETURN selected.name AS selected_process,
               collect(DISTINCT {
                 process_id: ancestor.process_id, name: ancestor.name,
                 direction: 'ancestor',
                 path: [node IN nodes(parent_path) | node.name]
               }) +
               collect(DISTINCT {
                 process_id: descendant.process_id, name: descendant.name,
                 direction: 'descendant',
                 path: [node IN nodes(child_path) | node.name]
               }) AS hierarchy
    """,
    "impact_analysis": """
        MATCH (dependency)
        WHERE (dependency:System OR dependency:Control)
          AND (dependency.system_id IN $entity_ids OR dependency.control_id IN $entity_ids
               OR toLower(dependency.name) IN $entity_names)
        MATCH (direct:Process)-[rel:USES_SYSTEM|GOVERNED_BY]->(dependency)
        WHERE rel.classifications IS NULL OR
              any(level IN rel.classifications WHERE level IN $allowed_classifications)
        MATCH impact_path=(impacted:Process)-[:HAS_SUBPROCESS|DEPENDS_ON*0..5]->(direct)
        WHERE all(path_rel IN relationships(impact_path)
                  WHERE path_rel.classifications IS NULL OR
                        any(level IN path_rel.classifications
                            WHERE level IN $allowed_classifications))
        RETURN DISTINCT labels(dependency)[0] AS dependency_type,
               dependency.name AS dependency,
               type(rel) AS dependency_relationship,
               direct.process_id AS directly_dependent_process_id,
               direct.name AS directly_dependent_process,
               impacted.process_id AS impacted_process_id,
               impacted.name AS impacted_process,
               CASE WHEN impacted = direct THEN 'direct' ELSE 'indirect' END AS impact_type,
               [node IN nodes(impact_path) | node.name] AS process_path,
               [path_rel IN relationships(impact_path) | type(path_rel)]
                 AS path_relationships,
               reduce(version_ids = coalesce(rel.evidence_version_ids, []),
                      path_rel IN relationships(impact_path) |
                      version_ids + coalesce(path_rel.evidence_version_ids, []))
                 AS evidence_version_ids,
               reduce(chunk_ids = coalesce(rel.supporting_chunk_ids, []),
                      path_rel IN relationships(impact_path) |
                      chunk_ids + coalesce(path_rel.supporting_chunk_ids, []))
                 AS evidence_chunk_ids
        ORDER BY impact_type, impacted_process
    """,
    "controls": """
        MATCH (selected:Process {process_id: $process_id})
        MATCH path=(selected)-[:HAS_SUBPROCESS*0..5]->(scope:Process)
        MATCH (scope)-[r:GOVERNED_BY]->(control:Control)
        WHERE r.classifications IS NULL OR
              any(level IN r.classifications WHERE level IN $allowed_classifications)
        RETURN selected.name AS selected_process, scope.process_id AS process_id,
               scope.name AS process, control.control_id AS id, control.name AS name,
               CASE WHEN scope = selected THEN 'direct' ELSE 'inherited_from_subprocess' END
                 AS applicability,
               [node IN nodes(path) | node.name] AS process_path,
               r.evidence_version_ids AS evidence_version_ids,
               r.supporting_chunk_ids AS evidence_chunk_ids
        ORDER BY process, name
    """,
    "systems": """
        MATCH (selected:Process {process_id: $process_id})
        MATCH path=(selected)-[:HAS_SUBPROCESS*0..5]->(scope:Process)
        MATCH (scope)-[r:USES_SYSTEM]->(system:System)
        WHERE r.classifications IS NULL OR
              any(level IN r.classifications WHERE level IN $allowed_classifications)
        RETURN selected.name AS selected_process, scope.process_id AS process_id,
               scope.name AS process, system.system_id AS id, system.name AS name,
               CASE WHEN scope = selected THEN 'direct' ELSE 'inherited_from_subprocess' END
                 AS dependency_type,
               [node IN nodes(path) | node.name] AS process_path,
               r.evidence_version_ids AS evidence_version_ids,
               r.supporting_chunk_ids AS evidence_chunk_ids
        ORDER BY process, name
    """,
    "ownership": """
        MATCH (selected:Process {process_id: $process_id})
        MATCH path=(selected)-[:HAS_SUBPROCESS*0..5]->(scope:Process)
        MATCH (scope)-[r:OWNED_BY]->(unit:BusinessUnit)
        WHERE r.classifications IS NULL OR
              any(level IN r.classifications WHERE level IN $allowed_classifications)
        RETURN scope.process_id AS process_id, scope.name AS process,
               unit.business_unit_id AS id, unit.name AS name,
               [node IN nodes(path) | node.name] AS process_path,
               r.evidence_version_ids AS evidence_version_ids,
               r.supporting_chunk_ids AS evidence_chunk_ids
        ORDER BY process, name
    """,
    "markets": """
        MATCH (selected:Process {process_id: $process_id})
        MATCH path=(selected)-[:HAS_SUBPROCESS*0..5]->(scope:Process)
        MATCH (scope)-[r:OPERATES_IN]->(market:Market)
        WHERE r.classifications IS NULL OR
              any(level IN r.classifications WHERE level IN $allowed_classifications)
        RETURN scope.process_id AS process_id, scope.name AS process,
               market.market_id AS id, market.name AS name,
               [node IN nodes(path) | node.name] AS process_path,
               r.evidence_version_ids AS evidence_version_ids,
               r.supporting_chunk_ids AS evidence_chunk_ids
        ORDER BY process, name
    """,
    "documents": """
        MATCH (selected:Process {process_id: $process_id})
        MATCH (selected)-[:HAS_SUBPROCESS*0..5]->(scope:Process)
        MATCH (scope)-[:HAS_DOCUMENT]->(document:Document)-[:HAS_VERSION]->
              (version:DocumentVersion {active: true})
        WHERE version.classification IN $allowed_classifications
        RETURN scope.name AS process, document.document_id AS id,
               document.title AS title, document.document_type AS document_type,
               version.document_version_id AS document_version_id,
               version.version AS version, version.classification AS classification
        ORDER BY process, document_type, title
    """,
    "bpmn_flow": """
        MATCH (selected:Process {process_id: $process_id})
        MATCH (selected)-[:HAS_SUBPROCESS*0..5]->(scope:Process)-[:MODELED_BY]->
              (model:BPMNModel)-[:DEFINES_ACTIVITY]->(activity:Activity)
        OPTIONAL MATCH (activity)-[flow:NEXT_ACTIVITY]->(next:Activity)
        RETURN scope.name AS process, model.name AS model,
               activity.name AS activity, next.name AS next_activity,
               flow.name AS condition
        ORDER BY process, activity
    """,
    "variants": """
        MATCH (selected:Process {process_id: $process_id})
        MATCH (selected)-[:HAS_SUBPROCESS*0..5]->(scope:Process)-[:HAS_VARIANT]->
              (variant:Variant)
        OPTIONAL MATCH (journey:Journey)-[:FOLLOWS_VARIANT]->(variant)
        RETURN scope.name AS process, variant.variant_id AS variant_id,
               variant.activity_ids AS activity_ids, count(journey) AS journey_count,
               avg(journey.duration_seconds) AS avg_duration_seconds
        ORDER BY journey_count DESC
    """,
    "journeys": """
        MATCH (selected:Process {process_id: $process_id})
        MATCH (selected)-[:HAS_SUBPROCESS*0..5]->(scope:Process)-[:HAS_JOURNEY]->
              (journey:Journey)
        OPTIONAL MATCH (journey)-[:FOLLOWS_VARIANT]->(variant:Variant)
        RETURN scope.name AS process, journey.journey_id AS journey_id,
               variant.variant_id AS variant_id, journey.duration_seconds AS duration_seconds,
               journey.outcome AS outcome
        ORDER BY process, journey.started_at DESC LIMIT 100
    """,
}


class OntologyPlanner:
    """Classify intent and entity mentions, then link them to governed IDs."""

    def __init__(self, settings: Settings, graph: Neo4jRepository, llm: LLMService):
        self.settings = settings
        self.graph = graph
        self.llm = llm

    async def plan(self, question: str, selected_process_id: str | None) -> RetrievalPlan:
        catalog = await self.graph.entity_catalog()
        if self.llm.enabled:
            raw = await self.llm.generate_json(
                """You are the retrieval planner for an enterprise process knowledge store.
Use graph only when the question asks about Process, Market, Control, System, or
BusinessUnit entities, their hierarchy, dependencies, ownership, impact, or relationships.
Use rag_only for narrative document questions that do not need these relationships.
For outages, failures, changes, dependencies, affected/impacted processes, select
impact_analysis. Extract entity text exactly. Never write Cypher. The application owns queries.
Return planner='llm'.""",
                (
                    f"QUESTION: {question}\nSELECTED_PROCESS_ID: {selected_process_id}\n"
                    f"GOVERNED_ENTITY_CATALOG: {catalog}"
                ),
                "process_retrieval_plan",
                retrieval_plan_schema(),
            )
            plan = RetrievalPlan.model_validate(raw)
        else:
            plan = offline_plan(question, selected_process_id, catalog)
        plan.entities = resolve_mentions(plan.entities, catalog)
        if selected_process_id and not any(
            item.entity_type == "Process" and item.resolved_id == selected_process_id
            for item in plan.entities
        ):
            selected = next(
                (item for item in catalog if item["entity_id"] == selected_process_id), None
            )
            if selected:
                plan.entities.append(
                    EntityMention(
                        entity_type="Process",
                        text=selected["name"],
                        resolved_id=selected["entity_id"],
                        resolved_name=selected["name"],
                    )
                )
        return plan


class HybridRetriever:
    def __init__(
        self,
        settings: Settings,
        graph: Neo4jRepository,
        vectors: QdrantRepository,
        embedder: Embedder,
        llm: LLMService,
    ):
        self.graph = graph
        self.vectors = vectors
        self.embedder = embedder
        self.planner = OntologyPlanner(settings, graph, llm)

    async def vector_retrieve(
        self, request: ChatRequest, include_descendants: bool = False
    ) -> tuple[str | None, list[Citation]]:
        allowed = CLASSIFICATION_ACCESS[request.classification_clearance]
        vector = (await self.embedder.embed([request.question]))[0]
        process_id = request.process_id
        version_scope = None
        vector_process_filter = process_id
        if process_id:
            version_scope = await self.graph.retrieval_scope(
                process_id, allowed, include_descendants=include_descendants
            )
            if include_descendants:
                vector_process_filter = None
        hits = await self.vectors.search(
            vector,
            min(20, request.top_k * 3),
            vector_process_filter,
            request.classification_clearance,
            version_scope,
        )
        hits = rerank_hits(request.question, hits, request.top_k)
        if not process_id:
            process_id = infer_process_id(hits)
        return process_id, [citation_from_hit(hit) for hit in hits]

    async def graph_retrieve(
        self, plan: RetrievalPlan, process_id: str | None, clearance: str
    ) -> list[dict[str, Any]]:
        if not plan.use_graph or plan.intent == "rag_only":
            return []
        query = GRAPH_QUERIES.get(plan.intent)
        if not query:
            return []
        process_mentions = [
            item.resolved_id
            for item in plan.entities
            if item.entity_type == "Process" and item.resolved_id
        ]
        effective_process_id = process_id or (process_mentions[0] if process_mentions else None)
        if process_mentions:
            effective_process_id = process_mentions[0]
        if plan.intent != "impact_analysis" and not effective_process_id:
            return []
        entity_ids = [item.resolved_id for item in plan.entities if item.resolved_id]
        entity_names = [item.resolved_name or item.text for item in plan.entities]
        return await self.graph.query(
            query,
            {
                "process_id": effective_process_id,
                "entity_ids": entity_ids,
                "entity_names": [name.casefold() for name in entity_names],
                "allowed_classifications": CLASSIFICATION_ACCESS[clearance],
            },
        )

    async def graph_evidence_citations(
        self, graph_facts: list[dict[str, Any]]
    ) -> list[Citation]:
        """Fetch the exact vector chunks referenced by returned graph edges."""
        chunk_ids = list(
            dict.fromkeys(
                chunk_id
                for fact in graph_facts
                for chunk_id in fact.get("evidence_chunk_ids", [])
            )
        )
        citations: list[Citation] = []
        for chunk_id in chunk_ids:
            payload = await self.vectors.get_chunk(chunk_id)
            if payload:
                citations.append(citation_from_hit({"score": 1.0, **payload}))
        return citations


def offline_plan(
    question: str, selected_process_id: str | None, catalog: list[dict[str, Any]]
) -> RetrievalPlan:
    """Ontology-aware local fallback; it never contains sample-specific answers."""
    text = question.casefold()
    mentions = []
    for item in catalog:
        names = [item["name"], *item.get("aliases", [])]
        exact = any(name.casefold() in text for name in names)
        distinctive_tokens = {
            token
            for name in names
            for token in re.findall(r"[a-z0-9-]+", name.casefold())
            if len(token) >= 5
            and token
            not in {
                "process",
                "processing",
                "system",
                "control",
                "operations",
                "management",
                "business",
            }
        }
        if exact or any(token in text for token in distinctive_tokens):
            mentions.append(
                EntityMention(entity_type=item["entity_type"], text=item["name"])
            )
    impact_words = ("impact", "affected", "down", "outage", "failure", "unavailable", "change")
    mapping = [
        ("impact_analysis", impact_words),
        ("process_hierarchy", ("subprocess", "parent process", "hierarchy", "upstream")),
        ("controls", ("control", "compliance", "risk")),
        ("systems", ("system", "application", "platform", "technology")),
        ("ownership", ("owner", "business unit", "team", "responsible")),
        ("markets", ("market", "country", "region", "geography")),
        ("bpmn_flow", ("bpmn", "flow", "activity", "step", "sequence")),
        ("variants", ("variant", "path")),
        ("journeys", ("journey", "case", "execution")),
        ("documents", ("document", "sop", "policy", "source")),
        ("process_overview", ("process", "overview", "describe")),
    ]
    intent = next(
        (name for name, words in mapping if any(word in text for word in words)),
        "rag_only",
    )
    uses_graph = intent != "rag_only" and (bool(mentions) or bool(selected_process_id))
    return RetrievalPlan(
        use_graph=uses_graph,
        intent=intent if uses_graph else "rag_only",
        entities=mentions,
        rationale=(
            "Question targets governed process entities or relationships."
            if uses_graph
            else "Question is narrative and can be answered from document passages."
        ),
        planner="offline_fallback",
    )


def resolve_mentions(
    mentions: list[EntityMention], catalog: list[dict[str, Any]]
) -> list[EntityMention]:
    for mention in mentions:
        candidates = [
            item
            for item in catalog
            if item["entity_type"] == mention.entity_type
            and (
                item["name"].casefold() == mention.text.casefold()
                or mention.text.casefold()
                in [alias.casefold() for alias in item.get("aliases", [])]
                or item["entity_id"].casefold() == mention.text.casefold()
            )
        ]
        if len(candidates) == 1:
            mention.resolved_id = candidates[0]["entity_id"]
            mention.resolved_name = candidates[0]["name"]
    return mentions


def citation_from_hit(hit: dict[str, Any]) -> Citation:
    return Citation(
        document_id=hit["document_id"],
        document_version_id=hit["document_version_id"],
        chunk_id=hit["chunk_id"],
        title=hit["title"],
        source_filename=hit.get("source_filename", hit["title"]),
        section=hit.get("section"),
        page_start=hit.get("page_start"),
        excerpt=compact_excerpt(hit["text"]),
        score=float(hit["score"]),
    )


def infer_process_id(hits: list[dict[str, Any]]) -> str | None:
    if not hits:
        return None
    scores: dict[str, float] = {}
    for hit in hits:
        scores[hit["process_id"]] = scores.get(hit["process_id"], 0.0) + float(hit["score"])
    return max(scores, key=scores.get)


def rerank_hits(
    question: str, hits: list[dict[str, Any]], top_k: int
) -> list[dict[str, Any]]:
    """Use lexical evidence to stabilize the lightweight offline embeddings."""
    query_tokens = content_tokens(question)
    frequencies = {
        token: sum(token in content_tokens(hit.get("text", "")) for hit in hits)
        for token in query_tokens
    }

    def lexical_score(hit: dict[str, Any]) -> float:
        hit_tokens = content_tokens(hit.get("text", ""))
        return sum(
            1 / max(1, frequencies[token])
            for token in query_tokens
            if token in hit_tokens
        )

    ranked = sorted(
        hits,
        key=lambda hit: (
            lexical_score(hit),
            float(hit.get("score", 0)),
        ),
        reverse=True,
    )
    if not ranked:
        return []
    best_score = lexical_score(ranked[0])
    if best_score:
        ranked = [hit for hit in ranked if lexical_score(hit) >= best_score * 0.75]
    return ranked[:top_k]


def content_tokens(text: str) -> set[str]:
    stop_words = {
        "what",
        "which",
        "when",
        "where",
        "does",
        "have",
        "with",
        "from",
        "about",
        "their",
        "this",
        "that",
        "process",
        "processes",
        "system",
        "systems",
        "control",
        "controls",
        "market",
        "markets",
        "business",
        "unit",
        "the",
        "and",
        "are",
        "was",
        "were",
        "for",
        "can",
    }
    return {
        token[:-1] if token.endswith("s") and len(token) > 5 else token
        for token in re.findall(r"[a-z0-9-]+", text.casefold())
        if len(token) >= 3 and token not in stop_words
    }


def compact_excerpt(text: str, limit: int = 800) -> str:
    text = re.sub(r"\s+", " ", text).strip()
    return text if len(text) <= limit else text[: limit - 1] + "…"
