import hashlib
import re
import uuid

from app.domain.models import ParsedDocument, TextChunk

CHUNK_NAMESPACE = uuid.UUID("16f7b5ea-8f24-4ec2-9f68-1f58868d555c")


def chunk_document(
    document: ParsedDocument,
    document_id: str,
    document_version_id: str,
    chunk_size: int,
    overlap: int,
) -> list[TextChunk]:
    if overlap >= chunk_size:
        raise ValueError("chunk overlap must be smaller than chunk size")

    paragraphs = [p.strip() for p in re.split(r"\n\s*\n", document.text) if p.strip()]
    chunks: list[tuple[str, str | None]] = []
    current = ""
    current_section: str | None = None
    section = None
    for paragraph in paragraphs:
        if is_heading(paragraph):
            section = paragraph.lstrip("#").strip()
        if len(current) + len(paragraph) + 2 <= chunk_size:
            if not current:
                current_section = section
            current = f"{current}\n\n{paragraph}".strip()
            continue
        if current:
            chunks.append((current, current_section))
        carry = current[-overlap:] if current else ""
        if len(paragraph) > chunk_size:
            start = 0
            while start < len(paragraph):
                piece = f"{carry}\n{paragraph[start : start + chunk_size - len(carry)]}".strip()
                chunks.append((piece, section))
                carry = piece[-overlap:]
                start += max(1, chunk_size - overlap)
            current = ""
            current_section = None
        else:
            current = f"{carry}\n{paragraph}".strip()
            current_section = section
    if current:
        chunks.append((current, current_section))

    metadata_text = metadata_evidence_text(document)
    metadata_hash = hashlib.sha256(metadata_text.encode("utf-8")).hexdigest()
    result: list[TextChunk] = [
        TextChunk(
            chunk_id=str(
                uuid.uuid5(
                    CHUNK_NAMESPACE,
                    f"{document_version_id}:metadata:{metadata_hash}",
                )
            ),
            document_id=document_id,
            document_version_id=document_version_id,
            process_id=document.metadata.process.process_id,
            ordinal=-1,
            chunk_kind="metadata",
            text=metadata_text,
            content_hash=metadata_hash,
            title=document.metadata.title,
            source_filename=document.original_filename,
            document_type=document.metadata.document_type,
            classification=document.metadata.classification,
            section="Document metadata",
            metadata={
                "version": document.metadata.version,
                "effective_date": (
                    document.metadata.effective_date.isoformat()
                    if document.metadata.effective_date
                    else None
                ),
                "source_uri": document.metadata.source_uri,
            },
        )
    ]
    search_from = 0
    for ordinal, (text, section_name) in enumerate(chunks):
        content_hash = hashlib.sha256(text.encode("utf-8")).hexdigest()
        char_start = document.text.find(text, search_from)
        if char_start < 0:
            char_start = document.text.find(text)
        char_end = char_start + len(text) if char_start >= 0 else None
        if char_end is not None:
            search_from = max(search_from, char_end - overlap)
        result.append(
            TextChunk(
                chunk_id=str(
                    uuid.uuid5(
                        CHUNK_NAMESPACE,
                        f"{document_version_id}:{ordinal}:{content_hash}",
                    )
                ),
                document_id=document_id,
                document_version_id=document_version_id,
                process_id=document.metadata.process.process_id,
                ordinal=ordinal,
                chunk_kind="content",
                text=text,
                content_hash=content_hash,
                title=document.metadata.title,
                source_filename=document.original_filename,
                document_type=document.metadata.document_type,
                classification=document.metadata.classification,
                section=section_name,
                char_start=char_start if char_start >= 0 else None,
                char_end=char_end,
                metadata={
                    "version": document.metadata.version,
                    "effective_date": (
                        document.metadata.effective_date.isoformat()
                        if document.metadata.effective_date
                        else None
                    ),
                    "source_uri": document.metadata.source_uri,
                },
            )
        )
    return result


def is_heading(paragraph: str) -> bool:
    first_line = paragraph.splitlines()[0].strip()
    if first_line.startswith("#"):
        return True
    return len(first_line) <= 100 and first_line.endswith(":") and "\n" not in paragraph


def metadata_evidence_text(document: ParsedDocument) -> str:
    metadata = document.metadata
    lines = [
        f"Document metadata: {metadata.title}",
        f"Process: {metadata.process.name} ({metadata.process.process_id})",
        f"Document type: {metadata.document_type}",
        f"Version: {metadata.version or 'unversioned'}",
        f"Classification: {metadata.classification}",
    ]
    for values in (
        metadata.markets,
        metadata.business_units,
        metadata.controls,
        metadata.systems,
    ):
        lines.extend(f"Declared in metadata: {value}" for value in values)
    lines.extend(
        f"Declared dependency: {dependency.name} ({dependency.process_id})"
        for dependency in metadata.depends_on_processes
    )
    return "\n".join(lines)
