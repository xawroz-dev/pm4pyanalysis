"""Side-by-side RAG-only and graph-assisted answer generation."""

import json
import re

from app.config import Settings
from app.domain.models import (
    AnswerResult,
    ChatRequest,
    ChatResponse,
    Citation,
    ComparisonResponse,
    RetrievalPlan,
)
from app.services.llm import LLMService
from app.services.retrieval import HybridRetriever


class ChatService:
    def __init__(self, settings: Settings, retriever: HybridRetriever, llm: LLMService):
        self.settings = settings
        self.retriever = retriever
        self.llm = llm

    async def compare(self, request: ChatRequest) -> ComparisonResponse:
        plan = await self.retriever.planner.plan(request.question, request.process_id)
        process_id, rag_citations = await self.retriever.vector_retrieve(
            request, include_descendants=False
        )
        rag_citations = rag_citations[:3]
        graph_facts = await self.retriever.graph_retrieve(
            plan, process_id, request.classification_clearance
        )
        graph_citations = await self.retriever.graph_evidence_citations(graph_facts)
        # Hybrid retrieval is additive: vector context is never discarded when
        # graph facts are available. Graph-edge evidence is appended and
        # deduplicated by chunk ID.
        hybrid_citations = merge_citations(rag_citations, graph_citations)

        if self.llm.enabled:
            rag_answer = await self._rag_answer(request.question, rag_citations)
            hybrid_answer = (
                await self._hybrid_answer(
                    request.question, plan, graph_facts, hybrid_citations
                )
                if plan.use_graph
                else rag_answer
            )
        else:
            rag_answer = deterministic_rag_answer(request.question, rag_citations)
            hybrid_answer = deterministic_hybrid_answer(
                request.question, plan, graph_facts, hybrid_citations
            )

        return ComparisonResponse(
            question=request.question,
            process_id=process_id,
            plan=plan,
            rag_only=AnswerResult(
                answer=rag_answer,
                citations=rag_citations,
                retrieval={
                    "strategy": "vector_similarity_only",
                    "vector_hits": len(rag_citations),
                    "graph_called": False,
                },
            ),
            hybrid=AnswerResult(
                answer=hybrid_answer,
                citations=hybrid_citations,
                graph_facts=graph_facts,
                retrieval={
                    "strategy": (
                        "llm_plan_then_graph_plus_vector"
                        if plan.use_graph
                        else "llm_plan_then_vector_only"
                    ),
                    "vector_hits": len(rag_citations),
                    "graph_evidence_hits": len(graph_citations),
                    "combined_evidence_hits": len(hybrid_citations),
                    "graph_called": plan.use_graph,
                    "graph_rows": len(graph_facts),
                    "intent": plan.intent,
                    "llm_generated_cypher": False,
                },
            ),
        )

    async def answer(self, request: ChatRequest) -> ChatResponse:
        """Compatibility endpoint returning the hybrid side of the comparison."""
        comparison = await self.compare(request)
        return ChatResponse(
            answer=comparison.hybrid.answer,
            intent=comparison.plan.intent,
            process_id=comparison.process_id,
            citations=comparison.hybrid.citations,
            graph_facts=comparison.hybrid.graph_facts,
            retrieval=comparison.hybrid.retrieval,
        )

    async def _rag_answer(self, question: str, citations) -> str:
        return await self.llm.generate_text(
            """Answer only from the supplied vector-retrieved passages.
Do not use graph knowledge, process hierarchy, or outside knowledge.
If the passages cannot establish the answer, state that limitation clearly.
For impact questions, report only process names explicitly present in the
passages. Do not turn an activity phrase into a named process and do not infer
an upstream or downstream process unless that named relationship is explicitly
stated in the retrieved passages.
Keep the answer under 100 words. Use plain text or a short bullet list; do not
add headings, preambles, or a separate sources section. Do not include document
IDs, chunk IDs, citations, or bracketed references in the answer because the UI
renders the retrieved evidence separately.""",
            f"QUESTION:\n{question}\n\nPASSAGES:\n{json.dumps(citation_context(citations))}",
        )

    async def _hybrid_answer(self, question, plan, graph_facts, citations) -> str:
        intent_instruction = (
            """This is impact analysis. Distinguish direct from indirect impact
and include graph paths. Group rows by impacted process; if a process has
multiple paths, name the process once and list the paths."""
            if plan.intent == "impact_analysis"
            else """Answer the question directly for the selected intent. Do not
introduce outage, impact, direct/indirect, or hypothetical consequences unless
the user asked for them."""
        )
        return await self.llm.generate_text(
            f"""Answer only from the supplied governed graph facts and vector passages.
{intent_instruction}
Never invent a relationship that is absent from GRAPH_FACTS.
Keep the answer under 140 words. Use plain text or a short bullet list; do not
add headings, horizontal rules, preambles, or a separate sources section. Do not
include document IDs, chunk IDs, citations, or bracketed references in the answer
because the UI renders the retrieved evidence separately.""",
            (
                f"QUESTION:\n{question}\n\nPLAN:\n{plan.model_dump_json()}\n\n"
                f"GRAPH_FACTS:\n{json.dumps(graph_facts, default=str)}\n\n"
                f"PASSAGES:\n{json.dumps(citation_context(citations))}"
            ),
        )


def citation_context(citations) -> list[dict]:
    return [
        {
            "document_id": item.document_id,
            "document_version_id": item.document_version_id,
            "chunk_id": item.chunk_id,
            "title": item.title,
            "source_filename": item.source_filename,
            "section": item.section,
            "excerpt": item.excerpt,
        }
        for item in citations
    ]


def merge_citations(*citation_groups: list[Citation]) -> list[Citation]:
    merged: list[Citation] = []
    seen_chunk_ids: set[str] = set()
    for citations in citation_groups:
        for citation in citations:
            if citation.chunk_id in seen_chunk_ids:
                continue
            seen_chunk_ids.add(citation.chunk_id)
            merged.append(citation)
    return merged


def deterministic_rag_answer(question: str, citations) -> str:
    if not citations:
        return "RAG found no accessible document passage that answers the question."
    if any(
        term in question.casefold()
        for term in ("impact", "affected", "down", "outage", "failure", "unavailable")
    ):
        return (
            "RAG found related passages, but those passages alone do not establish "
            "dependencies inherited through process relationships."
        )
    answer = best_extract(citations, question)
    return answer


def deterministic_hybrid_answer(
    question: str, plan: RetrievalPlan, facts: list[dict], citations
) -> str:
    if not plan.use_graph:
        return deterministic_rag_answer(question, citations)
    if plan.intent == "impact_analysis" and facts:
        lines = []
        for fact in facts:
            path = " → ".join(fact.get("process_path") or [])
            lines.append(
                f"{fact['impacted_process']} ({fact['impact_type']}; path: {path})"
            )
        return (
            f"The graph found {len(facts)} impacted process relationship(s): "
            + "; ".join(lines)
            + ". This includes indirect impacts that are not stated in the main-process text."
        )
    if facts:
        return summarize_graph_facts(facts)
    return deterministic_rag_answer(question, citations)


def summarize_graph_facts(facts: list[dict]) -> str:
    """Render useful offline answers from arbitrary governed query rows."""
    statements: list[str] = []
    for fact in facts[:12]:
        process = fact.get("process") or fact.get("selected_process")
        name = fact.get("name") or fact.get("entity")
        relationship = fact.get("relationship")
        path = fact.get("process_path")
        if process and name:
            statements.append(f"{process}: {name}")
        elif process and relationship and fact.get("entity"):
            statements.append(f"{process} {relationship} {fact['entity']}")
        elif path:
            statements.append(" → ".join(path))
    if statements:
        return "; ".join(dict.fromkeys(statements)) + "."
    return f"The graph returned {len(facts)} governed result(s)."


def best_extract(citations, question: str) -> str:
    """Pick the most question-relevant sentence for the offline demo."""
    stop_words = {
        "what",
        "which",
        "when",
        "where",
        "must",
        "does",
        "have",
        "been",
        "with",
        "from",
        "about",
        "their",
    }
    query_tokens = {
        token
        for token in re.findall(r"[a-z0-9-]+", question.casefold())
        if len(token) > 3 and token not in stop_words
    }
    sentences = [
        sentence.strip()
        for citation in citations
        for sentence in re.split(r"(?<=[.!?])\s+", citation.excerpt)
        if sentence.strip()
    ]
    if not sentences:
        return "The retrieved files contain related information."
    ranked = sorted(
        sentences,
        key=lambda sentence: (
            sum(token in sentence.casefold() for token in query_tokens),
            -len(sentence),
        ),
        reverse=True,
    )
    return ranked[0]
