import hashlib
import json
import math
import re
from typing import Any, Protocol

import httpx

from app.config import Settings
from app.domain.models import ExtractionResult, OpenExtractionResult, RetrievalPlan


class LLMProvider(Protocol):
    """Provider adapter contract used by the application-facing LLM service."""

    async def generate_json(
        self, system: str, user: str, schema_name: str, schema: dict[str, Any]
    ) -> dict[str, Any]: ...

    async def generate_text(self, system: str, user: str) -> str: ...

    async def close(self) -> None: ...


class OpenAICompatibleProvider:
    """Provider adapter for OpenAI-compatible chat completion APIs."""

    def __init__(self, settings: Settings):
        self.settings = settings
        self.client = httpx.AsyncClient(timeout=90.0)

    async def close(self) -> None:
        await self.client.aclose()

    async def generate_json(
        self, system: str, user: str, schema_name: str, schema: dict[str, Any]
    ) -> dict[str, Any]:
        response = await self.client.post(
            f"{self.settings.llm_base_url.rstrip('/')}/chat/completions",
            headers={
                "Authorization": f"Bearer {self.settings.llm_api_key}",
                "Content-Type": "application/json",
            },
            json={
                "model": self.settings.llm_model,
                "temperature": 0,
                "messages": [
                    {"role": "system", "content": system},
                    {"role": "user", "content": user},
                ],
                "response_format": {
                    "type": "json_schema",
                    "json_schema": {"name": schema_name, "strict": True, "schema": schema},
                },
            },
        )
        response.raise_for_status()
        content = _completion_content(response)
        return _parse_json_content(content)

    async def generate_text(self, system: str, user: str) -> str:
        response = await self.client.post(
            f"{self.settings.llm_base_url.rstrip('/')}/chat/completions",
            headers={"Authorization": f"Bearer {self.settings.llm_api_key}"},
            json={
                "model": self.settings.llm_model,
                "temperature": 0,
                "messages": [
                    {"role": "system", "content": system},
                    {"role": "user", "content": user},
                ],
            },
        )
        response.raise_for_status()
        return _completion_content(response).strip()


class LLMService:
    """Common interface for planning, extraction, and answer generation.

    Domain services call only ``generate_json`` and ``generate_text``. To add a
    provider, implement ``LLMProvider`` and update ``from_settings``.
    """

    def __init__(self, provider: LLMProvider | None):
        self.provider = provider

    @property
    def enabled(self) -> bool:
        return self.provider is not None

    @classmethod
    def from_settings(cls, settings: Settings) -> "LLMService":
        if settings.llm_provider == "openai" and settings.llm_api_key:
            return cls(OpenAICompatibleProvider(settings))
        return cls(None)

    async def close(self) -> None:
        if self.provider:
            await self.provider.close()

    async def generate_json(
        self, system: str, user: str, schema_name: str, schema: dict[str, Any]
    ) -> dict[str, Any]:
        if not self.provider:
            raise RuntimeError("LLM provider is not configured")
        return await self.provider.generate_json(system, user, schema_name, schema)

    async def generate_text(self, system: str, user: str) -> str:
        if not self.provider:
            raise RuntimeError("LLM provider is not configured")
        return await self.provider.generate_text(system, user)


class Embedder:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.client = httpx.AsyncClient(timeout=90.0)

    async def close(self) -> None:
        await self.client.aclose()

    async def embed(self, texts: list[str]) -> list[list[float]]:
        if self.settings.embedding_provider == "openai":
            if not self.settings.llm_api_key:
                raise RuntimeError("LLM_API_KEY is required for OpenAI embeddings")
            response = await self.client.post(
                f"{self.settings.llm_base_url.rstrip('/')}/embeddings",
                headers={"Authorization": f"Bearer {self.settings.llm_api_key}"},
                json={"model": self.settings.embedding_model, "input": texts},
            )
            response.raise_for_status()
            return [item["embedding"] for item in response.json()["data"]]
        return [hash_embedding(text, self.settings.embedding_dimensions) for text in texts]


def hash_embedding(text: str, dimensions: int) -> list[float]:
    """Deterministic feature hashing for an offline demo; not a production semantic model."""
    vector = [0.0] * dimensions
    tokens = re.findall(r"[a-z0-9][a-z0-9_-]+", text.lower())
    for token in tokens:
        digest = hashlib.sha256(token.encode()).digest()
        index = int.from_bytes(digest[:4], "big") % dimensions
        sign = 1.0 if digest[4] % 2 == 0 else -1.0
        vector[index] += sign * (1.0 + math.log1p(len(token)))
    norm = math.sqrt(sum(value * value for value in vector)) or 1.0
    return [value / norm for value in vector]


def constrained_schema() -> dict[str, Any]:
    schema = ExtractionResult.model_json_schema()
    return _strictify_schema(schema)


def open_schema() -> dict[str, Any]:
    schema = OpenExtractionResult.model_json_schema()
    return _strictify_schema(schema)


def retrieval_plan_schema() -> dict[str, Any]:
    """Strict schema for the LLM's intent, entity, and tool-routing decision."""
    return _strictify_schema(RetrievalPlan.model_json_schema())


def _strictify_schema(value: Any) -> Any:
    if isinstance(value, dict):
        result = {key: _strictify_schema(item) for key, item in value.items()}
        if result.get("type") == "object":
            result["additionalProperties"] = False
            result["required"] = list(result.get("properties", {}).keys())
        return result
    if isinstance(value, list):
        return [_strictify_schema(item) for item in value]
    return value


def _completion_content(response: httpx.Response) -> str:
    """Read either a normal OpenAI response or an OpenAI-compatible SSE response."""
    content_type = response.headers.get("content-type", "").lower()
    if "text/event-stream" not in content_type:
        return response.json()["choices"][0]["message"]["content"]

    parts: list[str] = []
    for line in response.text.splitlines():
        if not line.startswith("data:"):
            continue
        data = line.removeprefix("data:").strip()
        if not data or data == "[DONE]":
            continue
        event = json.loads(data)
        choice = (event.get("choices") or [{}])[0]
        delta = choice.get("delta") or {}
        if isinstance(delta.get("content"), str):
            parts.append(delta["content"])
        elif isinstance(choice.get("message", {}).get("content"), str):
            parts.append(choice["message"]["content"])
    return "".join(parts)


def _parse_json_content(content: str) -> dict[str, Any]:
    """Tolerate JSON fenced by a compatible model while still requiring an object."""
    cleaned = content.strip()
    if cleaned.startswith("```"):
        cleaned = re.sub(r"^```(?:json)?\s*", "", cleaned, flags=re.IGNORECASE)
        cleaned = re.sub(r"\s*```$", "", cleaned)
    start, end = cleaned.find("{"), cleaned.rfind("}")
    if start < 0 or end < start:
        raise ValueError("LLM response did not contain a JSON object")
    value = json.loads(cleaned[start : end + 1])
    if not isinstance(value, dict):
        raise ValueError("LLM response must be a JSON object")
    return value
