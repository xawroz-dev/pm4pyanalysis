# Simple Process Intelligence: RAG versus Graph RAG

This POC demonstrates one idea:

- **Vector RAG** answers from retrieved document chunks.
- **Hybrid Graph RAG** first decides whether the question needs connected
  process knowledge. If it does, it queries Neo4j and retrieves the exact
  supporting chunks from Qdrant. Otherwise it behaves like normal RAG.

The UI contains one question box and two answers. There is no process selector,
clearance selector, prefilled question, query builder, or graph configuration.

## Run

```bash
podman compose up --build -d
python3 scripts/load_sample.py
```

Docker users can replace `podman compose` with `docker compose`.

Open:

- Chat comparison: <http://localhost:8000/>
- API: <http://localhost:8000/docs>
- Neo4j Browser: <http://localhost:7474/browser/>

Neo4j development login:

```text
Username: neo4j
Password: change-me-enterprise
```

## Simple data flow

### Ingestion

1. Upload a document or BPMN file with metadata.
2. Parse and split it into chunks.
3. Create embeddings and store chunks in Qdrant.
4. Extract only the governed entities:
   `Process`, `Market`, `Control`, `System`, and `BusinessUnit`.
5. Extract only approved relationships:
   `HAS_SUBPROCESS`, `DEPENDS_ON`, `OPERATES_IN`, `GOVERNED_BY`,
   `USES_SYSTEM`, and `OWNED_BY`.
6. Store the entities and relationships in Neo4j.
7. Put evidence properties on each relationship so it points back to the exact
   Qdrant chunk IDs and document versions that support it.

### Question answering

1. The planner reads the question and extracts governed entity mentions.
2. If the question asks for a relationship, dependency, hierarchy, ownership,
   control, market, or impact, it selects a reviewed graph query.
3. Neo4j can execute a single-hop or multi-hop traversal.
4. The returned relationships provide supporting chunk IDs.
5. Those chunks are retrieved from Qdrant.
6. The answer uses both the connected graph facts and the supporting text.
7. If the question does not require graph entities or relationships, Neo4j is
   skipped and the answer uses vector RAG only.

The LLM chooses an intent and entity mentions, but it never writes arbitrary
Cypher. Application code owns a small set of parameterized queries.

Policy is represented as a governed `Document` with `document_type = policy`,
not as a duplicate business entity. The process-to-policy connection is
`Process-[:HAS_DOCUMENT]->Document`.

## The RAG-failure demonstration

Ask:

```text
Which processes are affected if the Falcon system goes down?
```

The relevant facts are separated:

```text
Card Payment Processing
  -HAS_SUBPROCESS-> Real-Time Fraud Screening
  -USES_SYSTEM-> Falcon Fraud Engine
```

The system relationship is supported by `fraud_screening_policy.md`. The
hierarchy is stored independently as a governed relationship. Document RAG can
find a passage about Falcon, but it should not invent the transitive impact.

Hybrid Graph RAG traverses the hierarchy and returns:

- **Real-Time Fraud Screening** — directly affected.
- **Card Payment Processing** — indirectly affected through its subprocess.

The hybrid evidence list is the deduplicated union of vector-search chunks and
chunks referenced by the returned graph relationships.

### Cross-process dependency demonstration

Ask:

```text
Which processes are affected if the Identity Verification Platform goes down?
```

The source facts are deliberately split:

```text
(Customer Identity Verification)
  -[:USES_SYSTEM]->(Identity Verification Platform)

(Digital Card Provisioning)
  -[:DEPENDS_ON]->(Customer Identity Verification)

(Digital Card Provisioning)
  -[:USES_SYSTEM]->(Token Vault)
```

Vector RAG retrieves the identity policy and can establish only Customer
Identity Verification. Hybrid retrieval follows `DEPENDS_ON` and also identifies
Digital Card Provisioning as indirectly affected. Its evidence list contains
the policy chunk supporting the system edge and the SOP chunk supporting the
process-dependency edge.

For a narrative question such as:

```text
How long must fraud alerts and model scores be retained?
```

the planner skips Neo4j. Vector RAG returns the seven-year retention statement
from `fraud_screening_policy.md`.

## Where chunk references belong

Do not attach every chunk that mentions “Canada” to the `Market` node.

Store evidence on the relationship it supports:

```text
(Card Payment Processing)
  -[:OPERATES_IN {
      evidence_version_ids: [...],
      supporting_chunk_ids: [...],
      evidence_snippets: [...]
    }]->
(Canada)
```

If 100 processes operate in Canada, the Canada node can have 100
`OPERATES_IN` relationships. Each relationship stores only the chunks that
support that specific process-to-market fact.

This is better than storing chunk IDs on the Market node because:

- evidence remains attached to the exact claim;
- unrelated processes do not share one enormous chunk list;
- version replacement can rebuild one relationship correctly;
- graph results can retrieve only their supporting chunks;
- the Market node stays a clean canonical entity.

Chunks are not Neo4j nodes in this POC. Full chunk text and embeddings remain
in Qdrant.

## API

No process or clearance selection is required:

```bash
curl -s http://localhost:8000/v1/compare \
  -H 'Content-Type: application/json' \
  -d '{
    "question": "Which processes are affected if the Falcon system goes down?"
  }' | python3 -m json.tool
```

The response contains:

- planner decision;
- RAG-only answer and referenced files;
- hybrid answer and referenced files;
- graph facts when graph retrieval was required.

The prose answer contains no document or chunk identifiers. Under each answer,
“Retrieved evidence” lists every distinct chunk with its filename, document
title, section, and chunk ID. Selecting a chunk opens its exact stored text.

## Neo4j queries

View all governed entities and business relationships:

```cypher
MATCH path=(process:Process)-[
  :HAS_SUBPROCESS|DEPENDS_ON|OPERATES_IN|OWNED_BY|GOVERNED_BY|USES_SYSTEM
]->(entity)
RETURN path
LIMIT 500;
```

Show the Falcon impact:

```cypher
MATCH (system:System {name: 'Falcon Fraud Engine'})
MATCH (direct:Process)-[:USES_SYSTEM]->(system)
MATCH path=(impacted:Process)-[:HAS_SUBPROCESS*0..5]->(direct)
RETURN impacted.name AS process,
       CASE WHEN impacted = direct THEN 'direct' ELSE 'indirect' END AS impact,
       [node IN nodes(path) | node.name] AS process_path;
```

Show the cross-process Identity Verification Platform impact:

```cypher
MATCH (system:System {name: 'Identity Verification Platform'})
MATCH (direct:Process)-[:USES_SYSTEM]->(system)
MATCH path=(impacted:Process)-[:HAS_SUBPROCESS|DEPENDS_ON*0..5]->(direct)
RETURN impacted.name AS process,
       CASE WHEN impacted = direct THEN 'direct' ELSE 'indirect' END AS impact,
       [node IN nodes(path) | node.name] AS process_path,
       [edge IN relationships(path) | type(edge)] AS relationship_path;
```

Inspect relationship evidence:

```cypher
MATCH (source)-[relationship]->(target)
RETURN source.name, type(relationship), target.name,
       relationship.evidence_version_ids,
       relationship.supporting_chunk_ids,
       relationship.evidence_snippets
LIMIT 500;
```

More queries are in `schema/visualization_queries.cypher`.

## Sample data

The credit-card sample contains:

- Card Payment Processing and its authorization, fraud, and settlement
  subprocesses;
- Card Dispute Management and Chargeback Investigation;
- Customer Identity Verification and Digital Card Provisioning, connected by
  `DEPENDS_ON` and using different local systems;
- Card Transaction Risk Monitoring, Merchant Settlement Management, and Batch
  Payment Clearing, covering payment holds, chargeback thresholds, merchant
  funding, Settlement Bus v3, and settlement-delay risk;
- policies, SOPs, process documents, two BPMN models, journeys, and variants.

## LLM mode

The POC runs locally without an API key using a transparent ontology-aware
fallback. To activate LLM planning, extraction, and answer generation:

```text
LLM_PROVIDER=openai
LLM_API_KEY=your-key
LLM_MODEL=gpt-4.1-mini
```

For an OpenAI-compatible router running on the container host:

```text
LLM_PROVIDER=openai
LLM_BASE_URL=http://host.containers.internal:20128/v1
LLM_API_KEY=your-local-router-key
LLM_MODEL=your-provider/your-model
```

`LLMService` is the only interface used by planning, extraction, and answer
generation. It exposes `generate_json` and `generate_text`; provider-specific
HTTP behavior is isolated in `OpenAICompatibleProvider`. Replacing the model
provider requires a new adapter plus one factory mapping, without changing
domain services.

The current adapter accepts both normal OpenAI JSON completions and routers that
always return OpenAI-compatible server-sent events. Keep credentials only in the
gitignored `.env` file; do not add them to the README or packaged source.

The graph schema and query allowlist remain fixed in both modes.

## Verification

```bash
podman run --rm -v "$PWD:/src" -w /src -e PYTHONPATH=/src process-intelligence-kg-api \
  sh -lc 'pip install -q ruff pytest pytest-asyncio &&
          ruff check app tests scripts &&
          pytest -q'
```

Production use additionally requires identity/access controls, source authority,
PII handling, entity review, ontology governance, evaluation datasets,
observability, and backup/restore procedures.
