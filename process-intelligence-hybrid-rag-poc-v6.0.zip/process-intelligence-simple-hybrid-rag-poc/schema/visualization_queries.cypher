// Neo4j Browser queries for the credit-card process-intelligence POC.

// 1. Every node, relationship, and property (bounded for a demo database).
MATCH (source)-[relationship]->(target)
RETURN source, relationship, target
LIMIT 500;

// 2. Governed business graph only. No chunks and no technical claim nodes.
MATCH path=(process:Process)-[
  :HAS_SUBPROCESS|DEPENDS_ON|OPERATES_IN|OWNED_BY|GOVERNED_BY|USES_SYSTEM
]->(entity)
RETURN path
LIMIT 500;

// 3. Main process plus all subprocesses and their governed dependencies.
MATCH hierarchy=(main:Process {process_id: 'CC-PAY-001'})
  -[:HAS_SUBPROCESS*0..5]->(process:Process)
OPTIONAL MATCH dependency=(process)-[
  :OPERATES_IN|OWNED_BY|GOVERNED_BY|USES_SYSTEM
]->(entity)
RETURN hierarchy, dependency
LIMIT 500;

// 4. The key hybrid demo: direct and indirect Falcon Fraud Engine impact.
MATCH (system:System {name: 'Falcon Fraud Engine'})
MATCH (direct:Process)-[:USES_SYSTEM]->(system)
MATCH impact=(impacted:Process)-[:HAS_SUBPROCESS*0..5]->(direct)
RETURN impacted.process_id AS impacted_process_id,
       impacted.name AS impacted_process,
       CASE WHEN impacted = direct THEN 'direct' ELSE 'indirect' END AS impact_type,
       [node IN nodes(impact) | node.name] AS process_path,
       system.name AS unavailable_system
ORDER BY impact_type, impacted_process;

// 5. Visual version of the same impact path.
MATCH system_edge=(direct:Process)-[:USES_SYSTEM]->
  (system:System {name: 'Falcon Fraud Engine'})
MATCH impact=(impacted:Process)-[:HAS_SUBPROCESS*0..5]->(direct)
RETURN impact, system_edge;

// 6. Systems used directly or through subprocesses by Card Payment Processing.
MATCH path=(main:Process {process_id: 'CC-PAY-001'})
  -[:HAS_SUBPROCESS*0..5]->(process:Process)-[:USES_SYSTEM]->(system:System)
RETURN main.name AS main_process, process.name AS using_process,
       system.name AS system, [node IN nodes(path) | node.name] AS path
ORDER BY using_process, system;

// 7. Controls and where they apply in the hierarchy.
MATCH path=(main:Process {process_id: 'CC-PAY-001'})
  -[:HAS_SUBPROCESS*0..5]->(process:Process)-[r:GOVERNED_BY]->(control:Control)
RETURN process.name AS process, control.control_id AS control_id,
       control.name AS control, r.confidence AS confidence,
       r.evidence_version_ids AS evidence_versions,
       r.supporting_chunk_ids AS evidence_chunks,
       [node IN nodes(path) | node.name] AS process_path
ORDER BY process, control;

// 8. Markets and business units for both process families.
MATCH (process:Process)-[r:OPERATES_IN|OWNED_BY]->(entity)
RETURN process.process_id, process.name, type(r) AS relationship,
       labels(entity)[0] AS entity_type, entity.name AS entity,
       properties(r) AS relationship_properties
ORDER BY process.name, relationship, entity;

// 9. Documents and active versions.
MATCH path=(process:Process)-[:HAS_DOCUMENT]->(document:Document)
  -[:HAS_VERSION]->(version:DocumentVersion {active: true})
RETURN path
LIMIT 500;

// 10. BPMN models and activity flow.
MATCH model_path=(process:Process)-[:MODELED_BY]->(model:BPMNModel)
  -[:DEFINES_ACTIVITY]->(activity:Activity)
OPTIONAL MATCH flow=(activity)-[:NEXT_ACTIVITY]->(next:Activity)
RETURN model_path, flow
LIMIT 500;

// 11. Observed journeys and variants.
MATCH journey_path=(process:Process)-[:HAS_JOURNEY]->(journey:Journey)
  -[:FOLLOWS_VARIANT]->(variant:Variant)
RETURN journey_path
LIMIT 500;

// 12. Inspect every property without a graph visualization.
MATCH (node)
RETURN labels(node) AS labels, properties(node) AS properties
ORDER BY labels, properties.name
LIMIT 500;

// 13. Inspect relationship evidence properties.
MATCH (source)-[relationship]->(target)
RETURN source.name AS source, type(relationship) AS relationship,
       target.name AS target, properties(relationship) AS properties
ORDER BY source, relationship, target
LIMIT 500;

// 14. Cross-process outage propagation through DEPENDS_ON.
MATCH system_edge=(direct:Process)-[:USES_SYSTEM]->
  (system:System {name: 'Identity Verification Platform'})
MATCH impact=(impacted:Process)-[:HAS_SUBPROCESS|DEPENDS_ON*0..5]->(direct)
RETURN impact, system_edge;

// 15. Settlement Bus v3 direct and multi-path indirect impact.
MATCH system_edge=(direct:Process)-[:USES_SYSTEM]->
  (system:System {name: 'Settlement Bus v3'})
MATCH impact=(impacted:Process)-[:HAS_SUBPROCESS|DEPENDS_ON*0..5]->(direct)
RETURN impact, system_edge;
