from pathlib import Path

from app.domain.models import DocumentMetadata, JourneyBatch
from app.services.retrieval import GRAPH_QUERIES

ROOT = Path(__file__).resolve().parents[1]


def test_sample_catalog_has_two_complete_processes():
    card_documents = [
        ("card_payment_process.metadata.json", "CC-PAY-001", "process"),
        ("card_payment_policy.metadata.json", "CC-PAY-001", "policy"),
        ("card_payment_bpmn.metadata.json", "CC-PAY-001", "bpmn"),
        ("transaction_authorization_sop.metadata.json", "CC-AUTH-010", "sop"),
        ("fraud_screening_policy.metadata.json", "CC-FRAUD-020", "policy"),
        ("clearing_settlement_sop.metadata.json", "CC-SETTLE-030", "sop"),
        ("dispute_management_process.metadata.json", "CC-DISPUTE-100", "process"),
        ("dispute_management_bpmn.metadata.json", "CC-DISPUTE-100", "bpmn"),
        ("chargeback_investigation_sop.metadata.json", "CC-CHARGEBACK-110", "sop"),
        (
            "customer_identity_verification_policy.metadata.json",
            "CC-IDV-210",
            "policy",
        ),
        (
            "digital_card_provisioning_sop.metadata.json",
            "CC-DIGITAL-200",
            "sop",
        ),
        (
            "enterprise_risk_compliance_policy.metadata.json",
            "CC-RISK-300",
            "policy",
        ),
        (
            "merchant_settlement_process.metadata.json",
            "CC-MERCHANT-400",
            "process",
        ),
        (
            "batch_payment_clearing_sop.metadata.json",
            "CC-BATCH-410",
            "sop",
        ),
    ]
    for filename, process_id, document_type in card_documents:
        metadata = DocumentMetadata.model_validate_json(
            (ROOT / "sample_data" / filename).read_text()
        )
        assert metadata.process.process_id == process_id
        assert metadata.document_type == document_type

    assert (
        len(
            JourneyBatch.model_validate_json(
                (ROOT / "sample_data" / "card_journeys.json").read_text()
            ).journeys
        )
        == 2
    )
    assert (
        len(
            JourneyBatch.model_validate_json(
                (ROOT / "sample_data" / "dispute_journeys.json").read_text()
            ).journeys
        )
        == 2
    )


def test_fixed_query_catalog_never_traverses_graph_chunk_nodes():
    query_text = "\n".join(GRAPH_QUERIES.values())
    assert "HAS_CHUNK" not in query_text
    assert ":Chunk" not in query_text
    assert ":Assertion" not in query_text
    assert "HAS_SUBPROCESS|DEPENDS_ON*0..5" in GRAPH_QUERIES["impact_analysis"]
