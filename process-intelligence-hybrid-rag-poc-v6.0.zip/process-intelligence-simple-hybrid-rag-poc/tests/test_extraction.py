import pytest

from app.config import Settings
from app.domain.models import (
    DocumentMetadata,
    ExtractedEntity,
    ExtractedRelationship,
    ExtractionResult,
)
from app.domain.ontology import NodeType, RelationshipType
from app.services.extraction import EntityExtractor, govern_extraction
from app.services.llm import LLMService


def test_governance_deduplicates_and_filters_low_confidence():
    result = ExtractionResult(
        entities=[
            ExtractedEntity(
                entity_type=NodeType.SYSTEM,
                canonical_name=" SAP S/4HANA ",
                confidence=0.95,
                evidence="SAP is the system of record",
            ),
            ExtractedEntity(
                entity_type=NodeType.SYSTEM,
                canonical_name="SAP S/4HANA",
                confidence=0.85,
                evidence="duplicate",
            ),
            ExtractedEntity(
                entity_type=NodeType.CONTROL,
                canonical_name="maybe-control",
                confidence=0.2,
                evidence="uncertain",
            ),
        ],
        relationships=[
            ExtractedRelationship(
                source_type=NodeType.PROCESS,
                source_ref="CC-PAY-001",
                relationship_type=RelationshipType.USES_SYSTEM,
                target_type=NodeType.SYSTEM,
                target_ref="SAP S/4HANA",
                confidence=0.95,
                evidence="SAP is the system of record",
            )
        ],
    )
    governed = govern_extraction(result, 0.72)
    assert len(governed.entities) == 1
    assert governed.entities[0].canonical_name == "SAP S/4HANA"
    assert len(governed.relationships) == 1


def test_sample_metadata_has_only_governed_lists():
    raw = {
        "title": "SOP",
        "document_type": "sop",
        "process": {"process_id": "P1", "name": "Example"},
        "systems": ["ERP"],
    }
    metadata = DocumentMetadata.model_validate(raw)
    assert metadata.systems == ["ERP"]


@pytest.mark.asyncio
async def test_metadata_dependency_becomes_governed_process_edge():
    metadata = DocumentMetadata.model_validate(
        {
            "title": "Digital Card SOP",
            "document_type": "sop",
            "process": {"process_id": "P-DIGITAL", "name": "Digital Card"},
            "systems": ["Token Vault"],
            "depends_on_processes": [
                {"process_id": "P-IDV", "name": "Identity Verification"}
            ],
        }
    )
    settings = Settings(llm_provider="metadata", llm_api_key="")
    llm = LLMService.from_settings(settings)
    try:
        result = await EntityExtractor(settings, llm).extract(
            "Digital Card depends on Identity Verification.", metadata
        )
    finally:
        await llm.close()

    assert any(
        relationship.relationship_type == RelationshipType.DEPENDS_ON
        and relationship.source_ref == "P-DIGITAL"
        and relationship.target_ref == "P-IDV"
        for relationship in result.relationships
    )
