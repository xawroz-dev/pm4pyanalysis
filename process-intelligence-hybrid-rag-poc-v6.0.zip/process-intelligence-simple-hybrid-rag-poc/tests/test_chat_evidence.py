from app.domain.models import Citation
from app.services.chat import merge_citations


def citation(chunk_id: str, document_id: str) -> Citation:
    return Citation(
        document_id=document_id,
        document_version_id=f"{document_id}:v1",
        chunk_id=chunk_id,
        title=document_id,
        source_filename=f"{document_id}.md",
        excerpt="evidence",
        score=1.0,
    )


def test_hybrid_evidence_is_vector_plus_graph_deduplicated_by_chunk() -> None:
    vector = [citation("chunk-a", "doc-a"), citation("chunk-b", "doc-a")]
    graph = [citation("chunk-b", "doc-a"), citation("chunk-c", "doc-b")]

    merged = merge_citations(vector, graph)

    assert [item.chunk_id for item in merged] == ["chunk-a", "chunk-b", "chunk-c"]
