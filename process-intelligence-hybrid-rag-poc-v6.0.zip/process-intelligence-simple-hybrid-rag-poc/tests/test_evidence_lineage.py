from app.domain.models import TextChunk
from app.repositories.neo4j import evidence_chunk_ids


def make_chunk(chunk_id: str, text: str) -> TextChunk:
    return TextChunk(
        chunk_id=chunk_id,
        document_id="DOC-1",
        document_version_id="DOC-1:version:1",
        process_id="CC-PAY-001",
        ordinal=0,
        chunk_kind="content",
        text=text,
        content_hash="hash",
        title="SOP",
        document_type="sop",
        classification="internal",
        source_filename="sop.md",
    )


def test_evidence_is_linked_to_the_exact_chunk_before_target_fallback():
    chunks = [
        make_chunk("chunk-1", "SAP appears in this unrelated introduction."),
        make_chunk("chunk-2", "Purchase orders are created and approved in SAP."),
    ]
    assert evidence_chunk_ids(
        "Purchase orders are created and approved in SAP.", "SAP", chunks
    ) == ["chunk-2"]


def test_metadata_evidence_only_links_to_the_metadata_chunk():
    chunks = [
        make_chunk("content", "The BPMN diagram does not contain the declared control."),
        make_chunk("metadata", "Declared in metadata: CTRL-PO-001"),
    ]
    chunks[1].chunk_kind = "metadata"
    assert evidence_chunk_ids("Declared in metadata: CTRL-PO-001", "CTRL-PO-001", chunks) == [
        "metadata"
    ]


def test_parent_relationship_evidence_links_to_metadata_chunk():
    chunks = [
        make_chunk(
            "metadata",
            "Declared parent process: Card Payment Processing (CC-PAY-001)",
        )
    ]
    chunks[0].chunk_kind = "metadata"
    assert evidence_chunk_ids(
        "Declared parent process: Card Payment Processing (CC-PAY-001)",
        "CC-FRAUD-020",
        chunks,
    ) == ["metadata"]
