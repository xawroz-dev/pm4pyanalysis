import json

import httpx
import pytest

from app.services.llm import LLMService, _completion_content, _parse_json_content


def test_reads_streamed_openai_compatible_completion() -> None:
    events = [
        {
            "choices": [
                {"delta": {"role": "assistant"}, "finish_reason": None}
            ]
        },
        {
            "choices": [
                {"delta": {"content": '{"use_graph":true}'}, "finish_reason": None}
            ]
        },
        {"choices": [{"delta": {}, "finish_reason": "stop"}]},
    ]
    body = "\n\n".join(f"data: {json.dumps(event)}" for event in events)
    body += "\n\ndata: [DONE]\n"
    response = httpx.Response(
        200,
        headers={"content-type": "text/event-stream"},
        content=body,
    )

    assert _completion_content(response) == '{"use_graph":true}'


def test_parses_json_from_markdown_fence() -> None:
    assert _parse_json_content("```json\n{\"intent\":\"rag_only\"}\n```") == {
        "intent": "rag_only"
    }


class FakeProvider:
    async def generate_json(self, system, user, schema_name, schema):
        return {"provider": "fake", "schema": schema_name}

    async def generate_text(self, system, user):
        return f"{system}:{user}"

    async def close(self):
        return None


@pytest.mark.asyncio
async def test_common_llm_service_delegates_to_replaceable_provider() -> None:
    service = LLMService(FakeProvider())
    assert await service.generate_text("system", "user") == "system:user"
    assert await service.generate_json("s", "u", "plan", {}) == {
        "provider": "fake",
        "schema": "plan",
    }
