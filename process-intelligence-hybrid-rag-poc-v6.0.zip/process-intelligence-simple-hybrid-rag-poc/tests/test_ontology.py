import pytest

from app.domain.ontology import (
    ALLOWED_RELATIONSHIPS,
    ONTOLOGY_VERSION,
    NodeType,
    RelationshipType,
    validate_relationship,
)


def test_allowed_relationship_is_accepted():
    validate_relationship(NodeType.PROCESS, RelationshipType.GOVERNED_BY, NodeType.CONTROL)


def test_unlisted_relationship_is_rejected():
    with pytest.raises(ValueError):
        validate_relationship(NodeType.CONTROL, RelationshipType.USES_SYSTEM, NodeType.SYSTEM)


def test_governed_graph_has_fixed_business_edges_and_no_chunk_nodes():
    assert ONTOLOGY_VERSION == "4.1"
    triples = {
        (source.value, relationship.value, target.value)
        for source, relationship, target in ALLOWED_RELATIONSHIPS
    }
    assert ("Document", "HAS_VERSION", "DocumentVersion") in triples
    assert ("Process", "HAS_SUBPROCESS", "Process") in triples
    assert ("Process", "DEPENDS_ON", "Process") in triples
    assert ("Process", "USES_SYSTEM", "System") in triples
    assert "Chunk" not in {item.value for item in NodeType}
    assert "Assertion" not in {item.value for item in NodeType}
    assert "HAS_CHUNK" not in {item.value for item in RelationshipType}
