from pathlib import Path

from app.domain.models import DocumentMetadata
from app.services.chunking import chunk_document
from app.services.ingestion import make_document_version_id
from app.services.llm import hash_embedding
from app.services.parsing import parse_document
from app.services.retrieval import offline_plan, rerank_hits

ROOT = Path(__file__).resolve().parents[1]


def test_chunks_have_stable_ids_and_process_metadata():
    content = (ROOT / "sample_data/transaction_authorization_sop.md").read_bytes()
    metadata = DocumentMetadata.model_validate_json(
        (ROOT / "sample_data/transaction_authorization_sop.metadata.json").read_text()
    )
    parsed = parse_document(content, "transaction_authorization_sop.md", "text/markdown", metadata)
    version_id = make_document_version_id("DOC-1", "1.0", parsed.checksum)
    first = chunk_document(parsed, "DOC-1", version_id, chunk_size=240, overlap=30)
    second = chunk_document(parsed, "DOC-1", version_id, chunk_size=240, overlap=30)
    assert [item.chunk_id for item in first] == [item.chunk_id for item in second]
    assert {item.process_id for item in first} == {"CC-AUTH-010"}
    assert {item.document_version_id for item in first} == {version_id}
    assert all(item.content_hash for item in first)
    assert all(item.active is False for item in first)


def test_hash_embeddings_are_deterministic_and_normalized():
    first = hash_embedding("three way match control", 32)
    second = hash_embedding("three way match control", 32)
    assert first == second
    assert abs(sum(value * value for value in first) - 1.0) < 1e-9


def test_offline_planner_uses_graph_only_for_governed_intents():
    catalog = [
        {
            "entity_type": "System",
            "entity_id": "system:falcon",
            "name": "Falcon Fraud Engine",
            "aliases": [],
        }
    ]
    impact = offline_plan(
        "What processes are impacted if the Falcon system is down?",
        None,
        catalog,
    )
    narrative = offline_plan(
        "How long must fraud alerts be retained?", None, catalog
    )
    assert impact.intent == "impact_analysis"
    assert impact.use_graph is True
    assert impact.entities[0].text == "Falcon Fraud Engine"
    assert narrative.intent == "rag_only"
    assert narrative.use_graph is False


def test_offline_reranker_keeps_the_named_system_evidence():
    hits = [
        {"text": "Settlement system supports a payment process.", "score": 0.8},
        {
            "text": "The Falcon Fraud Engine is unavailable during this outage.",
            "score": 0.4,
        },
    ]
    ranked = rerank_hits(
        "Which processes are affected if the Falcon system goes down?", hits, 6
    )
    assert ranked == [hits[1]]
