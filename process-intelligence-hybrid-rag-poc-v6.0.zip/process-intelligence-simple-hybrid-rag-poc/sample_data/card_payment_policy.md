# Card Payment Resilience Policy

Card Payment Processing must remain available in the United States and Canada.
Card Payments Operations owns end-to-end service recovery.

CC-CTRL-RESILIENCE-001 requires quarterly continuity exercises covering every
subprocess and requires recovery within 30 minutes for a critical outage.
Completed payment records are posted to the Card Ledger.

Each subprocess owner must document its own application dependencies, controls,
recovery procedure, and evidence-retention requirements.
