# Clearing and Settlement SOP

Clearing and Settlement is a subprocess of Card Payment Processing. It receives
clearing records, calculates network positions, posts financial entries, and
settles the issuer obligation.

Settlement Operations owns the subprocess for the United States and Canada.
The Settlement Hub processes clearing files and settlement positions.
CC-CTRL-SETTLE-003 requires daily reconciliation between network totals,
settlement positions, and the Card Ledger before financial close.
