# Merchant Settlement Management

## Process description

Merchant Settlement Management coordinates end-of-day clearing, interchange-fee
calculation, risk-hold release, merchant funding, and payout confirmation. The
process operates in the United States, Canada, and the European Union and is
owned by Merchant Services Operations.

## Architecture and dependencies

The Merchant Settlement Engine calculates net merchant positions and produces
the payout instruction. Merchant Settlement Management depends on Card
Transaction Risk Monitoring to release transaction or merchant holds before
funds are disbursed. Batch Payment Clearing is the subprocess that validates
network totals and submits the final funding batch through its documented
transport platform.

## Operational controls

CC-CTRL-SETTLEMENT-020 requires approved risk-hold disposition, balanced
clearing totals, and a traceable payout instruction before funding. A failure of
the Merchant Settlement Engine exposes the company to settlement-delay and
merchant-liquidity risk.
