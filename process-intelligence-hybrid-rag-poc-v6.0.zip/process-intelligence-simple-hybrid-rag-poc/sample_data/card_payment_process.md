# Card Payment Processing

Card Payment Processing accepts a cardholder purchase, coordinates authorization,
risk screening, clearing, and settlement, and posts the final financial result.
It operates in the United States and Canada and is owned by Card Payments Operations.

The process is composed of Transaction Authorization, Real-Time Fraud Screening,
and Clearing and Settlement. The main process records the completed transaction
in the Card Ledger. CC-CTRL-RESILIENCE-001 requires continuity testing for the
end-to-end payment service.

This main-process definition deliberately describes capabilities rather than the
applications used inside each subprocess. Subprocess operating procedures are
the authoritative source for their local systems and controls.
