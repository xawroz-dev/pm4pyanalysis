# Transaction Authorization SOP

Transaction Authorization is a subprocess of Card Payment Processing. It validates
the card status, account status, available credit, merchant information, and
transaction limits before returning an approval or decline.

The subprocess operates in the United States and Canada. Authorization Operations
owns it. The Card Authorization Switch is the system of record for the authorization
decision. CC-CTRL-AUTH-001 requires every decision to retain the request, response,
rule result, and timestamp for seven years.
