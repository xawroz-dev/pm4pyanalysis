# Digital Card Provisioning SOP

Digital Card Provisioning creates a virtual credit card credential and makes it
available for an approved mobile wallet. Digital Card Operations owns the
process in the United States and Canada.

The process depends on Customer Identity Verification completing successfully
before a new digital card can be issued. After that approval, the Token Vault
generates and stores the payment token. CC-CTRL-TOKEN-006 requires the identity
approval reference and token-generation result to be retained with the request.

The Token Vault is the local application dependency for Digital Card
Provisioning; the identity-verification application is owned by the upstream
Customer Identity Verification process.
