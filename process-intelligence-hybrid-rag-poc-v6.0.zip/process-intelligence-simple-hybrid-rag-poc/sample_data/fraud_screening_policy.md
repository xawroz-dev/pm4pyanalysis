# Real-Time Fraud Screening Policy

Every eligible authorization request is scored before the final authorization response.

Fraud Risk Operations owns the subprocess in the United States and Canada. The
Falcon Fraud Engine calculates the fraud score and recommended action.
CC-CTRL-FRAUD-002 requires high-risk transactions to be blocked or referred for
review. Fraud alerts, model scores, rule results, and analyst decisions must be
retained for seven years.

If the Falcon Fraud Engine is unavailable, the fraud subprocess cannot perform
normal real-time scoring and must invoke its approved degraded-mode procedure.
