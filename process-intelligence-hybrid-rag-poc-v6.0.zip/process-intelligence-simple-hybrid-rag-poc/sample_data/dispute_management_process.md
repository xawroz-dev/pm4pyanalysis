# Cardholder Dispute Management

Cardholder Dispute Management receives a cardholder claim, validates eligibility,
investigates the transaction, issues provisional credit when required, and resolves
the case. It operates in the United States, Canada, and the United Kingdom.

Dispute Operations owns the process. The Dispute Case Manager stores the case.
CC-CTRL-DISPUTE-001 requires acknowledgement within two business days and complete
case evidence. Chargeback Investigation is a subprocess used when recovery from
the merchant or acquirer is appropriate.
