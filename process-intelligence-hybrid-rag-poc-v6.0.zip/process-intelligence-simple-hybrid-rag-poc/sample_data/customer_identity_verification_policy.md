# Customer Identity Verification Policy

Customer Identity Verification confirms that an applicant is eligible before a
new digital credit card can be provisioned. Customer Identity Operations owns
the process in the United States and Canada.

The Identity Verification Platform validates identity evidence and returns the
approved, declined, or manual-review outcome. CC-CTRL-IDV-005 requires a valid
identity-verification outcome before card provisioning can continue.

If the Identity Verification Platform is unavailable, Customer Identity
Verification cannot produce a new approval outcome.
