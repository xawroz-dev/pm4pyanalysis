# Batch Payment Clearing SOP

## Subprocess purpose

Batch Payment Clearing is a critical subprocess of Merchant Settlement
Management. It validates card-network clearing totals, calculates batch
exceptions, and submits balanced merchant-funding instructions.

## Systems and ownership

Merchant Services Operations owns the subprocess in the United States, Canada,
and the European Union. Settlement Bus v3 transports clearing files, exception
responses, and final funding acknowledgements between the card processor and
the settlement platform.

## Control procedure

CC-CTRL-SETTLEMENT-021 requires the operator to reconcile network totals,
merchant positions, and funding acknowledgements before releasing the batch.
If Settlement Bus v3 is unavailable, Batch Payment Clearing stops and Merchant
Settlement Management cannot complete its end-of-day payout cycle.
