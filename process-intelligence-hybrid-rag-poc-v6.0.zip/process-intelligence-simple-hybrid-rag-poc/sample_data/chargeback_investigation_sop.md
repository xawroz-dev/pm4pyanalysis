# Chargeback Investigation SOP

Chargeback Investigation is a subprocess of Cardholder Dispute Management.
Chargeback Operations reviews transaction evidence, selects a reason code,
submits the chargeback, and tracks representment.

The subprocess operates in the United States, Canada, and the United Kingdom.
The Chargeback Workbench manages network deadlines and evidence packages.
CC-CTRL-CHARGEBACK-004 requires dual review for chargebacks above USD 25,000.
