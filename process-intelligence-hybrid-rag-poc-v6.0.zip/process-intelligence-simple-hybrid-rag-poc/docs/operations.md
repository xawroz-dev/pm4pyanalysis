# Demo operations

## Start

```bash
podman compose up --build -d
python3 scripts/load_sample.py
```

Open <http://localhost:8000/>.

## Demonstrate the difference

Ask:

```text
Which processes are affected if the Falcon system goes down?
```

Expected:

- Vector RAG reports that retrieved passages do not establish inherited impact.
- Hybrid Graph RAG reports Real-Time Fraud Screening as directly affected and
  Card Payment Processing as indirectly affected.
- Hybrid references `fraud_screening_policy.md`.
- The small status badge says `Graph used`.

Then ask:

```text
Which processes are affected if the Identity Verification Platform goes down?
```

Expected:

- Vector RAG identifies only Customer Identity Verification from the retrieved
  policy chunks.
- Hybrid Graph RAG additionally identifies Digital Card Provisioning by
  traversing `DEPENDS_ON`.
- Hybrid evidence contains a chunk from the identity policy and a chunk from
  the digital-card SOP.

Then ask:

```text
How long must fraud alerts and model scores be retained?
```

Expected:

- both answers report seven years;
- the status badge says `Graph not needed`;
- the policy file is listed as evidence.

## Business-process expert scenario

Ask:

```text
Which processes are impacted if Settlement Bus v3 goes down?
```

Expected:

- Vector RAG identifies the directly stated processes from retrieved passages.
- Hybrid Graph RAG additionally returns Merchant Settlement Management once,
  with two indirect paths:
  - through its Batch Payment Clearing subprocess;
  - through its dependency on Card Transaction Risk Monitoring.
- Hybrid evidence includes the risk policy, merchant-settlement process
  definition, and batch-clearing SOP.

Useful follow-up demonstrations:

```text
What is Card Transaction Risk Monitoring?
What controls govern Card Transaction Risk Monitoring?
Which markets does Merchant Settlement Management operate in?
What business risks are described in the Enterprise Risk and Compliance Governance Framework?
```

The last question is intentionally RAG-only. Regulatory non-compliance, fraud
exposure, merchant liquidity, and settlement-delay risk remain narrative policy
content because `Risk` is not in the fixed entity allowlist.

## Health

```bash
curl -s http://localhost:8000/health | python3 -m json.tool
podman compose ps
```

## Neo4j

Open <http://localhost:7474/browser/>.

```text
Username: neo4j
Password: change-me-enterprise
```

```cypher
MATCH path=(process:Process)-[
  :HAS_SUBPROCESS|DEPENDS_ON|OPERATES_IN|OWNED_BY|GOVERNED_BY|USES_SYSTEM
]->(entity)
RETURN path
LIMIT 500;
```

## Reconciliation

```bash
curl -s http://localhost:8000/v1/governance/reconciliation/CC-PAY-001 \
  | python3 -m json.tool
```

`consistent` means every chunk ID referenced by an active graph relationship
exists in the active Qdrant version scope.

## Reset the local POC

This removes only volumes created by this Compose project:

```bash
podman compose down -v
podman compose up --build -d
python3 scripts/load_sample.py
```
