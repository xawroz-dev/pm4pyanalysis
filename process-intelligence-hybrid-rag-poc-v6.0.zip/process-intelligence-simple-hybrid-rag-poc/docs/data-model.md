# Data model

## Business layer

| Source | Relationship | Target | Example |
|---|---|---|---|
| Process | `HAS_SUBPROCESS` | Process | Card Payment Processing → Real-Time Fraud Screening |
| Process | `DEPENDS_ON` | Process | Digital Card Provisioning → Customer Identity Verification |
| Process | `OPERATES_IN` | Market | Card Payment Processing → Canada |
| Process | `OWNED_BY` | BusinessUnit | Fraud Screening → Fraud Risk Operations |
| Process | `GOVERNED_BY` | Control | Fraud Screening → CC-CTRL-FRAUD-002 |
| Process | `USES_SYSTEM` | System | Fraud Screening → Falcon Fraud Engine |

These five entity types are the retrieval planner's governed entities:
`Process`, `Market`, `Control`, `System`, and `BusinessUnit`.

Policies are `Document` nodes with `document_type = policy`. This preserves
versioning, classification, source URI, and active-version lineage without
creating a second representation of the same artifact.

Risk descriptions remain document content in this POC. `Risk` is deliberately
not an extracted graph label, so terms such as regulatory non-compliance risk
cannot create an ungoverned sixth business dimension.

## Artifact and execution layer

| Source | Relationship | Target |
|---|---|---|
| Process | `HAS_DOCUMENT` | Document |
| Document | `HAS_VERSION` | DocumentVersion |
| DocumentVersion | `REPRESENTED_BY` | BPMNModel |
| Process | `MODELED_BY` | BPMNModel |
| BPMNModel | `DEFINES_ACTIVITY` | Activity |
| Activity | `NEXT_ACTIVITY` | Activity |
| Process | `HAS_JOURNEY` | Journey |
| Process | `HAS_VARIANT` | Variant |
| Journey | `FOLLOWS_VARIANT` | Variant |

## Evidence on a business edge

For example:

```text
(Real-Time Fraud Screening)-[:USES_SYSTEM]->(Falcon Fraud Engine)
```

The relationship contains:

```json
{
  "confidence": 1.0,
  "evidence_count": 1,
  "evidence_version_ids": ["DOC-CC-FRAUD-POLICY:version:..."],
  "supporting_chunk_ids": ["9edc..."],
  "evidence_snippets": ["Falcon Fraud Engine scores each authorization request."],
  "classifications": ["confidential"]
}
```

The full text for the chunk is retrieved from Qdrant by ID. The active
`DocumentVersion` also retains `extracted_facts_json`, so edges can be rebuilt
when a version is activated or superseded.

## Why the relationship is an edge, not a node

`USES_SYSTEM`, `OWNED_BY`, and similar concepts describe how two entities are
connected. Neo4j already gives relationships properties, so a separate claim
node is unnecessary for this POC and makes visualization confusing.

Use a separate claim/event node only when the relationship itself has rich
independent identity or lifecycle—for example multiple disagreeing claims that
must coexist, approvals performed by named reviewers, or valid-time intervals
that require temporal reasoning. Even then, expose a clean materialized
business view to normal users.

## Identity and normalization

- Process IDs come from metadata.
- Other governed IDs are deterministic UUID-based keys from type and canonical
  name unless an external ID is supplied.
- Entity labels and relationship types are allowlisted.
- Extraction confidence below the configured threshold is rejected.
- Duplicate facts from multiple active versions are aggregated onto one edge
  with multiple evidence IDs.

## Process hierarchy semantics

`HAS_SUBPROCESS` points from parent to child. `DEPENDS_ON` points from the
dependent process to its prerequisite. Impact traversal is performed from an
ancestor or dependent process to a directly affected process:

```cypher
MATCH (direct:Process)-[:USES_SYSTEM]->(system:System)
MATCH path=(impacted:Process)-[:HAS_SUBPROCESS|DEPENDS_ON*0..5]->(direct)
```

Path length zero means direct impact. A positive path length means an ancestor
or operationally dependent process is indirectly impacted. The maximum depth
is bounded to avoid unconstrained traversal.

## Vector record

Each Qdrant point contains:

`chunk_id`, `document_id`, `document_version_id`, `process_id`, `ordinal`,
`chunk_kind`, `text`, `content_hash`, `title`, `document_type`,
`classification`, `section`, source offsets, `active`, and embedding vector.

Metadata is also indexed as a deterministic chunk. This gives typed declarations
such as parent process or system an exact evidence anchor without creating graph
chunk nodes.
