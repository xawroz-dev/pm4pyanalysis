# Retrieval and governance

## Routing decision

The LLM receives the question and governed entity catalog. It returns a
schema-validated plan and resolves any named entities; the user does not select
a process first. Graph use is appropriate when an answer requires a relationship
among Process, Market, Control, System, or BusinessUnit.

Examples:

| Question | Intent | Graph? | Reason |
|---|---|---:|---|
| What is the alert retention period? | `rag_only` | No | Narrative policy fact |
| Which systems support this process? | `systems` | Yes | Process-to-System relationship |
| What is impacted if Falcon is down? | `impact_analysis` | Yes | Dependency plus hierarchy |
| What is impacted if the Identity Verification Platform is down? | `impact_analysis` | Yes | System edge plus `DEPENDS_ON` traversal |
| Who owns the fraud subprocess? | `ownership` | Yes | Process-to-BusinessUnit relationship |
| Show the procedure wording for referrals | `rag_only` | No | Passage retrieval |

The offline fallback uses the same intent contract for environments without an
LLM key. It is a demo continuity mechanism, not a substitute for model
evaluation.

## Entity linking

Mentions are typed by the planner and resolved against IDs, canonical names, and
aliases from Neo4j. The query receives resolved IDs and names as parameters.
Unresolved entities never become new graph nodes during query time.

Ingestion is the only path that can propose entities, and those entities must
pass the ontology allowlist and confidence threshold.

## Retrieval scopes

- RAG-only searches active chunks globally in the POC.
- Hybrid retains vector-search chunks, finds graph relationships, retrieves
  their exact supporting chunk IDs from Qdrant, and deduplicates the union.
- Graph retrieval uses one reviewed query template with resolved entity
  parameters.

No process or clearance selector is required in the demo UI.

## Evidence lineage

The API represents a citation as:

```text
[document_id@document_version_id#chunk_id]
```

The evidence API uses that version and chunk ID to return:

- document and process identity;
- active version and classification;
- exact Qdrant content;
- governed edges whose evidence properties reference the chunk.

The chat UI does not put this technical identifier inside the answer text. It
shows a separate retrieved-evidence list for each comparison side containing
the filename, title, section, and chunk ID.

Not every RAG chunk supports a graph relationship. Narrative passages are valid
retrieval context and remain intentionally unreferenced by graph edges.

## Reconciliation

```bash
curl -s http://localhost:8000/v1/governance/reconciliation/CC-PAY-001 \
  | python3 -m json.tool
```

The check reports:

- active graph version count;
- relationship evidence chunk count;
- active vector count;
- missing vector IDs referenced by graph edges;
- vectors attached to inactive graph versions;
- valid narrative chunks not referenced by graph edges.

## Noise demonstration

The isolated `/v1/demo/open-ontology` endpoint compares constrained extraction
with open extraction. Open extraction can create synonyms as separate labels,
invent relationship wording, and produce a dimension for every phrase. That
causes:

- lower entity-linking recall;
- query templates that cannot know every predicate;
- duplicate concepts and contradictory paths;
- less reliable evaluation;
- expensive stewardship and migrations.

The correct enterprise compromise is extensible but governed: version the
ontology, add approved types through change control, publish aliases, backfill,
and evaluate before activation.

## Evaluation suggestions

Build a golden question set containing:

- graph-negative narrative questions;
- direct entity questions;
- indirect one-hop and multi-hop impacts;
- ambiguous aliases;
- unknown entities;
- classification boundary tests;
- superseded document versions;
- conflicting evidence.

Measure planner routing precision/recall, entity-link accuracy, graph answer
correctness, citation correctness, retrieval recall, answer faithfulness, and
latency by path.
