# Architecture

## Purpose

The POC compares retrieval from text alone with retrieval from text plus a
governed process knowledge graph. Both paths use the same question and display
their sources separately.

```mermaid
flowchart LR
  UI["Comparison UI"] --> API["FastAPI"]
  API --> P["LLM retrieval planner"]
  API --> V["Qdrant chunks + embeddings"]
  P -->|"use_graph=true"| G["Neo4j governed graph"]
  P -->|"use_graph=false"| V
  G --> H["Hybrid answer context"]
  V --> R["RAG-only answer context"]
  V --> H
  R --> UI
  H --> UI
```

## Read path

1. The API embeds the question and performs global RAG-only search across active
   document versions.
2. The planner returns `use_graph`, one fixed intent, and typed entity mentions.
3. The application links mentions to the Neo4j entity catalog.
4. If graph use is justified, application code runs the matching parameterized
   Cypher template. Model-generated Cypher is prohibited.
5. Hybrid retrieval keeps the vector-search chunks and adds the exact Qdrant
   chunks referenced by returned graph relationships.
6. The answer model receives graph facts plus the deduplicated union of both
   evidence sets. The RAG-only answer receives vector passages only.

The two answers are generated independently; the RAG answer cannot see graph
facts.

## LLM provider boundary

Planning, extraction, and answer generation depend only on `LLMService`.
Its common methods are `generate_json` and `generate_text`. Vendor transport,
authentication, structured-output formatting, and streaming response handling
belong in provider adapters such as `OpenAICompatibleProvider`.

To replace the provider, implement the `LLMProvider` protocol and register the
adapter in `LLMService.from_settings`. Retrieval and ingestion services do not
need to change.

## Write path

```mermaid
sequenceDiagram
  participant C as Client
  participant A as API
  participant L as Extractor
  participant Q as Qdrant
  participant N as Neo4j
  C->>A: document + typed metadata
  A->>A: parse, checksum, deterministic chunks
  A->>L: constrained ontology extraction
  L-->>A: entities + approved relationships + evidence
  A->>N: stage immutable DocumentVersion
  A->>Q: upsert inactive chunks and embeddings
  A->>N: store extracted fact JSON on version
  A->>N: activate version and rebuild governed edges
  A->>Q: switch active version flags
```

If activation fails, compensating actions mark the graph version failed, remove
its vectors, and reactivate the previous version.

## Storage responsibilities

Neo4j stores domain topology and artifact lineage. Qdrant stores retrieval
fragments. `supporting_chunk_ids` and `evidence_version_ids` on business
relationships connect the stores without turning chunks into graph nodes.

This split supports:

- transitive impact and hierarchy queries in Neo4j;
- semantic passage search in Qdrant;
- independent lifecycle and scaling;
- exact relationship-to-passage audit;
- a graph that business users can still understand.

## Security boundaries

Each `DocumentVersion` has a classification. Vector search applies the same
clearance filter. Business relationships aggregate the classifications of their
evidence versions, and graph templates filter inaccessible edges.

The LLM receives only data already filtered by the application. It cannot
override the ontology, graph template, process scope, or clearance.

## Why fixed intents matter

The planner can choose only:

`rag_only`, `process_overview`, `process_hierarchy`, `impact_analysis`,
`controls`, `systems`, `ownership`, `markets`, `documents`, `bpmn_flow`,
`variants`, or `journeys`.

This bounded contract makes routing testable and prevents small wording changes
from producing arbitrary query structures. Adding an intent is an application
change with a reviewed query and evaluation cases, not an ungoverned prompt
change.
