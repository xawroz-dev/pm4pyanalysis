import json
import mimetypes
import os
import uuid
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parents[1]
BASE_URL = os.getenv("PROCESS_INTELLIGENCE_API_URL", "http://localhost:8000")


def post_multipart(file_path: Path, metadata: str) -> dict:
    boundary = f"----process-intelligence-{uuid.uuid4().hex}"
    media_type = mimetypes.guess_type(file_path.name)[0] or "application/octet-stream"
    pieces = [
        f"--{boundary}\r\n".encode(),
        (f'Content-Disposition: form-data; name="file"; filename="{file_path.name}"\r\n').encode(),
        f"Content-Type: {media_type}\r\n\r\n".encode(),
        file_path.read_bytes(),
        b"\r\n",
        f"--{boundary}\r\n".encode(),
        b'Content-Disposition: form-data; name="metadata"\r\n',
        b"Content-Type: application/json\r\n\r\n",
        metadata.encode(),
        b"\r\n",
        f"--{boundary}--\r\n".encode(),
    ]
    return post(
        "/v1/ingest/document",
        b"".join(pieces),
        f"multipart/form-data; boundary={boundary}",
    )


def post(path: str, body: bytes, content_type: str) -> dict:
    request = Request(
        f"{BASE_URL}{path}",
        data=body,
        headers={"Content-Type": content_type},
        method="POST",
    )
    try:
        with urlopen(request, timeout=120) as response:
            return json.loads(response.read())
    except HTTPError as exc:
        detail = exc.read().decode(errors="replace")
        raise RuntimeError(f"{path} returned HTTP {exc.code}: {detail}") from exc


def main() -> None:
    documents = [
        ("card_payment_process.md", "card_payment_process.metadata.json"),
        ("card_payment_policy.md", "card_payment_policy.metadata.json"),
        ("transaction_authorization_sop.md", "transaction_authorization_sop.metadata.json"),
        ("fraud_screening_policy.md", "fraud_screening_policy.metadata.json"),
        ("clearing_settlement_sop.md", "clearing_settlement_sop.metadata.json"),
        ("card_payment.bpmn", "card_payment_bpmn.metadata.json"),
        ("dispute_management_process.md", "dispute_management_process.metadata.json"),
        ("dispute_management.bpmn", "dispute_management_bpmn.metadata.json"),
        ("chargeback_investigation_sop.md", "chargeback_investigation_sop.metadata.json"),
        (
            "customer_identity_verification_policy.md",
            "customer_identity_verification_policy.metadata.json",
        ),
        (
            "digital_card_provisioning_sop.md",
            "digital_card_provisioning_sop.metadata.json",
        ),
        (
            "enterprise_risk_compliance_policy.md",
            "enterprise_risk_compliance_policy.metadata.json",
        ),
        (
            "merchant_settlement_process.md",
            "merchant_settlement_process.metadata.json",
        ),
        (
            "batch_payment_clearing_sop.md",
            "batch_payment_clearing_sop.metadata.json",
        ),
    ]
    for filename, metadata_filename in documents:
        file_path = ROOT / "sample_data" / filename
        metadata = (ROOT / "sample_data" / metadata_filename).read_text()
        print(json.dumps(post_multipart(file_path, metadata), indent=2))

    journeys = (ROOT / "sample_data" / "card_journeys.json").read_bytes()
    print(json.dumps(post("/v1/ingest/journeys", journeys, "application/json"), indent=2))
    disputes = (ROOT / "sample_data" / "dispute_journeys.json").read_bytes()
    print(json.dumps(post("/v1/ingest/journeys", disputes, "application/json"), indent=2))


if __name__ == "__main__":
    main()
