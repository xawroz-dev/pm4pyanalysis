/* The UI contains no hardcoded answers; both columns call the live comparison API. */
const $ = selector => document.querySelector(selector);

async function api(path, options) {
  const response = await fetch(path, options);
  if (!response.ok) throw new Error((await response.text()) || response.statusText);
  return response.json();
}

async function initialize() {
  try {
    const health = await api("/health");
    $("#health").textContent = health.status === "ok" ? "Ready" : "Unavailable";
    $("#health").classList.toggle("ok", health.status === "ok");
  } catch {
    $("#health").textContent = "Unavailable";
  }
}

async function compare(question) {
  $("#sendButton").disabled = true;
  $("#sendButton").textContent = "Thinking…";
  $("#ragAnswer").innerHTML = '<div class="loading">Searching documents…</div>';
  $("#hybridAnswer").innerHTML = '<div class="loading">Planning retrieval…</div>';
  $("#route").classList.add("hidden");
  try {
    const result = await api("/v1/compare", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({question, top_k: 6}),
    });
    renderAnswer("#ragAnswer", result.rag_only);
    renderAnswer("#hybridAnswer", result.hybrid);
    $("#route").textContent = result.hybrid.retrieval.graph_called
      ? "Graph used"
      : "Graph not needed";
    $("#route").classList.remove("hidden");
    wireFiles();
  } catch (error) {
    const message = `<p class="error">${escapeHtml(error.message)}</p>`;
    $("#ragAnswer").innerHTML = message;
    $("#hybridAnswer").innerHTML = message;
  } finally {
    $("#sendButton").disabled = false;
    $("#sendButton").textContent = "Ask";
  }
}

function renderAnswer(selector, result) {
  const chunks = uniqueChunks(result.citations || []);
  const documentCount = new Set(chunks.map(chunk => chunk.document_id)).size;
  $(selector).innerHTML = `<p class="answer">${escapeHtml(result.answer)}</p>
    <div class="evidence-list">
      <div class="evidence-heading">
        <h3>Retrieved evidence</h3>
        <span>${chunks.length} chunk${chunks.length === 1 ? "" : "s"} from
          ${documentCount} document${documentCount === 1 ? "" : "s"}</span>
      </div>
      ${chunks.length ? chunks.map(chunkButton).join("") : "<p>No chunks retrieved.</p>"}
    </div>`;
}

function uniqueChunks(citations) {
  const seen = new Set();
  return citations.filter(citation => {
    if (seen.has(citation.chunk_id)) return false;
    seen.add(citation.chunk_id);
    return true;
  });
}

function chunkButton(citation) {
  const location = citation.section || (
    citation.page_start ? `Page ${citation.page_start}` : "Document content"
  );
  return `<button class="evidence-chunk" data-chunk="${escapeHtml(citation.chunk_id)}">
    <strong>${escapeHtml(citation.source_filename)}</strong>
    <span>${escapeHtml(citation.title)} · ${escapeHtml(location)}</span>
    <code>Chunk ${escapeHtml(citation.chunk_id)}</code>
  </button>`;
}

function wireFiles() {
  document.querySelectorAll(".evidence-chunk").forEach(button => {
    button.onclick = async () => {
      const data = await api(`/v1/evidence/chunks/${encodeURIComponent(button.dataset.chunk)}?classification_clearance=restricted`);
      $("#evidenceTitle").textContent = data.content.source_filename || data.lineage.document_title;
      $("#evidenceBody").innerHTML = `<p>${escapeHtml(data.lineage.document_title)}</p>
        <div class="evidence-text">${escapeHtml(data.content.text)}</div>`;
      $("#evidenceDialog").showModal();
    };
  });
}

$("#compareForm").addEventListener("submit", event => {
  event.preventDefault();
  compare($("#question").value.trim());
});
$(".dialog-close").onclick = () => $("#evidenceDialog").close();

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, character => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
  })[character]);
}

initialize();
