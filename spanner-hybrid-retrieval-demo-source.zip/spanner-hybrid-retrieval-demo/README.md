# Project 2: Spanner hybrid retrieval demonstration

This project contains ready-to-insert document chunks, entities, relationships, full-text tokens,
and vectors. It demonstrates four knowledge-retrieval directions using one SQL statement per
request:

1. Vector → graph
2. Full text → graph
3. Vector + full text → graph
4. Graph → vector-ranked evidence chunks

No API key is required. A deterministic offline embedding is used so the data and query results
are reproducible. Project 1 and Project 2 use the same physical Spanner schema.

## Fastest option: one command

```bash
docker compose up --build --abort-on-container-exit
```

The `demo` container performs these steps:

```text
create emulator instance/database/schema
    -> insert ready-made chunks, entities, relationships, and vectors
    -> run hybrid query
    -> run vector-to-graph query
    -> run full-text-to-graph query
    -> run graph-to-vector query
    -> print the returned chunks and facts
```

The Python entry point used by the container is `scripts/one_shot_demo.py`. It waits for the local
Spanner container, creates the instance/database/schema when needed, inserts and verifies every
row, then executes all four query directions.

## Two-stage option: insert once, query repeatedly

```bash
make install
cp .env.example .env
docker compose up -d spanner
make insert
make demo
```

`make insert` runs `scripts/insert_all.py`, the requested one-shot insertion operation. It creates
the schema, generates all 256-dimensional vectors, inserts all tables with `insert_or_update`, and
reads table counts back from Spanner. It fails if any count differs from the seed manifest.

`make demo` connects to the already-loaded database and runs every query with explanations and
formatted output. It fails if a query returns no graph-enriched rows.

Run one query or show its complete SQL/GQL:

```bash
.venv/bin/python scripts/run_demo.py --query hybrid --show-sql
.venv/bin/python scripts/run_demo.py --query vector-to-graph
.venv/bin/python scripts/run_demo.py --query text-to-graph
.venv/bin/python scripts/run_demo.py --query graph-to-vector
```

Run the second business example:

```bash
.venv/bin/python scripts/run_demo.py \
  --question "Which controls reduce merchant regulatory risk?" \
  --text-query "identity | regulatory | onboarding" \
  --entity-key risk-regulatory
```

Add `--json` for machine-readable results. See the [runbook](docs/RUNBOOK.md) for every command and
the expected output.

## Seed graph

The executable seed is [process_knowledge.json](seed_data/process_knowledge.json). It contains:

- 8 ordinary-language evidence chunks across card authorization and merchant onboarding;
- 15 entities across Process, Policy, Risk, Control, Market, and System;
- 14 relationships with descriptions, rationale, selection context, confidence, and evidence;
- chunk links for every entity and relationship;
- deterministic 256-dimensional chunk and entity vectors generated during insertion.

The main business path includes:

```text
Card Payment Authorization
  -[EXPOSED_TO]-> Unauthorized Transaction
  <-[MITIGATES]- Real-Time Fraud Screening
```

and:

```text
Card Payment Authorization
  -[USES]-> Authorization Gateway
  -[GOVERNED_BY]-> Payment Authorization Policy
  -[OPERATES_IN]-> United States Commercial Cards
```

The second path demonstrates that the same schema supports another process and market:

```text
Merchant Onboarding
  -[USES]-> Merchant Onboarding Portal
  -[GOVERNED_BY]-> Know Your Customer Policy
  -[EXPOSED_TO]-> Regulatory Noncompliance

Automated Identity Verification
  -[MITIGATES]-> Regulatory Noncompliance
  -[DEPENDS_ON]-> Merchant Onboarding Portal
```

## The single hybrid query

The combined statement uses relational CTEs and `GRAPH_TABLE`:

```mermaid
flowchart LR
    Q["Question"] --> V["VectorSeeds with COSINE_DISTANCE"]
    Q --> F["TextSeeds with SEARCH + SCORE"]
    V --> U["Combine and rank chunk IDs"]
    F --> U
    U --> G["GRAPH_TABLE chunk → entity → relationship → entity"]
    G --> R["Ranked chunks and graph facts"]
```

It is a single call to `execute_sql`, not multiple application-side searches. The complete
executable statements are in [queries.py](src/hybrid_demo/queries.py). Print copyable SQL with:

```bash
make queries
```

## Graph to vector

Graph-to-vector starts with a known entity. A `GRAPH_TABLE` traversal selects relationships and
their `evidence_chunk_id` values. The outer SQL joins those chunks and ranks only that graph-derived
candidate set with `COSINE_DISTANCE`.

This is useful when the user already selected a process, risk, system, or control and wants the
most semantically relevant supporting evidence.

## Vector or full text to graph

Vector-to-graph and full-text-to-graph start with matching chunks. `ChunkMentionsEntity` turns each
chunk into graph entry entities, and `RELATES_TO` expands to neighboring facts.

This is useful when a natural-language question or keyword is the only starting context.

Read the [demonstration guide](docs/DEMONSTRATION.md) for the schema, query inputs, expected facts,
and production ANN option.

## Design references

The one-statement retrieval pattern was informed by the
[SpannerPropertyGraph reference repository](https://github.com/maguec/SpannerPropertyGraph) and
updated to the current `GRAPH_TABLE(... MATCH ... RETURN ...)` syntax documented for
[graphs within SQL](https://cloud.google.com/spanner/docs/reference/standard-sql/graph-sql-queries).
The vector and text portions follow the official
[Spanner Graph vector-search](https://cloud.google.com/spanner/docs/graph/perform-vector-similarity-search)
and [full-text plus graph](https://cloud.google.com/spanner/docs/graph/full-text-search-and-graph)
guides.
