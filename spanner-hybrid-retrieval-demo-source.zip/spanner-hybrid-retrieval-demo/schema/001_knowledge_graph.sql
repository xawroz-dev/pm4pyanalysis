CREATE TABLE Document (
  graph_id STRING(63) NOT NULL,
  document_id STRING(36) NOT NULL,
  filename STRING(512) NOT NULL,
  media_type STRING(128) NOT NULL,
  content_hash STRING(64) NOT NULL,
  metadata JSON NOT NULL,
  created_at TIMESTAMP NOT NULL
) PRIMARY KEY (graph_id, document_id);

CREATE TABLE Chunk (
  graph_id STRING(63) NOT NULL,
  chunk_id STRING(36) NOT NULL,
  document_id STRING(36) NOT NULL,
  ordinal INT64 NOT NULL,
  content STRING(MAX) NOT NULL,
  content_tokens TOKENLIST AS (TOKENIZE_FULLTEXT(content)) STORED HIDDEN,
  embedding ARRAY<FLOAT32>(vector_length=>256),
  metadata JSON NOT NULL,
  created_at TIMESTAMP NOT NULL,
  CONSTRAINT FK_Chunk_Document FOREIGN KEY (graph_id, document_id)
    REFERENCES Document (graph_id, document_id)
) PRIMARY KEY (graph_id, chunk_id);

CREATE SEARCH INDEX ChunkContentSearch
ON Chunk(content_tokens)
STORING (content)
PARTITION BY graph_id;

CREATE TABLE Entity (
  graph_id STRING(63) NOT NULL,
  entity_id STRING(36) NOT NULL,
  entity_type STRING(32) NOT NULL,
  name STRING(512) NOT NULL,
  description STRING(MAX) NOT NULL,
  aliases ARRAY<STRING(512)> NOT NULL,
  embedding ARRAY<FLOAT32>(vector_length=>256),
  chunk_ids ARRAY<STRING(36)> NOT NULL,
  confidence FLOAT64 NOT NULL,
  metadata JSON NOT NULL,
  created_at TIMESTAMP NOT NULL,
  CONSTRAINT CK_Entity_Confidence CHECK (confidence >= 0 AND confidence <= 1)
) PRIMARY KEY (graph_id, entity_id);

CREATE TABLE DocumentHasChunk (
  graph_id STRING(63) NOT NULL,
  document_id STRING(36) NOT NULL,
  chunk_id STRING(36) NOT NULL,
  CONSTRAINT FK_DocumentHasChunk_Document FOREIGN KEY (graph_id, document_id)
    REFERENCES Document (graph_id, document_id),
  CONSTRAINT FK_DocumentHasChunk_Chunk FOREIGN KEY (graph_id, chunk_id)
    REFERENCES Chunk (graph_id, chunk_id)
) PRIMARY KEY (graph_id, document_id, chunk_id);

CREATE TABLE ChunkMentionsEntity (
  graph_id STRING(63) NOT NULL,
  chunk_id STRING(36) NOT NULL,
  entity_id STRING(36) NOT NULL,
  CONSTRAINT FK_ChunkMentionsEntity_Chunk FOREIGN KEY (graph_id, chunk_id)
    REFERENCES Chunk (graph_id, chunk_id),
  CONSTRAINT FK_ChunkMentionsEntity_Entity FOREIGN KEY (graph_id, entity_id)
    REFERENCES Entity (graph_id, entity_id)
) PRIMARY KEY (graph_id, chunk_id, entity_id);

CREATE INDEX IX_ChunkMentionsEntity_Entity
ON ChunkMentionsEntity(graph_id, entity_id, chunk_id);

CREATE TABLE EntityRelationship (
  graph_id STRING(63) NOT NULL,
  relationship_id STRING(36) NOT NULL,
  source_entity_id STRING(36) NOT NULL,
  target_entity_id STRING(36) NOT NULL,
  relationship_type STRING(32) NOT NULL,
  description STRING(MAX) NOT NULL,
  rationale STRING(MAX) NOT NULL,
  selection_context ARRAY<STRING(1000)> NOT NULL,
  evidence_chunk_id STRING(36) NOT NULL,
  chunk_ids ARRAY<STRING(36)> NOT NULL,
  confidence FLOAT64 NOT NULL,
  metadata JSON NOT NULL,
  created_at TIMESTAMP NOT NULL,
  CONSTRAINT FK_Relationship_Source FOREIGN KEY (graph_id, source_entity_id)
    REFERENCES Entity (graph_id, entity_id),
  CONSTRAINT FK_Relationship_Target FOREIGN KEY (graph_id, target_entity_id)
    REFERENCES Entity (graph_id, entity_id),
  CONSTRAINT FK_Relationship_Evidence FOREIGN KEY (graph_id, evidence_chunk_id)
    REFERENCES Chunk (graph_id, chunk_id),
  CONSTRAINT CK_Relationship_Confidence CHECK (confidence >= 0 AND confidence <= 1)
) PRIMARY KEY (graph_id, relationship_id);

CREATE INDEX IX_Relationship_Source
ON EntityRelationship(graph_id, source_entity_id, target_entity_id);

CREATE INDEX IX_Relationship_Target
ON EntityRelationship(graph_id, target_entity_id, source_entity_id);

CREATE PROPERTY GRAPH EnterpriseKnowledgeGraph
  NODE TABLES (
    Document LABEL Document PROPERTIES ALL COLUMNS,
    Chunk LABEL Chunk PROPERTIES ALL COLUMNS,
    Entity LABEL Entity PROPERTIES ALL COLUMNS
  )
  EDGE TABLES (
    DocumentHasChunk
      SOURCE KEY (graph_id, document_id) REFERENCES Document (graph_id, document_id)
      DESTINATION KEY (graph_id, chunk_id) REFERENCES Chunk (graph_id, chunk_id)
      LABEL HAS_CHUNK PROPERTIES ALL COLUMNS,
    ChunkMentionsEntity
      SOURCE KEY (graph_id, chunk_id) REFERENCES Chunk (graph_id, chunk_id)
      DESTINATION KEY (graph_id, entity_id) REFERENCES Entity (graph_id, entity_id)
      LABEL MENTIONS PROPERTIES ALL COLUMNS,
    EntityRelationship
      SOURCE KEY (graph_id, source_entity_id) REFERENCES Entity (graph_id, entity_id)
      DESTINATION KEY (graph_id, target_entity_id) REFERENCES Entity (graph_id, entity_id)
      LABEL RELATES_TO PROPERTIES ALL COLUMNS
  );

