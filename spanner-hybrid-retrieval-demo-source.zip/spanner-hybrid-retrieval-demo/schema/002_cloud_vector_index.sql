-- Optional Cloud Spanner ANN optimization. Keep exact KNN as the correctness baseline.
CREATE VECTOR INDEX ChunkEmbeddingVectorIndex
ON Chunk(embedding)
WHERE embedding IS NOT NULL
OPTIONS (distance_type='COSINE', tree_depth=2, num_leaves=1000);

