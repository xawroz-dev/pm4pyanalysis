from __future__ import annotations

from pathlib import Path
from typing import Any, cast

from hybrid_demo.models import DemoSeed
from hybrid_demo.settings import Settings
from hybrid_demo.store import DemoStore, _json, query_types


class FakeTransaction:
    def __init__(self) -> None:
        self.writes: dict[str, list[tuple[Any, ...]]] = {}

    def insert_or_update(
        self,
        table: str,
        *,
        columns: tuple[str, ...],
        values: list[tuple[Any, ...]],
    ) -> None:
        assert columns
        self.writes[table] = values


class FakeSnapshot:
    def __enter__(self) -> FakeSnapshot:
        return self

    def __exit__(self, *_args: object) -> None:
        return None

    def execute_sql(self, *_args: object, **_kwargs: object) -> list[tuple[object, ...]]:
        if _args and "COUNT(*)" in str(_args[0]):
            return [
                ("Document", 1),
                ("Chunk", 8),
                ("Entity", 15),
                ("DocumentHasChunk", 8),
                ("ChunkMentionsEntity", 26),
                ("EntityRelationship", 14),
            ]
        return [
            (
                "chunk-1",
                "Fraud screening blocks suspicious payments.",
                "Real-Time Fraud Screening",
                "MITIGATES",
                "Screening mitigates unauthorized transaction risk.",
                "Unauthorized Transaction",
                "chunk-1",
                0.15,
                2.1,
                0.92,
            )
        ]


class FakeDatabase:
    def __init__(self) -> None:
        self.transaction = FakeTransaction()

    def run_in_transaction(self, function: Any, seed: DemoSeed) -> None:
        function(self.transaction, seed)

    def snapshot(self) -> FakeSnapshot:
        return FakeSnapshot()


def _store(database: FakeDatabase) -> DemoStore:
    store: Any = DemoStore.__new__(DemoStore)
    store._database = database
    return cast(DemoStore, store)


def test_load_writes_all_graph_vector_and_lineage_tables() -> None:
    path = Path(__file__).resolve().parents[1] / "seed_data" / "process_knowledge.json"
    database = FakeDatabase()
    seed = _store(database).load(path)

    assert len(seed.chunks) == 8
    assert set(database.transaction.writes) == {
        "Document",
        "Chunk",
        "Entity",
        "DocumentHasChunk",
        "ChunkMentionsEntity",
        "EntityRelationship",
    }
    assert len(database.transaction.writes["Entity"]) == 15
    assert len(database.transaction.writes["EntityRelationship"]) == 14
    assert len(database.transaction.writes["Chunk"][0][5]) == 256


def test_query_decodes_rows_and_parameter_types() -> None:
    store = _store(FakeDatabase())
    hits = store.query("SELECT demo", params={}, types={})

    assert hits[0].relationship_type == "MITIGATES"
    assert hits[0].hybrid_score == 0.92
    assert store.counts("payments")["Entity"] == 15
    assert set(query_types(vector=True, text=True, entity=True)) == {
        "graph_id",
        "limit",
        "query_embedding",
        "text_query",
        "entity_id",
    }
    assert set(query_types(vector=False, text=False, entity=False)) == {"graph_id", "limit"}
    assert _json({"b": 2, "a": 1}) == '{"a":1,"b":2}'
    assert Settings().spanner_project == "local-ai-kg"
