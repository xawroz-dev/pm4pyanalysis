import math

from hybrid_demo.embedding import DIMENSIONS, embed
from hybrid_demo.ids import stable_id


def test_demo_embedding_and_ids_are_deterministic() -> None:
    vector = embed("fraud controls for unauthorized transactions")
    assert vector == embed("fraud controls for unauthorized transactions")
    assert len(vector) == DIMENSIONS
    assert math.sqrt(sum(value * value for value in vector)) == 1.0
    assert stable_id("entity", "payments", "risk") == stable_id("entity", "payments", "risk")
