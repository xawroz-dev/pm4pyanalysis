from pathlib import Path

from hybrid_demo.models import DemoSeed


def test_seed_graph_is_complete() -> None:
    path = Path(__file__).resolve().parents[1] / "seed_data" / "process_knowledge.json"
    seed = DemoSeed.model_validate_json(path.read_text(encoding="utf-8"))
    entity_keys = {item.key for item in seed.entities}
    chunk_keys = {item.key for item in seed.chunks}

    assert {item.entity_type for item in seed.entities} >= {
        "Process",
        "Policy",
        "Risk",
        "Control",
        "Market",
        "System",
    }
    assert len(seed.chunks) == 8
    assert len(seed.entities) == 15
    assert len(seed.relationships) == 14
    assert all(item.source_key in entity_keys for item in seed.relationships)
    assert all(item.target_key in entity_keys for item in seed.relationships)
    assert all(item.evidence_chunk_key in chunk_keys for item in seed.relationships)
    assert all(set(item.entity_keys) <= entity_keys for item in seed.chunks)
