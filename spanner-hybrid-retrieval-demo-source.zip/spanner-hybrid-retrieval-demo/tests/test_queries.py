from hybrid_demo.queries import (
    FULLTEXT_TO_GRAPH_SQL,
    GRAPH_TO_VECTOR_SQL,
    HYBRID_TO_GRAPH_SQL,
    VECTOR_TO_GRAPH_SQL,
)


def test_hybrid_query_is_one_statement_with_all_retrieval_modes() -> None:
    assert "COSINE_DISTANCE" in HYBRID_TO_GRAPH_SQL
    assert "SEARCH(content_tokens" in HYBRID_TO_GRAPH_SQL
    assert "GRAPH_TABLE" in HYBRID_TO_GRAPH_SQL
    assert "RETURN" in HYBRID_TO_GRAPH_SQL
    assert "COLUMNS" not in HYBRID_TO_GRAPH_SQL
    assert "UNION ALL" in HYBRID_TO_GRAPH_SQL
    assert ";" not in HYBRID_TO_GRAPH_SQL


def test_directional_queries_are_single_statements() -> None:
    assert "COSINE_DISTANCE" in VECTOR_TO_GRAPH_SQL
    assert "SEARCH(content_tokens" in FULLTEXT_TO_GRAPH_SQL
    assert "MATCH (seed:Entity)" in GRAPH_TO_VECTOR_SQL
    assert "evidence_chunk_id" in GRAPH_TO_VECTOR_SQL
    assert all(
        ";" not in value
        for value in (VECTOR_TO_GRAPH_SQL, FULLTEXT_TO_GRAPH_SQL, GRAPH_TO_VECTOR_SQL)
    )
