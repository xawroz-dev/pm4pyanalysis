from pathlib import Path

from bootstrap import bootstrap

from hybrid_demo.settings import get_settings
from hybrid_demo.store import DemoStore


def insert_all() -> None:
    bootstrap()
    path = Path(__file__).resolve().parents[1] / "seed_data" / "process_knowledge.json"
    store = DemoStore(get_settings())
    seed = store.load(path)
    counts = store.counts(seed.graph_id)
    expected = {
        "Document": 1,
        "Chunk": len(seed.chunks),
        "Entity": len(seed.entities),
        "DocumentHasChunk": len(seed.chunks),
        "ChunkMentionsEntity": sum(len(chunk.entity_keys) for chunk in seed.chunks),
        "EntityRelationship": len(seed.relationships),
    }

    print("\n=== INSERTION COMPLETE ===")
    print(f"Graph '{seed.graph_id}' now contains the complete deterministic demonstration dataset.")
    print("\nTable                    Expected   Stored   Status")
    print("-" * 58)
    for table, expected_count in expected.items():
        actual = counts.get(table, 0)
        status = "OK" if actual == expected_count else "MISMATCH"
        print(f"{table:<25} {expected_count:>8} {actual:>8}   {status}")
    mismatches = {key for key, value in expected.items() if counts.get(key) != value}
    if mismatches:
        raise RuntimeError(f"insert verification failed for: {', '.join(sorted(mismatches))}")
    print("\nAll graph rows, chunk vectors, entity vectors, full-text source content, and")
    print("chunk-to-entity/evidence lineage were inserted and verified.")


def main() -> None:
    insert_all()


if __name__ == "__main__":
    main()
