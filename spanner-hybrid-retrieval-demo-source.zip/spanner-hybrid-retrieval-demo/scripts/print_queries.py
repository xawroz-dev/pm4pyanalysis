from hybrid_demo.queries import (
    FULLTEXT_TO_GRAPH_SQL,
    GRAPH_TO_VECTOR_SQL,
    HYBRID_TO_GRAPH_SQL,
    VECTOR_TO_GRAPH_SQL,
)


def main() -> None:
    values = {
        "HYBRID_TO_GRAPH_SQL": HYBRID_TO_GRAPH_SQL,
        "VECTOR_TO_GRAPH_SQL": VECTOR_TO_GRAPH_SQL,
        "FULLTEXT_TO_GRAPH_SQL": FULLTEXT_TO_GRAPH_SQL,
        "GRAPH_TO_VECTOR_SQL": GRAPH_TO_VECTOR_SQL,
    }
    for name, sql in values.items():
        print(f"\n-- {name}\n{sql};")


if __name__ == "__main__":
    main()
