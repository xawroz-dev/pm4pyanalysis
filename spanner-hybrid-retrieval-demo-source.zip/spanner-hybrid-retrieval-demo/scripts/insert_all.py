"""One-shot schema creation plus complete, verified demonstration-data insertion."""

from init_data import insert_all

if __name__ == "__main__":
    insert_all()
