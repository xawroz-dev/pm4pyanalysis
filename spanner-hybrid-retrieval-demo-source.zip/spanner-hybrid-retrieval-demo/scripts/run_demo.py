from __future__ import annotations

import argparse
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from google.cloud.spanner_v1 import param_types

from hybrid_demo.embedding import embed
from hybrid_demo.ids import stable_id
from hybrid_demo.models import DemoSeed, SearchHit
from hybrid_demo.queries import (
    FULLTEXT_TO_GRAPH_SQL,
    GRAPH_TO_VECTOR_SQL,
    HYBRID_TO_GRAPH_SQL,
    VECTOR_TO_GRAPH_SQL,
)
from hybrid_demo.settings import get_settings
from hybrid_demo.store import DemoStore

DEFAULT_QUESTION = "Which fraud controls mitigate unauthorized card transactions?"
DEFAULT_TEXT_QUERY = "fraud | unauthorized | screening"


@dataclass(frozen=True)
class Demonstration:
    key: str
    title: str
    explanation: str
    sql: str
    params: dict[str, Any]
    types: dict[str, Any]


def demonstrations(
    seed: DemoSeed,
    *,
    question: str,
    text_query: str,
    entity_key: str,
    limit: int,
) -> list[Demonstration]:
    vector = embed(question)
    vector_type = param_types.Array(param_types.FLOAT32)  # type: ignore[no-untyped-call]
    common_params: dict[str, Any] = {
        "graph_id": seed.graph_id,
        "query_embedding": vector,
        "seed_limit": 10,
        "limit": limit,
    }
    common_types: dict[str, Any] = {
        "graph_id": param_types.STRING,
        "query_embedding": vector_type,
        "seed_limit": param_types.INT64,
        "limit": param_types.INT64,
    }
    return [
        Demonstration(
            key="hybrid",
            title="HYBRID: VECTOR + FULL TEXT -> GRAPH",
            explanation=(
                "Ranks semantic and keyword chunk candidates, fuses their scores, then enters "
                "the property graph through MENTIONS and traverses RELATES_TO. Everything below "
                "is executed as one parameterized Spanner statement."
            ),
            sql=HYBRID_TO_GRAPH_SQL,
            params={**common_params, "text_query": text_query, "text_boost": 0.25},
            types={
                **common_types,
                "text_query": param_types.STRING,
                "text_boost": param_types.FLOAT64,
            },
        ),
        Demonstration(
            key="vector-to-graph",
            title="VECTOR -> GRAPH",
            explanation=(
                "Uses exact cosine-distance search to select semantically relevant chunks, then "
                "expands their mentioned entities and neighboring graph facts in the same query."
            ),
            sql=VECTOR_TO_GRAPH_SQL,
            params=common_params,
            types=common_types,
        ),
        Demonstration(
            key="text-to-graph",
            title="FULL TEXT -> GRAPH",
            explanation=(
                "Uses Spanner SEARCH and SCORE over the generated TOKENLIST, then converts "
                "matching chunks into graph entry points and returns connected facts in the "
                "same query."
            ),
            sql=FULLTEXT_TO_GRAPH_SQL,
            params={
                "graph_id": seed.graph_id,
                "text_query": text_query,
                "seed_limit": 10,
                "limit": limit,
            },
            types={
                "graph_id": param_types.STRING,
                "text_query": param_types.STRING,
                "seed_limit": param_types.INT64,
                "limit": param_types.INT64,
            },
        ),
        Demonstration(
            key="graph-to-vector",
            title="GRAPH -> VECTOR",
            explanation=(
                "Starts from a known entity, traverses its relationship evidence in GRAPH_TABLE, "
                "and vector-ranks only those graph-selected evidence chunks in the same query."
            ),
            sql=GRAPH_TO_VECTOR_SQL,
            params={
                "graph_id": seed.graph_id,
                "entity_id": stable_id("entity", seed.graph_id, entity_key),
                "query_embedding": vector,
                "limit": limit,
            },
            types={
                "graph_id": param_types.STRING,
                "entity_id": param_types.STRING,
                "query_embedding": vector_type,
                "limit": param_types.INT64,
            },
        ),
    ]


def run_demonstrations(
    *,
    selected: str = "all",
    question: str = DEFAULT_QUESTION,
    text_query: str = DEFAULT_TEXT_QUERY,
    entity_key: str = "risk-unauthorized",
    limit: int = 10,
    show_sql: bool = False,
    as_json: bool = False,
) -> None:
    seed_path = Path(__file__).resolve().parents[1] / "seed_data" / "process_knowledge.json"
    seed = DemoSeed.model_validate_json(seed_path.read_text(encoding="utf-8"))
    store = DemoStore(get_settings())
    values = demonstrations(
        seed,
        question=question,
        text_query=text_query,
        entity_key=entity_key,
        limit=limit,
    )
    chosen = values if selected == "all" else [item for item in values if item.key == selected]
    if not chosen:
        raise ValueError(f"unknown demonstration: {selected}")

    print("\nSPANNER GRAPH + VECTOR + FULL-TEXT RETRIEVAL DEMONSTRATION")
    print("=" * 72)
    print(f"Graph:      {seed.graph_id}")
    print(f"Question:   {question}")
    print(f"Text query: {text_query}")
    print(f"Graph seed: {entity_key}")

    for item in chosen:
        print(f"\n\n=== {item.title} ===")
        print(item.explanation)
        if show_sql:
            print(f"\nSQL/GQL:\n{item.sql};")
        hits = store.query(item.sql, params=item.params, types=item.types)
        if not hits:
            raise RuntimeError(f"{item.key} returned no rows")
        if as_json:
            print(json.dumps([hit.model_dump(mode="json") for hit in hits], indent=2))
        else:
            _print_hits(hits)
        print(f"\nResult check: PASS ({len(hits)} graph-enriched rows returned)")


def _print_hits(hits: list[SearchHit]) -> None:
    print("\n#  Seed entity                  Edge          Related entity")
    print("-" * 88)
    for index, hit in enumerate(hits, start=1):
        print(
            f"{index:<2} {_short(hit.seed_entity_name, 28):<28} "
            f"{_short(hit.relationship_type, 13):<13} {_short(hit.related_entity_name, 30)}"
        )
        print(f"   Fact:     {hit.relationship_description}")
        print(f"   Evidence: {_short(hit.chunk_content, 150)}")
        print(
            "   Scores:   "
            f"vector_distance={_score(hit.vector_distance)}  "
            f"text_score={_score(hit.text_score)}  "
            f"hybrid_score={_score(hit.hybrid_score)}"
        )
        print(f"   Chunk ID: {hit.evidence_chunk_id}\n")


def _short(value: str, length: int) -> str:
    return value if len(value) <= length else f"{value[: length - 1]}…"


def _score(value: float | None) -> str:
    return "-" if value is None else f"{value:.4f}"


def _arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run one or all single-statement Spanner hybrid retrieval demonstrations."
    )
    parser.add_argument(
        "--query",
        choices=("all", "hybrid", "vector-to-graph", "text-to-graph", "graph-to-vector"),
        default="all",
    )
    parser.add_argument("--question", default=DEFAULT_QUESTION)
    parser.add_argument("--text-query", default=DEFAULT_TEXT_QUERY)
    parser.add_argument("--entity-key", default="risk-unauthorized")
    parser.add_argument("--limit", type=int, default=10)
    parser.add_argument("--show-sql", action="store_true")
    parser.add_argument("--json", action="store_true", dest="as_json")
    return parser.parse_args()


def main() -> None:
    args = _arguments()
    run_demonstrations(
        selected=args.query,
        question=args.question,
        text_query=args.text_query,
        entity_key=args.entity_key,
        limit=args.limit,
        show_sql=args.show_sql,
        as_json=args.as_json,
    )


if __name__ == "__main__":
    main()
