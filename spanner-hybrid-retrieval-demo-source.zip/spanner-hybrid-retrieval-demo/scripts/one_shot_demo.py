"""Create schema, insert and verify all data, then execute every demonstration query."""

from init_data import insert_all
from run_demo import run_demonstrations


def main() -> None:
    insert_all()
    run_demonstrations(show_sql=False)


if __name__ == "__main__":
    main()
