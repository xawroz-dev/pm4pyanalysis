# Hybrid retrieval demonstration guide

## One physical model

Both projects use the following graph:

```mermaid
flowchart LR
    D["Document"] -->|HAS_CHUNK| C["Chunk + full-text tokens + vector"]
    C -->|MENTIONS| E["Entity + vector + chunk_ids"]
    E -->|RELATES_TO| E2["Entity"]
    R["Relationship metadata"] -.-> C2["evidence_chunk_id"]
```

`graph_id` is part of all primary and foreign keys. Every graph variable is also filtered by
`graph_id` in the query.

## Query 1: hybrid to graph

Input:

```text
Which fraud controls mitigate unauthorized card transactions?
```

The vector seed can recall the controls chunk from semantic similarity. The full-text seed can
recall chunks containing `fraud`, `unauthorized`, or `screening`. After seed fusion, the graph
expansion returns facts such as:

```text
Real-Time Fraud Screening -[MITIGATES]-> Unauthorized Transaction
Card Payment Authorization -[EXPOSED_TO]-> Unauthorized Transaction
```

The final rows retain vector distance, full-text score, hybrid score, relationship description,
and evidence chunk ID.

## Query 2: vector to graph

Exact KNN ranks all chunks with `COSINE_DISTANCE`. The top chunk IDs are passed to the graph
expansion inside the same statement.

Exact KNN is used because it is simple and provides a correctness baseline. For production Cloud
Spanner, qualify the optional vector index in `schema/002_cloud_vector_index.sql`, then evaluate an
ANN query using `APPROX_COSINE_DISTANCE`.

## Query 3: full text to graph

`Chunk.content_tokens` is a stored generated `TOKENLIST`. The `ChunkContentSearch` index supports
`SEARCH`, while `SCORE` orders matching chunks before graph expansion.

## Query 4: graph to vector

The query starts from the deterministic entity ID for `Unauthorized Transaction`. Graph traversal
returns neighboring relationships and their evidence chunks. Only those evidence chunks are then
ranked against the question vector.

## Why the demo embedding is not production AI

The deterministic signed-hash vector exists only to make insertion, vector storage, and SQL
composition runnable without credentials. It has limited semantic quality. Project 1 replaces it
with the OpenAI embeddings API while preserving the same 256-dimensional schema.

## Verification checklist

1. The bootstrap reports that the schema exists.
2. Insertion reports 8 chunks, 15 entities, and 14 relationships with `OK` status.
3. Each of the four headings prints at least one result.
4. Hybrid rows include both ranking fields and graph facts.
5. Graph-to-vector rows use relationship evidence chunks rather than scanning unrelated chunks.

The scripts enforce checks 2 and 3 automatically and exit nonzero on failure.
