# Local Spanner graph, vector, and full-text demonstration runbook

This runbook uses the Google Spanner emulator Docker image as the local Spanner-compatible runtime.
No AI API key is required because the seed vectors are generated deterministically.

## Option A: completely automatic

From the project directory:

```bash
docker compose up --build --abort-on-container-exit
```

The `demo` container runs `scripts/one_shot_demo.py`, which performs schema creation, complete
insertion, database count verification, and all four queries. The command can be run repeatedly;
the seed uses deterministic IDs and `insert_or_update`.

## Option B: keep the database running

```bash
make install
cp .env.example .env
docker compose up -d spanner
make insert
make demo
```

The insertion output should include:

```text
=== INSERTION COMPLETE ===
Table                    Expected   Stored   Status
----------------------------------------------------------
Document                        1        1   OK
Chunk                           8        8   OK
Entity                         15       15   OK
DocumentHasChunk                8        8   OK
ChunkMentionsEntity            26       26   OK
EntityRelationship             14       14   OK
```

Generated `TOKENLIST` values are maintained by Spanner and therefore do not have a separate row
count. Every Chunk row contains a 256-dimensional vector, and every Entity row contains a separate
256-dimensional vector.

The direct insertion command behind `make insert` is:

```bash
.venv/bin/python scripts/insert_all.py
```

## Query runner

Run all retrieval modes:

```bash
make demo
```

Run only hybrid vector plus text to graph:

```bash
.venv/bin/python scripts/run_demo.py --query hybrid --show-sql
```

The other query names are:

```text
vector-to-graph
text-to-graph
graph-to-vector
```

Each result prints:

- the chunk-derived seed entity;
- relationship type and full relationship description;
- the related entity;
- the evidence text and evidence chunk ID;
- vector distance, full-text score, and hybrid score when applicable;
- an explicit PASS result count.

The query runner exits nonzero when a selected query returns no rows.

## Card authorization example

```bash
.venv/bin/python scripts/run_demo.py \
  --question "Which fraud controls mitigate unauthorized card transactions?" \
  --text-query "fraud | unauthorized | screening" \
  --entity-key risk-unauthorized
```

Expected facts include:

```text
Real-Time Fraud Screening -[MITIGATES]-> Unauthorized Transaction
Card Payment Authorization -[EXPOSED_TO]-> Unauthorized Transaction
Card Payment Authorization -[USES]-> Real-Time Fraud Platform
```

## Merchant onboarding example

```bash
.venv/bin/python scripts/run_demo.py \
  --question "Which controls reduce merchant regulatory risk?" \
  --text-query "identity | regulatory | onboarding" \
  --entity-key risk-regulatory
```

Expected facts include:

```text
Automated Identity Verification -[MITIGATES]-> Regulatory Noncompliance
Merchant Onboarding -[EXPOSED_TO]-> Regulatory Noncompliance
Merchant Onboarding -[GOVERNED_BY]-> Know Your Customer Policy
```

## Copyable SQL/GQL

Print every statement:

```bash
make queries
```

Or pass `--show-sql` to the query runner to print the exact selected parameterized statement next
to its explanation and results. The statements in `src/hybrid_demo/queries.py` contain no embedded
user input and are each sent to Spanner with one `execute_sql` call.

## Stop the local runtime

```bash
docker compose down
```

The emulator is for functional demonstration. Validate Cloud Spanner edition, IAM, backups,
encryption, query plans, load, and optional ANN vector-index settings separately before production.
