from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field, model_validator


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class ChunkSeed(StrictModel):
    key: str
    content: str
    entity_keys: list[str]


class EntitySeed(StrictModel):
    key: str
    entity_type: str
    name: str
    description: str
    chunk_keys: list[str]


class RelationshipSeed(StrictModel):
    key: str
    source_key: str
    target_key: str
    relationship_type: str
    description: str
    rationale: str
    selection_context: list[str]
    evidence_chunk_key: str
    confidence: float = Field(ge=0, le=1)


class DemoSeed(StrictModel):
    graph_id: str
    document_key: str
    filename: str
    chunks: list[ChunkSeed]
    entities: list[EntitySeed]
    relationships: list[RelationshipSeed]

    @model_validator(mode="after")
    def validate_references(self) -> DemoSeed:
        chunk_keys = [item.key for item in self.chunks]
        entity_keys = [item.key for item in self.entities]
        if len(chunk_keys) != len(set(chunk_keys)):
            raise ValueError("chunk keys must be unique")
        if len(entity_keys) != len(set(entity_keys)):
            raise ValueError("entity keys must be unique")
        known_chunks = set(chunk_keys)
        known_entities = set(entity_keys)
        for chunk in self.chunks:
            if not set(chunk.entity_keys) <= known_entities:
                raise ValueError(f"chunk {chunk.key} references an unknown entity")
        for entity in self.entities:
            if not set(entity.chunk_keys) <= known_chunks:
                raise ValueError(f"entity {entity.key} references an unknown chunk")
        for relationship in self.relationships:
            if relationship.source_key not in known_entities:
                raise ValueError(f"relationship {relationship.key} has an unknown source")
            if relationship.target_key not in known_entities:
                raise ValueError(f"relationship {relationship.key} has an unknown target")
            if relationship.evidence_chunk_key not in known_chunks:
                raise ValueError(f"relationship {relationship.key} has an unknown evidence chunk")
        return self


class SearchHit(StrictModel):
    chunk_id: str
    chunk_content: str
    seed_entity_name: str
    relationship_type: str
    relationship_description: str
    related_entity_name: str
    evidence_chunk_id: str
    vector_distance: float | None
    text_score: float | None
    hybrid_score: float | None
