from __future__ import annotations

import json
import os
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from google.cloud import spanner
from google.cloud.spanner_v1 import param_types

from hybrid_demo.embedding import embed
from hybrid_demo.ids import stable_id
from hybrid_demo.models import DemoSeed, SearchHit
from hybrid_demo.settings import Settings


class DemoStore:
    def __init__(self, settings: Settings) -> None:
        if settings.spanner_emulator_host:
            os.environ["SPANNER_EMULATOR_HOST"] = settings.spanner_emulator_host
        client: Any = spanner.Client(project=settings.spanner_project)
        self._database = client.instance(settings.spanner_instance).database(
            settings.spanner_database
        )

    def load(self, path: Path) -> DemoSeed:
        seed = DemoSeed.model_validate_json(path.read_text(encoding="utf-8"))
        self._database.run_in_transaction(self._load_transaction, seed)
        return seed

    @staticmethod
    def _load_transaction(transaction: Any, seed: DemoSeed) -> None:
        now = datetime.now(UTC)
        document_id = stable_id("document", seed.graph_id, seed.document_key)
        chunk_ids = {item.key: stable_id("chunk", seed.graph_id, item.key) for item in seed.chunks}
        entity_ids = {
            item.key: stable_id("entity", seed.graph_id, item.key) for item in seed.entities
        }
        transaction.insert_or_update(
            "Document",
            columns=(
                "graph_id",
                "document_id",
                "filename",
                "media_type",
                "content_hash",
                "metadata",
                "created_at",
            ),
            values=[
                (
                    seed.graph_id,
                    document_id,
                    seed.filename,
                    "text/markdown",
                    stable_id("content", seed.graph_id, seed.document_key).replace("-", "") * 2,
                    _json({"source": "deterministic-demo"}),
                    now,
                )
            ],
        )
        transaction.insert_or_update(
            "Chunk",
            columns=(
                "graph_id",
                "chunk_id",
                "document_id",
                "ordinal",
                "content",
                "embedding",
                "metadata",
                "created_at",
            ),
            values=[
                (
                    seed.graph_id,
                    chunk_ids[item.key],
                    document_id,
                    ordinal,
                    item.content,
                    embed(item.content),
                    _json({"seed_key": item.key}),
                    now,
                )
                for ordinal, item in enumerate(seed.chunks)
            ],
        )
        transaction.insert_or_update(
            "Entity",
            columns=(
                "graph_id",
                "entity_id",
                "entity_type",
                "name",
                "description",
                "aliases",
                "embedding",
                "chunk_ids",
                "confidence",
                "metadata",
                "created_at",
            ),
            values=[
                (
                    seed.graph_id,
                    entity_ids[item.key],
                    item.entity_type,
                    item.name,
                    item.description,
                    [],
                    embed(f"{item.entity_type}: {item.name}. {item.description}"),
                    [chunk_ids[key] for key in item.chunk_keys],
                    1.0,
                    _json({"seed_key": item.key}),
                    now,
                )
                for item in seed.entities
            ],
        )
        transaction.insert_or_update(
            "DocumentHasChunk",
            columns=("graph_id", "document_id", "chunk_id"),
            values=[(seed.graph_id, document_id, chunk_ids[item.key]) for item in seed.chunks],
        )
        transaction.insert_or_update(
            "ChunkMentionsEntity",
            columns=("graph_id", "chunk_id", "entity_id"),
            values=[
                (seed.graph_id, chunk_ids[chunk.key], entity_ids[entity_key])
                for chunk in seed.chunks
                for entity_key in chunk.entity_keys
            ],
        )
        transaction.insert_or_update(
            "EntityRelationship",
            columns=(
                "graph_id",
                "relationship_id",
                "source_entity_id",
                "target_entity_id",
                "relationship_type",
                "description",
                "rationale",
                "selection_context",
                "evidence_chunk_id",
                "chunk_ids",
                "confidence",
                "metadata",
                "created_at",
            ),
            values=[
                (
                    seed.graph_id,
                    stable_id("relationship", seed.graph_id, item.key),
                    entity_ids[item.source_key],
                    entity_ids[item.target_key],
                    item.relationship_type,
                    item.description,
                    item.rationale,
                    item.selection_context,
                    chunk_ids[item.evidence_chunk_key],
                    [chunk_ids[item.evidence_chunk_key]],
                    item.confidence,
                    _json({"seed_key": item.key}),
                    now,
                )
                for item in seed.relationships
            ],
        )

    def query(self, sql: str, *, params: dict[str, Any], types: dict[str, Any]) -> list[SearchHit]:
        with self._database.snapshot() as snapshot:
            rows = list(snapshot.execute_sql(sql, params=params, param_types=types))
        return [
            SearchHit.model_validate(dict(zip(SearchHit.model_fields, row, strict=True)))
            for row in rows
        ]

    def counts(self, graph_id: str) -> dict[str, int]:
        sql = """
        SELECT 'Document' AS table_name, COUNT(*) AS row_count
        FROM Document WHERE graph_id=@graph_id
        UNION ALL
        SELECT 'Chunk', COUNT(*) FROM Chunk WHERE graph_id=@graph_id
        UNION ALL
        SELECT 'Entity', COUNT(*) FROM Entity WHERE graph_id=@graph_id
        UNION ALL
        SELECT 'DocumentHasChunk', COUNT(*) FROM DocumentHasChunk WHERE graph_id=@graph_id
        UNION ALL
        SELECT 'ChunkMentionsEntity', COUNT(*) FROM ChunkMentionsEntity WHERE graph_id=@graph_id
        UNION ALL
        SELECT 'EntityRelationship', COUNT(*)
        FROM EntityRelationship WHERE graph_id=@graph_id
        """
        with self._database.snapshot() as snapshot:
            rows = snapshot.execute_sql(
                sql,
                params={"graph_id": graph_id},
                param_types={"graph_id": param_types.STRING},
            )
            return {str(row[0]): int(row[1]) for row in rows}


def query_types(*, vector: bool, text: bool, entity: bool) -> dict[str, Any]:
    result: dict[str, Any] = {
        "graph_id": param_types.STRING,
        "limit": param_types.INT64,
    }
    if vector:
        result["query_embedding"] = param_types.Array(  # type: ignore[no-untyped-call]
            param_types.FLOAT32
        )
    if text:
        result["text_query"] = param_types.STRING
    if entity:
        result["entity_id"] = param_types.STRING
    return result


def _json(value: object) -> str:
    return json.dumps(value, separators=(",", ":"), sort_keys=True)
