from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_prefix="KG_", extra="ignore")

    spanner_project: str = "local-ai-kg"
    spanner_instance: str = "ai-knowledge"
    spanner_database: str = "process-knowledge"
    spanner_emulator_host: str | None = None


@lru_cache
def get_settings() -> Settings:
    return Settings()
