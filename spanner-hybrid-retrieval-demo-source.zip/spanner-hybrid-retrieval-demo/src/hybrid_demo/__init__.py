"""Spanner hybrid graph/vector/full-text demonstration."""
