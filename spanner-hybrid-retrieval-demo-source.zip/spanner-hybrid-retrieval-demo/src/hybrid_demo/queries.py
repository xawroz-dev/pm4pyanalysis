"""Every constant is exactly one parameterized database statement."""

GRAPH_EXPANSION = """
SELECT * FROM GRAPH_TABLE(
  EnterpriseKnowledgeGraph
  MATCH (c:Chunk)-[:MENTIONS]->(seed:Entity)-[rel:RELATES_TO]-(related:Entity)
  WHERE c.graph_id=@graph_id AND seed.graph_id=@graph_id
    AND rel.graph_id=@graph_id AND related.graph_id=@graph_id
  RETURN
    c.chunk_id AS chunk_id,
    c.content AS chunk_content,
    seed.name AS seed_entity_name,
    rel.relationship_type AS relationship_type,
    rel.description AS relationship_description,
    related.name AS related_entity_name,
    rel.evidence_chunk_id AS evidence_chunk_id
)
""".strip()

VECTOR_TO_GRAPH_SQL = f"""
WITH VectorSeeds AS (
  SELECT chunk_id, COSINE_DISTANCE(embedding, @query_embedding) AS vector_distance
  FROM Chunk
  WHERE graph_id=@graph_id AND embedding IS NOT NULL
  ORDER BY vector_distance
  LIMIT @seed_limit
), GraphExpansion AS ({GRAPH_EXPANSION})
SELECT g.*, v.vector_distance,
  CAST(NULL AS FLOAT64) AS text_score,
  CAST(NULL AS FLOAT64) AS hybrid_score
FROM VectorSeeds v JOIN GraphExpansion g USING (chunk_id)
ORDER BY vector_distance
LIMIT @limit
""".strip()

FULLTEXT_TO_GRAPH_SQL = f"""
WITH TextSeeds AS (
  SELECT chunk_id, SCORE(content_tokens, @text_query) AS text_score
  FROM Chunk
  WHERE graph_id=@graph_id AND SEARCH(content_tokens, @text_query)
  ORDER BY text_score DESC
  LIMIT @seed_limit
), GraphExpansion AS ({GRAPH_EXPANSION})
SELECT g.*, CAST(NULL AS FLOAT64) AS vector_distance,
  t.text_score, CAST(NULL AS FLOAT64) AS hybrid_score
FROM TextSeeds t JOIN GraphExpansion g USING (chunk_id)
ORDER BY text_score DESC
LIMIT @limit
""".strip()

HYBRID_TO_GRAPH_SQL = f"""
WITH VectorSeeds AS (
  SELECT chunk_id, COSINE_DISTANCE(embedding, @query_embedding) AS vector_distance,
    CAST(NULL AS FLOAT64) AS text_score
  FROM Chunk
  WHERE graph_id=@graph_id AND embedding IS NOT NULL
  ORDER BY vector_distance
  LIMIT @seed_limit
), TextSeeds AS (
  SELECT chunk_id, CAST(NULL AS FLOAT64) AS vector_distance,
    SCORE(content_tokens, @text_query) AS text_score
  FROM Chunk
  WHERE graph_id=@graph_id AND SEARCH(content_tokens, @text_query)
  ORDER BY text_score DESC
  LIMIT @seed_limit
), Combined AS (
  SELECT chunk_id, MIN(vector_distance) AS vector_distance, MAX(text_score) AS text_score
  FROM (SELECT * FROM VectorSeeds UNION ALL SELECT * FROM TextSeeds)
  GROUP BY chunk_id
), Ranked AS (
  SELECT chunk_id, vector_distance, text_score,
    (1.0 - IFNULL(vector_distance, 1.0))
      + IF(text_score IS NULL, 0.0, @text_boost) AS hybrid_score
  FROM Combined
  ORDER BY hybrid_score DESC
  LIMIT @seed_limit
), GraphExpansion AS ({GRAPH_EXPANSION})
SELECT g.*, r.vector_distance, r.text_score, r.hybrid_score
FROM Ranked r JOIN GraphExpansion g USING (chunk_id)
ORDER BY hybrid_score DESC
LIMIT @limit
""".strip()

GRAPH_TO_VECTOR_SQL = """
WITH GraphFacts AS (
  SELECT * FROM GRAPH_TABLE(
    EnterpriseKnowledgeGraph
    MATCH (seed:Entity)-[rel:RELATES_TO]-(related:Entity)
    WHERE seed.graph_id=@graph_id AND seed.entity_id=@entity_id
      AND rel.graph_id=@graph_id AND related.graph_id=@graph_id
    RETURN
      rel.evidence_chunk_id AS chunk_id,
      seed.name AS seed_entity_name,
      rel.relationship_type AS relationship_type,
      rel.description AS relationship_description,
      related.name AS related_entity_name,
      rel.evidence_chunk_id AS evidence_chunk_id
  )
)
SELECT f.chunk_id, c.content AS chunk_content, f.seed_entity_name,
  f.relationship_type, f.relationship_description, f.related_entity_name,
  f.evidence_chunk_id,
  COSINE_DISTANCE(c.embedding, @query_embedding) AS vector_distance,
  CAST(NULL AS FLOAT64) AS text_score,
  CAST(NULL AS FLOAT64) AS hybrid_score
FROM GraphFacts f
JOIN Chunk c ON c.graph_id=@graph_id AND c.chunk_id=f.chunk_id
WHERE c.embedding IS NOT NULL
ORDER BY vector_distance
LIMIT @limit
""".strip()
