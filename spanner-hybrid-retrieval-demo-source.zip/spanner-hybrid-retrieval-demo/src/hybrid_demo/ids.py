import uuid


def stable_id(kind: str, graph_id: str, key: str) -> str:
    return str(uuid.uuid5(uuid.NAMESPACE_URL, f"{kind}\x1f{graph_id}\x1f{key}"))
