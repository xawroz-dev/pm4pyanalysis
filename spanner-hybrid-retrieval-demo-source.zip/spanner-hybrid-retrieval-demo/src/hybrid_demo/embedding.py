from __future__ import annotations

import hashlib
import math
import re

DIMENSIONS = 256


def embed(text: str) -> list[float]:
    """Deterministic offline vector used only to make the demo immediately runnable."""
    vector = [0.0] * DIMENSIONS
    words = re.findall(r"[a-z0-9]+", text.casefold())
    features = [*words]
    features.extend(word[index : index + 3] for word in words for index in range(len(word) - 2))
    for feature in features:
        digest = hashlib.blake2b(feature.encode(), digest_size=8).digest()
        index = int.from_bytes(digest[:4], "big") % DIMENSIONS
        vector[index] += 1.0 if digest[4] & 1 else -1.0
    norm = math.sqrt(sum(value * value for value in vector))
    return vector if norm == 0 else [value / norm for value in vector]
