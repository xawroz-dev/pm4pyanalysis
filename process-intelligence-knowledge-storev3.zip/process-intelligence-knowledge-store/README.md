# Enterprise Process Intelligence Knowledge Store

A complete proof of concept that combines:

- Neo4j for governed process knowledge and connected operational context;
- Qdrant for document chunks and embeddings;
- a fixed-intent hybrid retrieval API;
- optional LLM entity extraction and answer generation;
- BPMN parsing, live journey and variant ingestion;
- a browser UI for chat, evidence inspection, and graph exploration.

The central design decision is simple: **the graph models the enterprise; the
vector store models retrieval passages**. A document chunk is not an enterprise
entity, so this implementation does not create `Chunk` nodes or `HAS_CHUNK`
relationships in Neo4j.

## Quick start

```bash
cp .env.example .env
docker compose up --build -d
python scripts/load_sample.py
```

Open:

- Knowledge Studio UI: <http://localhost:8000/>
- API documentation: <http://localhost:8000/docs>
- Neo4j Browser: <http://localhost:7474/browser/>
- Qdrant dashboard: <http://localhost:6333/dashboard>

Local demo Neo4j login:

```text
Username: neo4j
Password: change-me-enterprise
```

Change the password in `.env` before any shared or non-local deployment.

The fastest Neo4j visualization query is:

```cypher
MATCH path=(source)-[relationship]->(target)
RETURN path
LIMIT 500;
```

For a clean P2P business view:

```cypher
MATCH path=(p:Process {process_id: 'P2P-001'})
  -[:OPERATES_IN|OWNED_BY|GOVERNED_BY|USES_SYSTEM]->()
RETURN path;
```

If Neo4j Browser shows old Assertion captions as `TRUE`, run `:style reset`
once and rerun the query. This clears the browser's cached caption choice;
Assertion nodes now have names such as `GOVERNED_BY → CTRL-PO-001`.

See [schema/visualization_queries.cypher](schema/visualization_queries.cypher)
for queries that show all node properties, relationship properties, assertions,
documents, BPMN activities, journeys, and variants.

## What is demonstrated

Two processes are loaded, each with a process definition, SOP, policy, BPMN
diagram, and observed journeys.

| Process | Markets | Owners | Controls | Systems | Live variants |
|---|---|---|---|---|---|
| `P2P-001` Procure to Pay | United States, Canada | Global Procurement Operations, Accounts Payable Operations | `CTRL-PO-001`, `CTRL-3WM-002` | Coupa, SAP S/4HANA | Straight-through, match exception |
| `O2C-001` Order to Cash | Germany, United Kingdom | Global Order Management, Accounts Receivable | `CTRL-CREDIT-001`, `CTRL-REVREC-003` | Salesforce, SAP S/4HANA | Straight-through, credit hold |

Example questions:

```text
Which markets does Procure to Pay operate in?
What controls govern Order to Cash?
Show the BPMN flow.
Which live variants occurred?
Which documents support this process?
Show the evidence lineage.
```

## The graph model

The process is the main business node:

```mermaid
flowchart LR
  P["Process"] -->|OPERATES_IN| M["Market"]
  P -->|OWNED_BY| BU["BusinessUnit"]
  P -->|GOVERNED_BY| C["Control"]
  P -->|USES_SYSTEM| S["System"]
  P -->|HAS_DOCUMENT| D["Document"]
  D -->|HAS_VERSION| V["DocumentVersion"]
  P -->|MODELED_BY| B["BPMNModel"]
  B -->|DEFINES_ACTIVITY| A["Activity"]
  A -->|NEXT_ACTIVITY| A2["Activity"]
  P -->|HAS_JOURNEY| J["Journey"]
  J -->|FOLLOWS_VARIANT| VR["Variant"]
```

The four extracted business relationships are deliberately fixed:

| Source | Relationship | Target | Plain meaning |
|---|---|---|---|
| Process | `OPERATES_IN` | Market | Where the process applies |
| Process | `OWNED_BY` | BusinessUnit | Which organizational unit is accountable |
| Process | `GOVERNED_BY` | Control | Which control requirements apply |
| Process | `USES_SYSTEM` | System | Which applications support the process |

For example:

```text
(Procure to Pay)-[:OPERATES_IN]->(United States)
(Procure to Pay)-[:OPERATES_IN]->(Canada)
(Order to Cash)-[:USES_SYSTEM]->(Salesforce)
(Order to Cash)-[:GOVERNED_BY]->(CTRL-CREDIT-001)
```

This makes questions predictable. “Which markets?” always traverses
`OPERATES_IN`; the system does not need to guess whether the source used
`ACTIVE_IN`, `AVAILABLE_AT`, `COUNTRY_SCOPE`, or another LLM-created synonym.

## Assertions and evidence

Direct business relationships are convenient for fast traversal, but an
enterprise system must also explain why a relationship exists. The graph
therefore includes a controlled `Assertion` claim layer:

```mermaid
flowchart LR
  A["Assertion<br/>predicate=OPERATES_IN"] -->|SUBJECT| P["Process"]
  A -->|OBJECT| M["Market: Canada"]
  A -->|EVIDENCED_BY| V["DocumentVersion"]
  A -. "supporting_chunk_ids property" .-> Q["Qdrant passage IDs"]
```

An assertion stores:

- a deterministic `assertion_id`;
- one of the four approved predicates;
- confidence, status, and the extracted evidence phrase;
- `supporting_chunk_ids`, a small list of stable Qdrant point IDs;
- links to the subject process, target entity, and source document version.

The direct `Process-[:OPERATES_IN]->Market` relationship is a materialized view
of active approved assertions. It includes `assertion_count` and maximum
confidence. When a document version changes, its old assertions are
superseded, and the materialized business edge is recalculated.

## Why chunks are not graph nodes

Chunks are still essential; they simply belong in Qdrant.

### Recommended design used here

Neo4j stores:

- processes and stable enterprise entities;
- documents and immutable document versions;
- BPMN models and activities;
- journeys and variants;
- governed assertions and evidence references.

Qdrant stores:

- chunk text;
- embedding vector;
- deterministic `chunk_id`;
- `process_id`, `document_id`, `document_version_id`;
- classification, section, offsets, hashes, and active status.

The join keys are `document_version_id` and `chunk_id`.

### Advantages

- The business graph stays readable and explainable.
- Millions of retrieval fragments do not dominate graph storage and traversal.
- Re-chunking or changing an embedding model does not redefine business data.
- Qdrant performs the task it is optimized for: vector similarity and payload
  filtering.
- Exact citations remain possible because assertions retain supporting IDs.
- Narrative chunks that do not express a graph relationship can still answer
  detailed questions.

### Trade-offs

- Evidence display performs a small cross-store join.
- Deleting or re-indexing vector points needs reconciliation safeguards.
- A chunk cannot be explored as a first-class Neo4j node.

Those trade-offs are handled by stable IDs, active-version filtering, immutable
versions, and `/v1/governance/reconciliation/{process_id}`.

### When graph chunk nodes can be reasonable

Chunk nodes may be appropriate when chunks themselves have a graph-domain role:
legal citation networks, paragraph-level review workflows, annotations shared by
many applications, or graph algorithms over passages. Even then, avoid storing
embeddings in Neo4j merely to duplicate the vector index. For enterprise process
intelligence, document-version provenance plus chunk-ID references is the
cleaner default.

## Ingestion flow

1. Validate file size and metadata.
2. Parse TXT, Markdown, PDF, DOCX, BPMN, or XML.
3. Calculate a content checksum and deterministic document-version ID.
4. Extract only Market, BusinessUnit, Control, and System entities.
5. Validate every relationship against ontology version 3.0.
6. Produce deterministic metadata/content chunks and embeddings.
7. Stage `Process`, `Document`, and `DocumentVersion` in Neo4j.
8. Upsert chunks and vectors in Qdrant with `active=false`.
9. Create assertion nodes and record supporting Qdrant chunk IDs.
10. Parse BPMN activities and sequence flows when applicable.
11. Activate the new graph version and its assertions.
12. Activate the matching Qdrant points and supersede the previous version.
13. Rebuild the four materialized process relationships from active assertions.

The workflow is idempotent by document ID and checksum. If the checksum has not
changed, ingestion is skipped. A compensating rollback restores the prior
version if activation fails across stores.

## How hybrid RAG answers a question

For “Which controls govern Procure to Pay?”:

1. The classifier maps the wording to fixed intent `controls`.
2. Neo4j finds active document versions accessible to the user.
3. Qdrant searches only chunks for those versions and that process.
4. A fixed, parameterized Cypher query traverses `GOVERNED_BY` and validates
   each result against active approved assertions.
5. The answer combines exact graph facts with top document passages.
6. Citations contain `document_id`, `document_version_id`, and `chunk_id`.
7. Clicking a citation retrieves the Qdrant text and its graph provenance.

This is hybrid retrieval, not two unrelated pipelines. The stores are connected
by stable identifiers and a governed active-version scope.

## Why a fixed ontology is better for this POC

An open extractor can produce labels such as `Region`, `Country`, `Geography`,
and `Location` for the same idea, plus relationships such as `LOCATED_IN`,
`APPLIES_TO`, or `OPERATES_WITHIN`. At enterprise scale this causes:

- duplicate entities and synonym proliferation;
- unpredictable queries;
- sparse, noisy relationships;
- harder access control and stewardship;
- inconsistent retrieval dimensions;
- answers that are difficult to explain or compare over time.

The constrained model provides stable semantics, validation, indexes, ownership,
and repeatable query plans. The POC includes
`POST /v1/demo/compare-open-ontology` to demonstrate the difference without
allowing open extraction into the governed graph.

## API

| Method | Path | Purpose |
|---|---|---|
| `GET` | `/health` | Graph/vector/provider status |
| `GET` | `/v1/processes` | UI process catalog |
| `POST` | `/v1/ingest/document` | Ingest a document plus metadata |
| `POST` | `/v1/ingest/journeys` | Ingest observed executions |
| `POST` | `/v1/chat` | Fixed-intent hybrid RAG |
| `GET` | `/v1/ontology` | Allowed labels and relationships |
| `GET` | `/v1/evidence/chunks/{chunk_id}` | Exact vector text plus graph lineage |
| `GET` | `/v1/graph/processes/{id}/visualization` | Bounded graph JSON for the UI |
| `GET` | `/v1/governance/reconciliation/{id}` | Cross-store integrity check |
| `GET` | `/v1/graph/query-catalog` | Reviewed Cypher catalog |
| `POST` | `/v1/demo/compare-open-ontology` | Safe constrained-vs-open comparison |

Example chat call:

```bash
curl -s http://localhost:8000/v1/chat \
  -H 'Content-Type: application/json' \
  -d '{
    "question": "Which markets does this process operate in?",
    "process_id": "P2P-001",
    "classification_clearance": "confidential",
    "top_k": 6
  }' | python -m json.tool
```

## Using an LLM

The POC works offline with deterministic metadata extraction and hash
embeddings. To use an OpenAI-compatible endpoint, set:

```dotenv
LLM_PROVIDER=openai
LLM_API_KEY=your-key
LLM_MODEL=your-approved-model
EMBEDDING_PROVIDER=openai
EMBEDDING_MODEL=your-approved-embedding-model
EMBEDDING_DIMENSIONS=1536
```

Then rebuild the API. Use an enterprise secret manager in production; do not
commit keys to `.env`.

The LLM output is schema-constrained and validated again in Python. The chat LLM
cannot define labels, relationships, or Cypher.

## Production considerations

The POC demonstrates the correct logical boundaries but production deployment
also needs:

- SSO/OIDC and claims-based process/document authorization;
- secrets management and TLS/mTLS;
- asynchronous ingestion workers and dead-letter handling;
- malware scanning and content validation;
- canonical entity registries and stewardship workflows;
- assertion approval thresholds and human review;
- Qdrant collection aliases or blue/green re-indexing;
- Neo4j/Qdrant backup, restore, monitoring, and capacity plans;
- prompt, model, ontology, and extraction-version audit fields;
- tenant partitioning when multiple legal entities share infrastructure.

More detail:

- [Architecture](docs/architecture.md)
- [Data model](docs/data-model.md)
- [Retrieval and governance](docs/retrieval-and-governance.md)
- [Operations and demonstration](docs/operations.md)
