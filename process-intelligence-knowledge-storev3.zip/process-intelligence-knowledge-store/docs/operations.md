# Operations and demonstration guide

## Start and load

```bash
cp .env.example .env
docker compose up --build -d
docker compose ps
python scripts/load_sample.py
curl -s http://localhost:8000/health | python -m json.tool
```

The loader submits eight documents and two journey batches:

- P2P process definition, SOP, policy, and BPMN;
- O2C process definition, SOP, policy, and BPMN;
- two observed P2P journeys;
- two observed O2C journeys.

Reloading unchanged files returns `skipped`.

## Five-minute demonstration

1. Open <http://localhost:8000/>.
2. Select **Procure to Pay**.
3. Ask “Which markets does this process operate in?”
4. Show the structured graph rows and cited passages.
5. Click a citation to show exact text, version lineage, and supported assertions.
6. Open **Explore the graph** and switch among Business overview, Evidence &
   assertions, BPMN & execution, and All process views.
7. Switch to **Order to Cash** and ask about credit controls or live variants.
8. Open Neo4j Browser and run the queries below.

The demo explains three different truths:

- design truth: BPMN;
- governance truth: SOP/policy assertions and relationships;
- execution truth: journeys and variants.

## Neo4j access

URL: <http://localhost:7474/browser/>

```text
Username: neo4j
Password: change-me-enterprise
```

Use a strong secret outside the local POC.

If Neo4j Browser previously remembered `active` as the caption for Assertion
nodes, run this browser command once and then rerun the Cypher:

```text
:style reset
```

Assertions now have human-readable names such as `OPERATES_IN → Canada`.

### All relationships

```cypher
MATCH path=(source)-[relationship]->(target)
RETURN path
LIMIT 500;
```

### All nodes, links, and properties

```cypher
MATCH (source)-[relationship]->(target)
RETURN labels(source), properties(source),
       type(relationship), properties(relationship),
       labels(target), properties(target)
LIMIT 500;
```

### Markets

```cypher
MATCH (p:Process)-[r:OPERATES_IN]->(m:Market)
RETURN p.process_id, p.name, type(r), properties(r), m.name, properties(m)
ORDER BY p.name, m.name;
```

The complete query catalog is
`schema/visualization_queries.cypher`.

## API smoke checks

```bash
curl -s http://localhost:8000/v1/processes | python -m json.tool
curl -s 'http://localhost:8000/v1/graph/processes/P2P-001/visualization?view=all&classification_clearance=confidential' | python -m json.tool
curl -s http://localhost:8000/v1/governance/reconciliation/P2P-001 | python -m json.tool
curl -s http://localhost:8000/v1/governance/reconciliation/O2C-001 | python -m json.tool
```

Chat:

```bash
curl -s http://localhost:8000/v1/chat \
  -H 'Content-Type: application/json' \
  -d '{"question":"What controls govern this process?","process_id":"O2C-001","classification_clearance":"confidential"}' \
  | python -m json.tool
```

## Tests

```bash
python -m pip install -e '.[dev]'
ruff check .
ruff format --check .
pytest
node --check ui/app.js
```

## Resetting the POC

This deletes the local demo Neo4j and Qdrant volumes:

```bash
docker compose down -v
docker compose up --build -d
python scripts/load_sample.py
```

Do not use volume deletion on an environment containing data that must be
retained.

## Backup and production runbooks

Before production, define and test:

- Neo4j and Qdrant backups with restore drills;
- ontology and schema migration steps;
- blue/green vector re-indexing;
- ingestion retry and poison-document handling;
- reconciliation alerts;
- identity/authorization outage behavior;
- model and embedding rollback;
- retention, legal hold, and data deletion;
- audit export for documents, assertions, and prompts.
