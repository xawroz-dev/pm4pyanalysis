from __future__ import annotations

import json
import os
import urllib.request
from pathlib import Path


def main() -> None:
    api_url = os.getenv("KG_API_URL", "http://localhost:8080").rstrip("/")
    sample_directory = Path(__file__).resolve().parents[1] / "sample_data"
    samples = (
        ("process-risk", sample_directory / "process-risk.json"),
        ("product-market", sample_directory / "product-market-catalog.json"),
        ("product-market", sample_directory / "product-market-regulatory.json"),
    )
    for graph_id, sample in samples:
        request = urllib.request.Request(  # noqa: S310 - operator-supplied local API URL
            f"{api_url}/v1/graphs/{graph_id}/ingestions",
            data=sample.read_bytes(),
            headers={"content-type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(request, timeout=30) as response:  # noqa: S310
            print(f"{graph_id} <- {sample.name}")
            print(json.dumps(json.load(response), indent=2))


if __name__ == "__main__":
    main()
