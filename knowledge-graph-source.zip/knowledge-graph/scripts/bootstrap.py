from __future__ import annotations

import sys
import time
from pathlib import Path

from enterprise_kg.infrastructure.spanner import bootstrap_spanner
from enterprise_kg.settings import get_settings


def main() -> None:
    settings = get_settings()
    schema = Path(__file__).resolve().parents[1] / "schema" / "001_initial.sql"
    last_error: Exception | None = None
    for attempt in range(1, 31):
        try:
            bootstrap_spanner(settings, schema)
            print("Spanner instance, database, and property graph are ready.")
            return
        except Exception as exc:  # bootstrap retries cover emulator startup races
            last_error = exc
            print(f"Bootstrap attempt {attempt}/30 failed: {type(exc).__name__}", file=sys.stderr)
            time.sleep(min(attempt, 5))
    raise RuntimeError("Spanner bootstrap failed after 30 attempts") from last_error


if __name__ == "__main__":
    main()
