from pathlib import Path

from enterprise_kg.config.loader import FileConfigRegistry
from enterprise_kg.settings import get_settings


def main() -> None:
    directory = Path(get_settings().config_directory)
    registry = FileConfigRegistry(directory)
    registry.load()
    for item in registry.list():
        print(f"VALID {item.config.config_key} sha256={item.checksum}")


if __name__ == "__main__":
    main()
