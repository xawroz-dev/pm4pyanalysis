from __future__ import annotations

import json
import os
import urllib.request


def post_json(url: str, payload: dict[str, object]) -> dict[str, object]:
    request = urllib.request.Request(  # noqa: S310 - operator-supplied local API URL
        url,
        data=json.dumps(payload).encode(),
        headers={"content-type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(request, timeout=30) as response:  # noqa: S310
        result = json.load(response)
        if not isinstance(result, dict):
            raise RuntimeError("unexpected API response")
        return result


def get_json(url: str) -> dict[str, object]:
    with urllib.request.urlopen(url, timeout=30) as response:  # noqa: S310
        result = json.load(response)
        if not isinstance(result, dict):
            raise RuntimeError("unexpected API response")
        return result


def main() -> None:
    api_url = os.getenv("KG_API_URL", "http://localhost:8080").rstrip("/")
    result = post_json(
        f"{api_url}/v1/graphs/process-risk/traversals",
        {
            "traversal": "process_risk_controls",
            "start_canonical_id": "PROC-1001",
        },
    )
    paths = result.get("paths")
    if not isinstance(paths, list) or len(paths) != 1:
        raise RuntimeError(f"expected exactly one process-risk-control path, got {paths!r}")
    names = [node["canonical_name"] for node in paths[0]["nodes"]]
    expected = [
        "Card Payment Authorization",
        "Unauthorized Card Transaction",
        "Real-Time Fraud Screening",
    ]
    if names != expected:
        raise RuntimeError(f"unexpected path: {names}")
    first_node = paths[0]["nodes"][0]
    first_edge = paths[0]["edges"][0]
    if first_node["metadata"]["owner"] != "Payments Operations":
        raise RuntimeError("node metadata was not returned")
    if first_edge["creation_details"]["review_status"] != "approved":
        raise RuntimeError("relationship creation audit was not returned")
    if not first_edge["selection_context"]:
        raise RuntimeError("relationship selection context was not returned")
    selected = post_json(
        f"{api_url}/v1/graphs/process-risk/nodes/search",
        {
            "entity_type": "Process",
            "metadata_equals": {
                "business_domain": "Payments",
                "attributes.region": "global",
            },
            "chunk_id": "chunk-sop-100-section-2",
        },
    )
    selected_nodes = selected.get("nodes")
    if not isinstance(selected_nodes, list) or [
        item["canonical_id"] for item in selected_nodes
    ] != ["PROC-1001"]:
        raise RuntimeError(f"metadata node selection failed: {selected_nodes!r}")
    chunk_result = get_json(
        f"{api_url}/v1/graphs/process-risk/chunks/chunk-riskreg-2026-q3-risk-3001/entities"
    )
    chunk_nodes = chunk_result.get("nodes")
    if not isinstance(chunk_nodes, list) or {item["canonical_id"] for item in chunk_nodes} != {
        "CTRL-4001",
        "RISK-3001",
    }:
        raise RuntimeError(f"chunk-to-entity lookup failed: {chunk_nodes!r}")
    print(json.dumps(result, indent=2))
    market_result = post_json(
        f"{api_url}/v1/graphs/product-market/traversals",
        {"traversal": "market_products", "start_canonical_id": "PROC-1001"},
    )
    market_paths = market_result.get("paths")
    if not isinstance(market_paths, list) or len(market_paths) != 1:
        raise RuntimeError(f"expected one isolated market-product path, got {market_paths!r}")
    market_names = [node["canonical_name"] for node in market_paths[0]["nodes"]]
    if market_names != ["United States Commercial Market", "Commercial Card"]:
        raise RuntimeError(f"unexpected isolated market path: {market_names}")

    regulation_result = post_json(
        f"{api_url}/v1/graphs/product-market/traversals",
        {"traversal": "product_regulations", "start_canonical_id": "PROD-9001"},
    )
    regulation_paths = regulation_result.get("paths")
    if not isinstance(regulation_paths, list) or len(regulation_paths) != 1:
        raise RuntimeError(
            f"expected one product-process-regulation path, got {regulation_paths!r}"
        )
    regulation_names = [node["canonical_name"] for node in regulation_paths[0]["nodes"]]
    if regulation_names != [
        "Commercial Card",
        "Commercial Card Issuance",
        "Payment Card Industry Data Security Standard",
    ]:
        raise RuntimeError(f"unexpected regulation path: {regulation_names}")
    print(json.dumps(market_result, indent=2))
    print(json.dumps(regulation_result, indent=2))
    print(
        "SMOKE TEST PASSED: generic graph creation, traversal, chunk lookup, "
        "provenance, and isolation"
    )


if __name__ == "__main__":
    main()
