-- Contract the graph element tables to a generic physical model after 002/backfill.
ALTER TABLE GraphNode ADD COLUMN chunk_ids ARRAY<STRING(512)>;
ALTER TABLE GraphEdge ADD COLUMN chunk_ids ARRAY<STRING(512)>;

CREATE TABLE GraphNodeChunk (
  chunk_id STRING(512) NOT NULL,
  node_id STRING(36) NOT NULL,
  CONSTRAINT FK_GraphNodeChunk_Node FOREIGN KEY (node_id)
    REFERENCES GraphNode (node_id)
) PRIMARY KEY (chunk_id, node_id);

CREATE INDEX IX_GraphNodeChunk_Node
ON GraphNodeChunk(node_id, chunk_id);

CREATE OR REPLACE PROPERTY GRAPH EnterpriseKnowledgeGraph
  NODE TABLES (
    GraphNode
      LABEL Entity
      PROPERTIES (node_id, metadata, properties, chunk_ids, updated_at)
      DYNAMIC PROPERTIES (properties)
  )
  EDGE TABLES (
    GraphEdge
      SOURCE KEY (source_node_id) REFERENCES GraphNode (node_id)
      DESTINATION KEY (target_node_id) REFERENCES GraphNode (node_id)
      LABEL Relationship
      PROPERTIES (
        edge_id, source_node_id, target_node_id, metadata, properties,
        chunk_ids, confidence, evidence_id, created_at
      )
      DYNAMIC PROPERTIES (properties)
  );

DROP INDEX UX_GraphNode_Canonical;
DROP INDEX IX_GraphNode_Browse;
DROP INDEX IX_GraphEdge_Forward;
DROP INDEX IX_GraphEdge_Reverse;

CREATE INDEX IX_GraphEdge_Forward ON GraphEdge(source_node_id, target_node_id);
CREATE INDEX IX_GraphEdge_Reverse ON GraphEdge(target_node_id, source_node_id);

ALTER TABLE GraphNode DROP COLUMN namespace;
ALTER TABLE GraphNode DROP COLUMN graph_id;
ALTER TABLE GraphNode DROP COLUMN entity_type;
ALTER TABLE GraphNode DROP COLUMN canonical_id;
ALTER TABLE GraphNode DROP COLUMN canonical_name;
ALTER TABLE GraphNode DROP COLUMN aliases;
ALTER TABLE GraphNode DROP COLUMN business_domain;
ALTER TABLE GraphNode DROP COLUMN source_system;
ALTER TABLE GraphNode DROP COLUMN owner;
ALTER TABLE GraphNode DROP COLUMN security_classification;
ALTER TABLE GraphNode DROP COLUMN status;
ALTER TABLE GraphNode DROP COLUMN tags;
ALTER TABLE GraphNode DROP COLUMN effective_from;
ALTER TABLE GraphNode DROP COLUMN effective_to;
ALTER TABLE GraphNode DROP COLUMN config_version;

ALTER TABLE GraphEdge DROP COLUMN namespace;
ALTER TABLE GraphEdge DROP COLUMN graph_id;
ALTER TABLE GraphEdge DROP COLUMN relationship_type;
ALTER TABLE GraphEdge DROP COLUMN relationship_description;
ALTER TABLE GraphEdge DROP COLUMN rationale;
ALTER TABLE GraphEdge DROP COLUMN selection_context;
ALTER TABLE GraphEdge DROP COLUMN business_domain;
ALTER TABLE GraphEdge DROP COLUMN source_system;
ALTER TABLE GraphEdge DROP COLUMN owner;
ALTER TABLE GraphEdge DROP COLUMN security_classification;
ALTER TABLE GraphEdge DROP COLUMN status;
ALTER TABLE GraphEdge DROP COLUMN tags;
ALTER TABLE GraphEdge DROP COLUMN effective_from;
ALTER TABLE GraphEdge DROP COLUMN effective_to;
ALTER TABLE GraphEdge DROP COLUMN creation_details;
ALTER TABLE GraphEdge DROP COLUMN config_version;
