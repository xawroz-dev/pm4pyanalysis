CREATE TABLE GraphNode (
  node_id STRING(36) NOT NULL,
  metadata JSON NOT NULL,
  properties JSON NOT NULL,
  chunk_ids ARRAY<STRING(512)> NOT NULL,
  updated_at TIMESTAMP NOT NULL
) PRIMARY KEY (node_id);

CREATE TABLE GraphNodeChunk (
  chunk_id STRING(512) NOT NULL,
  node_id STRING(36) NOT NULL,
  CONSTRAINT FK_GraphNodeChunk_Node FOREIGN KEY (node_id)
    REFERENCES GraphNode (node_id)
) PRIMARY KEY (chunk_id, node_id);

CREATE INDEX IX_GraphNodeChunk_Node
ON GraphNodeChunk(node_id, chunk_id);

CREATE TABLE GraphEdge (
  edge_id STRING(36) NOT NULL,
  source_node_id STRING(36) NOT NULL,
  target_node_id STRING(36) NOT NULL,
  metadata JSON NOT NULL,
  properties JSON NOT NULL,
  chunk_ids ARRAY<STRING(512)> NOT NULL,
  confidence FLOAT64 NOT NULL,
  evidence_id STRING(64) NOT NULL,
  created_at TIMESTAMP NOT NULL,
  CONSTRAINT FK_GraphEdge_Source FOREIGN KEY (source_node_id)
    REFERENCES GraphNode (node_id),
  CONSTRAINT FK_GraphEdge_Target FOREIGN KEY (target_node_id)
    REFERENCES GraphNode (node_id),
  CONSTRAINT CK_GraphEdge_Confidence CHECK (confidence >= 0 AND confidence <= 1)
) PRIMARY KEY (edge_id);

CREATE INDEX IX_GraphEdge_Forward
ON GraphEdge(source_node_id, target_node_id);

CREATE INDEX IX_GraphEdge_Reverse
ON GraphEdge(target_node_id, source_node_id);

CREATE TABLE GraphEvidence (
  evidence_id STRING(64) NOT NULL,
  subject_id STRING(64) NOT NULL,
  subject_kind STRING(32) NOT NULL,
  namespace STRING(63) NOT NULL,
  graph_id STRING(63) NOT NULL,
  confidence FLOAT64 NOT NULL,
  provenance JSON NOT NULL,
  created_at TIMESTAMP NOT NULL,
  CONSTRAINT CK_GraphEvidence_Confidence CHECK (confidence >= 0 AND confidence <= 1)
) PRIMARY KEY (evidence_id);

CREATE INDEX IX_GraphEvidence_Subject
ON GraphEvidence(namespace, graph_id, subject_id);

CREATE TABLE IngestionBatch (
  namespace STRING(63) NOT NULL,
  graph_id STRING(63) NOT NULL,
  idempotency_key STRING(256) NOT NULL,
  config_version STRING(32) NOT NULL,
  nodes_upserted INT64 NOT NULL,
  edges_upserted INT64 NOT NULL,
  evidence_upserted INT64 NOT NULL,
  committed_at TIMESTAMP NOT NULL OPTIONS (allow_commit_timestamp=true)
) PRIMARY KEY (namespace, graph_id, idempotency_key);

CREATE TABLE GraphConfigRegistry (
  namespace STRING(63) NOT NULL,
  graph_id STRING(63) NOT NULL,
  config_version STRING(32) NOT NULL,
  checksum STRING(64) NOT NULL,
  status STRING(32) NOT NULL,
  activated_at TIMESTAMP OPTIONS (allow_commit_timestamp=true),
  activated_by STRING(256)
) PRIMARY KEY (namespace, graph_id, config_version);

CREATE PROPERTY GRAPH EnterpriseKnowledgeGraph
  NODE TABLES (
    GraphNode
      LABEL Entity
      PROPERTIES (
        node_id, metadata, properties, chunk_ids, updated_at
      )
      DYNAMIC PROPERTIES (properties)
  )
  EDGE TABLES (
    GraphEdge
      SOURCE KEY (source_node_id) REFERENCES GraphNode (node_id)
      DESTINATION KEY (target_node_id) REFERENCES GraphNode (node_id)
      LABEL Relationship
      PROPERTIES (
        edge_id, source_node_id, target_node_id, metadata, properties,
        chunk_ids, confidence, evidence_id, created_at
      )
      DYNAMIC PROPERTIES (properties)
  );
