-- Upgrade for databases created with 001 before element metadata became first class.
-- Columns are nullable during this expand phase so existing rows remain readable for backfill.
ALTER TABLE GraphNode ADD COLUMN business_domain STRING(200);
ALTER TABLE GraphNode ADD COLUMN source_system STRING(200);
ALTER TABLE GraphNode ADD COLUMN owner STRING(200);
ALTER TABLE GraphNode ADD COLUMN security_classification STRING(32);
ALTER TABLE GraphNode ADD COLUMN status STRING(32);
ALTER TABLE GraphNode ADD COLUMN tags ARRAY<STRING(200)>;
ALTER TABLE GraphNode ADD COLUMN effective_from TIMESTAMP;
ALTER TABLE GraphNode ADD COLUMN effective_to TIMESTAMP;
ALTER TABLE GraphNode ADD COLUMN metadata JSON;

ALTER TABLE GraphEdge ADD COLUMN relationship_description STRING(MAX);
ALTER TABLE GraphEdge ADD COLUMN rationale STRING(MAX);
ALTER TABLE GraphEdge ADD COLUMN selection_context ARRAY<STRING(1000)>;
ALTER TABLE GraphEdge ADD COLUMN business_domain STRING(200);
ALTER TABLE GraphEdge ADD COLUMN source_system STRING(200);
ALTER TABLE GraphEdge ADD COLUMN owner STRING(200);
ALTER TABLE GraphEdge ADD COLUMN security_classification STRING(32);
ALTER TABLE GraphEdge ADD COLUMN status STRING(32);
ALTER TABLE GraphEdge ADD COLUMN tags ARRAY<STRING(200)>;
ALTER TABLE GraphEdge ADD COLUMN effective_from TIMESTAMP;
ALTER TABLE GraphEdge ADD COLUMN effective_to TIMESTAMP;
ALTER TABLE GraphEdge ADD COLUMN metadata JSON;
ALTER TABLE GraphEdge ADD COLUMN creation_details JSON;

CREATE OR REPLACE PROPERTY GRAPH EnterpriseKnowledgeGraph
  NODE TABLES (
    GraphNode
      LABEL Entity
      PROPERTIES (
        node_id, namespace, graph_id, entity_type, canonical_id,
        canonical_name, aliases, business_domain, source_system, owner,
        security_classification, status, tags, effective_from, effective_to,
        properties, metadata, config_version, updated_at
      )
      DYNAMIC LABEL (entity_type)
      DYNAMIC PROPERTIES (properties)
  )
  EDGE TABLES (
    GraphEdge
      SOURCE KEY (source_node_id) REFERENCES GraphNode (node_id)
      DESTINATION KEY (target_node_id) REFERENCES GraphNode (node_id)
      LABEL Relationship
      PROPERTIES (
        edge_id, namespace, graph_id, relationship_type, source_node_id,
        target_node_id, relationship_description, rationale, selection_context,
        business_domain, source_system, owner, security_classification, status,
        tags, effective_from, effective_to, properties, metadata, creation_details,
        confidence, evidence_id, config_version, created_at
      )
      DYNAMIC LABEL (relationship_type)
      DYNAMIC PROPERTIES (properties)
  );
