# Documentation hub

This documentation describes the implemented enterprise knowledge graph kernel, its operating
model, and the production capabilities that remain integration boundaries.

If you want one document instead of an audience-specific path, read the
[complete plain-language explanation](detailed-explanation.md).

## Choose a path

| Audience | Start here | Then read |
|---|---|---|
| First-time reader | [Detailed explanation](detailed-explanation.md) | Choose a focused guide below |
| Domain team onboarding a graph | [Team onboarding](team-onboarding.md) | [Configuration](configuration.md), [API](api.md) |
| Platform or solution architect | [Architecture](architecture.md) | [Data model](data-model.md), [Spanner Graph fit](spanner-graph-fit.md) |
| RAG/AI engineer | [GraphRAG](graphrag.md) | [API](api.md), [Data model](data-model.md) |
| Security reviewer | [Security](security.md) | [Architecture](architecture.md), [Operations](operations.md) |
| SRE/operator | [Operations](operations.md) | [Testing](testing.md), [Security](security.md) |
| Contributor | [README](../README.md) | [Testing](testing.md), decision records below |

## System documentation

- [Architecture and design](architecture.md): boundaries, flows, identity, governance, retrieval,
  and scaling.
- [Generic physical data model](data-model.md): exact Spanner tables, metadata layout, chunk
  lineage, and schema tradeoffs.
- [HTTP API reference](api.md): endpoints, authorization, requests, responses, and error model.
- [GraphRAG integration](graphrag.md): chunk-first retrieval, graph expansion, provenance, and the
  vector/full-text roadmap.
- [Spanner Graph platform fit](spanner-graph-fit.md): why Spanner fits, where the application adds
  value, and what must be benchmarked.

## Delivery documentation

- [Team onboarding](team-onboarding.md): define, validate, ingest, retrieve, test, and promote a
  new domain without Python or DDL changes.
- [Configuration authoring](configuration.md): complete configuration contract and versioning
  rules.
- [Testing and demonstration](testing.md): unit, emulator, HTTP smoke, and pre-production tests.
- [Production operations](operations.md): rollout, observability, recovery, migration, and
  troubleshooting.
- [Security and threat model](security.md): trust boundaries, isolation, injection resistance,
  and data handling.

## Architecture decision records

- [ADR-0001: Generic physical graph model](decisions/0001-generic-physical-graph.md)
- [ADR-0002: Chunk-to-entity lineage](decisions/0002-chunk-entity-lineage.md)

## Implementation status legend

Documentation uses these terms deliberately:

| Term | Meaning |
|---|---|
| Implemented | Present in source, exercised by automated tests. |
| Reference boundary | Interface or schema exists, but an enterprise service must be connected. |
| Recommended | Production practice not automatically provisioned by this repository. |
| Future option | Candidate capability requiring design review, benchmark, and rollout approval. |

The source code and executable tests are authoritative when prose and behavior diverge. Fix both in
the same change.
