# Generic physical data model

## Design objective

Any team can define its own entity types, relationship types, typed domain properties, and JSON
metadata without creating a table or changing the Spanner property graph. The platform uses a
stable physical model and moves ontology enforcement into reviewed configuration and application
validation.

## Physical schema

```mermaid
erDiagram
    GraphNode ||--o{ GraphNodeChunk : "associated with"
    GraphNode ||--o{ GraphEdge : "source"
    GraphNode ||--o{ GraphEdge : "destination"
    GraphEvidence }o--|| GraphNode : "supports entity assertion"
    GraphEvidence }o--|| GraphEdge : "supports relationship assertion"

    GraphNode {
        string node_id PK
        json metadata
        json properties
        string_array chunk_ids
        timestamp updated_at
    }
    GraphNodeChunk {
        string chunk_id PK
        string node_id PK
    }
    GraphEdge {
        string edge_id PK
        string source_node_id FK
        string target_node_id FK
        json metadata
        json properties
        string_array chunk_ids
        float confidence
        string evidence_id
        timestamp created_at
    }
```

The evidence relationships in this diagram are conceptual: `GraphEvidence.subject_id` points to
an assertion ID, but no polymorphic foreign key is declared. The exact executable DDL is
[schema/001_initial.sql](../schema/001_initial.sql).

### Why `metadata` and `properties` are separate

- `properties` are ontology facts declared and type-checked by team configuration. Spanner exposes
  them as dynamic graph properties.
- `metadata` is arbitrary contextual JSON owned by the team, plus a protected platform envelope.
- `chunk_ids` is explicit because reverse RAG lookup is a primary access pattern, not an incidental
  metadata scan.
- IDs, endpoints, confidence, evidence, and timestamps remain columns because they are graph or
  transaction mechanics.

## Metadata layout

Teams can submit any JSON-compatible keys except `_system`:

```json
{
  "portfolio": "commercial-cards",
  "assessment_ref": "RA-2026-44",
  "applicability": {
    "jurisdiction": "global",
    "data_category": "cardholder-data"
  }
}
```

The repository adds a reserved envelope before persistence:

```json
{
  "portfolio": "commercial-cards",
  "assessment_ref": "RA-2026-44",
  "_system": {
    "node_id": "01d2d01e-2f33-5ae4-b9d7-46b7dc52299f",
    "namespace": "commercial-strategy",
    "graph_id": "product-market",
    "entity_type": "Product",
    "canonical_id": "PROD-9001",
    "canonical_name": "Commercial Card",
    "aliases": ["Business Card"],
    "config_version": "1.0.0"
  }
}
```

Relationship `_system` metadata contains `relationship_type`, `description`, `rationale`,
`selection_context`, `creation_details`, graph scope, and configuration version. API responses
remove `_system` and return identity/explanation fields in their typed response locations.

## Identity and isolation

Node IDs are deterministic UUIDv5 values over:

```text
namespace + graph_id + entity_type + normalized canonical_id
```

This prevents the same canonical text in two configured graphs from resolving to the same physical
node. Every Graph SQL path variable is also filtered by `_system.namespace` and
`_system.graph_id`.

This design deliberately does not put graph scope in the node/edge primary key, following the
requirement for minimal generic graph-element columns. Therefore, direct database writers could
bypass application isolation. Production must grant graph mutations only to the validated writer
service. If policy requires database-enforced tenant separation, use separate databases/projects
or adopt a reviewed composite-key variant.

## Chunk lineage

Each entity or relationship may carry up to 100 chunk IDs. When the same canonical node is asserted
from another source, chunk IDs are accumulated rather than overwritten. Node associations are
written to both `GraphNode.chunk_ids` and the chunk-first `GraphNodeChunk` table in the same
transaction.

```mermaid
flowchart LR
    C["Retrieved chunk ID"] --> L["GraphNodeChunk lookup"]
    L --> N1["Entity A"]
    L --> N2["Entity B"]
    N1 --> T["Approved traversal"]
    N2 --> T
    T --> E["Evidence-backed graph context"]
```

The array makes lineage visible on returned elements; the association table avoids scanning every
node for the reverse lookup.

## Relationship assertion identity

An edge ID includes relationship type, source/target node IDs, and an evidence fingerprint. Two
documents can assert the same semantic relationship without overwriting each other. This preserves
independent evidence, disagreement, confidence, and creation audit.

## Generic-model tradeoffs

| Benefit | Cost and mitigation |
|---|---|
| New teams require no DDL | Ontology enforcement must remain mandatory in the runtime. |
| Arbitrary metadata shapes | Unbounded ad hoc JSON filters can scan; cap results and promote proven hot paths deliberately. |
| One graph runtime and deployment | Writer IAM becomes a critical isolation boundary. |
| Multi-type paths avoid many physical tables | Strong per-property database typing is replaced by config validation. |
| Chunk lineage is source-agnostic | Chunk lifecycle and deletion must be reconciled with the document index. |

Do not add a shared physical column because one team requests it. Promote a field only after
cross-domain reuse, query-plan evidence, and a backward-compatible migration justify the coupling.
