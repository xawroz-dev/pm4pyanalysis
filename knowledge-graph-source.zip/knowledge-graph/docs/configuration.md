# Graph configuration authoring guide

## Start with questions

Write the business questions first. Include only entities and relationships necessary to answer those questions. The sample `process-risk.yaml` shows how a question about process risks and controls becomes:

```text
Process -[EXPOSED_TO]-> Risk <-[MITIGATES]- Control
```

## Required sections

| Section | Responsibility |
|---|---|
| `metadata` | Stable graph ID, namespace, semantic version, owner, classification. |
| `questions` | Intended business outcomes and scope guardrails. |
| `ontology.entities` | Names, descriptions, identifiers, aliases, and typed properties. |
| `ontology.relationships` | Directed allowlist with exact source and target types. |
| `sources` | Accepted source types/formats and extraction scope. |
| `resolution` | Authoritative IDs and automatic/manual match thresholds. |
| `retrieval` | Named, bounded traversal plans exposed by the API. |
| `governance` | Provenance, confidence, review, and role requirements. |

Entity names use PascalCase, relationships use uppercase snake case, and property/traversal names use lowercase snake case. Graph IDs and namespaces use lowercase kebab case. Versions use `major.minor.patch`.

## Change classification

| Change | Typical version | Treatment |
|---|---|---|
| Description, tag, new optional traversal | patch | Revalidate and activate. |
| Add entity, relationship, optional property | minor | Additive rollout and ingestion backfill. |
| Identifier change, relationship direction change, type narrowing/removal | major | Migration, dual-read, reconciliation, and rollback plan. |

Never reuse a version with different bytes. The SHA-256 checksum is part of validation output and should be stored in the production registry.

## Validation

```bash
.venv/bin/python scripts/validate_configs.py
```

Validation rejects duplicate names, unresolved entity references, invalid identifiers, undefined source extraction types, invalid resolution fields, traversals that exceed configured depth, and hops whose direction/type does not match the ontology.

Runtime validation additionally rejects unconfigured facts and properties, wrong property value types, relationship endpoint mismatches, and confidence below governance thresholds.

## Generic ingestion metadata

Ontology `properties` contain typed domain facts declared in team configuration. The separate
`metadata` object is deliberately generic JSON. Teams may choose unrelated keys and nested shapes;
the process-risk and product-market samples demonstrate different metadata vocabularies.

The only reserved key is `_system`. The platform creates it internally to persist isolation,
identity, configured type, version, and relationship explanation data inside the same JSON column.
Ingestion rejects a team-supplied `_system` value. Each node and relationship may also provide up
to 100 `chunk_ids`, which are deduplicated and accumulated for source lineage.

Every relationship still requires `description`, `rationale`, at least one `selection_context`
statement, and `creation_details`. These are serialized into `_system` rather than dedicated table
columns. Rule-created edges require `rule_id`; LLM-created edges require `model_id` and
`prompt_version`; reviewed edges require `reviewed_by`. The creation method must match provenance
`extraction_method`. See `sample_data/` for full valid payloads.

Use metadata for context that helps selection or interpretation but is not a shared platform
mechanic. Prefer stable, documented keys; avoid copying entire documents, credentials, or rapidly
changing derived scores. Keep ontology properties for domain facts that must be type-checked.

Example team-owned metadata:

```yaml
metadata:
  portfolio: commercial-cards
  applicability:
    jurisdiction: global
    customer_segment: enterprise
  extraction_tags: [policy, authorization]
chunk_ids:
  - chunk-sop-100-section-2
```

Relationship explanations should be useful independently:

```yaml
description: Real-time fraud screening mitigates unauthorized transaction risk.
rationale: The screening rule blocks high-risk authorization attempts before approval.
selection_context:
  - Select when explaining preventive controls for card authorization risk.
creation_details:
  method: rule
  generator: risk-register-importer
  pipeline_run_id: run-2026-08-16-001
  rule_id: relationship-map-v3
  created_by: service:kg-extractor
  created_at: 2026-08-16T12:00:00Z
  review_status: approved
  reviewed_by: user:risk-steward
```

The request `canonical_id` must equal the configured identifier property value. When an entity declares multiple identifier fields, join their values in declared order with `|`. This keeps canonical UUID generation deterministic across connectors.

## Shared ontology imports

`ontology.imports` records the shared definitions a team claims to reuse. In this reference kernel, complete effective definitions are checked into each graph artifact for deterministic runtime validation. A production configuration compiler should resolve imports from a signed, versioned enterprise ontology catalog and produce the same self-contained effective artifact.

For the complete delivery workflow, use the [team onboarding guide](team-onboarding.md).
