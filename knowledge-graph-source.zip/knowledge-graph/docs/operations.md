# Production operations runbook

## Local startup

```bash
docker compose up --build -d --wait
docker compose ps
curl -fsS http://localhost:8080/health/ready
```

`/health/live` proves only that the process is serving. `/health/ready` executes `SELECT 1` against Spanner. Neither proves that a particular graph fact is present; use the smoke traversal for that.

## Production deployment sequence

1. Validate and sign the configuration artifact; record its checksum.
2. Apply backward-compatible DDL through a dedicated migration identity.
3. Deploy the runtime with no configuration activation change.
4. Run schema and traversal contract tests against staging.
5. Activate one graph version with compare-and-set and audit metadata.
6. Canary ingestion for one namespace and reconcile source/entity/edge/evidence counts.
7. Enable reads, monitor latency/error/confidence/review metrics, then expand.
8. Keep the prior config addressable until backfill and query parity are verified.

## Generic element schema rollout

Fresh databases use the minimal generic schema in `schema/001_initial.sql`. Migrations 002 and 003
exist only for databases created by earlier revisions of this project. Contracting a non-empty
legacy database is intentionally not automatic: bootstrap stops and directs the operator here.

For a legacy database, first expand the schema, serialize every removed node/edge field into the
reserved `_system` JSON object, populate `chunk_ids` and `GraphNodeChunk`, and reconcile counts.
Only then run the reviewed 003 contract DDL. This prevents column removal before the data has a
verified JSON representation and rollback artifact.

## Observability

The API emits JSON request logs with request IDs and returns `x-request-id`. Add OpenTelemetry traces and metrics in the production distribution. Minimum dashboards/alerts:

- requests, latency, saturation, 4xx/5xx, and Spanner abort/retry rates;
- ingestion backlog age, batches, facts accepted/rejected/reviewed, and dead letters;
- nodes/edges/evidence per graph and source version, orphan attempts, duplicate rates;
- traversal latency/results by configured intent, empty-result anomalies, query budgets;
- configuration validation failures, activations, rollback events, and drift checks.

Never log document contents, tokens, credentials, or confidential graph properties.

### Suggested service objectives

Set targets from measured business demand rather than copying placeholder numbers. At minimum,
define separate SLOs for ingestion acceptance, chunk/entity lookup, approved traversal latency,
configuration availability, and evidence retrieval. Track both service latency and semantic
correctness indicators such as empty-result rate, rejected facts, unresolved entities, stale
source versions, and evidence coverage.

### Reconciliation jobs

Run graph-scoped checks on a schedule and after every backfill:

- each edge endpoint resolves to a node in the same protected graph scope;
- each edge and entity assertion resolves to evidence in the same namespace/graph;
- `GraphNode.chunk_ids` and `GraphNodeChunk` contain the same node associations;
- active configuration checksum matches the promoted artifact;
- counts by source/version match the connector manifest;
- no rejected-review relationships are exposed to retrieval.

Alert on drift; do not automatically delete or merge facts during reconciliation.

## Recovery and replay

Use durable source versions and stable idempotency keys. On partial worker failure, replay the message; the Spanner transaction either commits graph facts and the batch ledger together or commits neither. Route poison records to a dead-letter topic with validation issues and correlation IDs.

The emulator has no persistence. Production backup/PITR, restore verification, regional recovery, RPO, and RTO must be configured and exercised according to enterprise policy.

## Capacity and query management

- Benchmark expected graph shapes and data distributions on a non-production Spanner instance.
- Record query plans for every configured traversal before activation.
- Apply per-request deadlines, result limits, maximum hops, and per-graph quotas.
- Review JSON metadata filters from telemetry; promote only proven hot access paths to indexes or
  generated projections.
- Load-test concurrent ingestion and traversal, including transaction abort/retry behavior.
- Requalify emulator and client-library versions before changing pinned dependencies.

## Rollback

- Runtime: roll back to the previous compatible image.
- Config: reactivate the previous version; do not edit an activated artifact in place.
- Ingestion: stop the affected namespace consumer, reconcile batch IDs, and replay after correction.
- Schema: prefer expand/contract. Do not drop old columns/tables until all old readers are retired and backups verified.

## Production readiness gate

Do not expose production traffic until IAM, durable configuration activation, audit export,
backups/restore tests, dashboards/alerts, source reconciliation, load tests, and a rollback drill
have named owners and recorded evidence. The emulator smoke test proves functional compatibility;
it is not this gate.

## Emulator troubleshooting

- `UNAUTHENTICATED`: confirm `SPANNER_EMULATOR_HOST=localhost:9010` on the host or `spanner:9010` inside Compose.
- Empty state after restart: expected; the emulator is in-memory. Run the bootstrap and sample load again.
- Transaction aborts: keep writes inside retrying transaction runners and avoid concurrent schema changes.
- API ready but traversal empty: readiness is not data verification. Reload the sample and inspect the ingestion response.
