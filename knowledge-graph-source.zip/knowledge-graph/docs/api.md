# HTTP API reference

## Conventions

- Base URL: `http://localhost:8080` locally.
- Bodies use JSON and reject unknown fields.
- Graph operations resolve an active configuration and authorize against its allowed roles.
- Production uses trusted identity headers supplied by an authenticated gateway; see
  [security.md](security.md).
- The service returns `x-request-id` and structured error bodies.

## Endpoint summary

| Method and path | Purpose |
|---|---|
| `GET /health/live` | Process liveness only. |
| `GET /health/ready` | Spanner connectivity check. |
| `GET /v1/configurations` | List configurations visible to the principal. |
| `POST /v1/configurations/validate` | Validate a YAML document and return its identity/checksum. |
| `POST /v1/configurations/{graph_id}/versions/{version}/activate` | Activate a loaded version in the current registry process. |
| `POST /v1/graphs/{graph_id}/ingestions` | Atomically validate and write facts/evidence. |
| `POST /v1/graphs/{graph_id}/nodes/search` | Select nodes with safe generic filters. |
| `GET /v1/graphs/{graph_id}/chunks/{chunk_id}/entities` | Resolve a retrieved chunk to entities. |
| `POST /v1/graphs/{graph_id}/traversals` | Execute a configured bounded graph path. |
| `GET /v1/graphs/{graph_id}/evidence/{evidence_id}` | Retrieve exact provenance. |

Interactive OpenAPI documentation is exposed at `/docs` outside production.

The reference registry loads configuration files at startup and activation is in-process. The
activation endpoint is useful for local/runtime contract testing, but it is not a durable
multi-replica promotion control plane. Production must persist compare-and-set state and audit the
principal/checksum; see [architecture](architecture.md#configuration-lifecycle).

## Ingest graph facts

```http
POST /v1/graphs/process-risk/ingestions
Content-Type: application/json
```

Use the complete executable payload in
[sample_data/process-risk.json](../sample_data/process-risk.json). Important rules:

- The idempotency key represents source version plus transformation version.
- Entity and relationship types/endpoints must exist in configuration.
- Entity properties must match the configured identifier and property schema.
- Metadata may be arbitrary JSON, but `_system` is reserved.
- Relationship creation method must match provenance extraction method.
- Rule and LLM creation methods require their reproducibility details.

Successful response:

```json
{
  "graph_id": "process-risk",
  "namespace": "payments",
  "config_version": "1.0.0",
  "idempotency_key": "process-risk-generic-demo-v1",
  "nodes_upserted": 5,
  "edges_upserted": 4,
  "evidence_upserted": 9,
  "replayed": false
}
```

Repeating the same key returns the recorded counts with `replayed: true`.

## Search nodes

```http
POST /v1/graphs/process-risk/nodes/search
Content-Type: application/json
```

```json
{
  "entity_type": "Process",
  "name_prefix": "Card",
  "metadata_equals": {
    "business_domain": "Payments",
    "attributes.region": "global"
  },
  "chunk_id": "chunk-sop-100-section-2",
  "limit": 20
}
```

All filters are optional and combined with AND. `metadata_equals` supports at most 20 validated
dotted paths and scalar string, number, or boolean values. It does not accept JSONPath or SQL.

## Resolve a chunk to entities

```http
GET /v1/graphs/process-risk/chunks/chunk-riskreg-2026-q3-risk-3001/entities
```

The result is graph-scoped and returns at most 1,000 associated nodes. This endpoint is designed to
follow vector or full-text retrieval of a chunk.

## Execute an approved traversal

```http
POST /v1/graphs/process-risk/traversals
Content-Type: application/json
```

```json
{
  "traversal": "process_risk_controls",
  "start_canonical_id": "PROC-1001",
  "limit": 25
}
```

The traversal name selects a path compiled from reviewed configuration. User input never becomes
Graph SQL syntax. Each returned node includes team metadata and chunk IDs; each edge includes
description, rationale, selection context, creation details, confidence, chunk IDs, and evidence ID.

## Retrieve evidence

```http
GET /v1/graphs/process-risk/evidence/{evidence_id}
```

The response identifies the subject, source URI, source version, exact locator, extraction method,
observation time, optional content hash, and confidence.

## Error model

Domain errors have a stable machine code and human-readable message:

```json
{
  "code": "graph_fact_invalid",
  "message": "relationship type is not allowed: UNKNOWN",
  "field": null
}
```

| Status | Typical code | Meaning |
|---|---|---|
| `401` | framework authentication response | Missing trusted production identity. |
| `403` | framework authorization response | Principal lacks an allowed graph role. |
| `404` | `configuration_not_found` or `not_found` | Graph version or evidence does not exist in scope. |
| `422` | `configuration_invalid` | Configuration artifact failed semantic validation. |
| `422` | `graph_fact_invalid` | Ingestion or traversal violated the active contract. |
| `503` | readiness/infrastructure response | Spanner is unavailable. |

Client retry policy should retry transient infrastructure failures with jitter, but should not
retry validation or authorization failures unchanged.
