# Test and demonstration guide

## Test pyramid

1. Unit tests validate configuration semantics, canonicalization, property/type gates, relationship direction, idempotency, namespace isolation, approved traversal behavior, and API error mapping against the in-memory adapter.
2. The integration test creates a unique emulator database, applies the real DDL, writes the payment sample, executes Graph SQL, and verifies the returned path.
3. The Compose smoke test exercises the container image, bootstrap service, HTTP ingestion, Spanner transaction, property graph, HTTP retrieval, and evidence-bearing response.

## Commands

```bash
make install
make verify
```

For the real graph path:

```bash
docker compose up --build -d --wait
python3 scripts/load_sample.py
python3 scripts/smoke_test.py
```

## Verification matrix

| Concern | Unit | Emulator integration | HTTP smoke | Production qualification |
|---|:---:|:---:|:---:|:---:|
| Configuration and payload validation | Yes | Yes | Yes | Yes |
| Idempotent transaction behavior | Yes | Yes | Yes | Yes |
| Real DDL and Graph SQL | No | Yes | Yes | Yes |
| Nested metadata and chunk lookup | Yes | Yes | Yes | Yes |
| Cross-graph isolation | Yes | Yes | Yes | Yes |
| Container/startup wiring | No | No | Yes | Yes |
| IAM, TLS, audit, backup/restore | No | No | No | Yes |
| Query plans, capacity, latency, failover | No | No | No | Yes |

To inspect Graph SQL directly, configure `gcloud` for the emulator or run the application traversal API. The application path is preferred because it also proves config selection and namespace filters.

## Expected idempotency behavior

The process-risk batch reports five nodes, four edges, and nine evidence assertions. The two product-market source batches separately load catalog and regulatory facts. Repeating any payload with its original idempotency key reports the same counts and `replayed: true`. Changing facts while reusing an old key is an upstream contract error; production publishers should generate a stable key from source version plus transformation version.

The smoke and emulator integration tests also verify that arbitrary node metadata, relationship
descriptions, selection context, review details, chunk IDs, and provenance survive the full
Spanner Graph round trip. They exercise nested metadata filtering and chunk-to-entity lookup.

Example selection request:

```json
{
  "entity_type": "Process",
  "metadata_equals": {
    "business_domain": "Payments",
    "attributes.region": "global"
  },
  "chunk_id": "chunk-sop-100-section-2",
  "limit": 20
}
```

Send it to `POST /v1/graphs/process-risk/nodes/search`, then use a returned `canonical_id` as the
starting node for a configured traversal.

For the reverse RAG flow, call
`GET /v1/graphs/process-risk/chunks/chunk-riskreg-2026-q3-risk-3001/entities`.

## Adding a team graph

Every new graph should add at least one valid sample, one invalid-contract test, one approved-path
assertion, a colliding canonical ID isolation case, nested metadata selection, shared-chunk reverse
lookup, evidence verification, and replay verification. See [team onboarding](team-onboarding.md).

## What the emulator does not prove

- Production latency, capacity, partitioning, query plans, or quotas.
- IAM, fine-grained access, TLS, audit logs, backups, or monitoring.
- Multi-region failure behavior or recovery objectives.
- Compatibility of every production feature and error message.

Run pre-production contract, load, chaos, security, and restore tests against a non-production Enterprise-edition Spanner instance before release.
