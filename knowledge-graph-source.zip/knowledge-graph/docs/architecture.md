# Architecture and design decisions

## Design goals

The platform is optimized for organizational scalability: many domain teams share one engineering core while retaining independent graph identity, namespace, version, and lifecycle. It favors reviewed graph semantics and explainable facts over unrestricted LLM-created labels or queries.

## Layering

```text
HTTP / batch adapters
        |
Application services
        |
Domain contracts + graph config
        |
Repository port
   |             |
Memory tests   Spanner Graph
```

Dependencies point inward. The graph service knows the repository protocol, not the Google client. Spanner-specific mutation formats, parameter types, transactions, and Graph SQL decoding stay in the infrastructure adapter.

## System context

```mermaid
flowchart TB
    Team["Domain team"] --> Config["Reviewed YAML configuration"]
    Sources["Source connectors / extraction workers"] --> API["Knowledge graph API"]
    Client["Application or GraphRAG orchestrator"] --> API
    Gateway["Identity-aware gateway"] --> API
    Config --> Registry["Configuration registry"]
    Registry --> API
    API --> Validator["Validation, identity, and traversal services"]
    Validator --> Repo["Repository port"]
    Repo --> Spanner["Spanner tables + property graph"]
    Spanner --> API
    API --> Client
```

The repository implements the API, file-backed configuration registry, domain validation,
Spanner adapter, schema, emulator workflow, and executable samples. Identity gateways, source
connectors, extraction/embedding workers, durable configuration promotion, and answer generation
are explicit enterprise integration boundaries.

## Storage model

Spanner Graph maps relational input tables into graph elements. This implementation uses:

| Object | Purpose |
|---|---|
| `GraphNode` | Technical node ID, generic JSON metadata/properties, chunk IDs, and update timestamp. |
| `GraphNodeChunk` | Reverse index from a retrieved chunk ID to all associated nodes. |
| `GraphEdge` | Technical endpoints, generic JSON metadata/properties, chunk IDs, confidence, evidence ID, and timestamp. |
| `GraphEvidence` | Source URI, document version, locator, extraction method, timestamp, hash, and confidence. |
| `IngestionBatch` | Idempotency ledger committed atomically with graph mutations. |
| `GraphConfigRegistry` | Production-facing schema for configuration promotion state. |
| `EnterpriseKnowledgeGraph` | Property graph with stable `Entity`/`Relationship` labels and dynamic JSON-backed properties. |

The property graph uses stable `Entity` and `Relationship` labels. Entity and relationship types
are stored inside generic metadata and checked against each team's configuration. Domain
properties remain dynamic JSON properties. A team can therefore introduce completely different
entity types, relationship types, properties, and metadata keys without a DDL change or new Python
model.

The physical metadata document has one reserved `_system` object containing graph isolation,
configured type, canonical identity, display name, aliases, configuration version, and universal
relationship explanation fields. All other root keys belong to the team and can contain any
JSON-compatible structure. The API removes `_system` before returning team metadata and rejects
attempts to provide that reserved key during ingestion.

Relationships additionally store three different explanations because they serve different jobs:

- `description` states what the connection means in plain language.
- `rationale` explains why the assertion is justified.
- `selection_context` tells retrieval systems when this edge is the useful one to choose.

`creation_details` records method, generator, pipeline run, rule or model details, actor, time, and
review outcome. `GraphEvidence.provenance` independently identifies the source material and exact
locator. Keeping both distinguishes how a fact was produced from what source supports it.

`chunk_ids` are stored on both nodes and edges. Node associations are also written atomically to
`GraphNodeChunk`, whose chunk-first primary key supports the reverse RAG flow:

```text
retrieved chunk -> GraphNodeChunk -> associated entities -> approved graph traversal
```

## Identity and deduplication

Node IDs are UUIDv5 values derived from:

```text
namespace + graph_id + entity_type + normalized canonical_id
```

This provides deterministic retries and prevents identical text identifiers in different domains from colliding. Authoritative identifier selection is declared per entity in configuration. Fuzzy/semantic matching should be added as an asynchronous candidate-review service; it should never silently merge entities below the configured automatic threshold.

Edges include the source/target IDs, relationship type, and an evidence fingerprint. Two documents can therefore assert the same relationship without overwriting one another. Retrieval may return both facts, preserving disagreement and independent lineage.

## Ingestion transaction

1. Resolve the requested active configuration version.
2. Validate entity and relationship allowlists.
3. Validate relationship endpoints and configured properties/types.
4. Apply minimum confidence and manual-review gates.
5. Generate deterministic node and evidence identifiers.
6. In one Spanner read/write transaction, check the idempotency ledger, upsert nodes/edges/evidence, and insert the batch record.
7. On retry with the same key, return the recorded counts with `replayed=true`.

Spanner and its emulator can abort concurrent transactions; the client library transaction runner supplies retry behavior. A production ingestion worker should additionally use a durable queue, bounded attempts, and a dead-letter topic.

## Retrieval safety

The public API accepts a traversal name and starting canonical ID, not Graph SQL. The traversal name selects a reviewed path in the active graph configuration. The compiler emits syntax only from validated enum-like metadata and binds all runtime values as Spanner parameters.

The node-search endpoint follows the same rule: it accepts validated dotted metadata paths with
scalar equality values and a hard result cap. It never accepts query fragments. This lets clients
select the right starting node before executing an approved traversal.

Every query filters all nodes and edges by both `namespace` and `graph_id`. Stable base labels (`Entity`, `Relationship`) avoid interpolating team labels into query syntax. Configuration validation proves each hop matches a declared relationship direction and target type.

This is intentionally different from allowing an LLM to generate arbitrary Graph SQL. Natural-language routing can be added later, but it should select from approved traversal intents and never bypass authorization or query limits.

## Configuration lifecycle

Files in this repository model the reviewed artifact. A production registry should implement:

```text
DRAFT -> VALIDATED -> SECURITY_REVIEWED -> ACTIVE -> DEPRECATED
```

Activation must be compare-and-set, audited, and scoped to a graph ID. Additive changes can typically coexist on the generic physical schema. Breaking meaning, identifier, direction, or property-type changes require an explicit migration plan, dual-read period, and rollback target.

The current reference registry loads versioned YAML files and keeps activation state in process.
`GraphConfigRegistry` is provisioned as the production persistence contract, but the application
does not yet write activation state to that table. A production control plane must implement the
durable compare-and-set and audit behavior above before multi-replica deployment.

## Scaling path

- Partition ingestion by namespace and graph ID.
- Use uniformly distributed UUID node keys to avoid monotonic hotspots.
- Keep forward and reverse relationship indexes aligned with common traversal directions.
- Add Spanner JSON search indexes or a configuration-generated projection only for metadata paths proven hot in production; keep the shared base schema generic.
- Apply query budgets, result caps, deadlines, and per-namespace quotas.
- Test query plans and production data distributions on real Spanner; emulator timing is not representative.
- Separate extraction, entity-resolution review, graph writes, and RAG indexing into independently scalable workers.

## RAG integration boundary

Graph relationships provide topology; a vector store provides document similarity. Preserve a common evidence/chunk identifier so a hybrid answer can union graph-edge evidence with vector results without replacing either set. The answer contract should expose source title, version, locator, and evidence ID separately from generated prose.

See [GraphRAG integration](graphrag.md) for the implemented chunk-first flow and
[ADR-0002](decisions/0002-chunk-entity-lineage.md) for the lineage decision.
