# GraphRAG integration guide

## Goal

Use semantic or keyword retrieval to find relevant source chunks, map those chunks to governed
entities, expand through approved graph paths, and return evidence-backed context to an answer
model. Vector similarity and graph topology solve different retrieval problems; neither replaces
the other.

## Implemented retrieval flow

```mermaid
sequenceDiagram
    participant Client
    participant Retriever as "Vector/full-text retriever"
    participant KG as "Knowledge graph API"
    participant Spanner
    participant Model as "Answer model"

    Client->>Retriever: user question
    Retriever-->>Client: ranked chunk IDs
    Client->>KG: GET chunk/{chunk_id}/entities
    KG->>Spanner: GraphNodeChunk lookup in graph scope
    Spanner-->>KG: associated entities + metadata
    KG-->>Client: canonical entities
    Client->>KG: POST configured traversal
    KG->>Spanner: parameterized Graph SQL
    Spanner-->>KG: paths + evidence IDs
    KG-->>Client: governed graph context
    Client->>KG: GET evidence/{evidence_id}
    Client->>Model: chunks + graph paths + citations
```

The repository implements the knowledge graph calls and chunk lineage. It does not yet implement
embedding generation, vector indexing, full-text indexing, reranking, or answer generation.

## Recommended answer context

Keep machine-verifiable fields separate from generated prose:

```json
{
  "retrieved_chunks": [
    {"chunk_id": "chunk-riskreg-2026-q3-risk-3001", "score": 0.91}
  ],
  "entities": [
    {"canonical_id": "RISK-3001", "entity_type": "Risk"}
  ],
  "paths": [
    {
      "relationship_type": "MITIGATES",
      "evidence_id": "...",
      "confidence": 0.98
    }
  ],
  "citations": [
    {"document_uri": "gs://...", "version": "2026.3", "locator": "record RISK-3001"}
  ]
}
```

The answer model may summarize this context but must not invent graph facts, remove provenance, or
upgrade a relationship's confidence.

## Retrieval policy

1. Apply caller authorization and classification filters before exposing chunks or graph facts.
2. Resolve the top ranked chunk IDs to entities within one graph scope.
3. Deduplicate entities by deterministic node ID.
4. Choose only a configured traversal intent; never generate free-form Graph SQL.
5. Enforce hop/result/token budgets.
6. Retrieve evidence for every relationship included in the final answer.
7. Rerank using chunk score, path relevance, relationship confidence, and review status.
8. Return an explicit “insufficient evidence” result when support is weak or contradictory.

## Future Spanner-native option

Spanner can combine relational, graph, vector, and full-text capabilities. A future production
design may add `Document` and `Chunk` tables, embeddings/search indexes, and a relational-to-graph
query pipeline in the same database. Treat that as a qualified option, not implemented behavior.

Before adopting it:

- benchmark vector/full-text recall, latency, cost, and update patterns on representative data;
- decide whether chunks are graph nodes or remain relational records linked through IDs;
- validate index availability and edition/region constraints;
- define embedding versioning and reindex procedures;
- test authorization filtering before nearest-neighbor or text ranking;
- preserve the current chunk ID and evidence contracts so retrieval engines remain replaceable.

Official references:

- [Vector search with Spanner Graph](https://cloud.google.com/spanner/docs/graph/perform-vector-similarity-search)
- [Full-text search with Spanner Graph](https://cloud.google.com/spanner/docs/graph/full-text-search-and-graph)
- [Graphs within SQL](https://cloud.google.com/spanner/docs/reference/standard-sql/graph-sql-queries)
