# Enterprise Knowledge Graph: detailed explanation

This document explains the complete platform in one place. It is written for engineers, domain
teams, architects, and operators who need to understand how the system works without reading the
source code first.

## 1. What this project solves

Different teams want to create different knowledge graphs:

- a risk team may use `Process`, `Risk`, and `Control`;
- a product team may use `Market`, `Product`, and `Regulation`;
- another team may introduce `Vendor`, `Application`, or any other concept.

The platform must support those teams without adding a Python model, Spanner table, or deployment
for every new entity and relationship type.

The solution separates two concerns:

1. A stable shared platform stores and queries graph data.
2. Versioned YAML configuration defines each team's logical graph.

This provides flexibility without accepting uncontrolled data or arbitrary graph queries.

## 2. The design in one diagram

```mermaid
flowchart TD
    Config["Team YAML configuration"] --> Validation["Configuration and fact validation"]
    Source["Source documents or extraction pipeline"] --> Ingestion["Ingestion API"]
    Validation --> Ingestion
    Ingestion --> Identity["Deterministic identity and deduplication"]
    Identity --> Transaction["Atomic Spanner transaction"]
    Transaction --> Tables["Generic node, edge, evidence, and chunk tables"]
    Tables --> Graph["Spanner property graph"]
    Chunk["Retrieved chunk ID"] --> Lookup["Chunk-to-entity lookup"]
    Lookup --> Graph
    Client["Application or GraphRAG service"] --> Chunk
    Client --> Traversal["Approved traversal API"]
    Traversal --> Graph
    Graph --> Result["Entities, relationships, metadata, and evidence"]
    Result --> Client
```

## 3. Stable physical model, dynamic logical model

The physical Spanner model stays small and generic:

| Table | Purpose |
|---|---|
| `GraphNode` | Stores any kind of entity. |
| `GraphEdge` | Stores any kind of relationship. |
| `GraphNodeChunk` | Finds entities associated with a retrieved chunk. |
| `GraphEvidence` | Stores the source and extraction provenance for assertions. |
| `IngestionBatch` | Makes ingestion retry-safe and idempotent. |
| `GraphConfigRegistry` | Defines the persistence contract for production configuration promotion. |

The graph has two stable base labels:

- `Entity` for nodes;
- `Relationship` for edges.

Team-specific types such as `Process`, `Product`, `MITIGATES`, or `GOVERNS` are stored in protected
metadata and validated against the selected configuration. A new team therefore does not require
a new label or property-graph definition.

## 4. What is stored on a node

A node request contains generic identity fields, configured properties, arbitrary metadata, chunk
links, confidence, and provenance:

```json
{
  "entity_type": "Process",
  "canonical_id": "PROC-1001",
  "canonical_name": "Card Payment Authorization",
  "aliases": ["Card Authorization"],
  "properties": {
    "process_id": "PROC-1001",
    "criticality": "HIGH"
  },
  "metadata": {
    "portfolio": "commercial-cards",
    "attributes": {
      "region": "global"
    }
  },
  "chunk_ids": ["chunk-sop-100-section-2"],
  "confidence": 0.99,
  "provenance": {
    "source_id": "SOP-100",
    "document_uri": "gs://knowledge/sop-100.pdf",
    "document_version": "4.2",
    "locator": "section 2",
    "extraction_method": "import",
    "observed_at": "2026-08-16T12:00:00Z"
  }
}
```

The distinction between `properties` and `metadata` is simple:

- `properties` are domain facts declared and type-checked in the team's configuration;
- `metadata` is flexible team-owned context that can help select or understand the node.

The team may use any JSON metadata shape except the reserved `_system` key. The platform creates
`_system` internally to hold graph scope, entity type, canonical identity, aliases, and
configuration version. API responses hide this envelope and return the important fields normally.

## 5. What is stored on a relationship

A relationship is not only a source node, a target node, and a type. It also explains what the
relationship means, why it exists, when it should be selected, and how it was created.

```json
{
  "relationship_type": "MITIGATES",
  "source_entity_type": "Control",
  "source_canonical_id": "CTRL-4001",
  "target_entity_type": "Risk",
  "target_canonical_id": "RISK-3001",
  "description": "Real-time screening mitigates unauthorized transaction risk.",
  "rationale": "The control blocks high-risk authorization attempts before approval.",
  "selection_context": [
    "Use when explaining preventive controls for card authorization risk."
  ],
  "metadata": {
    "control_owner": "fraud-platform",
    "applicability": "real-time-authorization"
  },
  "chunk_ids": ["chunk-riskreg-2026-q3-risk-3001"],
  "creation_details": {
    "method": "rule",
    "generator": "risk-register-importer",
    "pipeline_run_id": "run-2026-08-16-001",
    "rule_id": "relationship-map-v3",
    "created_by": "service:kg-extractor",
    "created_at": "2026-08-16T12:00:00Z",
    "review_status": "approved",
    "reviewed_by": "user:risk-steward"
  },
  "confidence": 0.98,
  "provenance": {
    "source_id": "RISKREG-2026-Q3",
    "document_uri": "gs://knowledge/risk-register.json",
    "document_version": "2026.3",
    "locator": "record RISK-3001",
    "extraction_method": "rule",
    "observed_at": "2026-08-16T12:00:00Z"
  }
}
```

The explanation fields have different purposes:

| Field | Meaning |
|---|---|
| `description` | What the relationship means in plain language. |
| `rationale` | Why the relationship is supported. |
| `selection_context` | When a retrieval system should choose this relationship. |
| `creation_details` | Which person, rule, model, or pipeline created and reviewed it. |
| `provenance` | Which source material supports the assertion. |

## 6. How teams define their graph

Each YAML configuration declares:

- graph identity, namespace, owner, version, and classification;
- business questions the graph is intended to answer;
- entity types and their identifier rules;
- allowed directed relationships and endpoints;
- typed domain properties;
- accepted source types;
- entity-resolution thresholds;
- named traversal paths and limits;
- confidence, review, and access rules.

A simplified logical definition looks like this:

```yaml
ontology:
  entities:
    - name: Process
    - name: Risk
    - name: Control
  relationships:
    - name: EXPOSED_TO
      source: Process
      target: Risk
    - name: MITIGATES
      source: Control
      target: Risk
```

The complete executable examples are
[`process-risk.yaml`](../configs/process-risk.yaml) and
[`product-market.yaml`](../configs/product-market.yaml).

The runtime rejects facts that do not match the configuration. For example, it rejects
`Process -[MITIGATES]-> Market` when that relationship and endpoint pair are not declared.

## 7. Identity, retries, and duplicate prevention

Node IDs are deterministic UUIDv5 values generated from:

```text
namespace + graph_id + entity_type + normalized canonical_id
```

The same logical entity in the same graph receives the same node ID on every retry. An identical
canonical ID in another graph receives a different node ID.

Edge identity also includes its source, target, relationship type, and evidence fingerprint. Two
independent sources may therefore assert the same relationship without overwriting one another.

Every ingestion request includes an idempotency key. Nodes, edges, evidence, chunk links, and the
batch ledger are committed in one transaction. Repeating a committed key returns `replayed: true`
instead of creating duplicate facts.

## 8. Why chunk IDs are first-class

RAG retrieval normally finds a text chunk first. Graph traversal normally starts from an entity.
The platform connects these two workflows:

```text
retrieved chunk
    -> associated entities
    -> approved graph traversal
    -> relationships and neighboring entities
    -> evidence-backed answer context
```

Chunk IDs are stored on nodes and relationships for visible lineage. Node links are also written
to `GraphNodeChunk`, whose key begins with `chunk_id`, so reverse lookup does not scan every node.

When another source asserts an existing canonical node, its chunk IDs are accumulated rather than
replacing earlier associations.

## 9. Retrieval APIs

### Select a starting node

```http
POST /v1/graphs/process-risk/nodes/search
```

```json
{
  "entity_type": "Process",
  "metadata_equals": {
    "attributes.region": "global"
  },
  "chunk_id": "chunk-sop-100-section-2",
  "limit": 20
}
```

Metadata filtering accepts validated dotted paths and scalar equality values. It does not accept
SQL, JSONPath, or Graph SQL fragments.

### Resolve a retrieved chunk

```http
GET /v1/graphs/process-risk/chunks/chunk-riskreg-2026-q3-risk-3001/entities
```

### Traverse the graph

```http
POST /v1/graphs/process-risk/traversals
```

```json
{
  "traversal": "process_risk_controls",
  "start_canonical_id": "PROC-1001",
  "limit": 25
}
```

Clients select a reviewed traversal name. They cannot submit arbitrary Graph SQL. The runtime
compiles the configured path and binds runtime values as Spanner parameters.

### Retrieve evidence

```http
GET /v1/graphs/process-risk/evidence/{evidence_id}
```

See the [complete API reference](api.md) for every endpoint and error response.

## 10. Security and isolation

Every API operation resolves the graph configuration and checks the caller's role. Every query
filters the protected namespace and graph ID.

The minimal generic schema deliberately does not put graph scope in node and edge primary keys.
Consequently, production must allow graph mutations only through the validated writer service. A
direct database writer could otherwise bypass application validation and isolation.

For hard regulatory or tenant boundaries, use one of these stronger deployment patterns:

- separate Spanner databases or projects;
- separate runtime identities and network boundaries;
- a reviewed schema variant with graph scope in composite primary and foreign keys.

Chunk IDs are locators, not permissions. The API must authorize graph facts, chunks, and evidence
using caller identity and data classification.

## 11. What is implemented now

- FastAPI ingestion, node search, chunk lookup, traversal, evidence, configuration, and health
  endpoints.
- Strict YAML and request validation.
- Generic Spanner node/edge schema and property graph.
- Deterministic IDs, idempotent atomic ingestion, and provenance.
- Arbitrary metadata and typed configured properties.
- Detailed relationship explanations and creation audit.
- Chunk-to-entity lineage.
- Parameterized approved traversals.
- In-memory unit tests, Spanner emulator integration test, and HTTP smoke scripts.
- Two intentionally different team examples.

## 12. What remains an enterprise integration

The following are deliberately not presented as finished capabilities:

- authenticated API gateway and organization IAM integration;
- durable, audited, multi-replica configuration promotion;
- production source connectors and extraction workers;
- embedding generation, vector/full-text indexing, reranking, and answer generation;
- metrics/tracing backend, security event export, and enterprise alerting;
- production backups, restore drills, capacity tests, and disaster recovery;
- human entity-resolution and relationship-review workflow.

Spanner vector search, full-text search, SQL views, and graph algorithms are future options. They
should be benchmarked and reviewed before being added.

## 13. Run and verify locally

```bash
cp .env.example .env
docker compose up --build -d --wait
python3 scripts/load_sample.py
python3 scripts/smoke_test.py
```

The service is available at `http://localhost:8080`, with interactive API documentation at
`http://localhost:8080/docs`.

Run the host-side quality suite with:

```bash
make install
make verify
```

The emulator proves schema, transaction, and Graph SQL compatibility. It does not prove production
performance, IAM, backups, or multi-region behavior.

## 14. Adding a new team

The shortest safe onboarding flow is:

1. Define the business questions and required graph paths.
2. Add a versioned YAML configuration.
3. Validate the configuration.
4. Add representative sample data with evidence and chunk IDs.
5. Add tests for ingestion, isolation, traversal, chunk lookup, and replay.
6. Run the emulator and HTTP smoke path.
7. Complete security, data-owner, capacity, and rollback review.
8. Promote the immutable configuration version.

Team-specific concepts belong in configuration and data. They should not require shared runtime
or DDL changes.

## 15. Further detail

- [Documentation hub](index.md)
- [Architecture](architecture.md)
- [Physical data model](data-model.md)
- [Configuration authoring](configuration.md)
- [GraphRAG integration](graphrag.md)
- [Team onboarding](team-onboarding.md)
- [Security](security.md)
- [Operations](operations.md)
- [Testing](testing.md)
- [Spanner Graph fit and official references](spanner-graph-fit.md)

