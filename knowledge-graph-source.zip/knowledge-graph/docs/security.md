# Security and threat model

## Trust boundaries

The local Compose stack deliberately has no authentication because the Spanner emulator does not implement IAM or TLS. Do not expose it to an untrusted network.

Production requests should arrive through an authenticated service mesh or API gateway that validates workload/user identity and passes a tamper-resistant principal. Map that principal to graph roles and enforce the configured role set before configuration activation, ingestion, traversal, or evidence reads.

Set `KG_AUTH_MODE=trusted_headers` in production. The trusted gateway supplies `x-kg-principal` and comma-separated `x-kg-roles`; the service fails startup if production authentication is disabled. Strip any client-supplied copies of those headers at the gateway. Role suffixes define reader, writer, and administrator access, and every operation checks the active graph's configured allowlist.

## Required production controls

- Use workload identity/service accounts; do not distribute service-account keys.
- Grant separate reader, writer, configuration-promoter, and operator roles.
- Authorize on namespace and graph ID at every API and repository operation.
- Keep raw documents outside graph properties; store governed URIs and source locators.
- Classify evidence and prevent a lower-cleared answer from citing higher-classified facts.
- Encrypt in transit and at rest, use customer-managed keys where policy requires, and define key rotation.
- Put source credentials and provider keys in a secrets manager, never YAML or graph records.
- Emit immutable audit events for config validation/activation, ingestion source/version, manual entity merges, retrieval principal, and evidence access.
- Apply request size, rate, query depth, result, and transaction-mutation limits.
- Scan images/dependencies and generate an SBOM in the release pipeline.

## Threats and controls

| Threat | Implemented control | Production reinforcement |
|---|---|---|
| Cross-graph reads | Deterministic scoped IDs and namespace/graph filters on repository queries | Restrict direct database readers; use separate databases/projects for hard boundaries |
| Cross-graph writes | Runtime resolves the active graph config and validates every fact | Grant mutation IAM only to the validated writer service |
| Query injection | No free-form GQL; reviewed traversals and bound parameters | Review configuration promotion and cap execution budgets |
| Metadata escape | `_system` is rejected from client metadata; filter paths use a strict grammar | Add payload classification/DLP checks at ingestion |
| Evidence disclosure | Evidence lookup is graph-scoped and role-authorized | Apply document-level clearance and audit every read |
| Resource exhaustion | Request models cap metadata filters, chunk IDs, paths, and results | Add gateway quotas, deadlines, Spanner budgets, and tenant rate limits |
| Fact fabrication | Provenance, confidence, and relationship creation details are mandatory | Require human review where policy or confidence gates demand it |

## Injection resistance

The API does not expose free-form GQL. Traversal syntax comes from configuration that passes strict naming and topology validation. Request values use Spanner parameters. Graph/namespace filters are emitted for every node and edge in a path.

If natural-language query routing is added, the model may choose only an approved traversal name and typed arguments. Never execute model-authored Graph SQL or use model output as an authorization decision.

## Cross-team isolation

Logical isolation uses namespace plus graph ID in deterministic node IDs, validated writes,
evidence access, metadata search, chunk lookup, and every Graph SQL path variable. Graph scope is
stored in the protected `_system` metadata envelope rather than in `GraphNode`/`GraphEdge` primary
keys, so the database does not independently enforce that scope for direct writers.

Production must deny direct graph mutations and grant write IAM only to the validated application
identity. For stricter regulatory boundaries, deploy separate databases, instances, projects, or
VPCs per classification/tenant, or adopt a reviewed composite-key schema variant while keeping the
same runtime and configuration contract. See [the data-model tradeoff](data-model.md#identity-and-isolation).

## Metadata and chunk handling

Arbitrary metadata increases the need for classification policy. Reject secrets, credentials,
raw restricted documents, and uncontrolled personal data before ingestion. A chunk ID is a
locator, not an authorization token: chunk-to-entity results and evidence must be authorized using
the graph and source classification. Deletion and retention workflows must reconcile source
documents, retrieval indexes, `GraphNode.chunk_ids`, `GraphEdge.chunk_ids`, and
`GraphNodeChunk` associations.

## Data deletion

Entity deletion can affect shared relationship evidence and legal holds. Implement it as an auditable workflow: discover affected edges/evidence, enforce retention policy, tombstone first, reconcile downstream RAG indexes, then purge with approved authorization. This reference does not expose a destructive delete API.
