# ADR-0001: Use a generic physical graph model

- Status: Accepted
- Date: 2026-08-16

## Context

Independent teams must introduce different entities, relationships, properties, and metadata
without coordinating Spanner DDL or runtime releases. Strongly typed per-concept tables would make
the physical schema an organization-wide bottleneck.

## Decision

Use stable generic `GraphNode` and `GraphEdge` tables, static base graph labels, dynamic JSON
properties, and a protected `_system` metadata envelope. Enforce ontology types, endpoints,
properties, identity, traversal shape, confidence, and review policy in versioned configuration and
the shared runtime.

## Consequences

- Teams onboard without DDL or Python changes.
- Multi-domain facts share one execution engine while remaining logically scoped.
- JSON metadata filters require careful budgets and measured indexing decisions.
- Runtime validation and writer IAM are mandatory security/correctness boundaries.
- Database-enforced graph-scope keys remain an optional stricter deployment variant.

## Revisit when

A shared property becomes a proven cross-domain hot path, policy mandates database-enforced tenant
keys, or representative benchmarks show generic JSON cannot meet an approved SLO.
