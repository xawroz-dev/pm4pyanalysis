# ADR-0002: Persist chunk-to-entity lineage

- Status: Accepted
- Date: 2026-08-16

## Context

GraphRAG starts from retrieved document chunks, while graph traversal starts from canonical
entities. The platform needs a deterministic, graph-scoped bridge between those retrieval modes.
Scanning arbitrary metadata for chunk IDs would not provide a scalable reverse access path.

## Decision

Store deduplicated `chunk_ids` on nodes and edges for transparent lineage. Also persist node links
in `GraphNodeChunk` with primary key `(chunk_id, node_id)`. Accumulate links when independent
sources assert the same canonical node. Write nodes, links, edges, evidence, and idempotency records
in one Spanner transaction.

## Consequences

- A retrieved chunk can resolve directly to every associated entity.
- Returned graph elements expose their source-chunk lineage.
- Shared canonical nodes preserve chunk associations across source updates.
- Chunk deletion/reindex workflows must reconcile both the retrieval index and graph links.
- A future `Chunk` table or graph node can be added without changing the public chunk ID contract.

## Revisit when

Chunk cardinality regularly exceeds request limits, chunk lifecycle requires temporal versioning,
or the organization adopts a centralized document/chunk registry with stronger referential needs.
