# Team onboarding guide

## Outcome

A team adds a governed logical graph without changing the shared Python runtime, Spanner tables,
or property graph definition.

## 1. Define business questions

Start with decisions the graph must support, not a list of available source fields. Example:

```text
Which vendors supply systems used by a critical process?
Which controls mitigate risks introduced by those vendors?
```

Turn each question into a bounded path before defining the ontology.

## 2. Create the configuration

Copy one file in `configs/` and choose a unique graph ID and namespace. Define:

- entities and authoritative identifier properties;
- directed relationship endpoint pairs;
- typed domain properties;
- accepted sources and required source metadata;
- entity-resolution thresholds;
- named retrieval traversals and limits;
- confidence/review policy and allowed roles.

Teams may use arbitrary JSON metadata. Metadata vocabulary should be documented by the owning team,
but it does not require shared platform schema changes.

## 3. Validate locally

```bash
.venv/bin/python scripts/validate_configs.py
.venv/bin/pytest -m 'not integration'
```

Add negative tests for invalid endpoints, missing identifiers, unconfigured properties, and
unauthorized traversal shapes.

## 4. Create representative sample data

Add an executable payload under `sample_data/` that includes:

- at least one complete business path;
- provenance with a stable source/version/locator;
- arbitrary team metadata, including a nested object;
- chunk IDs shared by multiple entities where a source chunk mentions both;
- relationship description, rationale, selection context, and creation audit;
- a stable idempotency key derived from source and transformation versions.

Do not use production secrets or regulated source text in repository samples.

## 5. Add contract tests

Test these invariants:

1. Ingestion counts and idempotent replay.
2. Canonical ID and endpoint validation.
3. At least one approved traversal.
4. Namespace isolation using a colliding canonical ID from another graph.
5. Nested metadata selection.
6. Chunk-to-entity reverse lookup.
7. Evidence retrieval.

## 6. Run the real Spanner path

```bash
docker compose up --build -d --wait
python3 scripts/load_sample.py
python3 scripts/smoke_test.py
```

The emulator validates schema and query compatibility, not production performance or IAM.

## 7. Review and promote

Production promotion should follow:

```text
DRAFT -> VALIDATED -> SECURITY_REVIEWED -> ACTIVE -> DEPRECATED
```

Required review evidence:

- configuration checksum and semantic version;
- ontology owner and data steward approval;
- source authorization and classification mapping;
- sample reconciliation counts;
- query-plan/load evidence for expected scale;
- rollback version and backfill plan;
- dashboards, alerts, and runbook ownership.

## Definition of done

- No shared runtime or DDL change was needed for team-specific concepts.
- Every graph fact is source-backed and scoped.
- Every public query path is configured and bounded.
- Same-key replay is safe and duplicate-free.
- Chunk lookup can recover the entities used for GraphRAG expansion.
- The team owns configuration lifecycle, source quality, and semantic correctness.
