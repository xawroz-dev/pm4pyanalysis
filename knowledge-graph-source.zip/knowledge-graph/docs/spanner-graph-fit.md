# Spanner Graph platform fit

## Decision summary

Spanner Graph is a strong execution and persistence engine for this platform when enterprise scale,
transactional graph writes, relational interoperability, multi-hop traversal, and a Google Cloud
operating model matter. It is not the configuration-driven platform by itself; ontology,
validation, lifecycle, source mapping, and retrieval policy remain application responsibilities.

## Responsibility split

| Platform control plane | Spanner execution plane |
|---|---|
| Team configuration and versioning | Node/edge persistence |
| Ontology and endpoint validation | Transactional consistency |
| Source and extraction contracts | Property graph execution |
| Entity identity/resolution policy | Pattern matching and traversal |
| Confidence and review gates | Relational/graph interoperability |
| Authorization orchestration | Scale and availability primitives |
| Approved traversal catalog | Optional vector/full-text capabilities |
| Provenance and answer policy | Query/index execution |

The platform's differentiating capability is the left column. Spanner is replaceable only behind
the repository port, while configuration semantics remain stable.

## Why the generic model fits

The requirements favor a stable physical schema with a dynamic logical ontology. A table per
business concept would couple every team to DDL and deployment coordination. Generic node/edge
tables let Process, Risk, Market, Product, Regulation, Vendor, or future concepts coexist while the
configuration validator retains semantic control.

The implementation uses static `Entity` and `Relationship` graph labels plus JSON-backed metadata
and dynamic properties. This is a deliberate schemaless-physical/schematized-logical hybrid.

## Fit assessment

| Requirement | Assessment | Condition |
|---|---|---|
| Many independent teams | Strong | Enforce graph scope in every write/query and restrict direct writers. |
| Config-driven ontology | Strong | Keep validation above Spanner and version artifacts immutably. |
| Dynamic concepts | Strong | Avoid per-team physical schema generation. |
| Multi-hop retrieval | Strong | Expose reviewed bounded traversals, not free-form GQL. |
| Transactional lineage | Strong | Commit nodes, edges, evidence, chunks, and idempotency together. |
| GraphRAG | Strong candidate | Benchmark vector/full-text integration before production selection. |
| Property-heavy hot filters | Mixed | JSON is flexible; promote/index only measured hot paths. |
| Database-enforced tenant keys | Deliberate gap | Use separate databases or a composite-key variant when required. |
| Specialized graph science | Evaluate separately | Algorithm workloads and transactional retrieval have different needs. |

## Alternatives that were rejected

### One table per entity/relationship type

Rejected because each team's ontology would require DDL, graph-definition changes, rollout
coordination, and increasingly complex multi-type paths.

### Unrestricted schemaless writes

Rejected because flexibility without configuration validation permits semantic drift, invalid
endpoints, unsafe query generation, and irreconcilable identity.

### LLM-generated Graph SQL

Rejected because model output must not define query syntax, authorization scope, or result limits.
The model may route to a configured traversal name and typed arguments only.

## Capabilities to evaluate later

- Graphs built from SQL views for controlled exposure or policy-specific projections.
- Spanner-native vector similarity and full-text retrieval.
- JSON search indexes for high-value metadata paths.
- Graph algorithms for workloads distinct from online knowledge retrieval.
- Composite graph-scoped primary keys if database-level isolation outweighs the minimal schema goal.

Each option requires a benchmark, security review, operational plan, and explicit ADR before use.

## Official references

- [Spanner Graph schema overview](https://cloud.google.com/spanner/docs/graph/schema-overview)
- [Best practices for designing a graph schema](https://cloud.google.com/spanner/docs/graph/best-practices-designing-schema)
- [Manage schemaless graph data](https://cloud.google.com/spanner/docs/graph/manage-schemaless-data)
- [GQL query statements](https://cloud.google.com/spanner/docs/reference/standard-sql/graph-query-statements)
- [Graphs within SQL](https://cloud.google.com/spanner/docs/reference/standard-sql/graph-sql-queries)
- [Graphs created from SQL views](https://cloud.google.com/spanner/docs/graph/graph-with-views-overview)
- [Vector search with Spanner Graph](https://cloud.google.com/spanner/docs/graph/perform-vector-similarity-search)
- [Full-text search with Spanner Graph](https://cloud.google.com/spanner/docs/graph/full-text-search-and-graph)
- [Graph algorithm requirements](https://cloud.google.com/spanner/docs/graph/algorithm-schema-requirements-and-feature-compatibility)
