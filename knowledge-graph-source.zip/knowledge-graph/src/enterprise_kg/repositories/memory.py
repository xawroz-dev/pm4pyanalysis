from __future__ import annotations

from collections.abc import Mapping
from threading import RLock

from enterprise_kg.config.models import Direction, GraphConfig, TraversalDefinition
from enterprise_kg.domain.exceptions import GraphValidationError, NotFoundError
from enterprise_kg.domain.models import (
    GraphWriteSet,
    IngestionResult,
    NodeSearchRequest,
    PathEdge,
    PathNode,
    StoredEdge,
    StoredEvidence,
    StoredNode,
    TraversalPath,
)


class MemoryGraphRepository:
    """Deterministic test adapter with the same namespace and traversal semantics."""

    def __init__(self) -> None:
        self._nodes: dict[str, StoredNode] = {}
        self._edges: dict[str, StoredEdge] = {}
        self._evidence: dict[str, StoredEvidence] = {}
        self._batches: dict[tuple[str, str, str], IngestionResult] = {}
        self._lock = RLock()

    def apply(self, write_set: GraphWriteSet) -> IngestionResult:
        batch_key = (write_set.namespace, write_set.graph_id, write_set.idempotency_key)
        with self._lock:
            if existing := self._batches.get(batch_key):
                return existing.model_copy(update={"replayed": True})
            available = set(self._nodes) | {node.node_id for node in write_set.nodes}
            for edge in write_set.edges:
                if edge.source_node_id not in available or edge.target_node_id not in available:
                    raise GraphValidationError(
                        f"relationship {edge.relationship_type} references an unknown entity"
                    )
            for node in write_set.nodes:
                existing_node = self._nodes.get(node.node_id)
                chunk_ids = tuple(
                    dict.fromkeys(
                        [*(existing_node.chunk_ids if existing_node else ()), *node.chunk_ids]
                    )
                )
                self._nodes[node.node_id] = node.model_copy(update={"chunk_ids": chunk_ids})
            for edge in write_set.edges:
                existing_edge = self._edges.get(edge.edge_id)
                chunk_ids = tuple(
                    dict.fromkeys(
                        [*(existing_edge.chunk_ids if existing_edge else ()), *edge.chunk_ids]
                    )
                )
                self._edges[edge.edge_id] = edge.model_copy(update={"chunk_ids": chunk_ids})
            self._evidence.update({item.evidence_id: item for item in write_set.evidence})
            result = IngestionResult(
                graph_id=write_set.graph_id,
                namespace=write_set.namespace,
                config_version=write_set.config_version,
                idempotency_key=write_set.idempotency_key,
                nodes_upserted=len(write_set.nodes),
                edges_upserted=len(write_set.edges),
                evidence_upserted=len(write_set.evidence),
                replayed=False,
            )
            self._batches[batch_key] = result
            return result

    def traverse(
        self,
        config: GraphConfig,
        traversal: TraversalDefinition,
        start_canonical_id: str,
        limit: int,
    ) -> list[TraversalPath]:
        namespace = config.metadata.namespace
        graph_id = config.metadata.graph_id
        starts = [
            node
            for node in self._nodes.values()
            if node.namespace == namespace
            and node.graph_id == graph_id
            and node.entity_type == traversal.start_entity
            and node.canonical_id == start_canonical_id
        ]
        paths: list[TraversalPath] = []

        def walk(nodes: list[StoredNode], edges: list[StoredEdge], hop_index: int) -> None:
            if len(paths) >= limit:
                return
            if hop_index == len(traversal.hops):
                paths.append(
                    TraversalPath(
                        nodes=[_path_node(node) for node in nodes],
                        edges=[_path_edge(edge) for edge in edges],
                    )
                )
                return
            hop = traversal.hops[hop_index]
            current = nodes[-1]
            for edge in sorted(self._edges.values(), key=lambda item: item.edge_id):
                if (
                    edge.namespace != namespace
                    or edge.graph_id != graph_id
                    or edge.relationship_type != hop.relationship
                ):
                    continue
                candidate_id = (
                    edge.target_node_id
                    if hop.direction == Direction.OUTGOING
                    and edge.source_node_id == current.node_id
                    else edge.source_node_id
                    if hop.direction == Direction.INCOMING
                    and edge.target_node_id == current.node_id
                    else None
                )
                candidate = self._nodes.get(candidate_id or "")
                if candidate is not None and candidate.entity_type == hop.target:
                    walk([*nodes, candidate], [*edges, edge], hop_index + 1)

        for start in starts:
            walk([start], [], 0)
        return paths

    def evidence(self, namespace: str, graph_id: str, evidence_id: str) -> StoredEvidence:
        item = self._evidence.get(evidence_id)
        if item is None or item.namespace != namespace or item.graph_id != graph_id:
            raise NotFoundError(evidence_id)
        return item

    def search_nodes(self, config: GraphConfig, request: NodeSearchRequest) -> list[PathNode]:
        namespace = config.metadata.namespace
        graph_id = config.metadata.graph_id
        name_prefix = request.name_prefix.casefold() if request.name_prefix else None
        matches: list[StoredNode] = []
        for node in self._nodes.values():
            if node.namespace != namespace or node.graph_id != graph_id:
                continue
            if request.entity_type and node.entity_type != request.entity_type:
                continue
            if name_prefix and not node.canonical_name.casefold().startswith(name_prefix):
                continue
            if request.chunk_id and request.chunk_id not in node.chunk_ids:
                continue
            if any(
                _metadata_value(node.metadata, path) != expected
                for path, expected in request.metadata_equals.items()
            ):
                continue
            matches.append(node)
        return [
            _path_node(node)
            for node in sorted(matches, key=lambda item: (item.canonical_name, item.node_id))[
                : request.limit
            ]
        ]

    def entities_for_chunk(self, config: GraphConfig, chunk_id: str) -> list[PathNode]:
        nodes = [
            node
            for node in self._nodes.values()
            if node.namespace == config.metadata.namespace
            and node.graph_id == config.metadata.graph_id
            and chunk_id in node.chunk_ids
        ]
        return [
            _path_node(node)
            for node in sorted(nodes, key=lambda item: (item.canonical_name, item.node_id))
        ]

    def ready(self) -> bool:
        return True


def _path_node(node: StoredNode) -> PathNode:
    return PathNode(
        node_id=node.node_id,
        entity_type=node.entity_type,
        canonical_id=node.canonical_id,
        canonical_name=node.canonical_name,
        properties=node.properties,
        metadata=node.metadata,
        chunk_ids=list(node.chunk_ids),
    )


def _path_edge(edge: StoredEdge) -> PathEdge:
    return PathEdge(
        edge_id=edge.edge_id,
        relationship_type=edge.relationship_type,
        description=edge.description,
        rationale=edge.rationale,
        selection_context=list(edge.selection_context),
        confidence=edge.confidence,
        evidence_id=edge.evidence_id,
        properties=edge.properties,
        metadata=edge.metadata,
        chunk_ids=list(edge.chunk_ids),
        creation_details=edge.creation_details,
    )


def _metadata_value(metadata: Mapping[str, object], path: str) -> object:
    current: object = metadata
    for segment in path.split("."):
        if not isinstance(current, Mapping) or segment not in current:
            return None
        current = current[segment]
    return current
