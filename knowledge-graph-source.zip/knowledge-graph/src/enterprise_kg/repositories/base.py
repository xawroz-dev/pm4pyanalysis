from __future__ import annotations

from typing import Protocol

from enterprise_kg.config.models import GraphConfig, TraversalDefinition
from enterprise_kg.domain.models import (
    GraphWriteSet,
    IngestionResult,
    NodeSearchRequest,
    PathNode,
    StoredEvidence,
    TraversalPath,
)


class GraphRepository(Protocol):
    def apply(self, write_set: GraphWriteSet) -> IngestionResult: ...

    def traverse(
        self,
        config: GraphConfig,
        traversal: TraversalDefinition,
        start_canonical_id: str,
        limit: int,
    ) -> list[TraversalPath]: ...

    def evidence(self, namespace: str, graph_id: str, evidence_id: str) -> StoredEvidence: ...

    def search_nodes(self, config: GraphConfig, request: NodeSearchRequest) -> list[PathNode]: ...

    def entities_for_chunk(self, config: GraphConfig, chunk_id: str) -> list[PathNode]: ...

    def ready(self) -> bool: ...
