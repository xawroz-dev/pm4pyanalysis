from __future__ import annotations

from dataclasses import dataclass
from typing import Annotated, Literal, cast

from fastapi import Depends, HTTPException, Request, status

from enterprise_kg.config.loader import FileConfigRegistry
from enterprise_kg.repositories.base import GraphRepository
from enterprise_kg.services.graph_service import GraphService
from enterprise_kg.settings import Settings


def settings(request: Request) -> Settings:
    return cast(Settings, request.app.state.settings)


def config_registry(request: Request) -> FileConfigRegistry:
    return cast(FileConfigRegistry, request.app.state.config_registry)


def graph_repository(request: Request) -> GraphRepository:
    return cast(GraphRepository, request.app.state.graph_repository)


def graph_service(request: Request) -> GraphService:
    return cast(GraphService, request.app.state.graph_service)


@dataclass(frozen=True, slots=True)
class Principal:
    subject: str
    roles: frozenset[str]


def current_principal(
    request: Request,
    runtime_settings: Annotated[Settings, Depends(settings)],
) -> Principal:
    if runtime_settings.auth_mode == "disabled":
        return Principal(subject="local-developer", roles=frozenset({"*"}))
    subject = request.headers.get("x-kg-principal", "").strip()
    roles = frozenset(
        item.strip() for item in request.headers.get("x-kg-roles", "").split(",") if item.strip()
    )
    if not subject:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="authenticated principal is required",
        )
    return Principal(subject=subject, roles=roles)


def authorize(
    principal: Principal,
    configured_roles: tuple[str, ...],
    operation: Literal["read", "write", "admin"],
) -> None:
    if "*" in principal.roles:
        return
    suffixes = {
        "read": ("-reader", "-writer", "-admin"),
        "write": ("-writer", "-admin"),
        "admin": ("-admin",),
    }[operation]
    required = {role for role in configured_roles if role.endswith(suffixes)}
    if not principal.roles.intersection(required):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=f"{operation} access to this graph is required",
        )
