from __future__ import annotations

from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from typing import Any

from fastapi import FastAPI, Request, status
from fastapi.responses import JSONResponse

from enterprise_kg.api.routes import configurations, graphs, health
from enterprise_kg.config.loader import FileConfigRegistry
from enterprise_kg.domain.exceptions import (
    ConfigNotFoundError,
    ConfigValidationError,
    GraphValidationError,
    NotFoundError,
)
from enterprise_kg.infrastructure.spanner import SpannerGraphRepository
from enterprise_kg.observability import configure_logging, request_context_middleware
from enterprise_kg.repositories.memory import MemoryGraphRepository
from enterprise_kg.services.graph_service import GraphService
from enterprise_kg.settings import Settings, get_settings


def create_app(settings: Settings | None = None, repository: Any | None = None) -> FastAPI:
    runtime_settings = settings or get_settings()
    configure_logging(runtime_settings.log_level)

    @asynccontextmanager
    async def lifespan(app: FastAPI) -> AsyncIterator[None]:
        registry = FileConfigRegistry(runtime_settings.config_directory)
        registry.load()
        graph_repository = repository or (
            MemoryGraphRepository()
            if runtime_settings.repository_backend == "memory"
            else SpannerGraphRepository(runtime_settings)
        )
        app.state.settings = runtime_settings
        app.state.config_registry = registry
        app.state.graph_repository = graph_repository
        app.state.graph_service = GraphService(
            registry,
            graph_repository,
            max_entities=runtime_settings.request_max_entities,
            max_relationships=runtime_settings.request_max_relationships,
        )
        yield

    app = FastAPI(
        title="Enterprise Knowledge Graph Platform",
        version="0.1.0",
        description="Governed, config-driven graph ingestion and traversal on Spanner Graph.",
        lifespan=lifespan,
        docs_url="/docs" if runtime_settings.environment != "production" else None,
        redoc_url=None,
    )
    app.middleware("http")(request_context_middleware)
    app.include_router(health.router)
    app.include_router(configurations.router)
    app.include_router(graphs.router)

    @app.exception_handler(ConfigValidationError)
    async def config_validation_error(
        _request: Request, exc: ConfigValidationError
    ) -> JSONResponse:
        return JSONResponse(
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
            content={
                "code": "configuration_invalid",
                "message": str(exc),
                "issues": [
                    {"path": item.path, "message": item.message, "code": item.code}
                    for item in exc.issues
                ],
            },
        )

    @app.exception_handler(GraphValidationError)
    async def graph_validation_error(_request: Request, exc: GraphValidationError) -> JSONResponse:
        return JSONResponse(
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
            content={"code": "graph_fact_invalid", "message": str(exc), "field": exc.field},
        )

    @app.exception_handler(ConfigNotFoundError)
    async def config_not_found(_request: Request, exc: ConfigNotFoundError) -> JSONResponse:
        return JSONResponse(
            status_code=status.HTTP_404_NOT_FOUND,
            content={"code": "configuration_not_found", "message": str(exc)},
        )

    @app.exception_handler(NotFoundError)
    async def not_found(_request: Request, exc: NotFoundError) -> JSONResponse:
        return JSONResponse(
            status_code=status.HTTP_404_NOT_FOUND,
            content={"code": "not_found", "message": str(exc)},
        )

    return app


app = create_app()
