from __future__ import annotations

from typing import Annotated

from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field

from enterprise_kg.api.dependencies import (
    Principal,
    authorize,
    config_registry,
    current_principal,
)
from enterprise_kg.config.loader import FileConfigRegistry, parse_config

router = APIRouter(prefix="/v1/configurations", tags=["configurations"])


class ConfigSummary(BaseModel):
    graph_id: str
    namespace: str
    version: str
    active: bool
    checksum: str
    owner: str
    questions: list[str]


class ValidateConfigRequest(BaseModel):
    document: str = Field(min_length=1, max_length=1_000_000)


class ValidateConfigResponse(BaseModel):
    valid: bool
    graph_id: str
    namespace: str
    version: str
    checksum: str


@router.get("", response_model=list[ConfigSummary])
def list_configs(
    registry: Annotated[FileConfigRegistry, Depends(config_registry)],
    principal: Annotated[Principal, Depends(current_principal)],
) -> list[ConfigSummary]:
    return [
        ConfigSummary(
            graph_id=item.config.metadata.graph_id,
            namespace=item.config.metadata.namespace,
            version=item.config.metadata.version,
            active=registry.active_version(item.config.metadata.graph_id)
            == item.config.metadata.version,
            checksum=item.checksum,
            owner=item.config.metadata.owner,
            questions=list(item.config.questions),
        )
        for item in registry.list()
        if "*" in principal.roles
        or principal.roles.intersection(item.config.governance.allowed_roles)
    ]


@router.post("/validate", response_model=ValidateConfigResponse)
def validate_config(
    request: ValidateConfigRequest,
    principal: Annotated[Principal, Depends(current_principal)],
) -> ValidateConfigResponse:
    item = parse_config(request.document)
    authorize(principal, item.config.governance.allowed_roles, "admin")
    return ValidateConfigResponse(
        valid=True,
        graph_id=item.config.metadata.graph_id,
        namespace=item.config.metadata.namespace,
        version=item.config.metadata.version,
        checksum=item.checksum,
    )


@router.post("/{graph_id}/versions/{version}/activate", response_model=ConfigSummary)
def activate_config(
    graph_id: str,
    version: str,
    registry: Annotated[FileConfigRegistry, Depends(config_registry)],
    principal: Annotated[Principal, Depends(current_principal)],
) -> ConfigSummary:
    item = registry.get(graph_id, version)
    authorize(principal, item.config.governance.allowed_roles, "admin")
    registry.activate(graph_id, version)
    return ConfigSummary(
        graph_id=item.config.metadata.graph_id,
        namespace=item.config.metadata.namespace,
        version=item.config.metadata.version,
        active=True,
        checksum=item.checksum,
        owner=item.config.metadata.owner,
        questions=list(item.config.questions),
    )
