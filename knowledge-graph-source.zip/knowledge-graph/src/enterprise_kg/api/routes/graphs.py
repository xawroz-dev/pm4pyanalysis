from __future__ import annotations

from typing import Annotated

from fastapi import APIRouter, Depends

from enterprise_kg.api.dependencies import (
    Principal,
    authorize,
    config_registry,
    current_principal,
    graph_repository,
    graph_service,
)
from enterprise_kg.config.loader import FileConfigRegistry
from enterprise_kg.domain.models import (
    ChunkEntitiesResult,
    IngestionRequest,
    IngestionResult,
    NodeSearchRequest,
    NodeSearchResult,
    StoredEvidence,
    TraversalRequest,
    TraversalResult,
)
from enterprise_kg.repositories.base import GraphRepository
from enterprise_kg.services.graph_service import GraphService

router = APIRouter(prefix="/v1/graphs", tags=["graphs"])


@router.post("/{graph_id}/nodes/search", response_model=NodeSearchResult)
def search_nodes(
    graph_id: str,
    request: NodeSearchRequest,
    service: Annotated[GraphService, Depends(graph_service)],
    registry: Annotated[FileConfigRegistry, Depends(config_registry)],
    principal: Annotated[Principal, Depends(current_principal)],
) -> NodeSearchResult:
    config = registry.get(graph_id, request.config_version).config
    authorize(principal, config.governance.allowed_roles, "read")
    return service.search_nodes(graph_id, request)


@router.get("/{graph_id}/chunks/{chunk_id}/entities", response_model=ChunkEntitiesResult)
def entities_for_chunk(
    graph_id: str,
    chunk_id: str,
    service: Annotated[GraphService, Depends(graph_service)],
    registry: Annotated[FileConfigRegistry, Depends(config_registry)],
    principal: Annotated[Principal, Depends(current_principal)],
    config_version: str | None = None,
) -> ChunkEntitiesResult:
    config = registry.get(graph_id, config_version).config
    authorize(principal, config.governance.allowed_roles, "read")
    return service.entities_for_chunk(graph_id, chunk_id, config_version)


@router.post("/{graph_id}/ingestions", response_model=IngestionResult)
def ingest(
    graph_id: str,
    request: IngestionRequest,
    service: Annotated[GraphService, Depends(graph_service)],
    registry: Annotated[FileConfigRegistry, Depends(config_registry)],
    principal: Annotated[Principal, Depends(current_principal)],
) -> IngestionResult:
    config = registry.get(graph_id, request.config_version).config
    authorize(principal, config.governance.allowed_roles, "write")
    return service.ingest(graph_id, request)


@router.post("/{graph_id}/traversals", response_model=TraversalResult)
def traverse(
    graph_id: str,
    request: TraversalRequest,
    service: Annotated[GraphService, Depends(graph_service)],
    registry: Annotated[FileConfigRegistry, Depends(config_registry)],
    principal: Annotated[Principal, Depends(current_principal)],
) -> TraversalResult:
    config = registry.get(graph_id, request.config_version).config
    authorize(principal, config.governance.allowed_roles, "read")
    return service.traverse(graph_id, request)


@router.get("/{graph_id}/evidence/{evidence_id}", response_model=StoredEvidence)
def evidence(
    graph_id: str,
    evidence_id: str,
    registry: Annotated[FileConfigRegistry, Depends(config_registry)],
    repository: Annotated[GraphRepository, Depends(graph_repository)],
    principal: Annotated[Principal, Depends(current_principal)],
    config_version: str | None = None,
) -> StoredEvidence:
    config = registry.get(graph_id, config_version).config
    authorize(principal, config.governance.allowed_roles, "read")
    return repository.evidence(config.metadata.namespace, graph_id, evidence_id)
