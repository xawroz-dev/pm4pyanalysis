from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel

from enterprise_kg.api.dependencies import graph_repository
from enterprise_kg.domain.exceptions import RepositoryUnavailableError
from enterprise_kg.repositories.base import GraphRepository

router = APIRouter(tags=["health"])


class HealthResponse(BaseModel):
    status: str


@router.get("/health/live", response_model=HealthResponse)
def live() -> HealthResponse:
    return HealthResponse(status="ok")


@router.get("/health/ready", response_model=HealthResponse)
def ready(
    repository: Annotated[GraphRepository, Depends(graph_repository)],
) -> HealthResponse:
    try:
        is_ready = repository.ready()
    except RepositoryUnavailableError as exc:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="dependency unavailable"
        ) from exc
    if not is_ready:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="dependency unavailable"
        )
    return HealthResponse(status="ready")
