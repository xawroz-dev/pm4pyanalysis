"""Domain models and errors."""
