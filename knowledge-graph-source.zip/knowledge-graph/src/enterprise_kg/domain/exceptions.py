from __future__ import annotations

from dataclasses import dataclass

from pydantic import ValidationError


class KnowledgeGraphError(Exception):
    """Base exception for errors that are safe to map at the API boundary."""


class ConfigNotFoundError(KnowledgeGraphError):
    pass


class GraphValidationError(KnowledgeGraphError):
    def __init__(self, message: str, *, field: str | None = None) -> None:
        super().__init__(message)
        self.field = field


class RepositoryUnavailableError(KnowledgeGraphError):
    pass


class NotFoundError(KnowledgeGraphError):
    pass


@dataclass(frozen=True, slots=True)
class ValidationIssue:
    path: str
    message: str
    code: str


class ConfigValidationError(KnowledgeGraphError):
    def __init__(self, message: str, *, issues: tuple[ValidationIssue, ...] = ()) -> None:
        super().__init__(message)
        self.issues = issues

    @classmethod
    def from_pydantic(cls, error: ValidationError) -> ConfigValidationError:
        issues = tuple(
            ValidationIssue(
                path=".".join(str(part) for part in item["loc"]),
                message=item["msg"],
                code=item["type"],
            )
            for item in error.errors()
        )
        return cls("configuration validation failed", issues=issues)
