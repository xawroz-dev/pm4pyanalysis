from __future__ import annotations

from datetime import UTC, datetime
from enum import StrEnum
from typing import Annotated, Any, Literal

from pydantic import BaseModel, ConfigDict, Field, JsonValue, model_validator


class ApiModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


SelectionContext = Annotated[str, Field(min_length=5, max_length=1_000)]
ChunkId = Annotated[str, Field(min_length=1, max_length=512)]
MetadataPath = Annotated[
    str, Field(pattern=r"^[A-Za-z_][A-Za-z0-9_-]*(\.[A-Za-z_][A-Za-z0-9_-]*)*$")
]
MetadataScalar = str | int | float | bool


class ExtractionMethod(StrEnum):
    MANUAL = "manual"
    RULE = "rule"
    LLM = "llm"
    IMPORT = "import"


class Provenance(ApiModel):
    source_id: str = Field(min_length=1, max_length=512)
    document_uri: str = Field(min_length=1, max_length=2_048)
    document_version: str = Field(min_length=1, max_length=128)
    locator: str = Field(min_length=1, max_length=512)
    extraction_method: ExtractionMethod
    observed_at: datetime = Field(default_factory=lambda: datetime.now(UTC))
    content_hash: str | None = Field(default=None, pattern=r"^[a-fA-F0-9]{64}$")


class RelationshipCreationDetails(ApiModel):
    """Auditable explanation of the pipeline or human decision that created an edge."""

    method: ExtractionMethod
    generator: str = Field(min_length=2, max_length=200)
    pipeline_run_id: str = Field(min_length=1, max_length=256)
    rule_id: str | None = Field(default=None, max_length=256)
    model_id: str | None = Field(default=None, max_length=256)
    prompt_version: str | None = Field(default=None, max_length=128)
    created_by: str = Field(min_length=2, max_length=256)
    created_at: datetime = Field(default_factory=lambda: datetime.now(UTC))
    review_status: Literal["pending", "approved", "rejected", "not_required"]
    reviewed_by: str | None = Field(default=None, max_length=256)

    @model_validator(mode="after")
    def validate_method_details(self) -> RelationshipCreationDetails:
        if self.method == ExtractionMethod.RULE and not self.rule_id:
            raise ValueError("rule_id is required when method is rule")
        if self.method == ExtractionMethod.LLM and (not self.model_id or not self.prompt_version):
            raise ValueError("model_id and prompt_version are required when method is llm")
        if self.review_status in {"approved", "rejected"} and not self.reviewed_by:
            raise ValueError("reviewed_by is required for reviewed relationships")
        return self


class EntityInput(ApiModel):
    entity_type: str
    canonical_id: str = Field(min_length=1, max_length=512)
    canonical_name: str = Field(min_length=1, max_length=512)
    aliases: list[str] = Field(default_factory=list, max_length=100)
    properties: dict[str, Any] = Field(default_factory=dict)
    metadata: dict[str, JsonValue] = Field(default_factory=dict, max_length=100)
    chunk_ids: list[ChunkId] = Field(default_factory=list, max_length=100)
    confidence: float = Field(default=1.0, ge=0, le=1)
    provenance: Provenance

    @model_validator(mode="after")
    def protect_system_metadata(self) -> EntityInput:
        if "_system" in self.metadata:
            raise ValueError("metadata key _system is reserved by the platform")
        return self


class RelationshipInput(ApiModel):
    relationship_type: str
    source_entity_type: str
    source_canonical_id: str = Field(min_length=1, max_length=512)
    target_entity_type: str
    target_canonical_id: str = Field(min_length=1, max_length=512)
    description: str = Field(min_length=10, max_length=4_000)
    rationale: str = Field(min_length=10, max_length=4_000)
    selection_context: list[SelectionContext] = Field(min_length=1, max_length=25)
    properties: dict[str, Any] = Field(default_factory=dict)
    metadata: dict[str, JsonValue] = Field(default_factory=dict, max_length=100)
    chunk_ids: list[ChunkId] = Field(default_factory=list, max_length=100)
    creation_details: RelationshipCreationDetails
    confidence: float = Field(default=1.0, ge=0, le=1)
    provenance: Provenance

    @model_validator(mode="after")
    def creation_method_matches_provenance(self) -> RelationshipInput:
        if "_system" in self.metadata:
            raise ValueError("metadata key _system is reserved by the platform")
        if self.creation_details.method != self.provenance.extraction_method:
            raise ValueError("creation method must match provenance extraction_method")
        return self


class IngestionRequest(ApiModel):
    config_version: str | None = None
    source_type: str = Field(min_length=2, max_length=100)
    source_metadata: dict[str, str]
    idempotency_key: str = Field(min_length=8, max_length=256)
    entities: list[EntityInput] = Field(min_length=1)
    relationships: list[RelationshipInput] = Field(default_factory=list)

    @model_validator(mode="after")
    def unique_entity_keys(self) -> IngestionRequest:
        keys = [(item.entity_type, item.canonical_id) for item in self.entities]
        if len(keys) != len(set(keys)):
            raise ValueError("request contains duplicate entity type/canonical ID pairs")
        return self


class StoredNode(BaseModel):
    model_config = ConfigDict(frozen=True)

    node_id: str
    namespace: str
    graph_id: str
    entity_type: str
    canonical_id: str
    canonical_name: str
    aliases: tuple[str, ...]
    properties: dict[str, Any]
    metadata: dict[str, JsonValue]
    chunk_ids: tuple[str, ...]
    config_version: str
    updated_at: datetime


class StoredEvidence(BaseModel):
    model_config = ConfigDict(frozen=True)

    evidence_id: str
    subject_id: str
    subject_kind: str
    graph_id: str
    namespace: str
    confidence: float
    provenance: Provenance
    created_at: datetime


class StoredEdge(BaseModel):
    model_config = ConfigDict(frozen=True)

    edge_id: str
    namespace: str
    graph_id: str
    relationship_type: str
    source_node_id: str
    target_node_id: str
    description: str
    rationale: str
    selection_context: tuple[str, ...]
    properties: dict[str, Any]
    metadata: dict[str, JsonValue]
    chunk_ids: tuple[str, ...]
    creation_details: RelationshipCreationDetails
    confidence: float
    evidence_id: str
    config_version: str
    created_at: datetime


class GraphWriteSet(BaseModel):
    model_config = ConfigDict(frozen=True)

    namespace: str
    graph_id: str
    config_version: str
    idempotency_key: str
    nodes: tuple[StoredNode, ...]
    edges: tuple[StoredEdge, ...]
    evidence: tuple[StoredEvidence, ...]


class IngestionResult(ApiModel):
    graph_id: str
    namespace: str
    config_version: str
    idempotency_key: str
    nodes_upserted: int
    edges_upserted: int
    evidence_upserted: int
    replayed: bool


class TraversalRequest(ApiModel):
    traversal: str
    start_canonical_id: str = Field(min_length=1, max_length=512)
    config_version: str | None = None
    limit: int | None = Field(default=None, ge=1, le=1_000)


class NodeSearchRequest(ApiModel):
    """Bounded, metadata-aware node selection without accepting arbitrary SQL."""

    config_version: str | None = None
    entity_type: str | None = Field(default=None, min_length=1, max_length=63)
    name_prefix: str | None = Field(default=None, min_length=1, max_length=200)
    metadata_equals: dict[MetadataPath, MetadataScalar] = Field(default_factory=dict, max_length=20)
    chunk_id: ChunkId | None = None
    limit: int = Field(default=50, ge=1, le=200)


class PathNode(ApiModel):
    node_id: str
    entity_type: str
    canonical_id: str
    canonical_name: str
    properties: dict[str, Any]
    metadata: dict[str, JsonValue]
    chunk_ids: list[str]


class PathEdge(ApiModel):
    edge_id: str
    relationship_type: str
    description: str
    rationale: str
    selection_context: list[str]
    confidence: float
    evidence_id: str
    properties: dict[str, Any]
    metadata: dict[str, JsonValue]
    chunk_ids: list[str]
    creation_details: RelationshipCreationDetails


class TraversalPath(ApiModel):
    nodes: list[PathNode]
    edges: list[PathEdge]


class TraversalResult(ApiModel):
    graph_id: str
    namespace: str
    config_version: str
    traversal: str
    paths: list[TraversalPath]


class NodeSearchResult(ApiModel):
    graph_id: str
    namespace: str
    config_version: str
    nodes: list[PathNode]


class ChunkEntitiesResult(ApiModel):
    graph_id: str
    namespace: str
    config_version: str
    chunk_id: str
    nodes: list[PathNode]
