from functools import lru_cache
from pathlib import Path
from typing import Literal

from pydantic import Field, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Runtime configuration. Secrets are intentionally absent from local defaults."""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_prefix="KG_",
        extra="ignore",
        case_sensitive=False,
    )

    environment: Literal["local", "test", "production"] = "local"
    service_name: str = "enterprise-knowledge-graph"
    log_level: str = "INFO"
    config_directory: Path = Path("configs")
    repository_backend: Literal["spanner", "memory"] = "spanner"
    auth_mode: Literal["disabled", "trusted_headers"] = "disabled"

    spanner_project: str = "local-kg-project"
    spanner_instance: str = "enterprise-kg"
    spanner_database: str = "knowledge-graph"
    spanner_graph: str = "EnterpriseKnowledgeGraph"
    spanner_emulator_host: str | None = None

    request_max_entities: int = Field(default=2_000, ge=1, le=100_000)
    request_max_relationships: int = Field(default=10_000, ge=1, le=500_000)
    readiness_timeout_seconds: float = Field(default=3.0, gt=0, le=30)

    @model_validator(mode="after")
    def production_requires_authentication(self) -> "Settings":
        if self.environment == "production" and self.auth_mode == "disabled":
            raise ValueError("production requires KG_AUTH_MODE=trusted_headers")
        return self


@lru_cache
def get_settings() -> Settings:
    return Settings()
