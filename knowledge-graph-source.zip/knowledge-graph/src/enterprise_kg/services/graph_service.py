from __future__ import annotations

import hashlib
import json
import uuid
from datetime import UTC, datetime
from typing import Any

from enterprise_kg.config.loader import FileConfigRegistry
from enterprise_kg.config.models import (
    EntityDefinition,
    GraphConfig,
    PropertyDefinition,
    PropertyType,
)
from enterprise_kg.domain.exceptions import GraphValidationError
from enterprise_kg.domain.models import (
    ChunkEntitiesResult,
    GraphWriteSet,
    IngestionRequest,
    IngestionResult,
    NodeSearchRequest,
    NodeSearchResult,
    RelationshipInput,
    StoredEdge,
    StoredEvidence,
    StoredNode,
    TraversalRequest,
    TraversalResult,
)
from enterprise_kg.repositories.base import GraphRepository

ID_NAMESPACE = uuid.UUID("c8d51e55-9a10-4261-ae32-8736c9a8a199")


class GraphService:
    def __init__(
        self,
        configs: FileConfigRegistry,
        repository: GraphRepository,
        *,
        max_entities: int = 2_000,
        max_relationships: int = 10_000,
    ) -> None:
        self._configs = configs
        self._repository = repository
        self._max_entities = max_entities
        self._max_relationships = max_relationships

    def ingest(self, graph_id: str, request: IngestionRequest) -> IngestionResult:
        if len(request.entities) > self._max_entities:
            raise GraphValidationError(
                f"entity count exceeds request limit of {self._max_entities}"
            )
        if len(request.relationships) > self._max_relationships:
            raise GraphValidationError(
                f"relationship count exceeds request limit of {self._max_relationships}"
            )
        config = self._configs.get(graph_id, request.config_version).config
        write_set = self._build_write_set(config, request)
        return self._repository.apply(write_set)

    def traverse(self, graph_id: str, request: TraversalRequest) -> TraversalResult:
        config = self._configs.get(graph_id, request.config_version).config
        try:
            traversal = config.traversal(request.traversal)
        except StopIteration as exc:
            raise GraphValidationError(
                f"traversal is not allowed by configuration: {request.traversal}"
            ) from exc
        limit = min(request.limit or traversal.max_results, traversal.max_results)
        paths = self._repository.traverse(config, traversal, request.start_canonical_id, limit)
        return TraversalResult(
            graph_id=config.metadata.graph_id,
            namespace=config.metadata.namespace,
            config_version=config.metadata.version,
            traversal=traversal.name,
            paths=paths,
        )

    def search_nodes(self, graph_id: str, request: NodeSearchRequest) -> NodeSearchResult:
        config = self._configs.get(graph_id, request.config_version).config
        if request.entity_type is not None:
            _find_entity(config, request.entity_type)
        nodes = self._repository.search_nodes(config, request)
        return NodeSearchResult(
            graph_id=config.metadata.graph_id,
            namespace=config.metadata.namespace,
            config_version=config.metadata.version,
            nodes=nodes,
        )

    def entities_for_chunk(
        self, graph_id: str, chunk_id: str, config_version: str | None = None
    ) -> ChunkEntitiesResult:
        config = self._configs.get(graph_id, config_version).config
        nodes = self._repository.entities_for_chunk(config, chunk_id)
        return ChunkEntitiesResult(
            graph_id=config.metadata.graph_id,
            namespace=config.metadata.namespace,
            config_version=config.metadata.version,
            chunk_id=chunk_id,
            nodes=nodes,
        )

    def _build_write_set(self, config: GraphConfig, request: IngestionRequest) -> GraphWriteSet:
        now = datetime.now(UTC)
        node_lookup: dict[tuple[str, str], str] = {}
        nodes: list[StoredNode] = []
        edges: list[StoredEdge] = []
        evidence: list[StoredEvidence] = []
        try:
            source = next(
                item for item in config.sources if item.source_type == request.source_type
            )
        except StopIteration as exc:
            raise GraphValidationError(
                f"source type is not allowed: {request.source_type}"
            ) from exc
        missing_metadata = set(source.required_metadata) - set(request.source_metadata)
        if missing_metadata:
            raise GraphValidationError(
                f"source metadata is missing required fields: {sorted(missing_metadata)}"
            )

        for entity in request.entities:
            definition = _find_entity(config, entity.entity_type)
            if entity.entity_type not in source.extracts:
                raise GraphValidationError(
                    f"source {source.source_type} cannot extract {entity.entity_type}"
                )
            _validate_confidence(config, entity.confidence, entity.provenance.extraction_method)
            _validate_properties(
                definition.properties, entity.properties, definition=entity.entity_type
            )
            expected_canonical_id = "|".join(
                str(entity.properties[name]) for name in definition.identifiers
            )
            if entity.canonical_id != expected_canonical_id:
                raise GraphValidationError(
                    f"{entity.entity_type}.canonical_id must equal configured identifier "
                    f"value {expected_canonical_id}"
                )
            node_id = _stable_id(
                config.metadata.namespace,
                config.metadata.graph_id,
                entity.entity_type,
                entity.canonical_id.strip().casefold(),
            )
            node_lookup[(entity.entity_type, entity.canonical_id)] = node_id
            nodes.append(
                StoredNode(
                    node_id=node_id,
                    namespace=config.metadata.namespace,
                    graph_id=config.metadata.graph_id,
                    entity_type=entity.entity_type,
                    canonical_id=entity.canonical_id,
                    canonical_name=entity.canonical_name,
                    aliases=tuple(dict.fromkeys(entity.aliases)),
                    properties=entity.properties,
                    metadata=entity.metadata,
                    chunk_ids=tuple(dict.fromkeys(entity.chunk_ids)),
                    config_version=config.metadata.version,
                    updated_at=now,
                )
            )
            evidence_id = _evidence_id(node_id, entity.provenance.model_dump(mode="json"))
            evidence.append(
                StoredEvidence(
                    evidence_id=evidence_id,
                    subject_id=node_id,
                    subject_kind="entity",
                    graph_id=config.metadata.graph_id,
                    namespace=config.metadata.namespace,
                    confidence=entity.confidence,
                    provenance=entity.provenance,
                    created_at=now,
                )
            )

        for relationship in request.relationships:
            definition = _find_relationship(config, relationship)
            _validate_confidence(
                config, relationship.confidence, relationship.provenance.extraction_method
            )
            _validate_properties(
                definition.properties,
                relationship.properties,
                definition=relationship.relationship_type,
            )
            source_id = node_lookup.get(
                (relationship.source_entity_type, relationship.source_canonical_id)
            ) or _node_id(config, relationship.source_entity_type, relationship.source_canonical_id)
            target_id = node_lookup.get(
                (relationship.target_entity_type, relationship.target_canonical_id)
            ) or _node_id(config, relationship.target_entity_type, relationship.target_canonical_id)
            provenance_json = relationship.provenance.model_dump(mode="json")
            evidence_seed = _evidence_id(
                f"{relationship.relationship_type}:{source_id}:{target_id}", provenance_json
            )
            edge_id = _stable_id(
                config.metadata.namespace,
                config.metadata.graph_id,
                relationship.relationship_type,
                source_id,
                target_id,
                evidence_seed,
            )
            edges.append(
                StoredEdge(
                    edge_id=edge_id,
                    namespace=config.metadata.namespace,
                    graph_id=config.metadata.graph_id,
                    relationship_type=relationship.relationship_type,
                    source_node_id=source_id,
                    target_node_id=target_id,
                    description=relationship.description,
                    rationale=relationship.rationale,
                    selection_context=tuple(relationship.selection_context),
                    properties=relationship.properties,
                    metadata=relationship.metadata,
                    chunk_ids=tuple(dict.fromkeys(relationship.chunk_ids)),
                    creation_details=relationship.creation_details,
                    confidence=relationship.confidence,
                    evidence_id=evidence_seed,
                    config_version=config.metadata.version,
                    created_at=relationship.creation_details.created_at,
                )
            )
            evidence.append(
                StoredEvidence(
                    evidence_id=evidence_seed,
                    subject_id=edge_id,
                    subject_kind="relationship",
                    graph_id=config.metadata.graph_id,
                    namespace=config.metadata.namespace,
                    confidence=relationship.confidence,
                    provenance=relationship.provenance,
                    created_at=now,
                )
            )

        return GraphWriteSet(
            namespace=config.metadata.namespace,
            graph_id=config.metadata.graph_id,
            config_version=config.metadata.version,
            idempotency_key=request.idempotency_key,
            nodes=tuple(nodes),
            edges=tuple(edges),
            evidence=tuple(evidence),
        )


def _find_entity(config: GraphConfig, entity_type: str) -> EntityDefinition:
    try:
        return config.entity(entity_type)
    except StopIteration as exc:
        raise GraphValidationError(f"entity type is not allowed: {entity_type}") from exc


def _find_relationship(config: GraphConfig, item: RelationshipInput) -> Any:
    try:
        definition = config.relationship(item.relationship_type)
    except StopIteration as exc:
        raise GraphValidationError(
            f"relationship type is not allowed: {item.relationship_type}"
        ) from exc
    if (definition.source, definition.target) != (
        item.source_entity_type,
        item.target_entity_type,
    ):
        raise GraphValidationError(
            f"{item.relationship_type} must connect {definition.source} to {definition.target}"
        )
    return definition


def _validate_confidence(config: GraphConfig, confidence: float, method: Any) -> None:
    if confidence < config.governance.minimum_confidence:
        raise GraphValidationError(
            f"confidence {confidence} is below minimum {config.governance.minimum_confidence}"
        )
    if confidence < config.governance.manual_review_below and str(method) != "manual":
        raise GraphValidationError(
            f"confidence {confidence} requires manual review below "
            f"{config.governance.manual_review_below}"
        )


def _validate_properties(
    schema: dict[str, PropertyDefinition], values: dict[str, Any], *, definition: str
) -> None:
    unknown = set(values) - set(schema)
    if unknown:
        raise GraphValidationError(
            f"{definition} contains unconfigured properties: {sorted(unknown)}"
        )
    missing = {name for name, item in schema.items() if item.required} - set(values)
    if missing:
        raise GraphValidationError(
            f"{definition} is missing required properties: {sorted(missing)}"
        )
    for name, value in values.items():
        expected = schema[name].type
        if not _matches_type(expected, value):
            raise GraphValidationError(f"{definition}.{name} must be {expected}")


def _matches_type(expected: PropertyType, value: Any) -> bool:
    if expected == PropertyType.STRING:
        return isinstance(value, str)
    if expected == PropertyType.INTEGER:
        return isinstance(value, int) and not isinstance(value, bool)
    if expected == PropertyType.NUMBER:
        return isinstance(value, (int, float)) and not isinstance(value, bool)
    if expected == PropertyType.BOOLEAN:
        return isinstance(value, bool)
    if expected == PropertyType.DATETIME:
        if not isinstance(value, str):
            return False
        try:
            datetime.fromisoformat(value.replace("Z", "+00:00"))
        except ValueError:
            return False
        return True
    return isinstance(value, (dict, list, str, int, float, bool)) or value is None


def _node_id(config: GraphConfig, entity_type: str, canonical_id: str) -> str:
    _find_entity(config, entity_type)
    return _stable_id(
        config.metadata.namespace,
        config.metadata.graph_id,
        entity_type,
        canonical_id.strip().casefold(),
    )


def _stable_id(*parts: str) -> str:
    return str(uuid.uuid5(ID_NAMESPACE, "\x1f".join(parts)))


def _evidence_id(subject_id: str, provenance: dict[str, Any]) -> str:
    payload = json.dumps(provenance, sort_keys=True, separators=(",", ":"))
    digest = hashlib.sha256(f"{subject_id}\x1f{payload}".encode()).hexdigest()
    return digest
