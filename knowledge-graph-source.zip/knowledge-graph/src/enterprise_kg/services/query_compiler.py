from __future__ import annotations

from dataclasses import dataclass

from enterprise_kg.config.models import Direction, TraversalDefinition


@dataclass(frozen=True, slots=True)
class CompiledTraversal:
    sql: str
    node_count: int
    edge_count: int


def compile_traversal(graph_name: str, traversal: TraversalDefinition) -> CompiledTraversal:
    """Compile only reviewed traversal metadata; user text never becomes query syntax."""

    pattern = "(n0:Entity)"
    for index, hop in enumerate(traversal.hops):
        edge = f"[e{index}:Relationship]"
        node = f"(n{index + 1}:Entity)"
        pattern += f"-{edge}->{node}" if hop.direction == Direction.OUTGOING else f"<-{edge}-{node}"

    filters = [
        "JSON_VALUE(n0.metadata, '$._system.namespace') = @namespace",
        "JSON_VALUE(n0.metadata, '$._system.graph_id') = @graph_id",
        "JSON_VALUE(n0.metadata, '$._system.entity_type') = @entity_type_0",
        "JSON_VALUE(n0.metadata, '$._system.canonical_id') = @start_canonical_id",
    ]
    for index, _hop in enumerate(traversal.hops):
        filters.extend(
            [
                f"JSON_VALUE(e{index}.metadata, '$._system.namespace') = @namespace",
                f"JSON_VALUE(e{index}.metadata, '$._system.graph_id') = @graph_id",
                f"JSON_VALUE(e{index}.metadata, '$._system.relationship_type') = "
                f"@relationship_type_{index}",
                f"JSON_VALUE(n{index + 1}.metadata, '$._system.namespace') = @namespace",
                f"JSON_VALUE(n{index + 1}.metadata, '$._system.graph_id') = @graph_id",
                f"JSON_VALUE(n{index + 1}.metadata, '$._system.entity_type') = "
                f"@entity_type_{index + 1}",
            ]
        )

    returns: list[str] = []
    for index in range(len(traversal.hops) + 1):
        returns.extend(
            [
                f"n{index}.metadata AS n{index}_metadata",
                f"n{index}.properties AS n{index}_properties",
                f"n{index}.chunk_ids AS n{index}_chunk_ids",
            ]
        )
    for index in range(len(traversal.hops)):
        returns.extend(
            [
                f"e{index}.edge_id AS e{index}_edge_id",
                f"e{index}.metadata AS e{index}_metadata",
                f"e{index}.confidence AS e{index}_confidence",
                f"e{index}.evidence_id AS e{index}_evidence_id",
                f"e{index}.properties AS e{index}_properties",
                f"e{index}.chunk_ids AS e{index}_chunk_ids",
            ]
        )

    sql = (
        f"GRAPH `{graph_name}`\n"
        f"MATCH {pattern}\n"
        f"WHERE {' AND '.join(filters)}\n"
        f"RETURN {', '.join(returns)}\n"
        "LIMIT @limit"
    )
    return CompiledTraversal(
        sql=sql,
        node_count=len(traversal.hops) + 1,
        edge_count=len(traversal.hops),
    )
