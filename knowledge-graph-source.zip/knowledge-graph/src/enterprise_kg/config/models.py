from __future__ import annotations

import re
from enum import StrEnum
from typing import Annotated, Any, Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

ENTITY_NAME = re.compile(r"^[A-Z][A-Za-z0-9_]{0,62}$")
RELATIONSHIP_NAME = re.compile(r"^[A-Z][A-Z0-9_]{0,62}$")
PROPERTY_NAME = re.compile(r"^[a-z][a-z0-9_]{0,62}$")
SLUG = re.compile(r"^[a-z][a-z0-9-]{1,62}$")
SEMVER = re.compile(r"^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)$")


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class PropertyType(StrEnum):
    STRING = "string"
    INTEGER = "integer"
    NUMBER = "number"
    BOOLEAN = "boolean"
    DATETIME = "datetime"
    JSON = "json"


class Direction(StrEnum):
    OUTGOING = "outgoing"
    INCOMING = "incoming"


class SecurityClassification(StrEnum):
    PUBLIC = "public"
    INTERNAL = "internal"
    CONFIDENTIAL = "confidential"
    RESTRICTED = "restricted"


class PropertyDefinition(StrictModel):
    type: PropertyType = PropertyType.STRING
    description: str = Field(min_length=3, max_length=500)
    required: bool = False
    indexed: bool = False


class EntityDefinition(StrictModel):
    name: str
    description: str = Field(min_length=10, max_length=2_000)
    identifiers: tuple[str, ...] = Field(min_length=1)
    aliases: tuple[str, ...] = ()
    properties: dict[str, PropertyDefinition] = Field(default_factory=dict)

    @model_validator(mode="after")
    def validate_entity(self) -> EntityDefinition:
        if not ENTITY_NAME.fullmatch(self.name):
            raise ValueError(f"invalid entity name: {self.name}")
        unknown = set(self.identifiers) - set(self.properties)
        if unknown:
            raise ValueError(f"identifier properties are undefined: {sorted(unknown)}")
        invalid = [name for name in self.properties if not PROPERTY_NAME.fullmatch(name)]
        if invalid:
            raise ValueError(f"invalid property names: {sorted(invalid)}")
        return self


class RelationshipDefinition(StrictModel):
    name: str
    source: str
    target: str
    description: str = Field(min_length=10, max_length=2_000)
    properties: dict[str, PropertyDefinition] = Field(default_factory=dict)

    @model_validator(mode="after")
    def validate_relationship(self) -> RelationshipDefinition:
        if not RELATIONSHIP_NAME.fullmatch(self.name):
            raise ValueError(f"invalid relationship name: {self.name}")
        invalid = [name for name in self.properties if not PROPERTY_NAME.fullmatch(name)]
        if invalid:
            raise ValueError(f"invalid property names: {sorted(invalid)}")
        return self


class OntologyDefinition(StrictModel):
    imports: tuple[str, ...] = ()
    entities: tuple[EntityDefinition, ...] = Field(min_length=1)
    relationships: tuple[RelationshipDefinition, ...] = Field(min_length=1)


class SourceDefinition(StrictModel):
    source_type: str = Field(min_length=2, max_length=100)
    formats: tuple[str, ...] = Field(min_length=1)
    extracts: tuple[str, ...] = Field(min_length=1)
    required_metadata: tuple[str, ...] = ()


class ResolutionRule(StrictModel):
    entity: str
    authoritative_identifiers: tuple[str, ...] = Field(min_length=1)
    alias_fields: tuple[str, ...] = ()
    automatic_match_threshold: float = Field(default=0.95, ge=0, le=1)
    review_threshold: float = Field(default=0.75, ge=0, le=1)

    @model_validator(mode="after")
    def validate_thresholds(self) -> ResolutionRule:
        if self.review_threshold > self.automatic_match_threshold:
            raise ValueError("review_threshold cannot exceed automatic_match_threshold")
        return self


class TraversalHop(StrictModel):
    relationship: str
    direction: Direction
    target: str


class TraversalDefinition(StrictModel):
    name: str
    description: str = Field(min_length=10, max_length=1_000)
    start_entity: str
    hops: tuple[TraversalHop, ...] = Field(min_length=1, max_length=8)
    max_results: int = Field(default=100, ge=1, le=1_000)

    @model_validator(mode="after")
    def validate_name(self) -> TraversalDefinition:
        if not PROPERTY_NAME.fullmatch(self.name):
            raise ValueError(f"invalid traversal name: {self.name}")
        return self


class RetrievalDefinition(StrictModel):
    max_hops: int = Field(default=5, ge=1, le=8)
    traversals: tuple[TraversalDefinition, ...] = Field(min_length=1)


class Metadata(StrictModel):
    graph_id: str
    namespace: str
    version: str
    owner: str = Field(min_length=3, max_length=200)
    description: str = Field(min_length=20, max_length=2_000)
    security_classification: SecurityClassification
    tags: tuple[str, ...] = ()

    @model_validator(mode="after")
    def validate_identifiers(self) -> Metadata:
        if not SLUG.fullmatch(self.graph_id):
            raise ValueError("graph_id must be a lowercase kebab-case slug")
        if not SLUG.fullmatch(self.namespace):
            raise ValueError("namespace must be a lowercase kebab-case slug")
        if not SEMVER.fullmatch(self.version):
            raise ValueError("version must use semantic versioning (x.y.z)")
        return self


class GovernanceDefinition(StrictModel):
    provenance_required: Literal[True] = True
    minimum_confidence: float = Field(default=0.70, ge=0, le=1)
    manual_review_below: float = Field(default=0.85, ge=0, le=1)
    allowed_roles: tuple[str, ...] = Field(min_length=1)

    @model_validator(mode="after")
    def validate_confidence(self) -> GovernanceDefinition:
        if self.manual_review_below < self.minimum_confidence:
            raise ValueError("manual_review_below cannot be less than minimum_confidence")
        valid_suffixes = ("-reader", "-writer", "-admin")
        invalid_roles = [role for role in self.allowed_roles if not role.endswith(valid_suffixes)]
        if invalid_roles:
            raise ValueError(
                f"allowed roles require reader, writer, or admin suffixes: {invalid_roles}"
            )
        return self


class GraphConfig(StrictModel):
    api_version: Literal["kg.platform/v1"]
    kind: Literal["KnowledgeGraph"]
    metadata: Metadata
    questions: tuple[str, ...] = Field(min_length=1)
    ontology: OntologyDefinition
    sources: tuple[SourceDefinition, ...] = Field(min_length=1)
    resolution: tuple[ResolutionRule, ...] = ()
    retrieval: RetrievalDefinition
    governance: GovernanceDefinition

    @model_validator(mode="after")
    def validate_references(self) -> GraphConfig:
        entity_map = {entity.name: entity for entity in self.ontology.entities}
        if len(entity_map) != len(self.ontology.entities):
            raise ValueError("duplicate entity names are not allowed")

        relationship_map = {item.name: item for item in self.ontology.relationships}
        if len(relationship_map) != len(self.ontology.relationships):
            raise ValueError("duplicate relationship names are not allowed")

        for relationship in self.ontology.relationships:
            if relationship.source not in entity_map or relationship.target not in entity_map:
                raise ValueError(f"relationship {relationship.name} references an undefined entity")

        source_types = {source.source_type for source in self.sources}
        if len(source_types) != len(self.sources):
            raise ValueError("duplicate source types are not allowed")
        resolution_entities = {rule.entity for rule in self.resolution}
        if len(resolution_entities) != len(self.resolution):
            raise ValueError("duplicate entity resolution rules are not allowed")

        for source in self.sources:
            unknown = set(source.extracts) - set(entity_map)
            if unknown:
                raise ValueError(
                    f"source {source.source_type} extracts undefined entities: {sorted(unknown)}"
                )

        for rule in self.resolution:
            entity = entity_map.get(rule.entity)
            if entity is None:
                raise ValueError(f"resolution rule references undefined entity: {rule.entity}")
            unknown = set(rule.authoritative_identifiers) - set(entity.properties)
            if unknown:
                raise ValueError(
                    f"resolution rule for {rule.entity} references undefined properties: "
                    f"{sorted(unknown)}"
                )

        traversal_names: set[str] = set()
        for traversal in self.retrieval.traversals:
            if traversal.name in traversal_names:
                raise ValueError(f"duplicate traversal name: {traversal.name}")
            traversal_names.add(traversal.name)
            if len(traversal.hops) > self.retrieval.max_hops:
                raise ValueError(f"traversal {traversal.name} exceeds max_hops")
            current = traversal.start_entity
            if current not in entity_map:
                raise ValueError(f"traversal starts at undefined entity: {current}")
            for hop in traversal.hops:
                current_relationship = relationship_map.get(hop.relationship)
                if current_relationship is None:
                    raise ValueError(
                        f"traversal {traversal.name} uses undefined relationship: "
                        f"{hop.relationship}"
                    )
                expected_source = (
                    current_relationship.source
                    if hop.direction == Direction.OUTGOING
                    else current_relationship.target
                )
                expected_target = (
                    current_relationship.target
                    if hop.direction == Direction.OUTGOING
                    else current_relationship.source
                )
                if current != expected_source or hop.target != expected_target:
                    raise ValueError(
                        f"invalid hop {hop.relationship} from {current} to {hop.target} "
                        f"with direction {hop.direction}"
                    )
                current = hop.target
        return self

    @property
    def config_key(self) -> str:
        return f"{self.metadata.namespace}/{self.metadata.graph_id}@{self.metadata.version}"

    def entity(self, name: str) -> EntityDefinition:
        return next(item for item in self.ontology.entities if item.name == name)

    def relationship(self, name: str) -> RelationshipDefinition:
        return next(item for item in self.ontology.relationships if item.name == name)

    def traversal(self, name: str) -> TraversalDefinition:
        return next(item for item in self.retrieval.traversals if item.name == name)


JsonValue = Annotated[Any, Field(description="JSON-compatible value")]
