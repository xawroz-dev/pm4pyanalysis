from __future__ import annotations

import hashlib
from collections.abc import Iterable
from dataclasses import dataclass
from pathlib import Path

import yaml
from pydantic import ValidationError

from enterprise_kg.config.models import GraphConfig
from enterprise_kg.domain.exceptions import ConfigNotFoundError, ConfigValidationError


@dataclass(frozen=True, slots=True)
class LoadedConfig:
    config: GraphConfig
    checksum: str
    source: Path | None


def parse_config(document: str, *, source: Path | None = None) -> LoadedConfig:
    try:
        raw = yaml.safe_load(document)
        if not isinstance(raw, dict):
            raise ConfigValidationError("configuration root must be a mapping")
        config = GraphConfig.model_validate(raw)
    except yaml.YAMLError as exc:
        raise ConfigValidationError(f"invalid YAML: {exc}") from exc
    except ValidationError as exc:
        raise ConfigValidationError.from_pydantic(exc) from exc
    checksum = hashlib.sha256(document.encode("utf-8")).hexdigest()
    return LoadedConfig(config=config, checksum=checksum, source=source)


class FileConfigRegistry:
    """Immutable, process-local snapshot of reviewed configuration files."""

    def __init__(self, directory: Path) -> None:
        self._directory = directory
        self._configs: dict[tuple[str, str], LoadedConfig] = {}
        self._active: dict[str, str] = {}

    def load(self) -> None:
        loaded: dict[tuple[str, str], LoadedConfig] = {}
        for path in sorted(self._directory.glob("*.y*ml")):
            item = parse_config(path.read_text(encoding="utf-8"), source=path)
            key = (item.config.metadata.graph_id, item.config.metadata.version)
            if key in loaded:
                raise ConfigValidationError(
                    f"duplicate graph/version configuration: {key[0]}@{key[1]}"
                )
            loaded[key] = item
        if not loaded:
            raise ConfigValidationError(f"no configuration files found in {self._directory}")
        self._configs = loaded
        for graph_id, version in loaded:
            if graph_id not in self._active or _semver(version) > _semver(self._active[graph_id]):
                self._active[graph_id] = version

    def list(self) -> Iterable[LoadedConfig]:
        return self._configs.values()

    def get(self, graph_id: str, version: str | None = None) -> LoadedConfig:
        selected_version = version or self._active.get(graph_id)
        if selected_version is None:
            raise ConfigNotFoundError(graph_id)
        try:
            return self._configs[(graph_id, selected_version)]
        except KeyError as exc:
            raise ConfigNotFoundError(f"{graph_id}@{selected_version}") from exc

    def activate(self, graph_id: str, version: str) -> LoadedConfig:
        item = self.get(graph_id, version)
        self._active[graph_id] = version
        return item

    def active_version(self, graph_id: str) -> str:
        try:
            return self._active[graph_id]
        except KeyError as exc:
            raise ConfigNotFoundError(graph_id) from exc


def _semver(value: str) -> tuple[int, int, int]:
    return tuple(int(part) for part in value.split("."))  # type: ignore[return-value]
