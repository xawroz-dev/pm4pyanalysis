import uvicorn


def run() -> None:
    uvicorn.run("enterprise_kg.api.app:app", host="0.0.0.0", port=8080, reload=False)  # noqa: S104


if __name__ == "__main__":
    run()
