"""Config-driven enterprise knowledge graph platform."""

__version__ = "0.1.0"
