from __future__ import annotations

import json
import os
import re
from collections.abc import Mapping
from pathlib import Path
from typing import Any, cast

from google.cloud import spanner
from google.cloud.spanner_v1 import param_types
from google.cloud.spanner_v1.data_types import JsonObject

from enterprise_kg.config.models import GraphConfig, TraversalDefinition
from enterprise_kg.domain.exceptions import NotFoundError, RepositoryUnavailableError
from enterprise_kg.domain.models import (
    GraphWriteSet,
    IngestionResult,
    NodeSearchRequest,
    PathEdge,
    PathNode,
    Provenance,
    RelationshipCreationDetails,
    StoredEdge,
    StoredEvidence,
    StoredNode,
    TraversalPath,
)
from enterprise_kg.services.query_compiler import compile_traversal
from enterprise_kg.settings import Settings

SAFE_IDENTIFIER = re.compile(r"^[A-Za-z][A-Za-z0-9_]{0,127}$")


def create_database(settings: Settings) -> Any:
    if settings.spanner_emulator_host:
        os.environ.setdefault("SPANNER_EMULATOR_HOST", settings.spanner_emulator_host)
    client: Any = spanner.Client(project=settings.spanner_project)
    instance = client.instance(settings.spanner_instance)
    return instance.database(settings.spanner_database)


def bootstrap_spanner(settings: Settings, schema_file: Path) -> None:
    """Create local emulator resources and apply the baseline or pending migration."""

    if not SAFE_IDENTIFIER.fullmatch(settings.spanner_graph):
        raise ValueError("unsafe Spanner property graph identifier")
    if settings.spanner_emulator_host:
        os.environ.setdefault("SPANNER_EMULATOR_HOST", settings.spanner_emulator_host)
    client: Any = spanner.Client(project=settings.spanner_project)
    instance = client.instance(
        settings.spanner_instance,
        configuration_name="emulator-config",
        node_count=1,
    )
    if not instance.exists():
        instance.create().result(timeout=60)
    database = instance.database(settings.spanner_database)
    if not database.exists():
        database.create().result(timeout=60)
    if not _table_exists(database, "GraphNode"):
        _apply_schema(database, settings.spanner_graph, schema_file)
        return
    if not _column_exists(database, "GraphNode", "metadata"):
        _apply_schema(
            database,
            settings.spanner_graph,
            schema_file.with_name("002_element_metadata.sql"),
        )
    if not _column_exists(database, "GraphNode", "chunk_ids"):
        if _table_has_rows(database, "GraphNode"):
            raise RuntimeError(
                "generic element migration requires metadata backfill before contracting "
                "a non-empty GraphNode table; follow docs/operations.md"
            )
        _apply_schema(
            database,
            settings.spanner_graph,
            schema_file.with_name("003_generic_elements.sql"),
        )


def _apply_schema(database: Any, graph_name: str, schema_file: Path) -> None:
    schema = schema_file.read_text(encoding="utf-8")
    schema = schema.replace(
        "PROPERTY GRAPH EnterpriseKnowledgeGraph",
        f"PROPERTY GRAPH {graph_name}",
    )
    statements = _split_ddl(schema)
    database.update_ddl(statements).result(timeout=180)


def _table_exists(database: Any, table_name: str) -> bool:
    with database.snapshot() as snapshot:
        rows = list(
            snapshot.execute_sql(
                "SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = @table_name",
                params={"table_name": table_name},
                param_types={"table_name": param_types.STRING},
            )
        )
    return bool(rows and rows[0][0])


def _column_exists(database: Any, table_name: str, column_name: str) -> bool:
    with database.snapshot() as snapshot:
        rows = list(
            snapshot.execute_sql(
                """
                SELECT COUNT(*)
                FROM INFORMATION_SCHEMA.COLUMNS
                WHERE TABLE_NAME = @table_name AND COLUMN_NAME = @column_name
                """,
                params={"table_name": table_name, "column_name": column_name},
                param_types={
                    "table_name": param_types.STRING,
                    "column_name": param_types.STRING,
                },
            )
        )
    return bool(rows and rows[0][0])


def _table_has_rows(database: Any, table_name: str) -> bool:
    if table_name not in {"GraphNode", "GraphEdge"}:
        raise ValueError("unsupported table name")
    with database.snapshot() as snapshot:
        rows = list(
            snapshot.execute_sql(f"SELECT 1 FROM {table_name} LIMIT 1")  # noqa: S608
        )
    return bool(rows)


def _split_ddl(document: str) -> list[str]:
    lines = [line for line in document.splitlines() if not line.lstrip().startswith("--")]
    return [statement.strip() for statement in "\n".join(lines).split(";") if statement.strip()]


class SpannerGraphRepository:
    def __init__(self, settings: Settings) -> None:
        if not SAFE_IDENTIFIER.fullmatch(settings.spanner_graph):
            raise ValueError("unsafe Spanner property graph identifier")
        self._database = create_database(settings)
        self._graph_name = settings.spanner_graph

    def apply(self, write_set: GraphWriteSet) -> IngestionResult:
        def commit(transaction: Any) -> IngestionResult:
            existing = list(
                transaction.execute_sql(
                    """
                    SELECT config_version, nodes_upserted, edges_upserted, evidence_upserted
                    FROM IngestionBatch
                    WHERE namespace=@namespace AND graph_id=@graph_id
                      AND idempotency_key=@idempotency_key
                    """,
                    params={
                        "namespace": write_set.namespace,
                        "graph_id": write_set.graph_id,
                        "idempotency_key": write_set.idempotency_key,
                    },
                    param_types={
                        "namespace": param_types.STRING,
                        "graph_id": param_types.STRING,
                        "idempotency_key": param_types.STRING,
                    },
                )
            )
            if existing:
                version, node_count, edge_count, evidence_count = existing[0]
                return IngestionResult(
                    graph_id=write_set.graph_id,
                    namespace=write_set.namespace,
                    config_version=version,
                    idempotency_key=write_set.idempotency_key,
                    nodes_upserted=node_count,
                    edges_upserted=edge_count,
                    evidence_upserted=evidence_count,
                    replayed=True,
                )

            if write_set.nodes:
                node_ids = [node.node_id for node in write_set.nodes]
                existing_chunks = {
                    row[0]: list(row[1] or [])
                    for row in transaction.execute_sql(
                        "SELECT node_id, chunk_ids FROM GraphNode "
                        "WHERE node_id IN UNNEST(@node_ids)",
                        params={"node_ids": node_ids},
                        param_types={
                            "node_ids": param_types.Array(  # type: ignore[no-untyped-call]
                                param_types.STRING
                            )
                        },
                    )
                }
                merged_chunks = {
                    node.node_id: list(
                        dict.fromkeys([*existing_chunks.get(node.node_id, []), *node.chunk_ids])
                    )
                    for node in write_set.nodes
                }
                transaction.insert_or_update(
                    "GraphNode",
                    columns=(
                        "node_id",
                        "metadata",
                        "properties",
                        "chunk_ids",
                        "updated_at",
                    ),
                    values=[
                        (
                            node.node_id,
                            JsonObject(  # type: ignore[no-untyped-call]
                                _node_metadata(node)
                            ),
                            JsonObject(node.properties),  # type: ignore[no-untyped-call]
                            merged_chunks[node.node_id],
                            node.updated_at,
                        )
                        for node in write_set.nodes
                    ],
                )
                chunk_links = [
                    (chunk_id, node.node_id)
                    for node in write_set.nodes
                    for chunk_id in merged_chunks[node.node_id]
                ]
                if chunk_links:
                    transaction.insert_or_update(
                        "GraphNodeChunk",
                        columns=("chunk_id", "node_id"),
                        values=chunk_links,
                    )
            if write_set.edges:
                transaction.insert_or_update(
                    "GraphEdge",
                    columns=(
                        "edge_id",
                        "source_node_id",
                        "target_node_id",
                        "metadata",
                        "properties",
                        "chunk_ids",
                        "confidence",
                        "evidence_id",
                        "created_at",
                    ),
                    values=[
                        (
                            edge.edge_id,
                            edge.source_node_id,
                            edge.target_node_id,
                            JsonObject(_edge_metadata(edge)),  # type: ignore[no-untyped-call]
                            JsonObject(edge.properties),  # type: ignore[no-untyped-call]
                            list(edge.chunk_ids),
                            edge.confidence,
                            edge.evidence_id,
                            edge.created_at,
                        )
                        for edge in write_set.edges
                    ],
                )
            if write_set.evidence:
                transaction.insert_or_update(
                    "GraphEvidence",
                    columns=(
                        "evidence_id",
                        "subject_id",
                        "subject_kind",
                        "namespace",
                        "graph_id",
                        "confidence",
                        "provenance",
                        "created_at",
                    ),
                    values=[
                        (
                            item.evidence_id,
                            item.subject_id,
                            item.subject_kind,
                            item.namespace,
                            item.graph_id,
                            item.confidence,
                            JsonObject(  # type: ignore[no-untyped-call]
                                item.provenance.model_dump(mode="json")
                            ),
                            item.created_at,
                        )
                        for item in write_set.evidence
                    ],
                )
            transaction.insert(
                "IngestionBatch",
                columns=(
                    "namespace",
                    "graph_id",
                    "idempotency_key",
                    "config_version",
                    "nodes_upserted",
                    "edges_upserted",
                    "evidence_upserted",
                    "committed_at",
                ),
                values=[
                    (
                        write_set.namespace,
                        write_set.graph_id,
                        write_set.idempotency_key,
                        write_set.config_version,
                        len(write_set.nodes),
                        len(write_set.edges),
                        len(write_set.evidence),
                        spanner.COMMIT_TIMESTAMP,
                    )
                ],
            )
            return IngestionResult(
                graph_id=write_set.graph_id,
                namespace=write_set.namespace,
                config_version=write_set.config_version,
                idempotency_key=write_set.idempotency_key,
                nodes_upserted=len(write_set.nodes),
                edges_upserted=len(write_set.edges),
                evidence_upserted=len(write_set.evidence),
                replayed=False,
            )

        return cast(IngestionResult, self._database.run_in_transaction(commit))

    def traverse(
        self,
        config: GraphConfig,
        traversal: TraversalDefinition,
        start_canonical_id: str,
        limit: int,
    ) -> list[TraversalPath]:
        compiled = compile_traversal(self._graph_name, traversal)
        params: dict[str, Any] = {
            "namespace": config.metadata.namespace,
            "graph_id": config.metadata.graph_id,
            "entity_type_0": traversal.start_entity,
            "start_canonical_id": start_canonical_id,
            "limit": limit,
        }
        types: dict[str, Any] = {
            "namespace": param_types.STRING,
            "graph_id": param_types.STRING,
            "entity_type_0": param_types.STRING,
            "start_canonical_id": param_types.STRING,
            "limit": param_types.INT64,
        }
        for index, hop in enumerate(traversal.hops):
            params[f"relationship_type_{index}"] = hop.relationship
            params[f"entity_type_{index + 1}"] = hop.target
            types[f"relationship_type_{index}"] = param_types.STRING
            types[f"entity_type_{index + 1}"] = param_types.STRING

        with self._database.snapshot() as snapshot:
            rows = list(snapshot.execute_sql(compiled.sql, params=params, param_types=types))
        return [_decode_path(row, compiled.node_count, compiled.edge_count) for row in rows]

    def evidence(self, namespace: str, graph_id: str, evidence_id: str) -> StoredEvidence:
        with self._database.snapshot() as snapshot:
            rows = list(
                snapshot.execute_sql(
                    """
                    SELECT evidence_id, subject_id, subject_kind, graph_id, namespace,
                           confidence, provenance, created_at
                    FROM GraphEvidence
                    WHERE namespace=@namespace AND graph_id=@graph_id AND evidence_id=@evidence_id
                    """,
                    params={
                        "namespace": namespace,
                        "graph_id": graph_id,
                        "evidence_id": evidence_id,
                    },
                    param_types={
                        "namespace": param_types.STRING,
                        "graph_id": param_types.STRING,
                        "evidence_id": param_types.STRING,
                    },
                )
            )
        if not rows:
            raise NotFoundError(evidence_id)
        row = rows[0]
        return StoredEvidence(
            evidence_id=row[0],
            subject_id=row[1],
            subject_kind=row[2],
            graph_id=row[3],
            namespace=row[4],
            confidence=row[5],
            provenance=Provenance.model_validate(_json_value(row[6])),
            created_at=row[7],
        )

    def search_nodes(self, config: GraphConfig, request: NodeSearchRequest) -> list[PathNode]:
        filters = [
            "JSON_VALUE(metadata, '$._system.namespace')=@namespace",
            "JSON_VALUE(metadata, '$._system.graph_id')=@graph_id",
        ]
        params: dict[str, Any] = {
            "namespace": config.metadata.namespace,
            "graph_id": config.metadata.graph_id,
            "limit": request.limit,
        }
        types: dict[str, Any] = {
            "namespace": param_types.STRING,
            "graph_id": param_types.STRING,
            "limit": param_types.INT64,
        }
        if request.entity_type:
            filters.append("JSON_VALUE(metadata, '$._system.entity_type')=@entity_type")
            params["entity_type"] = request.entity_type
            types["entity_type"] = param_types.STRING
        if request.name_prefix:
            filters.append(
                "STARTS_WITH(LOWER(JSON_VALUE(metadata, '$._system.canonical_name')), "
                "LOWER(@name_prefix))"
            )
            params["name_prefix"] = request.name_prefix
            types["name_prefix"] = param_types.STRING
        if request.chunk_id:
            filters.append("@chunk_id IN UNNEST(chunk_ids)")
            params["chunk_id"] = request.chunk_id
            types["chunk_id"] = param_types.STRING
        for index, (path, value) in enumerate(request.metadata_equals.items()):
            parameter = f"metadata_value_{index}"
            filters.append(f"JSON_VALUE(metadata, '{_metadata_json_path(path)}')=@{parameter}")
            params[parameter] = _scalar_text(value)
            types[parameter] = param_types.STRING
        # JSON paths are built only from model-validated key segments; values remain bound.
        sql = f"""
            SELECT node_id, metadata, properties, chunk_ids
            FROM GraphNode
            WHERE {" AND ".join(filters)}
            ORDER BY JSON_VALUE(metadata, '$._system.canonical_name'), node_id
            LIMIT @limit
        """  # noqa: S608
        with self._database.snapshot() as snapshot:
            rows = list(snapshot.execute_sql(sql, params=params, param_types=types))
        return [_decode_node(row[0], row[1], row[2], row[3]) for row in rows]

    def entities_for_chunk(self, config: GraphConfig, chunk_id: str) -> list[PathNode]:
        with self._database.snapshot() as snapshot:
            rows = list(
                snapshot.execute_sql(
                    """
                    SELECT n.node_id, n.metadata, n.properties, n.chunk_ids
                    FROM GraphNodeChunk c
                    JOIN GraphNode n ON n.node_id = c.node_id
                    WHERE c.chunk_id=@chunk_id
                      AND JSON_VALUE(n.metadata, '$._system.namespace')=@namespace
                      AND JSON_VALUE(n.metadata, '$._system.graph_id')=@graph_id
                    ORDER BY JSON_VALUE(n.metadata, '$._system.canonical_name'), n.node_id
                    LIMIT 1000
                    """,
                    params={
                        "chunk_id": chunk_id,
                        "namespace": config.metadata.namespace,
                        "graph_id": config.metadata.graph_id,
                    },
                    param_types={
                        "chunk_id": param_types.STRING,
                        "namespace": param_types.STRING,
                        "graph_id": param_types.STRING,
                    },
                )
            )
        return [_decode_node(row[0], row[1], row[2], row[3]) for row in rows]

    def ready(self) -> bool:
        try:
            with self._database.snapshot() as snapshot:
                return list(snapshot.execute_sql("SELECT 1")) == [[1]]
        except Exception as exc:  # readiness intentionally converts infrastructure errors
            raise RepositoryUnavailableError("Spanner is unavailable") from exc


def _decode_path(row: Any, node_count: int, edge_count: int) -> TraversalPath:
    offset = 0
    nodes: list[PathNode] = []
    for _ in range(node_count):
        nodes.append(_decode_node("", row[offset], row[offset + 1], row[offset + 2]))
        offset += 3
    edges: list[PathEdge] = []
    for _ in range(edge_count):
        metadata, system = _split_metadata(row[offset + 1])
        edges.append(
            PathEdge(
                edge_id=row[offset],
                relationship_type=str(system["relationship_type"]),
                description=str(system["description"]),
                rationale=str(system["rationale"]),
                selection_context=list(system["selection_context"]),
                confidence=row[offset + 2],
                evidence_id=row[offset + 3],
                properties=_json_value(row[offset + 4]),
                metadata=metadata,
                chunk_ids=list(row[offset + 5] or []),
                creation_details=RelationshipCreationDetails.model_validate(
                    system["creation_details"]
                ),
            )
        )
        offset += 6
    return TraversalPath(nodes=nodes, edges=edges)


def _decode_node(node_id: str, metadata_value: Any, properties: Any, chunk_ids: Any) -> PathNode:
    metadata, system = _split_metadata(metadata_value)
    return PathNode(
        node_id=node_id or str(system["node_id"]),
        entity_type=str(system["entity_type"]),
        canonical_id=str(system["canonical_id"]),
        canonical_name=str(system["canonical_name"]),
        properties=_json_value(properties),
        metadata=metadata,
        chunk_ids=list(chunk_ids or []),
    )


def _split_metadata(value: Any) -> tuple[dict[str, Any], dict[str, Any]]:
    metadata = _json_value(value)
    system = metadata.pop("_system", {})
    return metadata, system if isinstance(system, dict) else {}


def _node_metadata(node: StoredNode) -> dict[str, Any]:
    return {
        **node.metadata,
        "_system": {
            "node_id": node.node_id,
            "namespace": node.namespace,
            "graph_id": node.graph_id,
            "entity_type": node.entity_type,
            "canonical_id": node.canonical_id,
            "canonical_name": node.canonical_name,
            "aliases": list(node.aliases),
            "config_version": node.config_version,
        },
    }


def _edge_metadata(edge: StoredEdge) -> dict[str, Any]:
    return {
        **edge.metadata,
        "_system": {
            "namespace": edge.namespace,
            "graph_id": edge.graph_id,
            "relationship_type": edge.relationship_type,
            "description": edge.description,
            "rationale": edge.rationale,
            "selection_context": list(edge.selection_context),
            "creation_details": edge.creation_details.model_dump(mode="json"),
            "config_version": edge.config_version,
        },
    }


def _metadata_json_path(path: str) -> str:
    return "$." + ".".join(f'"{segment}"' for segment in path.split("."))


def _scalar_text(value: str | int | float | bool) -> str:
    if isinstance(value, bool):
        return str(value).lower()
    return str(value)


def _json_value(value: Any) -> dict[str, Any]:
    if isinstance(value, Mapping):
        return dict(value)
    if isinstance(value, str):
        parsed = json.loads(value)
        return parsed if isinstance(parsed, dict) else {}
    serialize = getattr(value, "serialize", None)
    if callable(serialize):
        parsed = json.loads(serialize())
        return parsed if isinstance(parsed, dict) else {}
    return {}
