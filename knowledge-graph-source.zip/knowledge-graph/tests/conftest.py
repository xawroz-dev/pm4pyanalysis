from __future__ import annotations

import json
from pathlib import Path

import pytest

from enterprise_kg.config.loader import FileConfigRegistry
from enterprise_kg.domain.models import IngestionRequest
from enterprise_kg.repositories.memory import MemoryGraphRepository
from enterprise_kg.services.graph_service import GraphService

ROOT = Path(__file__).resolve().parents[1]


@pytest.fixture
def registry() -> FileConfigRegistry:
    item = FileConfigRegistry(ROOT / "configs")
    item.load()
    return item


@pytest.fixture
def repository() -> MemoryGraphRepository:
    return MemoryGraphRepository()


@pytest.fixture
def service(registry: FileConfigRegistry, repository: MemoryGraphRepository) -> GraphService:
    return GraphService(registry, repository)


@pytest.fixture
def process_request() -> IngestionRequest:
    raw = json.loads((ROOT / "sample_data" / "process-risk.json").read_text())
    return IngestionRequest.model_validate(raw)
