from __future__ import annotations

from enterprise_kg.domain.models import IngestionRequest, TraversalRequest
from enterprise_kg.services.graph_service import GraphService


def test_same_canonical_id_is_isolated_by_namespace(
    service: GraphService, process_request: IngestionRequest
) -> None:
    service.ingest("process-risk", process_request)
    provenance = {
        "source_id": "CAT-1",
        "document_uri": "gs://strategy/catalog.json",
        "document_version": "1.0",
        "locator": "record 1",
        "extraction_method": "import",
        "observed_at": "2026-08-15T12:00:00Z",
    }
    metadata = {
        "business_domain": "Commercial Strategy",
        "source_system": "Product Catalog",
        "owner": "Commercial Product Strategy",
        "security_classification": "confidential",
        "status": "active",
        "tags": ["isolation-test"],
    }
    product_request = IngestionRequest.model_validate(
        {
            "config_version": "1.0.0",
            "source_type": "ProductCatalog",
            "source_metadata": {
                "catalog_id": "CAT-1",
                "version": "1.0",
                "classification": "confidential",
            },
            "idempotency_key": "product-market-isolation-v1",
            "entities": [
                {
                    "entity_type": "Market",
                    "canonical_id": "PROC-1001",
                    "canonical_name": "United States",
                    "properties": {"market_id": "PROC-1001", "country_code": "US"},
                    "metadata": metadata,
                    "confidence": 1,
                    "provenance": provenance,
                },
                {
                    "entity_type": "Product",
                    "canonical_id": "PROD-1",
                    "canonical_name": "Commercial Card",
                    "properties": {"product_id": "PROD-1", "lifecycle": "active"},
                    "metadata": metadata,
                    "confidence": 1,
                    "provenance": provenance,
                },
            ],
            "relationships": [
                {
                    "relationship_type": "OFFERS",
                    "source_entity_type": "Market",
                    "source_canonical_id": "PROC-1001",
                    "target_entity_type": "Product",
                    "target_canonical_id": "PROD-1",
                    "description": "The United States market offers the Commercial Card product.",
                    "rationale": "The catalog explicitly lists the product for this market.",
                    "selection_context": ["Use for market and product isolation tests."],
                    "confidence": 1,
                    "properties": {},
                    "metadata": metadata,
                    "creation_details": {
                        "method": "import",
                        "generator": "test-catalog-importer",
                        "pipeline_run_id": "isolation-run-1",
                        "created_by": "test-suite",
                        "created_at": "2026-08-15T12:00:00Z",
                        "review_status": "not_required",
                    },
                    "provenance": provenance,
                }
            ],
        }
    )
    service.ingest("product-market", product_request)

    payments = service.traverse(
        "process-risk",
        TraversalRequest(traversal="process_systems", start_canonical_id="PROC-1001"),
    )
    strategy = service.traverse(
        "product-market",
        TraversalRequest(traversal="market_products", start_canonical_id="PROC-1001"),
    )
    assert payments.paths[0].nodes[-1].canonical_name == "Global Payment Gateway"
    assert strategy.paths[0].nodes[-1].canonical_name == "Commercial Card"
