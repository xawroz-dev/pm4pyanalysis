from pathlib import Path

import pytest

from enterprise_kg.config.loader import FileConfigRegistry, parse_config
from enterprise_kg.domain.exceptions import ConfigNotFoundError, ConfigValidationError

ROOT = Path(__file__).resolve().parents[2]


def test_loads_both_team_configs(registry: FileConfigRegistry) -> None:
    loaded = list(registry.list())
    assert {item.config.metadata.graph_id for item in loaded} == {
        "process-risk",
        "product-market",
    }
    assert registry.active_version("process-risk") == "1.0.0"


def test_activation_is_graph_scoped(registry: FileConfigRegistry) -> None:
    selected = registry.activate("product-market", "1.0.0")
    assert selected.config.metadata.namespace == "commercial-strategy"
    assert registry.active_version("process-risk") == "1.0.0"


def test_unknown_graph_is_rejected(registry: FileConfigRegistry) -> None:
    with pytest.raises(ConfigNotFoundError):
        registry.get("missing")


def test_relationship_to_unknown_entity_fails() -> None:
    document = (ROOT / "configs" / "process-risk.yaml").read_text()
    document = document.replace("target: System", "target: Vendor", 1)
    with pytest.raises(ConfigValidationError) as raised:
        parse_config(document)
    assert any("undefined entity" in issue.message for issue in raised.value.issues)


def test_invalid_traversal_direction_fails() -> None:
    document = (ROOT / "configs" / "process-risk.yaml").read_text()
    document = document.replace(
        "{relationship: USES, direction: outgoing, target: System}",
        "{relationship: USES, direction: incoming, target: System}",
        1,
    )
    with pytest.raises(ConfigValidationError) as raised:
        parse_config(document)
    assert any("invalid hop" in issue.message for issue in raised.value.issues)


def test_non_mapping_yaml_fails() -> None:
    with pytest.raises(ConfigValidationError, match="root must be a mapping"):
        parse_config("- one\n- two\n")
