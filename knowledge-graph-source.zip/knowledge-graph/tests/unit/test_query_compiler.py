from enterprise_kg.config.loader import FileConfigRegistry
from enterprise_kg.services.query_compiler import compile_traversal


def test_compiler_uses_parameters_and_base_labels(registry: FileConfigRegistry) -> None:
    config = registry.get("process-risk").config
    compiled = compile_traversal(
        "EnterpriseKnowledgeGraph", config.traversal("process_risk_controls")
    )
    expected = "MATCH (n0:Entity)-[e0:Relationship]->(n1:Entity)<-[e1:Relationship]-(n2:Entity)"
    assert expected in compiled.sql
    assert "@namespace" in compiled.sql
    assert "@start_canonical_id" in compiled.sql
    assert "PROC-1001" not in compiled.sql
    assert "n0.metadata AS n0_metadata" in compiled.sql
    assert "n0.chunk_ids AS n0_chunk_ids" in compiled.sql
    assert "e0.metadata AS e0_metadata" in compiled.sql
    assert "JSON_VALUE(n0.metadata, '$._system.entity_type')" in compiled.sql
    assert compiled.node_count == 3
    assert compiled.edge_count == 2
