from pathlib import Path

import pytest
from fastapi.testclient import TestClient
from pydantic import ValidationError

from enterprise_kg.api.app import create_app
from enterprise_kg.repositories.memory import MemoryGraphRepository
from enterprise_kg.settings import Settings

ROOT = Path(__file__).resolve().parents[2]


def test_api_health_and_config_listing() -> None:
    settings = Settings(
        environment="test",
        repository_backend="memory",
        config_directory=ROOT / "configs",
    )
    with TestClient(create_app(settings, MemoryGraphRepository())) as client:
        assert client.get("/health/live").json() == {"status": "ok"}
        assert client.get("/health/ready").json() == {"status": "ready"}
        configs = client.get("/v1/configurations")
        assert configs.status_code == 200
        assert {item["graph_id"] for item in configs.json()} == {
            "process-risk",
            "product-market",
        }


def test_api_maps_domain_validation_error() -> None:
    settings = Settings(
        environment="test",
        repository_backend="memory",
        config_directory=ROOT / "configs",
    )
    payload = (ROOT / "sample_data" / "process-risk.json").read_text()
    import json

    request = json.loads(payload)
    request["entities"][0]["entity_type"] = "Unknown"
    with TestClient(create_app(settings, MemoryGraphRepository())) as client:
        response = client.post("/v1/graphs/process-risk/ingestions", json=request)
    assert response.status_code == 422
    assert response.json()["code"] == "graph_fact_invalid"


def test_metadata_node_search_api() -> None:
    import json

    settings = Settings(
        environment="test",
        repository_backend="memory",
        config_directory=ROOT / "configs",
    )
    payload = json.loads((ROOT / "sample_data" / "process-risk.json").read_text())
    with TestClient(create_app(settings, MemoryGraphRepository())) as client:
        assert client.post("/v1/graphs/process-risk/ingestions", json=payload).status_code == 200
        response = client.post(
            "/v1/graphs/process-risk/nodes/search",
            json={
                "metadata_equals": {"business_domain": "Enterprise Risk"},
                "chunk_id": "chunk-riskreg-2026-q3-risk-3001",
            },
        )
    assert response.status_code == 200
    assert {node["canonical_id"] for node in response.json()["nodes"]} == {
        "CTRL-4001",
        "RISK-3001",
    }


def test_chunk_to_entities_api() -> None:
    import json

    settings = Settings(
        environment="test",
        repository_backend="memory",
        config_directory=ROOT / "configs",
    )
    payload = json.loads((ROOT / "sample_data" / "process-risk.json").read_text())
    with TestClient(create_app(settings, MemoryGraphRepository())) as client:
        client.post("/v1/graphs/process-risk/ingestions", json=payload)
        response = client.get("/v1/graphs/process-risk/chunks/chunk-arch-22-section-3-2/entities")
    assert response.status_code == 200
    assert {node["canonical_id"] for node in response.json()["nodes"]} == {
        "PROC-1001",
        "SYS-2001",
    }


def test_production_cannot_disable_authentication() -> None:
    with pytest.raises(ValidationError, match="production requires"):
        Settings(environment="production", auth_mode="disabled")


def test_trusted_header_authentication_and_roles() -> None:
    settings = Settings(
        environment="test",
        auth_mode="trusted_headers",
        repository_backend="memory",
        config_directory=ROOT / "configs",
    )
    with TestClient(create_app(settings, MemoryGraphRepository())) as client:
        assert client.get("/v1/configurations").status_code == 401
        hidden = client.get(
            "/v1/configurations",
            headers={"x-kg-principal": "user-1", "x-kg-roles": "unrelated-role"},
        )
        assert hidden.json() == []
        visible = client.get(
            "/v1/configurations",
            headers={
                "x-kg-principal": "payments-reader",
                "x-kg-roles": "payments-kg-reader",
            },
        )
        assert [item["graph_id"] for item in visible.json()] == ["process-risk"]
