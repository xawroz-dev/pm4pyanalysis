from __future__ import annotations

from copy import deepcopy

import pytest
from pydantic import ValidationError

from enterprise_kg.domain.exceptions import GraphValidationError
from enterprise_kg.domain.models import IngestionRequest, NodeSearchRequest, TraversalRequest
from enterprise_kg.services.graph_service import GraphService


def test_ingestion_is_idempotent(service: GraphService, process_request: IngestionRequest) -> None:
    first = service.ingest("process-risk", process_request)
    replay = service.ingest("process-risk", process_request)
    assert first.nodes_upserted == 5
    assert first.edges_upserted == 4
    assert first.evidence_upserted == 9
    assert first.replayed is False
    assert replay.replayed is True
    assert replay.nodes_upserted == first.nodes_upserted


def test_configured_risk_control_traversal(
    service: GraphService, process_request: IngestionRequest
) -> None:
    service.ingest("process-risk", process_request)
    result = service.traverse(
        "process-risk",
        TraversalRequest(traversal="process_risk_controls", start_canonical_id="PROC-1001"),
    )
    assert len(result.paths) == 1
    assert [node.canonical_name for node in result.paths[0].nodes] == [
        "Card Payment Authorization",
        "Unauthorized Card Transaction",
        "Real-Time Fraud Screening",
    ]
    assert [edge.relationship_type for edge in result.paths[0].edges] == [
        "EXPOSED_TO",
        "MITIGATES",
    ]
    assert result.paths[0].nodes[0].metadata["business_domain"] == "Payments"
    assert "chunk-sop-100-section-2" in result.paths[0].nodes[0].chunk_ids
    exposed_to = result.paths[0].edges[0]
    assert "unauthorized card transaction" in exposed_to.description.lower()
    assert exposed_to.metadata["source_system"] == "Risk Register"
    assert exposed_to.creation_details.generator == "risk-register-importer"
    assert exposed_to.selection_context


def test_reserved_platform_metadata_is_rejected(process_request: IngestionRequest) -> None:
    raw = process_request.model_dump(mode="json")
    raw["entities"][0]["metadata"]["_system"] = {"graph_id": "spoofed"}
    with pytest.raises(ValidationError, match="reserved by the platform"):
        IngestionRequest.model_validate(raw)


def test_relationship_creation_method_must_match_provenance(
    process_request: IngestionRequest,
) -> None:
    raw = process_request.model_dump(mode="json")
    raw["relationships"][0]["creation_details"]["method"] = "manual"
    with pytest.raises(ValidationError, match="creation method must match"):
        IngestionRequest.model_validate(raw)


def test_nodes_can_be_selected_by_operational_metadata(
    service: GraphService, process_request: IngestionRequest
) -> None:
    service.ingest("process-risk", process_request)
    result = service.search_nodes(
        "process-risk",
        NodeSearchRequest.model_validate(
            {
                "entity_type": "Process",
                "metadata_equals": {
                    "business_domain": "Payments",
                    "attributes.region": "global",
                },
                "chunk_id": "chunk-sop-100-section-2",
            }
        ),
    )
    assert [node.canonical_id for node in result.nodes] == ["PROC-1001"]
    assert result.nodes[0].metadata["owner"] == "Payments Operations"


def test_entities_can_be_retrieved_from_a_relevant_chunk(
    service: GraphService, process_request: IngestionRequest
) -> None:
    service.ingest("process-risk", process_request)
    result = service.entities_for_chunk("process-risk", "chunk-riskreg-2026-q3-risk-3001")
    assert {node.canonical_id for node in result.nodes} == {"RISK-3001", "CTRL-4001"}


def test_unconfigured_entity_is_rejected(
    service: GraphService, process_request: IngestionRequest
) -> None:
    raw = process_request.model_dump(mode="json")
    raw["entities"][0]["entity_type"] = "Vendor"
    request = IngestionRequest.model_validate(raw)
    with pytest.raises(GraphValidationError, match="entity type is not allowed"):
        service.ingest("process-risk", request)


def test_unconfigured_property_is_rejected(
    service: GraphService, process_request: IngestionRequest
) -> None:
    raw = process_request.model_dump(mode="json")
    raw["entities"][0]["properties"]["unknown_field"] = "not allowed"
    request = IngestionRequest.model_validate(raw)
    with pytest.raises(GraphValidationError, match="unconfigured properties"):
        service.ingest("process-risk", request)


def test_low_confidence_requires_review(
    service: GraphService, process_request: IngestionRequest
) -> None:
    raw = process_request.model_dump(mode="json")
    raw["entities"][0]["confidence"] = 0.80
    request = IngestionRequest.model_validate(raw)
    with pytest.raises(GraphValidationError, match="requires manual review"):
        service.ingest("process-risk", request)


def test_unknown_traversal_is_rejected(
    service: GraphService, process_request: IngestionRequest
) -> None:
    service.ingest("process-risk", process_request)
    with pytest.raises(GraphValidationError, match="not allowed"):
        service.traverse(
            "process-risk",
            TraversalRequest(traversal="free_form_sql", start_canonical_id="PROC-1001"),
        )


def test_relationship_endpoints_are_validated(
    service: GraphService, process_request: IngestionRequest
) -> None:
    raw = deepcopy(process_request.model_dump(mode="json"))
    raw["relationships"][0]["target_entity_type"] = "Risk"
    request = IngestionRequest.model_validate(raw)
    with pytest.raises(GraphValidationError, match="must connect Process to System"):
        service.ingest("process-risk", request)


def test_unconfigured_source_is_rejected(
    service: GraphService, process_request: IngestionRequest
) -> None:
    raw = process_request.model_dump(mode="json")
    raw["source_type"] = "UnknownRepository"
    request = IngestionRequest.model_validate(raw)
    with pytest.raises(GraphValidationError, match="source type is not allowed"):
        service.ingest("process-risk", request)


def test_required_source_metadata_is_enforced(
    service: GraphService, process_request: IngestionRequest
) -> None:
    raw = process_request.model_dump(mode="json")
    raw["source_metadata"].pop("classification")
    request = IngestionRequest.model_validate(raw)
    with pytest.raises(GraphValidationError, match="missing required fields"):
        service.ingest("process-risk", request)


def test_canonical_id_must_match_configured_identifier(
    service: GraphService, process_request: IngestionRequest
) -> None:
    raw = process_request.model_dump(mode="json")
    raw["entities"][0]["canonical_id"] = "different-id"
    request = IngestionRequest.model_validate(raw)
    with pytest.raises(GraphValidationError, match="configured identifier"):
        service.ingest("process-risk", request)
