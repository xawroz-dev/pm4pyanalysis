from __future__ import annotations

import json
import os
import uuid
from pathlib import Path

import pytest

from enterprise_kg.config.loader import FileConfigRegistry
from enterprise_kg.domain.models import IngestionRequest, NodeSearchRequest, TraversalRequest
from enterprise_kg.infrastructure.spanner import (
    SpannerGraphRepository,
    bootstrap_spanner,
    create_database,
)
from enterprise_kg.services.graph_service import GraphService
from enterprise_kg.settings import Settings

ROOT = Path(__file__).resolve().parents[2]


@pytest.mark.integration
def test_spanner_graph_round_trip() -> None:
    host = os.getenv("SPANNER_EMULATOR_HOST")
    if not host:
        pytest.skip("SPANNER_EMULATOR_HOST is not set")
    settings = Settings(
        environment="test",
        spanner_emulator_host=host,
        spanner_database=f"kg-test-{uuid.uuid4().hex[:12]}",
    )
    bootstrap_spanner(settings, ROOT / "schema" / "001_initial.sql")
    registry = FileConfigRegistry(ROOT / "configs")
    registry.load()
    repository = SpannerGraphRepository(settings)
    database = create_database(settings)
    with database.snapshot() as snapshot:
        node_columns = {
            row[0]
            for row in snapshot.execute_sql(
                "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME='GraphNode'"
            )
        }
    with database.snapshot() as snapshot:
        edge_columns = {
            row[0]
            for row in snapshot.execute_sql(
                "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME='GraphEdge'"
            )
        }
    assert node_columns == {"node_id", "metadata", "properties", "chunk_ids", "updated_at"}
    assert edge_columns == {
        "edge_id",
        "source_node_id",
        "target_node_id",
        "metadata",
        "properties",
        "chunk_ids",
        "confidence",
        "evidence_id",
        "created_at",
    }
    service = GraphService(registry, repository)
    samples = (
        ("process-risk", "process-risk.json"),
        ("product-market", "product-market-catalog.json"),
        ("product-market", "product-market-regulatory.json"),
    )
    for graph_id, filename in samples:
        request = IngestionRequest.model_validate(
            json.loads((ROOT / "sample_data" / filename).read_text())
        )
        service.ingest(graph_id, request)
    result = service.traverse(
        "process-risk",
        TraversalRequest(traversal="process_risk_controls", start_canonical_id="PROC-1001"),
    )
    assert len(result.paths) == 1
    assert [node.canonical_name for node in result.paths[0].nodes] == [
        "Card Payment Authorization",
        "Unauthorized Card Transaction",
        "Real-Time Fraud Screening",
    ]
    assert result.paths[0].nodes[0].metadata["owner"] == "Payments Operations"
    assert result.paths[0].edges[0].metadata["status"] == "active"
    assert result.paths[0].edges[0].creation_details.review_status == "approved"
    assert "risk and control coverage" in result.paths[0].edges[0].selection_context[0]

    market = service.traverse(
        "product-market",
        TraversalRequest(traversal="market_products", start_canonical_id="PROC-1001"),
    )
    assert [node.canonical_name for node in market.paths[0].nodes] == [
        "United States Commercial Market",
        "Commercial Card",
    ]
    assert market.paths[0].nodes[0].node_id != result.paths[0].nodes[0].node_id

    evidence_id = result.paths[0].edges[0].evidence_id
    evidence = repository.evidence("payments", "process-risk", evidence_id)
    assert evidence.provenance.source_id == "RISKREG-2026-Q3"

    selected = service.search_nodes(
        "process-risk",
        NodeSearchRequest.model_validate(
            {
                "entity_type": "Process",
                "metadata_equals": {
                    "business_domain": "Payments",
                    "attributes.region": "global",
                },
                "chunk_id": "chunk-sop-100-section-2",
            }
        ),
    )
    assert [node.canonical_id for node in selected.nodes] == ["PROC-1001"]

    generic_selected = service.search_nodes(
        "product-market",
        NodeSearchRequest.model_validate(
            {
                "entity_type": "Market",
                "metadata_equals": {
                    "active": True,
                    "catalog_lineage.period": "2026-Q3",
                },
            }
        ),
    )
    assert [node.canonical_id for node in generic_selected.nodes] == ["PROC-1001"]

    chunk_entities = service.entities_for_chunk("process-risk", "chunk-riskreg-2026-q3-risk-3001")
    assert {node.canonical_id for node in chunk_entities.nodes} == {
        "CTRL-4001",
        "RISK-3001",
    }
