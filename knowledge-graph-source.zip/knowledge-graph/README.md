# Enterprise Knowledge Graph Platform

A production-oriented Python reference implementation for a governed, config-driven, multi-domain knowledge graph on Google Cloud Spanner Graph.

The platform keeps domain meaning in independently versioned YAML files while the shared runtime owns validation, canonical IDs, idempotent writes, provenance, namespace isolation, graph persistence, and approved traversals. A new team onboards by describing its questions, entities, relationships, sources, resolution rules, and traversals—not by adding domain-specific Python code.

For one complete, plain-language walkthrough, read
[Enterprise Knowledge Graph: detailed explanation](docs/detailed-explanation.md).

## What is included

- FastAPI service with liveness, readiness, configuration, ingestion, evidence, and traversal APIs.
- Pydantic validation for ontology references, property types, traversal direction, confidence gates, and semantic versions.
- Minimal generic `GraphNode` and `GraphEdge` tables mapped to Spanner Graph with dynamic properties.
- Atomic, retry-safe, idempotent ingestion batches and deterministic UUIDv5 canonical IDs.
- First-class provenance records for every entity assertion and relationship fact.
- Team-defined JSON metadata on every graph element with no shared business-field schema.
- Chunk-to-entity lineage for taking a retrieved RAG chunk directly to its associated graph entities.
- Bounded node discovery by arbitrary scalar metadata paths, entity type, name prefix, or chunk ID.
- Parameterized Graph SQL generated only from reviewed traversal configuration; no user-generated GQL endpoint.
- Two isolated example domains: `payments/process-risk` and `commercial-strategy/product-market`.
- Docker Compose workflow using the official Spanner emulator image, plus unit and emulator integration tests.
- Audience-oriented architecture, data model, API, GraphRAG, onboarding, security, operations,
  and test documentation with architecture decision records.

Spanner Graph uses tables as graph input and supports SQL/PGQ pattern queries. The local emulator now lists GQL as supported, but it is in-memory and is not a performance or production substitute. See the [Spanner Graph schema overview](https://cloud.google.com/spanner/docs/graph/schema-overview) and [emulator documentation](https://cloud.google.com/spanner/docs/emulator).

## Architecture at a glance

```text
Reviewed team YAML
      |
      v
Config registry -> schema/traversal validation
      |
      v
Graph service -> canonicalization -> governed fact validation
      |
      v
Spanner transaction
  |- GraphNode
  |- GraphNodeChunk
  |- GraphEdge
  |- GraphEvidence
  `- IngestionBatch
      |
      v
Spanner property graph -> approved Graph SQL traversal -> evidence IDs
```

The storage schema is flexible, but writes are not schemaless in the governance sense: every label, relationship, property, endpoint, and traversal must exist in the selected graph configuration.

## Quick start with Docker

Requirements: Docker with Compose v2 and Python 3.12 for the host-side smoke scripts.

```bash
cp .env.example .env
docker compose up --build -d --wait
python3 scripts/load_sample.py
python3 scripts/smoke_test.py
```

Open `http://localhost:8080/docs` for the local OpenAPI UI. The smoke test verifies this real graph path:

```text
Card Payment Authorization
  -[EXPOSED_TO]-> Unauthorized Card Transaction
  <-[MITIGATES]- Real-Time Fraud Screening
```

It also loads the isolated `commercial-strategy/product-market` namespace and verifies `Market -> Product -> Process <- Regulation`. Both graphs intentionally use `PROC-1001` in different contexts, proving that namespace/graph-scoped identity and traversal filters prevent cross-team leakage.

The emulator loses all schema and data when its container stops. The `bootstrap` one-shot service recreates the instance, database, tables, indexes, constraints, and property graph on the next `docker compose up`.

Compose pins emulator `1.5.56` for repeatable local/CI behavior. Override `SPANNER_EMULATOR_IMAGE` deliberately when qualifying a newer release.

## Local Python verification

```bash
make install
make verify
```

Run only the hermetic unit suite:

```bash
.venv/bin/pytest -m 'not integration'
```

Run the Spanner round-trip integration test against an already running emulator:

```bash
export SPANNER_EMULATOR_HOST=localhost:9010
.venv/bin/pytest -m integration
```

## API examples

List and inspect graph configurations:

```bash
curl -s http://localhost:8080/v1/configurations | python3 -m json.tool
```

Load the sample with an idempotency key:

```bash
curl -sS -X POST http://localhost:8080/v1/graphs/process-risk/ingestions \
  -H 'content-type: application/json' \
  --data-binary @sample_data/process-risk.json
```

Repeat the same request. The response returns `"replayed": true` and does not duplicate facts.

Execute a configured traversal:

```bash
curl -sS -X POST http://localhost:8080/v1/graphs/process-risk/traversals \
  -H 'content-type: application/json' \
  -d '{"traversal":"process_risk_controls","start_canonical_id":"PROC-1001"}' \
  | python3 -m json.tool
```

Select nodes using arbitrary nested metadata and a chunk ID:

```bash
curl -sS -X POST http://localhost:8080/v1/graphs/process-risk/nodes/search \
  -H 'content-type: application/json' \
  -d '{"entity_type":"Process","metadata_equals":{"attributes.region":"global"},"chunk_id":"chunk-sop-100-section-2"}' \
  | python3 -m json.tool
```

Resolve a retrieved chunk back to all associated entities:

```bash
curl -sS \
  http://localhost:8080/v1/graphs/process-risk/chunks/chunk-riskreg-2026-q3-risk-3001/entities \
  | python3 -m json.tool
```

Traversal nodes return team-owned `metadata` and `chunk_ids`. Traversal edges return `description`,
`rationale`, `selection_context`, `metadata`, `creation_details`, confidence, and evidence ID.
The sample payloads are executable examples of the complete ingestion contract.

The traversal returns evidence IDs. Retrieve the exact source assertion with:

```bash
curl -sS http://localhost:8080/v1/graphs/process-risk/evidence/EVIDENCE_ID
```

## Repository map

```text
configs/                 independently versioned team graph definitions
docs/                    architecture, governance, security, and runbooks
sample_data/             deterministic payment-domain demonstration
schema/                  Spanner DDL and property graph definition
scripts/                 bootstrap, config validation, load, and smoke test
src/enterprise_kg/
  api/                   HTTP boundary and error mapping
  config/                strict config model and registry
  domain/                graph facts and provenance contracts
  infrastructure/        Spanner adapter and bootstrap
  repositories/          storage port and in-memory test adapter
  services/              validation, IDs, ingestion, traversal compiler
tests/                   unit and emulator integration tests
```

## Deliberate production boundaries

This project implements the graph platform kernel, not an all-in-one enterprise deployment. Before production, connect it to your workload identity/IAM gateway, durable configuration registry and approval workflow, source connectors, extraction workers, vector index/RAG service, metrics backend, and secrets manager. Those boundaries and rollout controls are detailed in [security.md](docs/security.md) and [operations.md](docs/operations.md).

Start with the [detailed explanation](docs/detailed-explanation.md) or
[documentation hub](docs/index.md), then use the focused references below as needed:

- [Architecture and design decisions](docs/architecture.md)
- [Generic physical data model](docs/data-model.md)
- [HTTP API reference](docs/api.md)
- [GraphRAG integration guide](docs/graphrag.md)
- [Team onboarding guide](docs/team-onboarding.md)
- [Spanner Graph platform fit](docs/spanner-graph-fit.md)
- [Configuration authoring guide](docs/configuration.md)
- [API and end-to-end test guide](docs/testing.md)
- [Production operations runbook](docs/operations.md)
- [Security and threat model](docs/security.md)
- [ADR-0001: Generic physical graph](docs/decisions/0001-generic-physical-graph.md)
- [ADR-0002: Chunk-to-entity lineage](docs/decisions/0002-chunk-entity-lineage.md)
