# Commercial card authorization operating narrative

Commercial card purchases are handled by the Card Payment Authorization process. The process
receives an authorization request from a merchant, validates the account, evaluates available
credit, and returns an approve or decline response in under two seconds. The United States
Commercial Cards market is the initial operating market for this process.

The Authorization Gateway system receives each request and sends transaction features to the
Real-Time Fraud Platform system. Card Payment Authorization depends on both systems. If either
system is unavailable, legitimate customer purchases can be delayed or declined.

The Payment Authorization Policy requires account status, credit availability, sanctions, and
fraud checks before a transaction is approved. The policy applies to the Card Payment
Authorization process and is reviewed annually by the payments risk committee.

Unauthorized Transaction is a material risk for the process because a stolen card or compromised
credential can be used without the cardholder's permission. Authorization Service Outage is a
second risk because gateway or fraud-platform failures can prevent timely authorization decisions.

Real-Time Fraud Screening is a preventive control. It scores authorization attempts and blocks
high-risk transactions before approval, which mitigates Unauthorized Transaction. Active-Active
Gateway Failover is a resilience control that routes requests to a healthy region when the primary
Authorization Gateway becomes unavailable. It mitigates Authorization Service Outage.

Control owners review screening effectiveness, false-positive rates, gateway failover tests,
policy exceptions, and market-specific authorization performance every quarter.

