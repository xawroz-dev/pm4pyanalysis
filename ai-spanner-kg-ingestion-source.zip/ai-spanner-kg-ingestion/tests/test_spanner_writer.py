from __future__ import annotations

from typing import Any

from ai_spanner_kg.contracts import IngestionBundle
from ai_spanner_kg.memory_writer import MemoryKnowledgeWriter
from ai_spanner_kg.service import IngestionService
from ai_spanner_kg.spanner_writer import SpannerKnowledgeWriter, _json

from .test_ingestion import FakeEmbeddings, FakeExtractor


class FakeTransaction:
    def __init__(self, existing: bool = False) -> None:
        self.existing = existing
        self.writes: dict[str, list[tuple[object, ...]]] = {}

    def execute_sql(self, *_args: object, **_kwargs: object) -> list[tuple[str]]:
        return [("doc",)] if self.existing else []

    def insert_or_update(
        self,
        table: str,
        *,
        columns: tuple[str, ...],
        values: list[tuple[Any, ...]],
    ) -> None:
        assert columns
        self.writes[table] = values


def _bundle() -> IngestionBundle:
    memory = MemoryKnowledgeWriter()
    service = IngestionService(
        FakeExtractor(),
        FakeEmbeddings(),
        memory,
        max_upload_bytes=100_000,
        chunk_size=2_000,
        chunk_overlap=100,
    )
    service.ingest("payments", "process.txt", b"Normal process narrative.")
    return next(iter(memory.bundles.values()))


def test_transaction_writes_graph_vector_and_lineage_tables() -> None:
    transaction = FakeTransaction(existing=True)
    result = SpannerKnowledgeWriter._write(transaction, _bundle())

    assert result.replayed
    assert set(transaction.writes) == {
        "Document",
        "Chunk",
        "Entity",
        "DocumentHasChunk",
        "ChunkMentionsEntity",
        "EntityRelationship",
    }
    assert len(transaction.writes["Entity"]) == 6
    assert _json({"b": 2, "a": 1}) == '{"a":1,"b":2}'
