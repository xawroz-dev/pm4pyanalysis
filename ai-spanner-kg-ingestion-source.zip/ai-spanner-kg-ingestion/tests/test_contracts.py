import pytest
from pydantic import ValidationError

from ai_spanner_kg.contracts import (
    ChunkExtraction,
    ExtractedEntity,
    ExtractedRelationship,
)


def test_structured_output_rejects_unknown_relationship_references() -> None:
    with pytest.raises(ValidationError, match="unknown local entity"):
        ChunkExtraction(
            entities=[
                ExtractedEntity(
                    local_id="one",
                    entity_type="Process",
                    name="Order Process",
                    description="Processes customer orders from receipt through completion.",
                    confidence=0.9,
                    evidence_quote="order process",
                )
            ],
            relationships=[
                ExtractedRelationship(
                    source_local_id="one",
                    target_local_id="missing",
                    relationship_type="USES",
                    description="The process uses a supporting system for order execution.",
                    rationale="The document explicitly states that the system is used.",
                    selection_context=["Use for process dependency analysis."],
                    confidence=0.8,
                    evidence_quote="uses the system",
                )
            ],
        )
