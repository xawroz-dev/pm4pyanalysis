from ai_spanner_kg.contracts import (
    Attribute,
    ChunkExtraction,
    ExtractedEntity,
    ExtractedRelationship,
    TextChunk,
)
from ai_spanner_kg.memory_writer import MemoryKnowledgeWriter
from ai_spanner_kg.service import IngestionService


class FakeExtractor:
    def extract(self, _chunk: TextChunk) -> ChunkExtraction:
        return ChunkExtraction(
            entities=[
                _entity("p1", "Process", "Card Payment Authorization"),
                _entity("s1", "System", "Authorization Gateway"),
                _entity("r1", "Risk", "Unauthorized Transaction"),
                _entity("c1", "Control", "Real-Time Fraud Screening"),
                _entity("m1", "Market", "United States Commercial Cards"),
                _entity("po1", "Policy", "Payment Authorization Policy"),
            ],
            relationships=[
                ExtractedRelationship(
                    source_local_id="c1",
                    target_local_id="r1",
                    relationship_type="MITIGATES",
                    description="Real-time screening mitigates unauthorized transaction risk.",
                    rationale="Suspicious authorization attempts are blocked before approval.",
                    selection_context=["Use when finding preventive fraud controls."],
                    attributes=[Attribute(key="frequency", value="real-time")],
                    confidence=0.97,
                    evidence_quote=(
                        "scores authorization attempts and blocks high-risk transactions"
                    ),
                )
            ],
        )


class FakeEmbeddings:
    dimensions = 256

    def embed(self, texts: list[str]) -> list[list[float]]:
        return [[float((index + 1) % 7) / 7 for index in range(256)] for _ in texts]


def _entity(local_id: str, entity_type: str, name: str) -> ExtractedEntity:
    return ExtractedEntity(
        local_id=local_id,
        entity_type=entity_type,
        name=name,
        description=f"Enterprise knowledge entity for {name}.",
        aliases=[],
        attributes=[],
        confidence=0.95,
        evidence_quote=name,
    )


def test_llm_extraction_is_linked_to_chunks_and_idempotent() -> None:
    writer = MemoryKnowledgeWriter()
    service = IngestionService(
        FakeExtractor(),
        FakeEmbeddings(),
        writer,
        max_upload_bytes=100_000,
        chunk_size=2000,
        chunk_overlap=100,
    )
    content = b"The authorization process uses a gateway and fraud screening mitigates risk."

    first = service.ingest("payments", "process.txt", content)
    replay = service.ingest("payments", "process.txt", content)
    bundle = next(iter(writer.bundles.values()))

    assert first.entities == 6
    assert first.relationships == 1
    assert replay.replayed
    assert all(entity.chunk_ids for entity in bundle.entities)
    assert all(relationship.chunk_ids for relationship in bundle.relationships)
    assert bundle.relationships[0].evidence_chunk_id == bundle.chunks[0].chunk_id
    assert len(bundle.chunk_embeddings[bundle.chunks[0].chunk_id]) == 256


def test_rejects_invalid_graph_id() -> None:
    service = IngestionService(
        FakeExtractor(),
        FakeEmbeddings(),
        MemoryKnowledgeWriter(),
        max_upload_bytes=100_000,
        chunk_size=2000,
        chunk_overlap=100,
    )
    try:
        service.ingest("Invalid Graph", "process.txt", b"normal document")
    except ValueError as exc:
        assert "graph_id" in str(exc)
    else:
        raise AssertionError("invalid graph ID was accepted")
