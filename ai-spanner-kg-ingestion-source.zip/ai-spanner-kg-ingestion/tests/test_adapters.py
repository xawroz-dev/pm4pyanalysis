from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace
from typing import Any, cast

from fastapi.testclient import TestClient
from openai import OpenAI

from ai_spanner_kg.api import _metadata, create_app
from ai_spanner_kg.contracts import (
    ChunkExtraction,
    IngestionResult,
    TextChunk,
)
from ai_spanner_kg.ontology import load_ontology
from ai_spanner_kg.openai_providers import (
    OpenAIEmbeddingProvider,
    OpenAIKnowledgeExtractor,
)
from ai_spanner_kg.service import IngestionService
from ai_spanner_kg.settings import Settings


class _FakeIngestionService:
    def ingest(
        self,
        graph_id: str,
        _filename: str,
        _content: bytes,
        _metadata: object,
    ) -> IngestionResult:
        if graph_id == "invalid":
            raise ValueError("bad document")
        return IngestionResult(
            graph_id=graph_id,
            document_id="doc-1",
            chunks=1,
            entities=2,
            relationships=1,
            replayed=False,
        )


def test_api_upload_health_and_error_handling() -> None:
    settings = Settings(max_upload_bytes=1_000)
    service = cast(IngestionService, _FakeIngestionService())
    with TestClient(create_app(settings, service)) as client:
        assert client.get("/health/live").json() == {"status": "ok"}
        response = client.post(
            "/v1/graphs/payments/documents",
            files={"file": ("process.txt", b"Normal business prose.", "text/plain")},
            data={"metadata_json": '{"owner":"operations"}'},
        )
        assert response.status_code == 200
        assert response.json()["entities"] == 2

        invalid = client.post(
            "/v1/graphs/invalid/documents",
            files={"file": ("process.txt", b"text", "text/plain")},
        )
        assert invalid.status_code == 422
        assert invalid.json()["code"] == "invalid_document"


def test_metadata_must_be_an_object() -> None:
    assert _metadata('{"team":"risk"}') == {"team": "risk"}
    try:
        _metadata("[]")
    except ValueError as exc:
        assert "JSON object" in str(exc)
    else:
        raise AssertionError("list metadata was accepted")


def test_openai_adapters_use_structured_output_and_order_embeddings() -> None:
    parsed = ChunkExtraction()
    ontology = load_ontology(Path("config/ontology.json"))

    class Responses:
        def parse(self, **kwargs: object) -> object:
            assert kwargs["text_format"] is ChunkExtraction
            return SimpleNamespace(output_parsed=parsed)

    class Embeddings:
        def create(self, **kwargs: object) -> object:
            assert kwargs["dimensions"] == 3
            return SimpleNamespace(
                data=[
                    SimpleNamespace(index=1, embedding=[0.0, 1.0, 0.0]),
                    SimpleNamespace(index=0, embedding=[1.0, 0.0, 0.0]),
                ]
            )

    client: Any = SimpleNamespace(responses=Responses(), embeddings=Embeddings())
    chunk = TextChunk(chunk_id="c1", document_id="d1", ordinal=0, content="Narrative")
    assert OpenAIKnowledgeExtractor("test", ontology, cast(OpenAI, client)).extract(chunk) == parsed

    provider = OpenAIEmbeddingProvider("test", 3, cast(OpenAI, client))
    assert provider.dimensions == 3
    assert provider.embed([]) == []
    assert provider.embed(["a", "b"]) == [[1.0, 0.0, 0.0], [0.0, 1.0, 0.0]]


def test_openai_extractor_rejects_missing_parsed_output() -> None:
    client: Any = SimpleNamespace(
        responses=SimpleNamespace(parse=lambda **_kwargs: SimpleNamespace(output_parsed=None))
    )
    extractor = OpenAIKnowledgeExtractor(
        "test", load_ontology(Path("config/ontology.json")), cast(OpenAI, client)
    )
    chunk = TextChunk(chunk_id="c1", document_id="d1", ordinal=0, content="Narrative")
    try:
        extractor.extract(chunk)
    except RuntimeError as exc:
        assert "no structured output" in str(exc)
    else:
        raise AssertionError("missing parsed output was accepted")
