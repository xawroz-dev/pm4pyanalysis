import pytest

from ai_spanner_kg.documents import read_document, split_chunks


def test_plain_document_and_chunking() -> None:
    text, media_type = read_document("process.md", b"A normal process narrative.")
    assert text == "A normal process narrative."
    assert media_type == "text/markdown"
    assert len(split_chunks("Sentence. " * 200, 500, 50)) > 1


def test_invalid_document_is_rejected() -> None:
    with pytest.raises(ValueError, match="supported documents"):
        read_document("process.csv", b"a,b")
    with pytest.raises(ValueError, match="overlap"):
        split_chunks("text", 100, 100)
