from pathlib import Path

import pytest
from pydantic import ValidationError

from ai_spanner_kg.contracts import ChunkExtraction, ExtractedEntity, ExtractedRelationship
from ai_spanner_kg.ontology import (
    EntityDefinition,
    OntologyConfig,
    RelationshipDefinition,
    load_ontology,
)


def _entity(local_id: str, entity_type: str) -> ExtractedEntity:
    return ExtractedEntity(
        local_id=local_id,
        entity_type=entity_type,
        name=f"{entity_type} example",
        description=f"A sufficiently detailed {entity_type} description.",
        confidence=0.9,
        evidence_quote=f"{entity_type} example",
    )


def test_config_accepts_valid_types_and_relationship_direction() -> None:
    ontology = load_ontology(Path("config/ontology.json"))
    extraction = ChunkExtraction(
        entities=[_entity("control", "Control"), _entity("risk", "Risk")],
        relationships=[
            ExtractedRelationship(
                source_local_id="control",
                target_local_id="risk",
                relationship_type="MITIGATES",
                description="The configured control mitigates the identified risk.",
                rationale="The narrative directly explains the mitigating behavior.",
                selection_context=["Use for control-to-risk analysis."],
                confidence=0.9,
                evidence_quote="control mitigates the risk",
            )
        ],
    )
    ontology.validate_extraction(extraction)


def test_config_rejects_unconfigured_types_and_invalid_direction() -> None:
    ontology = load_ontology(Path("config/ontology.json"))
    with pytest.raises(ValueError, match="entity type is not configured"):
        ontology.validate_extraction(ChunkExtraction(entities=[_entity("x", "Vendor")]))

    wrong_direction = ChunkExtraction(
        entities=[_entity("risk", "Risk"), _entity("control", "Control")],
        relationships=[
            ExtractedRelationship(
                source_local_id="risk",
                target_local_id="control",
                relationship_type="MITIGATES",
                description="This deliberately reverses the configured relationship direction.",
                rationale="The test verifies that ontology constraints are applied.",
                selection_context=["Validation test."],
                confidence=0.5,
                evidence_quote="risk mitigates control",
            )
        ],
    )
    with pytest.raises(ValueError, match="does not allow source"):
        ontology.validate_extraction(wrong_direction)


def test_config_definition_rejects_duplicates_and_unknown_endpoint_types() -> None:
    entity = EntityDefinition(name="Thing", description="A generic configured thing.")
    with pytest.raises(ValidationError, match="entity type names must be unique"):
        OntologyConfig(
            version="v1",
            entity_types=[entity, entity],
            relationship_types=[
                RelationshipDefinition(name="LINKS", description="Links two things.")
            ],
        )
    with pytest.raises(ValidationError, match="unknown target type"):
        OntologyConfig(
            version="v1",
            entity_types=[entity],
            relationship_types=[
                RelationshipDefinition(
                    name="LINKS",
                    description="Links a thing to an unknown type.",
                    source_types=["Thing"],
                    target_types=["Missing"],
                )
            ],
        )
