# Project 1: AI document-to-Spanner-Graph ingestion

This service accepts a normal process document, chunks it, uses an LLM to extract typed entities
and relationships, creates embeddings, and writes the complete evidence-linked graph to Spanner.

It does **not** require documents to contain special `Process:` or `Relationship:` lines. The sample
is ordinary business prose.

## Pipeline

```mermaid
flowchart LR
    D["PDF, DOCX, Markdown, or text"] --> T["Text extraction"]
    T --> C["Overlapping chunks"]
    C --> L["LLM structured extraction"]
    L --> E["Entity resolution"]
    C --> V["Chunk embeddings"]
    E --> EV["Entity embeddings"]
    V --> S["Atomic Spanner transaction"]
    EV --> S
    L --> S
    S --> G["Document, Chunk, Entity, and graph edges"]
```

The core is ontology-agnostic. The ready-to-run sample configuration includes `Process`, `Policy`,
`Risk`, `Control`, `Market`, and `System`, but a team can replace those types and relationship rules
in `config/ontology.json` without changing Python or Spanner DDL. Every extracted entity has
`chunk_ids`. Every relationship has `evidence_chunk_id`, `chunk_ids`, description, rationale,
selection context, confidence, and the supporting quote in generic JSON metadata.

## Team-defined ontology

The configuration controls:

- entity type names, meanings, and examples;
- relationship type names and meanings;
- allowed source and target entity types for every relationship;
- a version that can be recorded with future extraction audit data.

The LLM receives this configuration in its extraction prompt. The service validates every returned
type and relationship direction against it before persistence. See the
[configuration guide](docs/CONFIGURATION.md).

## Add credentials later

```bash
cp .env.example .env
```

Set `OPENAI_API_KEY` in `.env` when you are ready. The value is not included in this repository.
The extraction and embedding model names are independently configurable.

The integration follows the official OpenAI Python patterns for
[Pydantic Structured Outputs](https://developers.openai.com/api/docs/guides/structured-outputs)
and [embeddings](https://developers.openai.com/api/docs/guides/embeddings).

## Run

```bash
make install
docker compose up --build -d
```

Upload the ordinary sample document:

```bash
curl -sS -X POST http://localhost:8082/v1/graphs/payments/documents \
  -F 'metadata_json={"owner":"payments-risk","classification":"internal"}' \
  -F 'file=@sample_data/card-payment-process.md;type=text/markdown' \
  | python3 -m json.tool
```

The LLM processes each chunk independently and may return no facts for irrelevant chunks. The
service validates local relationship references, resolves repeated entities to deterministic IDs,
merges chunk evidence, batches embeddings, and writes all rows in one transaction.

## Validate without a token

Unit tests use fake structured extraction and fake embeddings, so they run without network access:

```bash
make verify
```

See [pipeline details](docs/PIPELINE.md), the [configuration guide](docs/CONFIGURATION.md), and the executable
[Spanner schema](schema/001_knowledge_graph.sql).
