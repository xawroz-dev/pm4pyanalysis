# LLM extraction and ingestion details

## Chunk-level extraction contract

The model receives one chunk plus the team ontology from `config/ontology.json` and returns a
Pydantic `ChunkExtraction` object. The schema requires:

- entity type, name, description, aliases, attributes, confidence, and evidence quote;
- relationship endpoints referencing local entity IDs;
- relationship type, description, rationale, selection context, confidence, and evidence quote.

The system prompt forbids unsupported inference and permits an empty response. Pydantic validation
rejects unknown endpoint references. Ontology validation then rejects unconfigured entity types,
unconfigured relationship types, and invalid source/target type combinations before persistence.

## Canonicalization

An entity ID is a UUIDv5 over:

```text
graph_id + entity_type + normalized entity name
```

This is deliberately conservative. Production entity resolution can introduce authoritative IDs,
alias matching, and review queues without changing the writer contract.

Relationships remain assertion-level records. Their IDs include source, type, target, and evidence
chunk, so two chunks can independently support or contradict the same semantic relationship.

## Chunk lineage

The system records lineage in two forms:

1. `Entity.chunk_ids` and `EntityRelationship.chunk_ids` make evidence visible on returned graph
   elements.
2. `ChunkMentionsEntity` provides a chunk-first access path for vector/full-text-to-graph queries.

`EntityRelationship.evidence_chunk_id` is a foreign key to the primary supporting chunk.

## Transaction boundary

The Spanner writer commits the document, chunks, embeddings, entities, mention links, and
relationships together. The document ID uses the content hash, making an identical upload
idempotent.

## Model boundaries

The repository does not contain a key. `OPENAI_API_KEY` is read by the SDK at runtime. Extraction
and embeddings are interfaces, allowing another approved provider or a deterministic test fake to
be substituted without changing chunking, identity, or Spanner persistence.

Before production, add concurrency limits, request retries, extraction caching, model/config version
metadata, content safety checks, malware scanning, human review, source authorization, and cost
budgets.
