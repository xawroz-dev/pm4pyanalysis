# Configuring a team ontology

The shared ingestion code and physical Spanner schema remain stable. Each team changes only
`config/ontology.json` to define what its graph means.

## Entity definitions

Each entity definition has a type name, a plain-language description, and optional examples. These
values guide the LLM; they do not create new Spanner tables.

```json
{
  "name": "Vendor",
  "description": "An external organization supplying a product or service.",
  "examples": ["Cloud hosting provider", "Payment processor"]
}
```

## Relationship definitions

Relationship rules constrain both meaning and direction:

```json
{
  "name": "SUPPLIED_BY",
  "description": "The source system or product is supplied by the target vendor.",
  "source_types": ["System", "Product"],
  "target_types": ["Vendor"]
}
```

An empty `source_types` or `target_types` list means any configured entity type is permitted on that
side. Prefer precise lists because they catch extraction errors before data reaches the graph.

## Adding another team

1. Copy `config/ontology.json` to a team-owned configuration file.
2. Replace the sample entity and relationship definitions.
3. Set `KG_ONTOLOGY_PATH` to that file.
4. Use a separate `graph_id` for logical isolation.
5. Run `make verify`, then upload representative documents and review extracted evidence.

No Python class, enum, table, or property-graph definition needs to change. The physical `Entity`
table stores the configured type as data and stores team-specific attributes in the `metadata` JSON
column. The edge table follows the same pattern for relationship attributes while keeping explicit
description, rationale, selection context, confidence, and chunk lineage because those fields are
needed for trustworthy retrieval.

## Governance

Treat ontology changes as versioned configuration. Review changes to meanings and allowed endpoint
types, test them against a curated document set, and use a new graph namespace for incompatible
changes. In production, persist the ontology version and model version with every extraction job so
results are reproducible and auditable.
