from __future__ import annotations

import json
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from typing import Annotated, cast

from fastapi import FastAPI, File, Form, Request, UploadFile
from fastapi.concurrency import run_in_threadpool
from fastapi.responses import JSONResponse
from pydantic import JsonValue

from ai_spanner_kg.contracts import IngestionResult
from ai_spanner_kg.ontology import load_ontology
from ai_spanner_kg.openai_providers import OpenAIEmbeddingProvider, OpenAIKnowledgeExtractor
from ai_spanner_kg.service import IngestionService
from ai_spanner_kg.settings import Settings, get_settings
from ai_spanner_kg.spanner_writer import SpannerKnowledgeWriter


def create_app(
    settings: Settings | None = None,
    injected_service: IngestionService | None = None,
) -> FastAPI:
    runtime = settings or get_settings()

    @asynccontextmanager
    async def lifespan(app: FastAPI) -> AsyncIterator[None]:
        app.state.service = injected_service or IngestionService(
            OpenAIKnowledgeExtractor(
                runtime.extraction_model, load_ontology(runtime.ontology_path)
            ),
            OpenAIEmbeddingProvider(runtime.embedding_model, runtime.embedding_dimensions),
            SpannerKnowledgeWriter(runtime),
            max_upload_bytes=runtime.max_upload_bytes,
            chunk_size=runtime.chunk_size,
            chunk_overlap=runtime.chunk_overlap,
        )
        yield

    app = FastAPI(
        title="AI Spanner Knowledge Graph Ingestion",
        version="0.1.0",
        lifespan=lifespan,
    )

    @app.exception_handler(ValueError)
    async def invalid_request(_request: Request, exc: ValueError) -> JSONResponse:
        return JSONResponse(
            status_code=422,
            content={"code": "invalid_document", "message": str(exc)},
        )

    @app.get("/health/live")
    def live() -> dict[str, str]:
        return {"status": "ok"}

    @app.post("/v1/graphs/{graph_id}/documents", response_model=IngestionResult)
    async def upload(
        request: Request,
        graph_id: str,
        file: Annotated[UploadFile, File()],
        metadata_json: Annotated[str, Form()] = "{}",
    ) -> IngestionResult:
        content = await file.read(runtime.max_upload_bytes + 1)
        metadata = _metadata(metadata_json)
        return cast(
            IngestionResult,
            await run_in_threadpool(
                request.app.state.service.ingest,
                graph_id,
                file.filename or "document.txt",
                content,
                metadata,
            ),
        )

    return app


def _metadata(value: str) -> dict[str, JsonValue]:
    parsed = json.loads(value)
    if not isinstance(parsed, dict):
        raise ValueError("metadata_json must be a JSON object")
    return cast(dict[str, JsonValue], parsed)


app = create_app()
