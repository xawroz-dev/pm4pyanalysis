from __future__ import annotations

import json
import os
from typing import Any, cast

from google.cloud import spanner
from google.cloud.spanner_v1 import param_types

from ai_spanner_kg.contracts import IngestionBundle, IngestionResult
from ai_spanner_kg.settings import Settings


class SpannerKnowledgeWriter:
    def __init__(self, settings: Settings) -> None:
        if settings.spanner_emulator_host:
            os.environ["SPANNER_EMULATOR_HOST"] = settings.spanner_emulator_host
        client: Any = spanner.Client(project=settings.spanner_project)
        self._database = client.instance(settings.spanner_instance).database(
            settings.spanner_database
        )

    def write(self, bundle: IngestionBundle) -> IngestionResult:
        return cast(IngestionResult, self._database.run_in_transaction(self._write, bundle))

    @staticmethod
    def _write(transaction: Any, bundle: IngestionBundle) -> IngestionResult:
        existing = list(
            transaction.execute_sql(
                "SELECT document_id FROM Document "
                "WHERE graph_id=@graph_id AND document_id=@document_id",
                params={"graph_id": bundle.graph_id, "document_id": bundle.document_id},
                param_types={
                    "graph_id": param_types.STRING,
                    "document_id": param_types.STRING,
                },
            )
        )
        created_at = bundle.entities[0].created_at
        transaction.insert_or_update(
            "Document",
            columns=(
                "graph_id",
                "document_id",
                "filename",
                "media_type",
                "content_hash",
                "metadata",
                "created_at",
            ),
            values=[
                (
                    bundle.graph_id,
                    bundle.document_id,
                    bundle.filename,
                    bundle.media_type,
                    bundle.content_hash,
                    _json(bundle.document_metadata),
                    created_at,
                )
            ],
        )
        transaction.insert_or_update(
            "Chunk",
            columns=(
                "graph_id",
                "chunk_id",
                "document_id",
                "ordinal",
                "content",
                "embedding",
                "metadata",
                "created_at",
            ),
            values=[
                (
                    bundle.graph_id,
                    chunk.chunk_id,
                    bundle.document_id,
                    chunk.ordinal,
                    chunk.content,
                    bundle.chunk_embeddings[chunk.chunk_id],
                    _json({}),
                    created_at,
                )
                for chunk in bundle.chunks
            ],
        )
        transaction.insert_or_update(
            "Entity",
            columns=(
                "graph_id",
                "entity_id",
                "entity_type",
                "name",
                "description",
                "aliases",
                "embedding",
                "chunk_ids",
                "confidence",
                "metadata",
                "created_at",
            ),
            values=[
                (
                    item.graph_id,
                    item.entity_id,
                    item.entity_type,
                    item.name,
                    item.description,
                    item.aliases,
                    item.embedding,
                    item.chunk_ids,
                    item.confidence,
                    _json(item.metadata),
                    item.created_at,
                )
                for item in bundle.entities
            ],
        )
        transaction.insert_or_update(
            "DocumentHasChunk",
            columns=("graph_id", "document_id", "chunk_id"),
            values=[(bundle.graph_id, bundle.document_id, item.chunk_id) for item in bundle.chunks],
        )
        transaction.insert_or_update(
            "ChunkMentionsEntity",
            columns=("graph_id", "chunk_id", "entity_id"),
            values=[
                (bundle.graph_id, chunk_id, item.entity_id)
                for item in bundle.entities
                for chunk_id in item.chunk_ids
            ],
        )
        if bundle.relationships:
            transaction.insert_or_update(
                "EntityRelationship",
                columns=(
                    "graph_id",
                    "relationship_id",
                    "source_entity_id",
                    "target_entity_id",
                    "relationship_type",
                    "description",
                    "rationale",
                    "selection_context",
                    "evidence_chunk_id",
                    "chunk_ids",
                    "confidence",
                    "metadata",
                    "created_at",
                ),
                values=[
                    (
                        item.graph_id,
                        item.relationship_id,
                        item.source_entity_id,
                        item.target_entity_id,
                        item.relationship_type,
                        item.description,
                        item.rationale,
                        item.selection_context,
                        item.evidence_chunk_id,
                        item.chunk_ids,
                        item.confidence,
                        _json(item.metadata),
                        item.created_at,
                    )
                    for item in bundle.relationships
                ],
            )
        return IngestionResult(
            graph_id=bundle.graph_id,
            document_id=bundle.document_id,
            chunks=len(bundle.chunks),
            entities=len(bundle.entities),
            relationships=len(bundle.relationships),
            replayed=bool(existing),
        )


def _json(value: object) -> str:
    return json.dumps(value, separators=(",", ":"), sort_keys=True)
