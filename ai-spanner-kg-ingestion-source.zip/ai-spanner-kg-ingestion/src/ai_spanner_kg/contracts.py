from __future__ import annotations

from datetime import datetime
from typing import Protocol

from pydantic import BaseModel, ConfigDict, Field, JsonValue, model_validator


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class Attribute(StrictModel):
    key: str = Field(min_length=1, max_length=100)
    value: str = Field(min_length=1, max_length=1000)


class ExtractedEntity(StrictModel):
    local_id: str = Field(min_length=1, max_length=64)
    entity_type: str = Field(min_length=1, max_length=64)
    name: str = Field(min_length=2, max_length=512)
    description: str = Field(min_length=10, max_length=4000)
    aliases: list[str] = Field(default_factory=list, max_length=25)
    attributes: list[Attribute] = Field(default_factory=list, max_length=50)
    confidence: float = Field(ge=0, le=1)
    evidence_quote: str = Field(min_length=3, max_length=2000)


class ExtractedRelationship(StrictModel):
    source_local_id: str
    target_local_id: str
    relationship_type: str = Field(min_length=1, max_length=64)
    description: str = Field(min_length=10, max_length=4000)
    rationale: str = Field(min_length=10, max_length=4000)
    selection_context: list[str] = Field(min_length=1, max_length=10)
    attributes: list[Attribute] = Field(default_factory=list, max_length=50)
    confidence: float = Field(ge=0, le=1)
    evidence_quote: str = Field(min_length=3, max_length=2000)


class ChunkExtraction(StrictModel):
    entities: list[ExtractedEntity] = Field(default_factory=list, max_length=100)
    relationships: list[ExtractedRelationship] = Field(default_factory=list, max_length=200)

    @model_validator(mode="after")
    def validate_relationship_references(self) -> ChunkExtraction:
        identifiers = [entity.local_id for entity in self.entities]
        if len(identifiers) != len(set(identifiers)):
            raise ValueError("entity local_id values must be unique")
        known = set(identifiers)
        for relationship in self.relationships:
            if (
                relationship.source_local_id not in known
                or relationship.target_local_id not in known
            ):
                raise ValueError("relationship references an unknown local entity")
        return self


class TextChunk(StrictModel):
    chunk_id: str
    document_id: str
    ordinal: int
    content: str


class GraphEntity(StrictModel):
    graph_id: str
    entity_id: str
    entity_type: str
    name: str
    description: str
    aliases: list[str]
    metadata: dict[str, JsonValue]
    embedding: list[float]
    chunk_ids: list[str]
    confidence: float
    created_at: datetime


class GraphRelationship(StrictModel):
    graph_id: str
    relationship_id: str
    source_entity_id: str
    target_entity_id: str
    relationship_type: str
    description: str
    rationale: str
    selection_context: list[str]
    metadata: dict[str, JsonValue]
    evidence_chunk_id: str
    chunk_ids: list[str]
    confidence: float
    created_at: datetime


class IngestionBundle(StrictModel):
    graph_id: str
    document_id: str
    filename: str
    media_type: str
    content_hash: str
    document_metadata: dict[str, JsonValue]
    chunks: list[TextChunk]
    chunk_embeddings: dict[str, list[float]]
    entities: list[GraphEntity]
    relationships: list[GraphRelationship]


class IngestionResult(StrictModel):
    graph_id: str
    document_id: str
    chunks: int
    entities: int
    relationships: int
    replayed: bool


class KnowledgeExtractor(Protocol):
    def extract(self, chunk: TextChunk) -> ChunkExtraction: ...


class EmbeddingProvider(Protocol):
    @property
    def dimensions(self) -> int: ...

    def embed(self, texts: list[str]) -> list[list[float]]: ...


class KnowledgeWriter(Protocol):
    def write(self, bundle: IngestionBundle) -> IngestionResult: ...
