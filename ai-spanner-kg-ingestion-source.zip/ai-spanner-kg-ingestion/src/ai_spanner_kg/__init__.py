"""LLM-driven document extraction and Spanner Graph ingestion."""
