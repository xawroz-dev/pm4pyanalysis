from __future__ import annotations

import hashlib
import re
import uuid
from dataclasses import dataclass, field
from datetime import UTC, datetime

from pydantic import JsonValue

from ai_spanner_kg.contracts import (
    EmbeddingProvider,
    ExtractedEntity,
    GraphEntity,
    GraphRelationship,
    IngestionBundle,
    IngestionResult,
    KnowledgeExtractor,
    KnowledgeWriter,
    TextChunk,
)
from ai_spanner_kg.documents import read_document, split_chunks


@dataclass
class _EntityAccumulator:
    entity: ExtractedEntity
    aliases: set[str] = field(default_factory=set)
    chunk_ids: set[str] = field(default_factory=set)
    attributes: dict[str, str] = field(default_factory=dict)
    confidence: float = 0.0
    evidence_quotes: list[str] = field(default_factory=list)


class IngestionService:
    def __init__(
        self,
        extractor: KnowledgeExtractor,
        embeddings: EmbeddingProvider,
        writer: KnowledgeWriter,
        *,
        max_upload_bytes: int,
        chunk_size: int,
        chunk_overlap: int,
    ) -> None:
        self._extractor = extractor
        self._embeddings = embeddings
        self._writer = writer
        self._max_upload_bytes = max_upload_bytes
        self._chunk_size = chunk_size
        self._chunk_overlap = chunk_overlap

    def ingest(
        self,
        graph_id: str,
        filename: str,
        content: bytes,
        metadata: dict[str, JsonValue] | None = None,
    ) -> IngestionResult:
        graph_id = _graph_id(graph_id)
        if len(content) > self._max_upload_bytes:
            raise ValueError("document exceeds the configured upload limit")
        text, media_type = read_document(filename, content)
        content_hash = hashlib.sha256(content).hexdigest()
        document_id = _stable_id("document", graph_id, content_hash)
        chunks = [
            TextChunk(
                chunk_id=_stable_id("chunk", document_id, str(ordinal)),
                document_id=document_id,
                ordinal=ordinal,
                content=value,
            )
            for ordinal, value in enumerate(
                split_chunks(text, self._chunk_size, self._chunk_overlap)
            )
        ]
        extractions = [(chunk, self._extractor.extract(chunk)) for chunk in chunks]
        now = datetime.now(UTC)

        entity_records: dict[str, _EntityAccumulator] = {}
        relationship_records: list[GraphRelationship] = []
        for chunk, extraction in extractions:
            local_to_global: dict[str, str] = {}
            for entity in extraction.entities:
                entity_id = _stable_id(
                    "entity", graph_id, entity.entity_type, _normalize(entity.name)
                )
                local_to_global[entity.local_id] = entity_id
                current = entity_records.setdefault(
                    entity_id,
                    _EntityAccumulator(entity=entity),
                )
                current.aliases.update(entity.aliases)
                current.chunk_ids.add(chunk.chunk_id)
                current.attributes.update({item.key: item.value for item in entity.attributes})
                current.evidence_quotes.append(entity.evidence_quote)
                current.confidence = max(current.confidence, entity.confidence)

            for relationship in extraction.relationships:
                source_id = local_to_global[relationship.source_local_id]
                target_id = local_to_global[relationship.target_local_id]
                relationship_records.append(
                    GraphRelationship(
                        graph_id=graph_id,
                        relationship_id=_stable_id(
                            "relationship",
                            graph_id,
                            source_id,
                            relationship.relationship_type,
                            target_id,
                            chunk.chunk_id,
                        ),
                        source_entity_id=source_id,
                        target_entity_id=target_id,
                        relationship_type=relationship.relationship_type,
                        description=relationship.description,
                        rationale=relationship.rationale,
                        selection_context=relationship.selection_context,
                        metadata={
                            "attributes": {
                                item.key: item.value for item in relationship.attributes
                            },
                            "evidence_quote": relationship.evidence_quote,
                            "extraction_method": "llm_structured_output",
                        },
                        evidence_chunk_id=chunk.chunk_id,
                        chunk_ids=[chunk.chunk_id],
                        confidence=relationship.confidence,
                        created_at=now,
                    )
                )

        if not entity_records:
            raise ValueError("the LLM extracted no supported entities from the document")

        entity_texts = []
        for record in entity_records.values():
            entity = record.entity
            entity_texts.append(f"{entity.entity_type}: {entity.name}. {entity.description}")
        entity_vectors = self._embeddings.embed(entity_texts)
        chunk_vectors = self._embeddings.embed([chunk.content for chunk in chunks])
        if len(entity_vectors) != len(entity_records) or len(chunk_vectors) != len(chunks):
            raise RuntimeError("embedding provider returned an unexpected number of vectors")

        graph_entities: list[GraphEntity] = []
        for (entity_id, record), vector in zip(entity_records.items(), entity_vectors, strict=True):
            entity = record.entity
            entity_metadata: dict[str, JsonValue] = {
                "attributes": {key: value for key, value in record.attributes.items()},
                "evidence_quotes": [quote for quote in record.evidence_quotes],
                "extraction_method": "llm_structured_output",
            }
            graph_entities.append(
                GraphEntity(
                    graph_id=graph_id,
                    entity_id=entity_id,
                    entity_type=entity.entity_type,
                    name=entity.name,
                    description=entity.description,
                    aliases=sorted(record.aliases),
                    metadata=entity_metadata,
                    embedding=vector,
                    chunk_ids=sorted(record.chunk_ids),
                    confidence=record.confidence,
                    created_at=now,
                )
            )

        return self._writer.write(
            IngestionBundle(
                graph_id=graph_id,
                document_id=document_id,
                filename=filename,
                media_type=media_type,
                content_hash=content_hash,
                document_metadata=metadata or {},
                chunks=chunks,
                chunk_embeddings={
                    chunk.chunk_id: vector
                    for chunk, vector in zip(chunks, chunk_vectors, strict=True)
                },
                entities=graph_entities,
                relationships=relationship_records,
            )
        )


def _stable_id(*parts: str) -> str:
    return str(uuid.uuid5(uuid.NAMESPACE_URL, "\x1f".join(parts)))


def _normalize(value: str) -> str:
    return re.sub(r"\s+", " ", value.strip().casefold())


def _graph_id(value: str) -> str:
    if not re.fullmatch(r"[a-z][a-z0-9-]{1,62}", value):
        raise ValueError("graph_id must be lowercase kebab case and 2-63 characters")
    return value
