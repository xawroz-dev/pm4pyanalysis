from __future__ import annotations

from io import BytesIO
from pathlib import Path

from docx import Document as WordDocument
from pypdf import PdfReader


def read_document(filename: str, content: bytes) -> tuple[str, str]:
    suffix = Path(filename).suffix.casefold()
    if suffix in {".txt", ".md"}:
        try:
            text = content.decode("utf-8")
        except UnicodeDecodeError as exc:
            raise ValueError("text documents must use UTF-8") from exc
        media_type = "text/markdown" if suffix == ".md" else "text/plain"
    elif suffix == ".pdf":
        text = "\n\n".join(page.extract_text() or "" for page in PdfReader(BytesIO(content)).pages)
        media_type = "application/pdf"
    elif suffix == ".docx":
        document = WordDocument(BytesIO(content))
        text = "\n\n".join(paragraph.text for paragraph in document.paragraphs)
        media_type = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    else:
        raise ValueError("supported documents are .txt, .md, .pdf, and .docx")
    text = text.replace("\x00", "").strip()
    if not text:
        raise ValueError("document contains no extractable text")
    return text, media_type


def split_chunks(text: str, size: int, overlap: int) -> list[str]:
    if overlap >= size:
        raise ValueError("chunk overlap must be smaller than chunk size")
    normalized = "\n".join(line.rstrip() for line in text.splitlines()).strip()
    result: list[str] = []
    start = 0
    while start < len(normalized):
        end = min(start + size, len(normalized))
        if end < len(normalized):
            boundary = max(normalized.rfind("\n\n", start, end), normalized.rfind(". ", start, end))
            if boundary > start + size // 2:
                end = boundary + 1
        value = normalized[start:end].strip()
        if value:
            result.append(value)
        if end == len(normalized):
            break
        start = end - overlap
    return result
