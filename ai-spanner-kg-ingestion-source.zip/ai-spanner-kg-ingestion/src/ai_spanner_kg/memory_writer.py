from ai_spanner_kg.contracts import IngestionBundle, IngestionResult


class MemoryKnowledgeWriter:
    def __init__(self) -> None:
        self.bundles: dict[tuple[str, str], IngestionBundle] = {}

    def write(self, bundle: IngestionBundle) -> IngestionResult:
        key = (bundle.graph_id, bundle.document_id)
        replayed = key in self.bundles
        self.bundles[key] = bundle
        return IngestionResult(
            graph_id=bundle.graph_id,
            document_id=bundle.document_id,
            chunks=len(bundle.chunks),
            entities=len(bundle.entities),
            relationships=len(bundle.relationships),
            replayed=replayed,
        )
