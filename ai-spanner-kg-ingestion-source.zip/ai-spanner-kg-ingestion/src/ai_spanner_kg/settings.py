from functools import lru_cache
from pathlib import Path

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=(".env", ".env.local"), env_prefix="KG_", extra="ignore"
    )

    extraction_model: str = "gpt-5.6"
    ontology_path: Path = Path("config/ontology.json")
    embedding_model: str = "text-embedding-3-small"
    embedding_dimensions: int = Field(default=256, ge=32, le=3072)
    spanner_project: str = "local-ai-kg"
    spanner_instance: str = "ai-knowledge"
    spanner_database: str = "process-knowledge"
    spanner_emulator_host: str | None = None
    max_upload_bytes: int = Field(default=10 * 1024 * 1024, ge=1, le=100 * 1024 * 1024)
    chunk_size: int = Field(default=1500, ge=500, le=8000)
    chunk_overlap: int = Field(default=200, ge=0, le=1000)


@lru_cache
def get_settings() -> Settings:
    return Settings()
