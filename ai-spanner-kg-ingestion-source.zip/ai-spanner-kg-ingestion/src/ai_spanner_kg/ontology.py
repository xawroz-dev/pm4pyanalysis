from __future__ import annotations

from pathlib import Path

from pydantic import Field, model_validator

from ai_spanner_kg.contracts import ChunkExtraction, StrictModel


class EntityDefinition(StrictModel):
    name: str = Field(min_length=1, max_length=64)
    description: str = Field(min_length=5, max_length=2_000)
    examples: list[str] = Field(default_factory=list, max_length=20)


class RelationshipDefinition(StrictModel):
    name: str = Field(min_length=1, max_length=64)
    description: str = Field(min_length=5, max_length=2_000)
    source_types: list[str] = Field(default_factory=list, max_length=100)
    target_types: list[str] = Field(default_factory=list, max_length=100)


class OntologyConfig(StrictModel):
    version: str = Field(min_length=1, max_length=64)
    entity_types: list[EntityDefinition] = Field(min_length=1, max_length=100)
    relationship_types: list[RelationshipDefinition] = Field(min_length=1, max_length=200)

    @model_validator(mode="after")
    def validate_definitions(self) -> OntologyConfig:
        entity_names = [item.name for item in self.entity_types]
        relationship_names = [item.name for item in self.relationship_types]
        if len(entity_names) != len(set(entity_names)):
            raise ValueError("entity type names must be unique")
        if len(relationship_names) != len(set(relationship_names)):
            raise ValueError("relationship type names must be unique")
        known = set(entity_names)
        for relationship in self.relationship_types:
            if not set(relationship.source_types) <= known:
                raise ValueError(f"{relationship.name} has an unknown source type")
            if not set(relationship.target_types) <= known:
                raise ValueError(f"{relationship.name} has an unknown target type")
        return self

    def validate_extraction(self, extraction: ChunkExtraction) -> None:
        entities = {item.local_id: item for item in extraction.entities}
        allowed_entities = {item.name for item in self.entity_types}
        relationships = {item.name: item for item in self.relationship_types}
        for entity in entities.values():
            if entity.entity_type not in allowed_entities:
                raise ValueError(f"entity type is not configured: {entity.entity_type}")
        for relationship in extraction.relationships:
            definition = relationships.get(relationship.relationship_type)
            if definition is None:
                raise ValueError(
                    f"relationship type is not configured: {relationship.relationship_type}"
                )
            source_type = entities[relationship.source_local_id].entity_type
            target_type = entities[relationship.target_local_id].entity_type
            if definition.source_types and source_type not in definition.source_types:
                raise ValueError(
                    f"{relationship.relationship_type} does not allow source {source_type}"
                )
            if definition.target_types and target_type not in definition.target_types:
                raise ValueError(
                    f"{relationship.relationship_type} does not allow target {target_type}"
                )


def load_ontology(path: Path) -> OntologyConfig:
    return OntologyConfig.model_validate_json(path.read_text(encoding="utf-8"))
