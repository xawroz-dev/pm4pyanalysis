from __future__ import annotations

from openai import OpenAI

from ai_spanner_kg.contracts import ChunkExtraction, TextChunk
from ai_spanner_kg.ontology import OntologyConfig

SYSTEM_PROMPT = """You extract a governed enterprise knowledge graph from one document chunk.
Extract only facts explicitly supported by the chunk and use only the configured ontology below.
Give every entity a unique local_id. Relationships must reference local_ids from the same response.
Preserve relationship meaning with a description, rationale, selection_context, confidence, and an
exact short evidence_quote. Do not infer facts that are not stated. Return empty lists when the
chunk has no supported facts.

CONFIGURED ONTOLOGY:
{ontology}"""


class OpenAIKnowledgeExtractor:
    def __init__(
        self,
        model: str,
        ontology: OntologyConfig,
        client: OpenAI | None = None,
    ) -> None:
        self._model = model
        self._ontology = ontology
        self._client = client or OpenAI()

    def extract(self, chunk: TextChunk) -> ChunkExtraction:
        response = self._client.responses.parse(
            model=self._model,
            input=[
                {
                    "role": "system",
                    "content": SYSTEM_PROMPT.format(
                        ontology=self._ontology.model_dump_json(indent=2)
                    ),
                },
                {
                    "role": "user",
                    "content": f"chunk_id={chunk.chunk_id}\n\n{chunk.content}",
                },
            ],
            text_format=ChunkExtraction,
        )
        if response.output_parsed is None:
            raise RuntimeError("the extraction model returned no structured output")
        self._ontology.validate_extraction(response.output_parsed)
        return response.output_parsed


class OpenAIEmbeddingProvider:
    def __init__(self, model: str, dimensions: int, client: OpenAI | None = None) -> None:
        self._model = model
        self._dimensions = dimensions
        self._client = client or OpenAI()

    @property
    def dimensions(self) -> int:
        return self._dimensions

    def embed(self, texts: list[str]) -> list[list[float]]:
        if not texts:
            return []
        response = self._client.embeddings.create(
            model=self._model,
            input=texts,
            dimensions=self._dimensions,
            encoding_format="float",
        )
        ordered = sorted(response.data, key=lambda item: item.index)
        return [list(item.embedding) for item in ordered]
