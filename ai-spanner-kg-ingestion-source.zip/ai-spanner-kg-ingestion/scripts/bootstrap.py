from __future__ import annotations

import os
import time
from pathlib import Path
from typing import Any

from google.api_core.exceptions import DeadlineExceeded, RetryError, ServiceUnavailable
from google.cloud import spanner
from google.cloud.spanner_v1 import param_types

from ai_spanner_kg.settings import get_settings


def main() -> None:
    for attempt in range(1, 31):
        try:
            _bootstrap()
            return
        except (DeadlineExceeded, RetryError, ServiceUnavailable):
            if attempt == 30:
                raise
            print(f"Waiting for the Spanner emulator ({attempt}/30)...")
            time.sleep(2)


def _bootstrap() -> None:
    settings = get_settings()
    if settings.embedding_dimensions != 256:
        raise ValueError("baseline schema requires KG_EMBEDDING_DIMENSIONS=256")
    if settings.spanner_emulator_host:
        os.environ["SPANNER_EMULATOR_HOST"] = settings.spanner_emulator_host
    client: Any = spanner.Client(project=settings.spanner_project)
    instance = client.instance(
        settings.spanner_instance,
        configuration_name="emulator-config",
        node_count=1,
    )
    if not instance.exists():
        instance.create().result(timeout=60)
    database = instance.database(settings.spanner_database)
    if not database.exists():
        database.create().result(timeout=60)
    if _table_exists(database, "Document"):
        print("Knowledge graph schema already exists.")
        return
    schema = Path(__file__).resolve().parents[1] / "schema" / "001_knowledge_graph.sql"
    database.update_ddl(_split_ddl(schema.read_text(encoding="utf-8"))).result(timeout=180)
    print("Knowledge graph schema created.")


def _table_exists(database: Any, name: str) -> bool:
    with database.snapshot() as snapshot:
        rows = list(
            snapshot.execute_sql(
                "SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME=@name",
                params={"name": name},
                param_types={"name": param_types.STRING},
            )
        )
    return bool(rows and rows[0][0])


def _split_ddl(value: str) -> list[str]:
    lines = [line for line in value.splitlines() if not line.lstrip().startswith("--")]
    return [item.strip() for item in "\n".join(lines).split(";") if item.strip()]


if __name__ == "__main__":
    main()
