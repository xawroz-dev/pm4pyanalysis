# Data model

## Design principles

1. `Process` is the center of the enterprise view.
2. Labels and relationships are allow-listed.
3. Business facts are separate from the evidence that justified them.
4. Documents are versioned and never silently overwritten.
5. BPMN represents expected design; Journey and Variant represent actual runs.
6. Chunks and embeddings stay in Qdrant.

## Neo4j node catalog

| Label | Key | Purpose |
|---|---|---|
| `Process` | `process_id` | Stable process identity |
| `Market` | `market_id` | Country or governed operating market |
| `BusinessUnit` | `business_unit_id` | Accountable organizational unit |
| `Control` | `control_id` | Control requirement |
| `System` | `system_id` | Application or platform |
| `Document` | `document_id` | Logical artifact |
| `DocumentVersion` | `document_version_id` | Immutable content version |
| `Assertion` | `assertion_id` | Auditable claim derived from a version |
| `BPMNModel` | `bpmn_id` | Parsed expected process model |
| `Activity` | `activity_id` | BPMN activity |
| `Journey` | `journey_id` | Observed process instance |
| `Variant` | `variant_id` | Repeated observed activity path |

There is intentionally no `Chunk` label.

## Relationship catalog

### Business semantics

| From | Relationship | To |
|---|---|---|
| Process | `OPERATES_IN` | Market |
| Process | `OWNED_BY` | BusinessUnit |
| Process | `GOVERNED_BY` | Control |
| Process | `USES_SYSTEM` | System |

### Artifact and assertion provenance

| From | Relationship | To |
|---|---|---|
| Process | `HAS_DOCUMENT` | Document |
| Document | `HAS_VERSION` | DocumentVersion |
| Assertion | `SUBJECT` | Process |
| Assertion | `OBJECT` | Market, BusinessUnit, Control, or System |
| Assertion | `EVIDENCED_BY` | DocumentVersion |

### Design and execution

| From | Relationship | To |
|---|---|---|
| Process | `MODELED_BY` | BPMNModel |
| DocumentVersion | `REPRESENTED_BY` | BPMNModel |
| BPMNModel | `DEFINES_ACTIVITY` | Activity |
| Activity | `NEXT_ACTIVITY` | Activity |
| Process | `HAS_JOURNEY` | Journey |
| Process | `HAS_VARIANT` | Variant |
| Journey | `FOLLOWS_VARIANT` | Variant |

The ontology also reserves controlled activity relationships
`PERFORMED_BY`, `USES_SYSTEM`, and `ENFORCES_CONTROL` for later enrichment.

## Example fact and provenance

Suppose a policy states that Procure to Pay applies in Canada.

```text
Process(P2P-001) -OPERATES_IN-> Market(Canada)

Assertion(
  predicate = OPERATES_IN,
  confidence = 1.0,
  evidence = "applies to the United States and Canada markets",
  supporting_chunk_ids = ["..."]
)
  -SUBJECT-> Process(P2P-001)
  -OBJECT-> Market(Canada)
  -EVIDENCED_BY-> DocumentVersion(DOC-P2P-POLICY-001 version 2.0)
```

The first edge is easy to query. The assertion is the audit record. The
supporting chunk ID opens the exact text in Qdrant.

## Important properties

### Process

`process_id`, `name`, `description`, `owner`, `status`, `criticality`, `tags`,
`ontology_version`, timestamps.

### Document

`document_id`, `title`, `document_type`, `source_uri`, `original_filename`,
`current_version_id`, timestamps.

### DocumentVersion

`document_version_id`, `document_id`, `version`, `effective_date`,
`classification`, `checksum`, `media_type`, `vector_chunk_count`, `status`,
`active`, timestamps.

### Assertion

`assertion_id`, `process_id`, `document_version_id`, `predicate`,
`target_type`, `target_id`, `confidence`, `evidence`,
`supporting_chunk_ids`, `status`, `active`, `ontology_version`, timestamps.

### Materialized business relationship

`materialized=true`, `assertion_count`, `confidence`, `ontology_version`,
`updated_at`.

### Journey and Variant

A Journey stores timestamps, outcome, duration, attributes JSON, and events
JSON. A Variant stores its ordered activity IDs. For very high volumes, retain
raw events in a lake/process-mining platform and store graph aggregates or
selected cases rather than every event.

## Qdrant payload

Each point contains:

```json
{
  "chunk_id": "deterministic UUID",
  "document_id": "DOC-P2P-SOP-001",
  "document_version_id": "DOC-P2P-SOP-001:version:...",
  "process_id": "P2P-001",
  "ordinal": 2,
  "chunk_kind": "content",
  "text": "exact passage text",
  "content_hash": "...",
  "title": "Procure-to-Pay Standard Operating Procedure",
  "document_type": "sop",
  "classification": "internal",
  "section": "Control requirements",
  "char_start": 800,
  "char_end": 1600,
  "active": true
}
```

The vector itself is stored beside this payload.

## Identity and update rules

- User-supplied enterprise IDs are preferred.
- Otherwise, domain entity IDs are deterministic from type and canonical name.
- Document-version IDs are deterministic from document ID, version, and checksum.
- Assertion IDs are deterministic from version, process, predicate, target type,
  and target ID.
- Re-ingesting an unchanged document ID/checksum is a no-op.
- Only one version per logical document is active.
- Only active approved assertions contribute to materialized business edges.
