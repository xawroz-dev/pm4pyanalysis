# Architecture

## Goal

The store must answer both structured and narrative process questions:

- Where does a process operate?
- Who owns it?
- Which controls and systems apply?
- What does the policy or SOP say?
- What is the designed BPMN flow?
- Which paths are actually occurring?
- What exact evidence supports the answer?

No single storage pattern handles all of these equally well. The application
uses Neo4j for connected enterprise facts and Qdrant for semantic passages.

## Logical components

```mermaid
flowchart LR
  U["Files + metadata"] --> I["Ingestion service"]
  J["Live journey events"] --> I
  I --> X["Governed extraction"]
  X --> N["Neo4j<br/>business graph"]
  I --> C["Chunk + embed"]
  C --> Q["Qdrant<br/>passages"]
  B["Browser UI / API"] --> R["Fixed-intent retriever"]
  R --> N
  R --> Q
  R --> L["Optional answer LLM"]
  L --> B
```

### Neo4j owns

- process identity and metadata;
- Market, BusinessUnit, Control, and System entities;
- process-to-entity relationships;
- document and immutable version provenance;
- auditable assertions;
- BPMN models, activities, and flow;
- observed journeys and variants.

### Qdrant owns

- deterministic chunk IDs;
- chunk text and locators;
- embeddings;
- process/document/version scope;
- classification and active flags.

### Shared identity

Every vector payload has `process_id`, `document_id`, and
`document_version_id`. The point ID is the `chunk_id`. An assertion may keep a
small `supporting_chunk_ids` list. These keys provide a deliberate cross-store
join without representing every passage as a graph entity.

## Read path

```mermaid
sequenceDiagram
  participant UI
  participant API
  participant Graph as Neo4j
  participant Vector as Qdrant
  participant LLM
  UI->>API: question + process + clearance
  API->>Graph: active accessible version IDs
  Graph-->>API: version scope
  API->>Vector: similarity search within scope
  Vector-->>API: passages + chunk IDs
  API->>Graph: fixed query for classified intent
  Graph-->>API: governed facts + assertion evidence
  API->>LLM: facts and passages only
  LLM-->>API: cited response
  API-->>UI: answer, facts, citations
```

The offline mode replaces the final LLM call with deterministic formatting.

## Write and activation path

Document versions are immutable. New data is staged before it becomes visible:

1. parse, validate, extract, chunk, and embed;
2. stage graph version;
3. write inactive Qdrant points;
4. write staged assertions and BPMN structure;
5. activate the selected Neo4j version;
6. activate the matching Qdrant points;
7. supersede the old version and rebuild materialized business edges.

The POC uses compensating rollback because Neo4j and Qdrant do not share an ACID
transaction. A production pipeline should add a durable ingestion state machine,
retry queue, and reconciliation schedule.

## Retrieval boundary versus domain boundary

A 900-character fragment exists because a retrieval algorithm needs it.
Changing chunk size can split it into two different fragments even though the
enterprise process has not changed. That makes a chunk a retrieval artifact,
not a stable domain concept.

Keeping chunks vector-only:

- prevents re-chunking from rewriting the business graph;
- keeps graph exploration useful to process owners;
- reduces node and edge volume;
- preserves passage-level citation through stable IDs.

Assertions bridge meaning and evidence. They remain meaningful across UI,
governance, and audit workflows, while their supporting IDs locate exact text.

## Scale and safety

- UI graph endpoints return bounded process views, never the entire enterprise
  graph by default.
- Chat uses a code-owned intent catalog and parameters, not LLM-generated Cypher.
- Vector searches filter by classification, active document version, and process.
- Unique constraints protect canonical IDs.
- Direct business relationships are materialized from active assertions for
  fast traversal.
- Full-database visualization queries are included only for the small POC.

## Production evolution

Recommended next capabilities:

1. external master-data IDs for markets, units, controls, and applications;
2. identity resolution and steward approval queues;
3. ABAC/RBAC enforced in both graph and vector scopes;
4. temporal validity for facts beyond document-version activation;
5. event-lake ingestion for high-volume journeys, with aggregated graph nodes;
6. ontology migrations with compatibility tests;
7. observability for retrieval recall, citation accuracy, and assertion drift.
