# Retrieval and governance

## Fixed-intent hybrid retrieval

The retriever classifies a question into one reviewed intent:

`process_overview`, `controls`, `systems`, `ownership`, `markets`, `documents`,
`evidence_lineage`, `bpmn_flow`, `variants`, `journeys`, or
`generic_evidence`.

Each intent maps to a parameterized Cypher query in
`app/services/retrieval.py`. User text never becomes Cypher.

In parallel, the question is embedded and searched in Qdrant. The vector query
is filtered by:

- process ID;
- active document versions obtained from Neo4j;
- document classification allowed by the caller;
- active chunk status.

The graph yields exact relationships. The passages yield explanatory context.
The answer contains both structured rows and exact citations.

## Evidence lineage

A citation ID can be resolved in two steps:

1. Qdrant returns the chunk payload and its `document_version_id`.
2. Neo4j returns the Process → Document → DocumentVersion provenance and any
   Assertion whose `supporting_chunk_ids` contains that chunk.

Some passages have no matching assertion. That is expected. For example, an SOP
paragraph may explain exception handling without defining a Market, owner,
Control, or System fact. It remains valuable RAG context.

## Reconciliation rules

The correct integrity rules are:

- every active assertion-referenced chunk ID exists in Qdrant;
- every active Qdrant chunk belongs to an active graph document version.

It is **not** correct to require the number of graph references to equal the
number of vector chunks. Unreferenced chunks are normal narrative context.

Call:

```bash
curl -s http://localhost:8000/v1/governance/reconciliation/P2P-001 \
  | python -m json.tool
```

## Classification controls

Clearance levels are cumulative:

| Clearance | Accessible classifications |
|---|---|
| public | public |
| internal | public, internal |
| confidential | public, internal, confidential |
| restricted | all four |

The graph scopes active document versions before vector retrieval, and both
graph facts and evidence endpoints enforce the same allowed classifications.
Production systems should derive clearance and process permissions from signed
identity claims, not request body fields.

## Extraction governance

The extractor may produce only:

- Market → `OPERATES_IN`;
- BusinessUnit → `OWNED_BY`;
- Control → `GOVERNED_BY`;
- System → `USES_SYSTEM`.

Pydantic validates output types and the ontology validates relationship triples.
Low-confidence results are removed. Unresolved targets are removed. Repeated
facts are normalized and deduplicated. An optional LLM therefore proposes
facts; it does not control the schema.

## Why open ontologies become noisy

Without constraints, similar content can create:

```text
Country, Market, Territory, Geography, Nation
OPERATES_IN, APPLIES_TO, AVAILABLE_IN, SERVES, COVERS
```

This increases the number of query dimensions without increasing useful
knowledge. A retrieval system then needs synonym expansion, uncertain path
selection, and continuous cleanup. Fixed semantics allow a single tested query,
stable dashboards, and clear stewardship.

The comparison API demonstrates noisy extraction in isolation; it never writes
those arbitrary labels or relationships to Neo4j.

## Evaluation recommendations

For production, maintain a labeled question set and track:

- intent classification accuracy;
- graph fact precision and recall;
- vector passage recall at K;
- citation correctness;
- unsupported answer rate;
- classification leakage tests;
- stale-version retrieval rate;
- entity duplication rate;
- percentage of assertions awaiting review.

Test ontology and prompt changes against the same set before deployment.
