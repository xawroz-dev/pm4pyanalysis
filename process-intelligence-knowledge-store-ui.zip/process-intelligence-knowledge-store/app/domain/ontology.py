"""Governed enterprise process-intelligence ontology.

Only stable business concepts and artifact provenance belong in Neo4j. Retrieval
chunks and embeddings are intentionally owned by the vector store.
"""

from enum import StrEnum

ONTOLOGY_VERSION = "3.0"


class NodeType(StrEnum):
    PROCESS = "Process"
    DOCUMENT = "Document"
    DOCUMENT_VERSION = "DocumentVersion"
    ASSERTION = "Assertion"
    BPMN_MODEL = "BPMNModel"
    ACTIVITY = "Activity"
    JOURNEY = "Journey"
    VARIANT = "Variant"
    MARKET = "Market"
    BUSINESS_UNIT = "BusinessUnit"
    CONTROL = "Control"
    SYSTEM = "System"


class RelationshipType(StrEnum):
    HAS_DOCUMENT = "HAS_DOCUMENT"
    HAS_VERSION = "HAS_VERSION"
    SUBJECT = "SUBJECT"
    OBJECT = "OBJECT"
    EVIDENCED_BY = "EVIDENCED_BY"
    REPRESENTED_BY = "REPRESENTED_BY"
    MODELED_BY = "MODELED_BY"
    DEFINES_ACTIVITY = "DEFINES_ACTIVITY"
    HAS_JOURNEY = "HAS_JOURNEY"
    HAS_VARIANT = "HAS_VARIANT"
    FOLLOWS_VARIANT = "FOLLOWS_VARIANT"
    OPERATES_IN = "OPERATES_IN"
    OWNED_BY = "OWNED_BY"
    GOVERNED_BY = "GOVERNED_BY"
    USES_SYSTEM = "USES_SYSTEM"
    PERFORMED_BY = "PERFORMED_BY"
    ENFORCES_CONTROL = "ENFORCES_CONTROL"
    NEXT_ACTIVITY = "NEXT_ACTIVITY"


DOMAIN_ENTITY_TYPES = {
    NodeType.MARKET,
    NodeType.BUSINESS_UNIT,
    NodeType.CONTROL,
    NodeType.SYSTEM,
}

ALLOWED_RELATIONSHIPS: set[tuple[NodeType, RelationshipType, NodeType]] = {
    (NodeType.PROCESS, RelationshipType.HAS_DOCUMENT, NodeType.DOCUMENT),
    (NodeType.DOCUMENT, RelationshipType.HAS_VERSION, NodeType.DOCUMENT_VERSION),
    (NodeType.DOCUMENT_VERSION, RelationshipType.REPRESENTED_BY, NodeType.BPMN_MODEL),
    (NodeType.ASSERTION, RelationshipType.SUBJECT, NodeType.PROCESS),
    (NodeType.ASSERTION, RelationshipType.OBJECT, NodeType.MARKET),
    (NodeType.ASSERTION, RelationshipType.OBJECT, NodeType.BUSINESS_UNIT),
    (NodeType.ASSERTION, RelationshipType.OBJECT, NodeType.CONTROL),
    (NodeType.ASSERTION, RelationshipType.OBJECT, NodeType.SYSTEM),
    (NodeType.ASSERTION, RelationshipType.EVIDENCED_BY, NodeType.DOCUMENT_VERSION),
    (NodeType.PROCESS, RelationshipType.MODELED_BY, NodeType.BPMN_MODEL),
    (NodeType.BPMN_MODEL, RelationshipType.DEFINES_ACTIVITY, NodeType.ACTIVITY),
    (NodeType.PROCESS, RelationshipType.HAS_JOURNEY, NodeType.JOURNEY),
    (NodeType.PROCESS, RelationshipType.HAS_VARIANT, NodeType.VARIANT),
    (NodeType.JOURNEY, RelationshipType.FOLLOWS_VARIANT, NodeType.VARIANT),
    (NodeType.PROCESS, RelationshipType.OPERATES_IN, NodeType.MARKET),
    (NodeType.PROCESS, RelationshipType.OWNED_BY, NodeType.BUSINESS_UNIT),
    (NodeType.PROCESS, RelationshipType.GOVERNED_BY, NodeType.CONTROL),
    (NodeType.PROCESS, RelationshipType.USES_SYSTEM, NodeType.SYSTEM),
    (NodeType.ACTIVITY, RelationshipType.PERFORMED_BY, NodeType.BUSINESS_UNIT),
    (NodeType.ACTIVITY, RelationshipType.USES_SYSTEM, NodeType.SYSTEM),
    (NodeType.ACTIVITY, RelationshipType.ENFORCES_CONTROL, NodeType.CONTROL),
    (NodeType.ACTIVITY, RelationshipType.NEXT_ACTIVITY, NodeType.ACTIVITY),
}

ID_KEYS: dict[NodeType, str] = {
    NodeType.PROCESS: "process_id",
    NodeType.DOCUMENT: "document_id",
    NodeType.DOCUMENT_VERSION: "document_version_id",
    NodeType.ASSERTION: "assertion_id",
    NodeType.BPMN_MODEL: "bpmn_id",
    NodeType.ACTIVITY: "activity_id",
    NodeType.JOURNEY: "journey_id",
    NodeType.VARIANT: "variant_id",
    NodeType.MARKET: "market_id",
    NodeType.BUSINESS_UNIT: "business_unit_id",
    NodeType.CONTROL: "control_id",
    NodeType.SYSTEM: "system_id",
}


def validate_relationship(
    source_type: NodeType, relationship_type: RelationshipType, target_type: NodeType
) -> None:
    triple = (source_type, relationship_type, target_type)
    if triple not in ALLOWED_RELATIONSHIPS:
        raise ValueError(f"Relationship triple is outside ontology v{ONTOLOGY_VERSION}: {triple}")
