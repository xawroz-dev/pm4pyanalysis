/* The UI consumes only bounded APIs. It never constructs or submits Cypher. */
const state = { processes: [], processId: "", clearance: "internal", graph: null };
const $ = (selector) => document.querySelector(selector);
const colors = {
  Process: "#087f78", Market: "#4a83c3", BusinessUnit: "#7758b3",
  Control: "#d98324", System: "#2f9b6d", Document: "#58717b",
  DocumentVersion: "#91a4ab", Assertion: "#c95d75", BPMNModel: "#226c91",
  Activity: "#58a4c5", Journey: "#aa773d", Variant: "#b89555"
};
const prompts = {
  "P2P-001": [
    "Which markets does Procure to Pay operate in?",
    "What controls govern this process?",
    "Show the BPMN flow and activities.",
    "Which live process variants have occurred?"
  ],
  "O2C-001": [
    "Which systems support Order to Cash?",
    "Who owns this process?",
    "What controls govern credit and revenue?",
    "Show the live journeys and their outcomes."
  ]
};

async function api(path, options) {
  const response = await fetch(path, options);
  if (!response.ok) throw new Error((await response.text()) || response.statusText);
  return response.json();
}

async function initialize() {
  try {
    const [health, processResult] = await Promise.all([api("/health"), api("/v1/processes")]);
    $("#health").textContent = health.status === "ok" ? "Stores healthy" : "Degraded";
    $("#health").classList.toggle("ok", health.status === "ok");
    state.processes = processResult.processes;
    $("#processSelect").innerHTML = state.processes.map(
      p => `<option value="${escapeHtml(p.process_id)}">${escapeHtml(p.name)} · ${escapeHtml(p.process_id)}</option>`
    ).join("");
    state.processId = state.processes[0]?.process_id || "";
    renderSummary();
    renderPrompts();
  } catch (error) {
    $("#health").textContent = "API unavailable";
    $("#messages").insertAdjacentHTML("beforeend", `<p class="error">${escapeHtml(error.message)}</p>`);
  }
}

function currentProcess() {
  return state.processes.find(p => p.process_id === state.processId) || {};
}

function renderSummary() {
  const p = currentProcess();
  $("#summary").innerHTML = `
    <article class="summary-card primary"><small>Selected process</small><strong>${escapeHtml(p.name || "No data")}</strong><span>${escapeHtml(p.description || "")}</span></article>
    <article class="summary-card"><small>Documents</small><strong>${p.document_count ?? 0}</strong><span>Process, SOP, policy, BPMN</span></article>
    <article class="summary-card"><small>Live journeys</small><strong>${p.journey_count ?? 0}</strong><span>Observed executions</span></article>
    <article class="summary-card"><small>Criticality</small><strong>${escapeHtml(p.criticality || "—")}</strong><span>${escapeHtml(p.owner || "Owner unavailable")}</span></article>`;
}

function renderPrompts() {
  $("#prompts").innerHTML = (prompts[state.processId] || prompts["P2P-001"]).map(
    p => `<button class="prompt" data-question="${escapeHtml(p)}">${escapeHtml(p)}</button>`
  ).join("");
  document.querySelectorAll(".prompt").forEach(button => button.onclick = () => ask(button.dataset.question));
}

async function ask(question) {
  if (!question.trim()) return;
  $("#question").value = "";
  $("#messages").insertAdjacentHTML("beforeend", `<article class="message user"><div>${escapeHtml(question)}</div></article>`);
  const loadingId = `loading-${Date.now()}`;
  $("#messages").insertAdjacentHTML("beforeend", `<article id="${loadingId}" class="message assistant"><div class="avatar">PI</div><div><p>Searching governed graph facts and document evidence…</p></div></article>`);
  $("#messages").scrollTop = $("#messages").scrollHeight;
  $("#sendButton").disabled = true;
  try {
    const result = await api("/v1/chat", {
      method: "POST", headers: {"Content-Type": "application/json"},
      body: JSON.stringify({question, process_id: state.processId, classification_clearance: state.clearance, top_k: 6})
    });
    $(`#${loadingId}`).outerHTML = renderAnswer(result);
    wireCitations();
    renderFollowups(result.intent);
  } catch (error) {
    $(`#${loadingId}`).innerHTML = `<div class="avatar">!</div><div><p class="error">${escapeHtml(error.message)}</p></div>`;
  } finally {
    $("#sendButton").disabled = false;
    $("#messages").scrollTop = $("#messages").scrollHeight;
  }
}

function renderAnswer(result) {
  const facts = result.graph_facts || [];
  const factTable = facts.length ? renderFactTable(facts.slice(0, 20)) : "";
  const citations = (result.citations || []).map((c, i) => `
    <button class="citation" data-chunk="${escapeHtml(c.chunk_id)}">
      <strong>${i + 1}. ${escapeHtml(c.title)}</strong>
      <span>${escapeHtml(c.section || "Document passage")} · score ${Number(c.score).toFixed(3)}</span>
    </button>`).join("");
  return `<article class="message assistant"><div class="avatar">PI</div><div>
    <p>${escapeHtml(result.answer)}</p>${factTable}
    ${citations ? `<div class="citations">${citations}</div>` : ""}
    <p class="eyebrow">Intent: ${escapeHtml(result.intent)} · ${facts.length} graph row(s) · ${(result.citations || []).length} vector passage(s)</p>
  </div></article>`;
}

function renderFactTable(rows) {
  const keys = [...new Set(rows.flatMap(Object.keys))].slice(0, 6);
  return `<div class="table-scroll"><table class="facts"><thead><tr>${keys.map(k => `<th>${escapeHtml(k)}</th>`).join("")}</tr></thead>
    <tbody>${rows.map(row => `<tr>${keys.map(k => `<td>${escapeHtml(formatValue(row[k]))}</td>`).join("")}</tr>`).join("")}</tbody></table></div>`;
}

function renderFollowups(intent) {
  const map = {
    markets: ["Which controls apply?", "Show supporting documents"],
    controls: ["Which systems execute these controls?", "Show evidence lineage"],
    systems: ["Show the BPMN flow", "Who owns the process?"],
    bpmn_flow: ["Compare this with live variants"],
    variants: ["Show the recent journeys"],
    documents: ["Show evidence lineage"]
  };
  $("#followups").innerHTML = (map[intent] || []).map(q => `<button>${escapeHtml(q)}</button>`).join("");
  $("#followups").querySelectorAll("button").forEach(button => button.onclick = () => ask(button.textContent));
}

function wireCitations() {
  document.querySelectorAll(".citation").forEach(button => button.onclick = async () => {
    try {
      const data = await api(`/v1/evidence/chunks/${encodeURIComponent(button.dataset.chunk)}?classification_clearance=${state.clearance}`);
      $("#evidenceTitle").textContent = data.lineage.document_title;
      const assertions = data.lineage.assertions?.filter(Boolean) || [];
      $("#evidenceBody").innerHTML = `
        <div class="property"><strong>Process</strong><span>${escapeHtml(data.lineage.process_name)}</span></div>
        <div class="property"><strong>Version</strong><span>${escapeHtml(data.lineage.version)}</span></div>
        <div class="property"><strong>Chunk ID</strong><span>${escapeHtml(data.lineage.chunk_id)}</span></div>
        <div class="property"><strong>Assertions</strong><span>${escapeHtml(assertions.map(a => `${a.predicate} ${a.target_name}`).join(", ") || "Narrative context only")}</span></div>
        <h3>Retrieved text</h3><div class="evidence-text">${escapeHtml(data.content.text)}</div>`;
      $("#evidenceDialog").showModal();
    } catch (error) { alert(error.message); }
  });
}

async function loadGraph() {
  const view = $("#viewSelect").value;
  const data = await api(`/v1/graph/processes/${encodeURIComponent(state.processId)}/visualization?view=${view}&classification_clearance=${state.clearance}`);
  state.graph = data;
  renderGraph(data.nodes || [], data.edges || []);
}

function renderGraph(nodes, edges) {
  const svg = $("#graphCanvas");
  const width = svg.clientWidth || 900, height = 520, cx = width / 2, cy = height / 2;
  svg.setAttribute("viewBox", `0 0 ${width} ${height}`);
  const process = nodes.find(n => n.label === "Process");
  const others = nodes.filter(n => n !== process);
  const positioned = new Map();
  if (process) positioned.set(process.id, {x: cx, y: cy});
  const groups = [...new Set(others.map(n => n.label))];
  others.forEach((node, index) => {
    const groupIndex = groups.indexOf(node.label);
    const same = others.filter(n => n.label === node.label);
    const itemIndex = same.indexOf(node);
    const angle = (Math.PI * 2 * groupIndex / Math.max(groups.length, 1)) - Math.PI / 2;
    const spread = (itemIndex - (same.length - 1) / 2) * 28;
    const radius = Math.min(width, height) * (groups.length > 5 ? .38 : .34);
    positioned.set(node.id, {x: cx + Math.cos(angle) * radius - Math.sin(angle) * spread, y: cy + Math.sin(angle) * radius + Math.cos(angle) * spread});
  });
  const edgeMarkup = edges.map(edge => {
    const a = positioned.get(edge.source), b = positioned.get(edge.target);
    if (!a || !b) return "";
    const mx = (a.x + b.x) / 2, my = (a.y + b.y) / 2;
    return `<g><line class="graph-edge" x1="${a.x}" y1="${a.y}" x2="${b.x}" y2="${b.y}"/><text class="graph-edge-label" x="${mx}" y="${my - 4}" text-anchor="middle">${escapeHtml(edge.relationship)}</text></g>`;
  }).join("");
  const nodeMarkup = nodes.map(node => {
    const p = positioned.get(node.id); if (!p) return "";
    const radius = node.label === "Process" ? 28 : 18;
    return `<g class="graph-node" data-node="${escapeHtml(node.id)}" transform="translate(${p.x},${p.y})"><circle r="${radius}" fill="${colors[node.label] || "#70858d"}"/><text y="${radius + 15}" text-anchor="middle">${escapeHtml(shorten(node.name, 25))}</text></g>`;
  }).join("");
  svg.innerHTML = edgeMarkup + nodeMarkup;
  svg.querySelectorAll(".graph-node").forEach(element => element.onclick = () => inspectNode(nodes.find(n => n.id === element.dataset.node)));
  $("#legend").innerHTML = groups.concat(process ? ["Process"] : []).filter((x, i, a) => a.indexOf(x) === i).map(label => `<span><i style="background:${colors[label] || "#70858d"}"></i>${escapeHtml(label)}</span>`).join("");
  $("#relationshipRows").innerHTML = edges.map(edge => {
    const source = nodes.find(n => n.id === edge.source), target = nodes.find(n => n.id === edge.target);
    return `<tr><td>${escapeHtml(source?.name || edge.source)}</td><td>${escapeHtml(edge.relationship)}</td><td>${escapeHtml(target?.name || edge.target)}</td><td>${escapeHtml(formatValue(edge.properties))}</td></tr>`;
  }).join("");
  $("#graphCount").textContent = `${nodes.length} nodes · ${edges.length} relationships`;
}

function inspectNode(node) {
  if (!node) return;
  $("#inspector").innerHTML = `<p class="eyebrow">${escapeHtml(node.label)}</p><h3>${escapeHtml(node.name)}</h3>
    ${Object.entries(node.properties || {}).sort().map(([k,v]) => `<div class="property"><strong>${escapeHtml(k)}</strong><span>${escapeHtml(formatValue(v))}</span></div>`).join("")}`;
}

function formatValue(value) {
  if (value === null || value === undefined) return "—";
  if (typeof value === "object") return JSON.stringify(value);
  return String(value);
}
function shorten(value, max) { value = String(value || ""); return value.length > max ? value.slice(0, max - 1) + "…" : value; }
function escapeHtml(value) { return String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }

$("#chatForm").addEventListener("submit", event => { event.preventDefault(); ask($("#question").value); });
$("#processSelect").addEventListener("change", event => {
  state.processId = event.target.value; renderSummary(); renderPrompts();
  if (!$(".tab[data-tab='graph']").classList.contains("active")) return;
  loadGraph().catch(error => alert(error.message));
});
$("#clearanceSelect").addEventListener("change", event => { state.clearance = event.target.value; });
$("#viewSelect").addEventListener("change", () => loadGraph().catch(error => alert(error.message)));
document.querySelectorAll(".tab").forEach(tab => tab.onclick = () => {
  document.querySelectorAll(".tab").forEach(t => t.classList.toggle("active", t === tab));
  $("#chatPanel").classList.toggle("hidden", tab.dataset.tab !== "chat");
  $("#graphPanel").classList.toggle("hidden", tab.dataset.tab !== "graph");
  if (tab.dataset.tab === "graph") loadGraph().catch(error => alert(error.message));
});
$(".dialog-close").onclick = () => $("#evidenceDialog").close();
initialize();
