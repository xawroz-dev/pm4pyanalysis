# Procure-to-Pay Process Definition

## Purpose and scope

Procure to Pay (P2P-001) converts an approved business need into a paid supplier
invoice. It operates in the United States and Canada. Global Procurement Operations
owns the process and Accounts Payable Operations resolves invoice exceptions.

## Business flow

1. An employee submits a purchase request in Coupa.
2. The request is approved under CTRL-PO-001.
3. SAP S/4HANA creates and records the purchase order.
4. The receiving team records delivery.
5. Accounts Payable performs control CTRL-3WM-002 before payment.
6. SAP S/4HANA releases the supplier payment.

The BPMN model defines the expected flow. Live journeys show whether actual cases
follow the straight-through path or a match-exception variant.
