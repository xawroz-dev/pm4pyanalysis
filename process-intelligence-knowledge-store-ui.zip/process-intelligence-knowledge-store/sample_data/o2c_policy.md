# Order Acceptance and Revenue Policy

All customer orders in Germany and the United Kingdom must follow the Order-to-Cash
process. Global Order Management is accountable for order acceptance and Accounts
Receivable is accountable for invoicing and collection.

CTRL-CREDIT-001 requires a recorded credit approval before fulfillment. Salesforce
is the system used for customer and order intake.

CTRL-REVREC-003 prohibits revenue recognition before fulfillment is confirmed.
SAP S/4HANA is the system of record for fulfillment, invoices, receivables, cash
application, and the accounting entry.
