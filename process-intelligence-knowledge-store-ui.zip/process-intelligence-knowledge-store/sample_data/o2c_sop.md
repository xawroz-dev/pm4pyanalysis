# Order-to-Cash Standard Operating Procedure

The Order-to-Cash process applies to Germany and the United Kingdom. Global Order
Management reviews customer orders received in Salesforce. Accounts Receivable
manages invoices and payments in SAP S/4HANA.

For CTRL-CREDIT-001, an order may proceed only when the customer has sufficient
credit or an authorized manager releases the hold. After fulfillment, SAP S/4HANA
issues an invoice. Accounts Receivable applies the customer payment to the invoice
and investigates any difference before closing the order.

For CTRL-REVREC-003, revenue recognition requires confirmed fulfillment and a valid
customer invoice. Evidence of the credit decision, fulfillment, invoice, and cash
application must be retained with the order record.
