# Order-to-Cash Process Definition

## Purpose and scope

Order to Cash (O2C-001) converts an accepted customer order into collected cash. It
operates in Germany and the United Kingdom. Global Order Management owns order
acceptance, while Accounts Receivable owns invoicing and collection.

## Business flow

1. Salesforce receives the customer order.
2. Global Order Management validates the customer and order.
3. CTRL-CREDIT-001 requires a credit check before fulfillment.
4. SAP S/4HANA records fulfillment and issues the invoice.
5. CTRL-REVREC-003 requires confirmed fulfillment before revenue recognition.
6. Accounts Receivable applies payment and closes the order.

The BPMN model is the expected design. Live journeys contain a straight-through
variant and a credit-hold variant for comparison.
