// Ontology v3.0. Executed automatically by the API; retained for DBA review.
CREATE CONSTRAINT process_process_id IF NOT EXISTS FOR (n:Process) REQUIRE n.process_id IS UNIQUE;
CREATE CONSTRAINT document_document_id IF NOT EXISTS FOR (n:Document) REQUIRE n.document_id IS UNIQUE;
CREATE CONSTRAINT documentversion_document_version_id IF NOT EXISTS FOR (n:DocumentVersion) REQUIRE n.document_version_id IS UNIQUE;
CREATE CONSTRAINT assertion_assertion_id IF NOT EXISTS FOR (n:Assertion) REQUIRE n.assertion_id IS UNIQUE;
CREATE CONSTRAINT bpmnmodel_bpmn_id IF NOT EXISTS FOR (n:BPMNModel) REQUIRE n.bpmn_id IS UNIQUE;
CREATE CONSTRAINT activity_activity_id IF NOT EXISTS FOR (n:Activity) REQUIRE n.activity_id IS UNIQUE;
CREATE CONSTRAINT journey_journey_id IF NOT EXISTS FOR (n:Journey) REQUIRE n.journey_id IS UNIQUE;
CREATE CONSTRAINT variant_variant_id IF NOT EXISTS FOR (n:Variant) REQUIRE n.variant_id IS UNIQUE;
CREATE CONSTRAINT market_market_id IF NOT EXISTS FOR (n:Market) REQUIRE n.market_id IS UNIQUE;
CREATE CONSTRAINT businessunit_business_unit_id IF NOT EXISTS FOR (n:BusinessUnit) REQUIRE n.business_unit_id IS UNIQUE;
CREATE CONSTRAINT control_control_id IF NOT EXISTS FOR (n:Control) REQUIRE n.control_id IS UNIQUE;
CREATE CONSTRAINT system_system_id IF NOT EXISTS FOR (n:System) REQUIRE n.system_id IS UNIQUE;

CREATE INDEX process_name IF NOT EXISTS FOR (n:Process) ON (n.name);
CREATE INDEX document_version_checksum IF NOT EXISTS FOR (n:DocumentVersion) ON (n.checksum);
CREATE INDEX assertion_active_predicate IF NOT EXISTS FOR (n:Assertion) ON (n.active, n.predicate);
