// PROCESS INTELLIGENCE GRAPH EXPLORATION QUERIES
// Paste one query at a time into http://localhost:7474/browser/

// 1. Small demo: view every stored relationship as a graph.
MATCH path=(source)-[relationship]->(target)
RETURN path
LIMIT 500;

// 2. Recommended business view for Procure to Pay.
MATCH path=(p:Process {process_id: 'P2P-001'})
  -[:OPERATES_IN|OWNED_BY|GOVERNED_BY|USES_SYSTEM]->()
RETURN path;

// 3. Recommended business view for Order to Cash.
MATCH path=(p:Process {process_id: 'O2C-001'})
  -[:OPERATES_IN|OWNED_BY|GOVERNED_BY|USES_SYSTEM]->()
RETURN path;

// 4. Explore every node, relationship, and property in a readable table.
MATCH (source)-[relationship]->(target)
RETURN labels(source) AS source_labels,
       properties(source) AS source_properties,
       type(relationship) AS relationship,
       properties(relationship) AS relationship_properties,
       labels(target) AS target_labels,
       properties(target) AS target_properties
ORDER BY relationship
LIMIT 500;

// 5. Markets: shows "operates in" and all Market properties.
MATCH (p:Process)-[r:OPERATES_IN]->(m:Market)
RETURN p.process_id AS process_id, p.name AS process,
       type(r) AS relationship, properties(r) AS relationship_properties,
       m.market_id AS market_id, m.name AS market,
       properties(m) AS market_properties
ORDER BY process, market;

// 6. Inventory all node labels.
MATCH (node)
UNWIND labels(node) AS label
RETURN label, count(*) AS node_count
ORDER BY node_count DESC, label;

// 7. Inventory all relationship types.
MATCH ()-[r]->()
RETURN type(r) AS relationship, count(*) AS relationship_count
ORDER BY relationship_count DESC, relationship;

// 8. Process artifacts and active versions. There are no Chunk nodes.
MATCH path=(p:Process {process_id: 'P2P-001'})-[:HAS_DOCUMENT]->
           (d:Document)-[:HAS_VERSION]->(v:DocumentVersion {active: true})
RETURN path;

// 9. Auditable claim: assertion -> process/entity/version.
MATCH (a:Assertion {active: true})-[:SUBJECT]->(p:Process {process_id: 'P2P-001'})
MATCH (a)-[:OBJECT]->(entity)
MATCH (a)-[:EVIDENCED_BY]->(v:DocumentVersion {active: true})
RETURN a.assertion_id, a.predicate, a.confidence, a.evidence,
       a.supporting_chunk_ids, labels(entity) AS entity_type, properties(entity),
       v.document_version_id, v.version
ORDER BY a.predicate, entity.name;

// 10. Visualize assertions and provenance as paths.
MATCH evidence=(p:Process {process_id: 'P2P-001'})<-[:SUBJECT]-
               (a:Assertion {active: true})-[:OBJECT]->(entity)
MATCH version=(a)-[:EVIDENCED_BY]->(v:DocumentVersion {active: true})
RETURN evidence, version
LIMIT 200;

// 11. Expected BPMN model and activity sequence.
MATCH model=(p:Process {process_id: 'P2P-001'})-[:MODELED_BY]->
            (b:BPMNModel)-[:DEFINES_ACTIVITY]->(activity:Activity)
OPTIONAL MATCH flow=(activity)-[:NEXT_ACTIVITY]->(next:Activity)
RETURN model, flow;

// 12. Live journeys and variants.
MATCH journey=(p:Process {process_id: 'P2P-001'})-[:HAS_JOURNEY]->
              (j:Journey)-[:FOLLOWS_VARIANT]->(v:Variant)
RETURN journey;

// 13. Compare markets, controls, owners, and systems for both examples.
MATCH (p:Process)-[r:OPERATES_IN|OWNED_BY|GOVERNED_BY|USES_SYSTEM]->(entity)
WHERE p.process_id IN ['P2P-001', 'O2C-001']
RETURN p.process_id, p.name, type(r), labels(entity)[0], entity.name,
       r.assertion_count, r.confidence
ORDER BY p.process_id, type(r), entity.name;

// 14. Demo-only neighborhood. Keep depth and LIMIT bounded in production.
MATCH path=(p:Process {process_id: 'O2C-001'})-[*1..3]-(node)
RETURN path
LIMIT 500;
