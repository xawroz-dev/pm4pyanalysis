from pathlib import Path

from app.domain.models import DocumentMetadata, JourneyBatch
from app.services.retrieval import GRAPH_QUERIES

ROOT = Path(__file__).resolve().parents[1]


def test_sample_catalog_has_two_complete_processes():
    for prefix, process_id in (("p2p", "P2P-001"), ("o2c", "O2C-001")):
        for artifact in ("process", "sop", "policy", "bpmn"):
            metadata = DocumentMetadata.model_validate_json(
                (ROOT / "sample_data" / f"{prefix}_{artifact}.metadata.json").read_text()
            )
            assert metadata.process.process_id == process_id
            assert metadata.document_type == artifact

    assert (
        len(
            JourneyBatch.model_validate_json(
                (ROOT / "sample_data" / "journeys.json").read_text()
            ).journeys
        )
        == 2
    )
    assert (
        len(
            JourneyBatch.model_validate_json(
                (ROOT / "sample_data" / "journeys_o2c.json").read_text()
            ).journeys
        )
        == 2
    )


def test_fixed_query_catalog_never_traverses_graph_chunk_nodes():
    query_text = "\n".join(GRAPH_QUERIES.values())
    assert "HAS_CHUNK" not in query_text
    assert ":Chunk" not in query_text
