// 1. Clean semantic process neighborhood.
MATCH path=(p:Process {process_id: "P2P-001"})
           -[:OPERATES_IN|OWNED_BY|GOVERNED_BY|USES_SYSTEM]->(entity)
RETURN path;

// 2. Complete active evidence lineage: process -> document -> version -> chunk.
MATCH path=(p:Process {process_id: "P2P-001"})-[:HAS_DOCUMENT]->(:Document)
           -[:HAS_VERSION]->(:DocumentVersion {active: true})
           -[:HAS_CHUNK]->(:Chunk {active: true})
RETURN path
LIMIT 200;

// 3. Show the chunks and assertions supporting each semantic fact.
MATCH semantic=(p:Process {process_id: "P2P-001"})
               -[:OPERATES_IN|OWNED_BY|GOVERNED_BY|USES_SYSTEM]->(entity)
MATCH (a:Assertion {active: true})-[:SUBJECT]->(p)
MATCH assertion=(a)-[:OBJECT]->(entity)
MATCH evidence=(chunk:Chunk {active: true})-[:SUPPORTS]->(a)
MATCH lineage=(:Document)-[:HAS_VERSION]->(:DocumentVersion {active: true})
              -[:HAS_CHUNK]->(chunk)
RETURN semantic, assertion, evidence, lineage
LIMIT 250;

// 4. Trace one citation using the chunk_id returned by chat.
MATCH lineage=(p:Process)-[:HAS_DOCUMENT]->(d:Document)-[:HAS_VERSION]->
              (v:DocumentVersion)-[:HAS_CHUNK]->(c:Chunk {
                chunk_id: "REPLACE_WITH_CHUNK_ID"
              })
OPTIONAL MATCH evidence=(c)-[:SUPPORTS]->(a:Assertion)-[:OBJECT]->(target)
RETURN lineage, evidence, target;

// 5. List active documents, their immutable versions, and chunk counts.
MATCH (p:Process {process_id: "P2P-001"})-[:HAS_DOCUMENT]->(d:Document)
      -[:HAS_VERSION]->(v:DocumentVersion)
OPTIONAL MATCH (v)-[:HAS_CHUNK]->(c:Chunk)
RETURN d.document_id AS document_id, d.title AS document,
       v.document_version_id AS document_version_id, v.version AS version,
       v.status AS status, v.active AS active, v.classification AS classification,
       v.created_at AS created_at, count(c) AS chunks
ORDER BY document, created_at DESC;

// 6. Evidence coverage and assertion support count per semantic edge.
MATCH (p:Process)-[r:OPERATES_IN|OWNED_BY|GOVERNED_BY|USES_SYSTEM]->(entity)
OPTIONAL MATCH (a:Assertion {active: true})-[:SUBJECT]->(p)
WHERE a.predicate = type(r)
OPTIONAL MATCH (a)-[:OBJECT]->(entity)
OPTIONAL MATCH (c:Chunk {active: true})-[:SUPPORTS]->(a)
RETURN p.process_id AS process_id, type(r) AS predicate,
       labels(entity)[0] AS entity_type, entity.name AS entity,
       count(DISTINCT a) AS assertions, count(DISTINCT c) AS supporting_chunks,
       r.confidence AS confidence
ORDER BY process_id, predicate, entity;

// 7. Detect orphaned active chunks or assertions.
MATCH (c:Chunk {active: true})
WHERE NOT EXISTS { MATCH (:DocumentVersion {active: true})-[:HAS_CHUNK]->(c) }
RETURN "orphan_active_chunk" AS issue, c.chunk_id AS id
UNION ALL
MATCH (a:Assertion {active: true})
WHERE NOT EXISTS { MATCH (:Chunk {active: true})-[:SUPPORTS]->(a) }
RETURN "assertion_without_active_chunk" AS issue, a.assertion_id AS id;

// 8. BPMN process flow for the active BPMN document version.
MATCH (p:Process {process_id: "P2P-001"})-[:HAS_DOCUMENT]->(:Document)
      -[:HAS_VERSION]->(:DocumentVersion {active: true})-[:REPRESENTED_BY]->(b:BPMNModel)
MATCH path=(b)-[:DEFINES_ACTIVITY]->(a:Activity)-[:NEXT_ACTIVITY*0..12]->(next:Activity)
RETURN path
LIMIT 100;

// 9. Variant frequency and average duration.
MATCH (p:Process {process_id: "P2P-001"})-[:HAS_VARIANT]->(v:Variant)
OPTIONAL MATCH (j:Journey)-[:FOLLOWS_VARIANT]->(v)
RETURN v.variant_id AS variant, count(j) AS journeys,
       round(avg(j.duration_seconds), 1) AS avg_duration_seconds
ORDER BY journeys DESC, avg_duration_seconds DESC;

// 10. Prove that the relationship vocabulary remains finite.
MATCH ()-[r]->()
RETURN type(r) AS relationship_type, count(r) AS relationship_count
ORDER BY relationship_type;
