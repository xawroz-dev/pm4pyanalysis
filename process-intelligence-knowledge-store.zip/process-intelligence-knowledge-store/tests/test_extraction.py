from app.domain.models import (
    DocumentMetadata,
    ExtractedEntity,
    ExtractedRelationship,
    ExtractionResult,
)
from app.domain.ontology import NodeType, RelationshipType
from app.services.extraction import govern_extraction


def test_governance_deduplicates_and_filters_low_confidence():
    result = ExtractionResult(
        entities=[
            ExtractedEntity(
                entity_type=NodeType.SYSTEM,
                canonical_name=" SAP S/4HANA ",
                confidence=0.95,
                evidence="SAP is the system of record",
            ),
            ExtractedEntity(
                entity_type=NodeType.SYSTEM,
                canonical_name="SAP S/4HANA",
                confidence=0.85,
                evidence="duplicate",
            ),
            ExtractedEntity(
                entity_type=NodeType.CONTROL,
                canonical_name="maybe-control",
                confidence=0.2,
                evidence="uncertain",
            ),
        ],
        relationships=[
            ExtractedRelationship(
                source_type=NodeType.PROCESS,
                source_ref="P2P-001",
                relationship_type=RelationshipType.USES_SYSTEM,
                target_type=NodeType.SYSTEM,
                target_ref="SAP S/4HANA",
                confidence=0.95,
                evidence="SAP is the system of record",
            )
        ],
    )
    governed = govern_extraction(result, 0.72)
    assert len(governed.entities) == 1
    assert governed.entities[0].canonical_name == "SAP S/4HANA"
    assert len(governed.relationships) == 1


def test_sample_metadata_has_only_governed_lists():
    raw = {
        "title": "SOP",
        "document_type": "sop",
        "process": {"process_id": "P1", "name": "Example"},
        "systems": ["ERP"],
    }
    metadata = DocumentMetadata.model_validate(raw)
    assert metadata.systems == ["ERP"]
