from pathlib import Path

from app.domain.models import DocumentMetadata
from app.services.parsing import parse_bpmn_structure, parse_document

ROOT = Path(__file__).resolve().parents[1]


def metadata() -> DocumentMetadata:
    return DocumentMetadata.model_validate_json(
        (ROOT / "sample_data/p2p_bpmn.metadata.json").read_text()
    )


def test_bpmn_parser_extracts_activities_and_flows():
    content = (ROOT / "sample_data/p2p.bpmn").read_bytes()
    structure = parse_bpmn_structure(content)
    assert structure["bpmn_process_id"] == "Process_P2P"
    assert len(structure["activities"]) == 8
    assert len(structure["flows"]) == 7
    assert structure["flows"][0]["source_id"] == "Start_Request"


def test_bpmn_is_also_rendered_as_retrievable_text():
    content = (ROOT / "sample_data/p2p.bpmn").read_bytes()
    parsed = parse_document(content, "p2p.bpmn", "application/xml", metadata())
    assert "Create purchase order" in parsed.text
    assert "Start_Request -> Submit_Request" in parsed.text
