import pytest

from app.domain.ontology import (
    ALLOWED_RELATIONSHIPS,
    ONTOLOGY_VERSION,
    NodeType,
    RelationshipType,
    validate_relationship,
)


def test_allowed_relationship_is_accepted():
    validate_relationship(NodeType.PROCESS, RelationshipType.GOVERNED_BY, NodeType.CONTROL)


def test_unlisted_relationship_is_rejected():
    with pytest.raises(ValueError):
        validate_relationship(NodeType.CONTROL, RelationshipType.USES_SYSTEM, NodeType.SYSTEM)


def test_evidence_layer_is_fixed_in_ontology():
    assert ONTOLOGY_VERSION == "2.0"
    triples = {
        (source.value, relationship.value, target.value)
        for source, relationship, target in ALLOWED_RELATIONSHIPS
    }
    assert ("Document", "HAS_VERSION", "DocumentVersion") in triples
    assert ("DocumentVersion", "HAS_CHUNK", "Chunk") in triples
    assert ("Chunk", "SUPPORTS", "Assertion") in triples
    assert ("Assertion", "SUBJECT", "Process") in triples
    assert ("Assertion", "OBJECT", "System") in triples
