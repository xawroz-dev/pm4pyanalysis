# Process Intelligence Knowledge Store

Runnable enterprise reference implementation for governed process intelligence using:

- Neo4j for the semantic graph, artifact lineage, and evidence provenance;
- Qdrant for chunk text and vector similarity search;
- FastAPI for ingestion, graph exploration, reconciliation, and hybrid chat;
- fixed LLM entity types, predicates, and query intents;
- deterministic offline providers so the complete demo runs without external API keys.

Ontology version `2.0` explicitly connects chunks to immutable document versions and governed
assertions. Qdrant and Neo4j share the same `chunk_id`; chunks are evidence artifacts, not
LLM-invented business entities.

## The core design decision

The LLM is an extractor, not an ontology designer and not a Cypher author.

It may propose only:

- `Market`
- `BusinessUnit`
- `Control`
- `System`

And only these process facts:

- `Process-OPERATES_IN-Market`
- `Process-OWNED_BY-BusinessUnit`
- `Process-GOVERNED_BY-Control`
- `Process-USES_SYSTEM-System`

Every accepted fact becomes a governed `Assertion` supported by one or more exact `Chunk`
nodes. A separate, clean semantic edge is materialized once per process/entity pair. Repeated
evidence therefore increases support without creating duplicate business relationships.

## Architecture

```mermaid
flowchart LR
  S["SOP, policy, BPMN + metadata"] --> P["Parse and checksum"]
  P --> V["Immutable DocumentVersion"]
  P --> C["Deterministic chunks"]
  P --> X["Constrained extraction"]

  C --> E["Embedding provider"]
  E --> Q[("Qdrant")]

  V --> G[("Neo4j evidence graph")]
  C --> G
  X --> O["Ontology validator"]
  O --> A["Governed assertions"]
  A --> G

  J["Live journeys and variants"] --> G

  U["Chat API"] --> I["Fixed intent router"]
  I --> R["Graph-scoped retrieval"]
  R --> G
  R --> Q
  G --> H["Grounded answer with versioned chunk citations"]
  Q --> H
```

The physical stores are intentionally separate but logically joined:

| Concern | Neo4j | Qdrant |
|---|---|---|
| Business entities and facts | Yes | No |
| Document/version lineage | Yes | Payload reference |
| Thin chunk metadata | Yes | Yes |
| Full chunk text | No | Yes |
| Embeddings | No | Yes |
| Assertion provenance | Yes | No |
| Shared join key | `Chunk.chunk_id` | Point ID and payload `chunk_id` |

## Graph model

```mermaid
graph LR
  P["Process"] -->|HAS_DOCUMENT| D["Document"]
  D -->|HAS_VERSION| V["DocumentVersion"]
  V -->|HAS_CHUNK| C["Chunk"]
  C -->|SUPPORTS| A["Assertion"]
  A -->|SUBJECT| P
  A -->|OBJECT| S["System / Control / Market / BusinessUnit"]
  P -->|approved semantic predicate| S

  V -->|REPRESENTED_BY| B["BPMNModel"]
  B -->|DEFINES_ACTIVITY| T["Activity"]
  T -->|NEXT_ACTIVITY| T2["Activity"]

  P -->|HAS_JOURNEY| J["Journey"]
  P -->|HAS_VARIANT| R["Variant"]
  J -->|FOLLOWS_VARIANT| R
```

### Domain nodes

`Process`, `Market`, `BusinessUnit`, `Control`, and `System` represent stable business meaning.

### Artifact and evidence nodes

- `Document` is the logical document identity.
- `DocumentVersion` is an immutable content revision identified by logical document ID,
  declared version, and checksum.
- `Chunk` is deterministic evidence metadata. It contains locators and hashes, not embeddings.
- `Assertion` is a version-specific claim with an approved predicate, confidence, evidence
  excerpt, subject, object, and supporting chunk links.
- `BPMNModel`, `Activity`, `Journey`, and `Variant` are produced by deterministic parsers or
  operational APIs rather than unconstrained document extraction.

Adding fixed evidence types does not weaken ontology governance. The noisy alternative is
allowing the LLM to invent labels and predicates such as `Application`, `Platform`, `Tool`,
`RUNS_ON`, `UTILIZES`, and `DEPENDS_ON`.

## Document lifecycle

1. Parse the upload and compute its checksum.
2. Derive a stable logical `document_id`.
3. Derive an immutable `document_version_id` from document ID, declared version, and checksum.
4. Idempotently skip when the same logical document already has the same active checksum.
5. Extract only governed entities and relationships.
6. Build one deterministic metadata-evidence chunk plus content chunks and embeddings before
   changing active state.
7. Stage `DocumentVersion` and `Chunk` nodes in Neo4j with `active=false`.
8. Upsert Qdrant points with the identical `chunk_id` and `active=false`.
9. Create version-specific assertions and connect exact chunks using `SUPPORTS`.
10. Activate the new graph version, materialize approved semantic edges, and switch Qdrant
    payload flags.
11. If activation fails, compensating actions restore the previous graph/vector version.

Old versions remain in Neo4j for lineage but are marked `SUPERSEDED`. Normal retrieval searches
only active versions and active Qdrant points.

## Assertion and semantic-edge behavior

If two documents state that Procure-to-Pay uses SAP:

```text
Chunk A ─SUPPORTS─> Assertion A ─OBJECT─> SAP
Chunk B ─SUPPORTS─> Assertion B ─OBJECT─> SAP

Both assertions ─SUBJECT─> Procure-to-Pay

Procure-to-Pay ─USES_SYSTEM─> SAP
```

There are two auditable assertions but one materialized semantic edge. The edge records the
active assertion count and maximum confidence. When a document version is superseded, its
assertions stop supporting the materialized graph. The materialization is rebuilt from active,
approved assertions.

## Hybrid retrieval

### Process ID supplied

1. The fixed intent router selects an approved query.
2. Neo4j returns active document-version IDs allowed by the caller's classification clearance.
3. Qdrant vector search is filtered to that exact version scope.
4. Neo4j returns governed facts and supporting assertion/chunk IDs for the intent.
5. The answer combines exact graph facts with narrative chunk evidence.
6. Citations use:

```text
[document_id@document_version_id#chunk_id]
```

### Process ID not supplied

1. Qdrant searches active, accessible chunks.
2. Scores are grouped to infer the most likely process.
3. Neo4j derives the authorized active version scope for that process.
4. Qdrant is searched again inside that scope.
5. The approved intent query retrieves graph facts.

The API never accepts arbitrary Cypher from chat and the LLM never writes Cypher.

## Security boundary

The POC enforces document classification filters:

- `public`
- `internal`
- `confidential`
- `restricted`

A caller's clearance expands the allowed set monotonically. Classification is repeated in the
Neo4j `DocumentVersion` and Qdrant payload so both retrieval paths enforce it.

For production, add `tenant_id`, principal/entitlement IDs, legal-hold state, and policy-decision
service results to every version, chunk payload, uniqueness scope, and query filter. Do not rely
on the chat model to enforce access control.

## Run locally

Requirements: Podman with Compose or Docker Compose.

```bash
cp .env.example .env
podman compose up --build -d
curl http://localhost:8000/health
python3 scripts/load_sample.py
```

Docker users can replace `podman compose` with `docker compose`.

Services:

- API documentation: <http://localhost:8000/docs>
- Neo4j Browser: <http://localhost:7474>
- Qdrant dashboard: <http://localhost:6333/dashboard>

Default local Neo4j login:

```text
username: neo4j
password: change-me-enterprise
```

Change that password in `.env` outside a throwaway local demo.

## Offline and LLM-backed modes

The default mode sends no enterprise content externally:

```text
LLM_PROVIDER=metadata
EMBEDDING_PROVIDER=hash
```

- Metadata lists drive governed extraction.
- Deterministic feature hashing provides locally reproducible retrieval.

For an OpenAI-compatible production provider:

```text
LLM_PROVIDER=openai
EMBEDDING_PROVIDER=openai
LLM_API_KEY=...
LLM_MODEL=...
EMBEDDING_MODEL=...
```

The LLM response is still validated against the same Pydantic schema and ontology allowlist.

## Load the included sample

```bash
python3 scripts/load_sample.py
```

The loader ingests:

- a Procure-to-Pay SOP;
- a policy document;
- a BPMN model;
- live journeys and variants.

Then inspect consistency:

```bash
curl http://localhost:8000/v1/governance/reconciliation/P2P-001
```

Expected result:

```json
{
  "process_id": "P2P-001",
  "status": "consistent",
  "graph_active_chunks": 6,
  "vector_active_chunks": 6,
  "graph_only_chunk_ids": [],
  "vector_only_chunk_ids": []
}
```

The sample produces one metadata chunk and one content chunk for each of three documents with the
default chunk size. Larger documents produce additional content chunks.

## API examples

### Ingest a document

```bash
curl -X POST http://localhost:8000/v1/ingest/document \
  -F 'file=@sample_data/p2p_sop.txt;type=text/plain' \
  -F 'metadata=<sample_data/p2p_sop.metadata.json'
```

The result includes both logical and immutable identifiers:

```json
{
  "status": "created",
  "process_id": "P2P-001",
  "document_id": "P2P-SOP-001",
  "document_version_id": "P2P-SOP-001:version:...",
  "chunks_indexed": 1,
  "entities_upserted": 4,
  "assertions_upserted": 4
}
```

### Ask a hybrid question

```bash
curl -X POST http://localhost:8000/v1/chat \
  -H 'Content-Type: application/json' \
  -d '{
    "question": "Which systems support this process and what evidence proves it?",
    "process_id": "P2P-001",
    "classification_clearance": "internal",
    "top_k": 6
  }'
```

### Resolve a citation

Use a returned `chunk_id`:

```bash
curl \
  'http://localhost:8000/v1/evidence/chunks/REPLACE_WITH_CHUNK_ID?classification_clearance=internal'
```

This returns the Qdrant content together with Neo4j process, document-version, locator, and
assertion lineage.

### View chunk lineage only

```bash
curl \
  'http://localhost:8000/v1/graph/chunks/REPLACE_WITH_CHUNK_ID/lineage?classification_clearance=internal'
```

### View a process evidence subgraph

```bash
curl \
  'http://localhost:8000/v1/graph/processes/P2P-001/subgraph?classification_clearance=internal'
```

### Inspect the fixed ontology

```bash
curl http://localhost:8000/v1/ontology
```

### Demonstrate open-ontology noise

```bash
curl -X POST http://localhost:8000/v1/demo/compare-open-ontology \
  -F 'file=@sample_data/p2p_sop.txt;type=text/plain' \
  -F 'metadata=<sample_data/p2p_sop.metadata.json'
```

This comparison endpoint does not write open extraction results to Neo4j.

## Neo4j Browser queries

Clean semantic view:

```cypher
MATCH path=(p:Process {process_id: "P2P-001"})
           -[:OPERATES_IN|OWNED_BY|GOVERNED_BY|USES_SYSTEM]->(entity)
RETURN path;
```

Active document and chunk lineage:

```cypher
MATCH path=(p:Process {process_id: "P2P-001"})-[:HAS_DOCUMENT]->(:Document)
           -[:HAS_VERSION]->(:DocumentVersion {active: true})
           -[:HAS_CHUNK]->(:Chunk {active: true})
RETURN path
LIMIT 200;
```

Evidence supporting materialized facts:

```cypher
MATCH semantic=(p:Process {process_id: "P2P-001"})
               -[:OPERATES_IN|OWNED_BY|GOVERNED_BY|USES_SYSTEM]->(entity)
MATCH (a:Assertion {active: true})-[:SUBJECT]->(p)
MATCH assertion=(a)-[:OBJECT]->(entity)
MATCH evidence=(chunk:Chunk {active: true})-[:SUPPORTS]->(a)
RETURN semantic, assertion, evidence
LIMIT 250;
```

The complete visualization catalog is in
[`schema/visualization_queries.cypher`](schema/visualization_queries.cypher).

## API catalog

| Method | Path | Purpose |
|---|---|---|
| `GET` | `/health` | Neo4j/Qdrant readiness and provider mode |
| `POST` | `/v1/ingest/document` | Versioned document, BPMN, chunk, vector, assertion ingestion |
| `POST` | `/v1/ingest/journeys` | Live journey and variant ingestion |
| `POST` | `/v1/chat` | Fixed-intent hybrid GraphRAG |
| `GET` | `/v1/ontology` | Governed node and relationship catalog |
| `GET` | `/v1/graph/processes/{id}/subgraph` | Active process evidence rows |
| `GET` | `/v1/graph/chunks/{id}/lineage` | Neo4j chunk lineage |
| `GET` | `/v1/evidence/chunks/{id}` | Authorized exact chunk content plus lineage |
| `GET` | `/v1/governance/reconciliation/{id}` | Active graph/vector chunk drift report |
| `GET` | `/v1/graph/query-catalog` | Fixed application Cypher catalog |
| `POST` | `/v1/demo/compare-open-ontology` | Non-persisting constrained/open comparison |

## Test and quality commands

```bash
python -m pytest -q
ruff check .
```

Live smoke test:

```bash
podman compose up --build -d
curl http://localhost:8000/health
python3 scripts/load_sample.py
curl http://localhost:8000/v1/governance/reconciliation/P2P-001
```

## Failure and reconciliation behavior

Neo4j and Qdrant do not provide a distributed transaction. The POC therefore uses:

- staged inactive graph and vector records;
- idempotent IDs and upserts;
- an explicit activation switch;
- compensating rollback to the previous version;
- a reconciliation endpoint that compares active chunk IDs.

A full production implementation should add a durable ingestion/outbox record, retry worker,
dead-letter handling, metrics, and scheduled reconciliation. See
[`docs/operations.md`](docs/operations.md).

## What is intentionally not stored

- Embedding arrays are not stored in Neo4j.
- Unrestricted LLM labels and predicates are never persisted.
- Every noun mention is not turned into a `MENTIONS` edge.
- Raw source binaries are not stored in Neo4j.
- Chat does not execute LLM-generated Cypher.

For production, store source binaries in immutable object storage and retain object URI, checksum,
page/section/offset locators, and retention state in `DocumentVersion` and `Chunk`.

## Additional documentation

- [Architecture and trade-offs](docs/architecture.md)
- [Ontology and data model](docs/data-model.md)
- [Retrieval, assertions, and governance](docs/retrieval-and-governance.md)
- [Operations and production hardening](docs/operations.md)
- [Neo4j constraints](schema/constraints.cypher)
- [Neo4j visualization queries](schema/visualization_queries.cypher)

## Repository map

```text
app/domain/ontology.py       fixed node and relationship allowlist
app/domain/models.py         validated API and extraction contracts
app/services/chunking.py     deterministic, version-scoped chunks
app/services/extraction.py   constrained extraction and noise comparison
app/services/ingestion.py    staged version activation and compensation
app/services/retrieval.py    graph-scoped fixed-intent hybrid retrieval
app/repositories/neo4j.py    lineage, assertions, materialized facts
app/repositories/vector.py   Qdrant payloads, activation, search, reconciliation
schema/                      DBA constraints and visualization queries
sample_data/                 SOP, policy, BPMN, metadata, journeys
tests/                       ontology, parsing, extraction, lineage, retrieval tests
docs/                        architecture, model, retrieval, operations guides
```

## Production checklist

- Replace the demo password and use a secrets manager.
- Require authenticated principals and server-derived tenant/clearance context.
- Add immutable object storage for originals and extracted text.
- Use semantic embeddings and an approved LLM deployment.
- Add antivirus, content-type validation, OCR, and parser sandboxing.
- Add a durable outbox and scheduled graph/vector reconciliation.
- Add assertion review and rejection workflows for high-impact facts.
- Add canonical entity master-data integration.
- Add retention, legal hold, deletion, and re-embedding workflows.
- Benchmark chunking, vector filters, Cypher plans, and graph cardinalities at target scale.
- Monitor unsupported extraction rates, assertion coverage, retrieval quality, and stale versions.
