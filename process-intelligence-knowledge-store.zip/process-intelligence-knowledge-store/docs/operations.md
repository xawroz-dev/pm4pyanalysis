# Operations and production hardening

## Local startup

```bash
cp .env.example .env
podman compose up --build -d
curl http://localhost:8000/health
python3 scripts/load_sample.py
```

Expected services:

```text
API      http://localhost:8000
Neo4j    http://localhost:7474
Qdrant   http://localhost:6333
```

## Verify graph/vector consistency

```bash
curl http://localhost:8000/v1/governance/reconciliation/P2P-001
```

`consistent` means the active Neo4j chunk ID set exactly matches the active Qdrant point ID set
for the process.

`drift_detected` reports:

- IDs active only in Neo4j;
- IDs active only in Qdrant.

The POC reports drift but does not automatically delete records because the safe repair direction
depends on the authoritative ingestion/outbox state.

## Reingesting a logical document

Use the same `document_id` and send changed content. The service:

- creates a new immutable version;
- leaves the prior version available for audit;
- switches active chunks and assertions;
- rematerializes semantic facts;
- disables old Qdrant points from normal search.

Sending the same content again is an idempotent skip.

## Inspect failed versions

```cypher
MATCH (d:Document)-[:HAS_VERSION]->(v:DocumentVersion {status: "FAILED"})
RETURN d.document_id, d.title, v.document_version_id, v.error, v.updated_at
ORDER BY v.updated_at DESC;
```

## Inspect assertion coverage

```cypher
MATCH (a:Assertion {active: true})
OPTIONAL MATCH (c:Chunk {active: true})-[:SUPPORTS]->(a)
RETURN a.predicate, count(DISTINCT a) AS assertions,
       count(DISTINCT c) AS supporting_chunks;
```

## Container logs

```bash
podman compose logs --tail=200 api
podman compose logs --tail=200 neo4j
podman compose logs --tail=200 qdrant
```

## Reset the local demo

The following destroys only this Compose project's named demo volumes:

```bash
podman compose down -v
podman compose up --build -d
python3 scripts/load_sample.py
```

Do not use that command against a production deployment.

## Backup domains

Back up each concern independently:

- Neo4j database: semantic graph, lineage, assertions, BPMN, journeys;
- Qdrant snapshots: retrieval points and embeddings;
- object store: source binaries and authoritative extracted text;
- configuration: ontology version, extraction schemas, model versions, query catalog;
- ingestion/outbox database: workflow recovery and audit events.

A usable restore must preserve shared `chunk_id` values.

## Production ingestion workflow

Replace the in-request saga with a durable state machine:

```text
RECEIVED
PARSED
EXTRACTED
GRAPH_STAGED
VECTOR_STAGED
ASSERTIONS_STAGED
ACTIVATING
ACTIVE
FAILED
```

Each transition should be idempotent and persisted. Workers should use bounded retries and a
dead-letter queue. Activation should hold a per-document lock to prevent two revisions becoming
active concurrently.

## Scheduled reconciliation

At minimum compare:

- active graph chunk IDs versus active vector point IDs;
- Qdrant payload version/process IDs versus Neo4j lineage;
- active assertions without active supporting chunks;
- materialized semantic edges without active assertions;
- active versions without object-store sources;
- embedding model/version drift.

Emit metrics and alerts rather than silently repairing destructive differences.

## Security hardening

- Put Neo4j and Qdrant on private networks.
- Disable default passwords.
- Use secret-manager injected credentials.
- Authenticate all API calls.
- Derive tenant and clearance server-side.
- Apply tenant filters in every graph and vector query.
- Encrypt transport and storage.
- Scan uploads and sandbox parsers.
- Log access to restricted chunks and source documents.
- Redact sensitive content before sending it to external LLMs.
- Apply retention, legal-hold, and defensible-deletion policies.

## Model and embedding upgrades

Record:

- extraction model and prompt/schema version on assertions;
- embedding model, dimensions, and version on chunks and vector payloads;
- chunker version and parameters on document versions.

Re-embedding should create a new vector collection or named vector while preserving `chunk_id`.
It should not rewrite assertion history.

## Scale testing

Benchmark with representative:

- document sizes and formats;
- chunks per version;
- versions per document;
- assertions per chunk;
- processes per tenant;
- journey/event volume;
- concurrent ingestion and chat traffic;
- Qdrant filter selectivity;
- Neo4j traversal depth and result limits.

Monitor Neo4j query plans for label scans and Qdrant payload indexes for filter performance.

## Known POC limitations

- No durable external outbox or worker queue.
- No object storage for original source binaries.
- No tenant authentication or policy service.
- Text parsers provide limited page mapping; richer PDF/DOCX locators require parser-specific
  extraction.
- Assertion approval is automatic after schema validation and confidence filtering.
- Materialized relationship refresh is global and should be process-scoped or incremental at scale.
- Offline hash embeddings demonstrate architecture, not production semantic quality.
