# Ontology and data model

## Ontology policy

Ontology version `2.0` separates domain meaning from deterministic evidence infrastructure.
Every node label and relationship triple is defined in `app/domain/ontology.py`.

The API rejects extracted triples outside this allowlist.

## Node catalog

| Label | Identity | Created by | Purpose |
|---|---|---|---|
| `Process` | `process_id` | Metadata/journey API | Aggregate root |
| `Document` | `document_id` | Ingestion service | Logical document |
| `DocumentVersion` | `document_version_id` | Ingestion service | Immutable revision |
| `Chunk` | `chunk_id` | Deterministic chunker | Evidence locator and vector join |
| `Assertion` | `assertion_id` | Governed extraction | Version-specific supported fact |
| `Market` | `market_id` | Constrained extraction | Governed domain entity |
| `BusinessUnit` | `business_unit_id` | Constrained extraction | Governed domain entity |
| `Control` | `control_id` | Constrained extraction | Governed domain entity |
| `System` | `system_id` | Constrained extraction | Governed domain entity |
| `BPMNModel` | `bpmn_id` | BPMN parser | Versioned process model |
| `Activity` | `activity_id` | BPMN parser | BPMN step |
| `Journey` | `journey_id` | Journey API | Observed execution |
| `Variant` | `variant_id` | Journey API | Grouped activity path |

## Relationship catalog

### Evidence and artifact relationships

| Source | Relationship | Target |
|---|---|---|
| Process | `HAS_DOCUMENT` | Document |
| Document | `HAS_VERSION` | DocumentVersion |
| DocumentVersion | `HAS_CHUNK` | Chunk |
| DocumentVersion | `HAS_ASSERTION` | Assertion |
| Chunk | `SUPPORTS` | Assertion |
| Assertion | `SUBJECT` | Process |
| Assertion | `OBJECT` | Market, BusinessUnit, Control, or System |
| DocumentVersion | `REPRESENTED_BY` | BPMNModel |

### Materialized semantic relationships

| Source | Relationship | Target |
|---|---|---|
| Process | `OPERATES_IN` | Market |
| Process | `OWNED_BY` | BusinessUnit |
| Process | `GOVERNED_BY` | Control |
| Process | `USES_SYSTEM` | System |

### BPMN and operational relationships

| Source | Relationship | Target |
|---|---|---|
| Process | `MODELED_BY` | BPMNModel |
| BPMNModel | `DEFINES_ACTIVITY` | Activity |
| Activity | `NEXT_ACTIVITY` | Activity |
| Activity | `PERFORMED_BY` | BusinessUnit |
| Activity | `USES_SYSTEM` | System |
| Activity | `ENFORCES_CONTROL` | Control |
| Process | `HAS_JOURNEY` | Journey |
| Process | `HAS_VARIANT` | Variant |
| Journey | `FOLLOWS_VARIANT` | Variant |

## Identity strategy

### Document

`document_id` is a stable logical identifier supplied by source metadata when possible. If absent,
the demo derives it from the content checksum.

### Document version

`document_version_id` is UUIDv5-derived from:

```text
document_id + declared_version + checksum
```

The same input produces the same ID. Changed content produces a different immutable version even
if a source mistakenly reuses the declared version string.

### Chunk

`chunk_id` is UUIDv5-derived from:

```text
document_version_id + chunk_kind + ordinal + chunk_content_hash
```

It is used simultaneously as:

- the Neo4j `Chunk.chunk_id`;
- the Qdrant point ID;
- the Qdrant payload `chunk_id`;
- the chat citation locator.

### Assertion

`assertion_id` is UUIDv5-derived from:

```text
document_version_id + process_id + predicate + target_type + target_id
```

This deduplicates repeated extraction of the same fact from the same immutable source version.
Different versions or documents retain distinct assertions.

## Important properties

### DocumentVersion

- `document_version_id`
- `document_id`
- `version`
- `checksum`
- `classification`
- `effective_date`
- `media_type`
- `status`: `STAGED`, `ACTIVE`, `SUPERSEDED`, or `FAILED`
- `active`
- timestamps and failure text

### Chunk

- `chunk_id`
- `document_id`
- `document_version_id`
- `process_id`
- `ordinal`
- `chunk_kind`: `metadata` or `content`
- `content_hash`
- `section`
- character and page locators
- `classification`
- `active`
- `vector_status`

The graph deliberately omits the embedding and normally omits full chunk text.

Each version receives one synthetic metadata-evidence chunk containing normalized, explicit
metadata declarations. This allows metadata-extracted assertions to cite metadata rather than an
unrelated content span.

### Assertion

- `assertion_id`
- `document_version_id`
- `process_id`
- approved `predicate`
- `target_type` and `target_id`
- `confidence`
- `evidence`
- `status`
- `active`
- `ontology_version`

### Materialized semantic edge

- `materialized=true`
- `assertion_count`
- maximum active assertion `confidence`
- `ontology_version`
- update timestamp

## Version semantics

Only one version of a logical document is active. Superseding a version:

- marks old chunks inactive;
- marks old assertions inactive and superseded;
- activates new chunks and assertions;
- rebuilds materialized semantic facts from all currently active assertions.

Historical versions remain traversable for audit but normal retrieval filters them out.

## Cardinality controls

- One logical `Document` per `document_id`.
- One immutable `DocumentVersion` per derived version ID.
- One `Chunk` per deterministic chunk ID.
- One assertion per source version and governed fact.
- One materialized semantic edge per process, predicate, and target.
- No arbitrary labels, predicates, or `MENTIONS` fan-out.
