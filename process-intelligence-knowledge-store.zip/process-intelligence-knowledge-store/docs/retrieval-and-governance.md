# Retrieval, assertions, and governance

## Fixed intents

The chat router recognizes only a controlled intent catalog:

- process overview;
- controls;
- systems;
- ownership;
- markets;
- documents;
- evidence lineage;
- BPMN flow;
- variants;
- journeys;
- generic governed evidence.

Each intent maps to parameterized Cypher held in application code. The LLM cannot generate or
submit Cypher.

## Graph-scoped vector retrieval

When `process_id` is known:

1. Neo4j identifies active `DocumentVersion` nodes visible at the caller's clearance.
2. Their IDs are supplied as a Qdrant `MatchAny` filter.
3. Qdrant also filters `active=true`, `process_id`, and classification.
4. The graph intent query returns semantic facts and their evidence chunk IDs.
5. The answer uses graph facts for exact relationships and chunks for narrative evidence.

This makes the graph an authorization and scope boundary rather than an unrelated enrichment
query.

## Vector-first discovery

When `process_id` is absent:

1. search accessible active Qdrant points;
2. aggregate hit scores by `process_id`;
3. select the most likely process;
4. derive its authorized active version scope from Neo4j;
5. search Qdrant again within that scope;
6. execute the fixed intent query.

The second search prevents mixed-process citations after process inference.

## Evidence resolution

Every chat citation contains:

```text
document_id
document_version_id
chunk_id
```

`GET /v1/evidence/chunks/{chunk_id}` first checks graph lineage and clearance. It then retrieves
the exact Qdrant payload. If the graph record exists but the vector payload does not, the API
returns a conflict that directs operations to reconciliation.

## How extraction evidence becomes chunk support

The extractor returns a short evidence span for each governed relationship. The ingestion service:

1. normalizes the evidence span;
2. routes explicit metadata declarations to the version's deterministic metadata chunk;
3. finds an exact normalized match in the version's content chunks;
4. otherwise finds chunks containing the governed target name;
5. rejects relationships that cannot be resolved to any evidence chunk;
6. limits support links to three chunks.

This creates a sparse evidence graph. It does not create a relationship for every noun mention.

## Materialization

Assertions are the auditable source of truth. Direct process/entity semantic edges are a
materialized read model.

On version activation the application:

1. deactivates assertions from superseded versions;
2. activates approved assertions from the selected version;
3. removes previously materialized process/entity edges;
4. recreates them from all active approved assertions;
5. records support count and maximum confidence.

This ensures a fact disappears when its final active source disappears.

## Classification enforcement

The request supplies a demo clearance:

```text
public < internal < confidential < restricted
```

Both graph and vector searches use the corresponding allowed classification set.

In production, callers must not be allowed to self-assert clearance. Authentication middleware
should derive tenant and authorization context from signed identity and a policy decision service.

## Constrained versus open extraction

Open extraction commonly produces:

- near-duplicate types such as `Team`, `Department`, `Owner`, and `Function`;
- overlapping system labels such as `Tool`, `Platform`, `Application`, and `Technology`;
- inconsistent predicates such as `USES`, `RUNS_ON`, `SUPPORTED_BY`, and `DEPENDS_ON`;
- ambiguous mention edges that do not prove a business fact.

The governed design improves:

- query predictability;
- canonicalization;
- graph visualization;
- Cypher reuse;
- retrieval evaluation;
- access-control review;
- data-quality ownership;
- explainability.

The comparison endpoint deliberately runs an open extractor without persistence so the difference
can be demonstrated safely.

## Retrieval-quality evaluation

A production evaluation set should score:

- intent accuracy;
- process identification;
- authorized version-scope accuracy;
- chunk recall and precision;
- assertion evidence correctness;
- graph fact accuracy;
- citation resolvability;
- answer faithfulness;
- unsupported claim rate;
- latency by retrieval stage.

Evaluate graph-only, vector-only, and hybrid retrieval separately to show the value of each layer.
