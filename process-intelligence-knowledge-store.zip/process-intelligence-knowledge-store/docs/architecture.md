# Architecture and trade-offs

## Objective

The knowledge store must answer process questions from both stable business relationships and
the exact evidence that supports them. It must also remain understandable after thousands of
documents, revisions, process journeys, and repeated mentions.

The design therefore separates four concerns:

1. semantic business meaning;
2. artifact and evidence lineage;
3. vector retrieval infrastructure;
4. controlled query and answer orchestration.

## Logical components

### Semantic graph

Neo4j stores stable business concepts and a small relationship vocabulary. A clean semantic edge,
such as `Process-USES_SYSTEM-System`, is optimized for business queries and visualization.

### Evidence graph

Neo4j also stores controlled infrastructure nodes:

- logical document;
- immutable document version;
- thin chunk metadata;
- governed assertion;
- BPMN structure;
- journey and variant records.

These types are created deterministically by application code. The LLM cannot invent new evidence
labels or relationship types.

### Vector index

Qdrant stores:

- one point per chunk;
- the embedding;
- chunk text;
- duplicated filter metadata;
- the same `chunk_id` used in Neo4j;
- an `active` lifecycle flag.

Qdrant is responsible for similarity search. Neo4j is responsible for meaning, provenance,
version scope, and graph traversal.

### API and orchestration

FastAPI coordinates parsing, extraction, staging, vector indexing, assertion creation, version
activation, retrieval, and reconciliation. Chat selects only fixed intents and parameterized
queries.

## Why not keep chunks only in Qdrant?

That is simple and valid for a small prototype, but it forces application-side provenance joins.
Graph-first queries cannot naturally answer:

- Which exact chunks support this relationship?
- Which claims will disappear if version 3 is superseded?
- Does every active assertion have active evidence?
- Which process facts depend on a restricted document?

Thin graph chunk nodes make those questions explicit without moving embedding workloads to Neo4j.

## Why not put text and vectors in Neo4j?

It reduces the number of products but mixes workloads and lifecycles:

- large embeddings and text increase graph backup and page-cache pressure;
- vector search and graph traversal scale differently;
- re-embedding should not rewrite semantic history;
- source text retention may differ from graph retention.

The POC keeps vectors and full chunk text in Qdrant. A production system may keep authoritative
text in immutable object storage and only retrieval copies in Qdrant.

## Why assertions instead of direct chunk-to-entity mentions?

A mention is not necessarily a fact. A policy may state that SAP is prohibited, which mentions SAP
but does not establish that the process uses it.

An assertion explicitly represents:

- subject;
- predicate;
- object;
- evidence excerpt;
- confidence;
- document version;
- supporting chunks;
- lifecycle and approval status.

Multiple assertions can support one semantic edge. This prevents duplicate semantic relationships
while preserving each source's evidence.

## Trade-off summary

| Design | Strengths | Weaknesses |
|---|---|---|
| Vector-only chunks | Simple and fast | Weak graph provenance and lifecycle joins |
| Full chunks/vectors in graph | One store | Graph bloat and mixed workloads |
| Direct `MENTIONS` edges | Easy mention exploration | Dense, noisy, semantically ambiguous |
| Thin graph chunks + Qdrant | Strong lineage and scalable search | Cross-store coordination required |
| Governed assertions | Precise support and review lifecycle | More nodes and query complexity |

The implementation chooses thin graph chunks, Qdrant embeddings, and governed assertions.

## Consistency model

Neo4j and Qdrant cannot commit in one transaction. Ingestion uses a small saga:

1. create inactive graph records;
2. create inactive vector records;
3. connect assertions and evidence;
4. activate the graph version;
5. switch vector active flags;
6. compensate to the previous version when activation fails.

Stable IDs make every operation idempotent. The reconciliation API detects any residual drift.

Production should add a durable outbox and retry worker so a process crash between steps can be
recovered automatically.

## Scaling characteristics

Chunk nodes increase node count but remain sparse:

- one incoming `HAS_CHUNK`;
- zero or a small number of `SUPPORTS` edges;
- no unrestricted mention fan-out.

The semantic graph remains small because materialized process/entity edges are deduplicated.
Chunk scale is handled mainly by Qdrant; provenance traversal is handled by indexed Neo4j IDs and
version-scoped paths.
