# Procure-to-Pay Approval Policy

All purchases in the United States and Canada must follow the Procure-to-Pay process.
Global Procurement Operations is accountable for purchase-order governance.

CTRL-PO-001: a purchase order must be approved before supplier dispatch.
CTRL-3WM-002: Accounts Payable Operations must resolve three-way-match exceptions
before payment. Coupa records requisition approval, while SAP S/4HANA is the system
of record for purchase orders, receipts, invoices, and payments.

