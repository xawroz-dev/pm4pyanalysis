import json
import mimetypes
import os
import uuid
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parents[1]
BASE_URL = os.getenv("PROCESS_INTELLIGENCE_API_URL", "http://localhost:8000")


def post_multipart(file_path: Path, metadata: str) -> dict:
    boundary = f"----process-intelligence-{uuid.uuid4().hex}"
    media_type = mimetypes.guess_type(file_path.name)[0] or "application/octet-stream"
    pieces = [
        f"--{boundary}\r\n".encode(),
        (f'Content-Disposition: form-data; name="file"; filename="{file_path.name}"\r\n').encode(),
        f"Content-Type: {media_type}\r\n\r\n".encode(),
        file_path.read_bytes(),
        b"\r\n",
        f"--{boundary}\r\n".encode(),
        b'Content-Disposition: form-data; name="metadata"\r\n',
        b"Content-Type: application/json\r\n\r\n",
        metadata.encode(),
        b"\r\n",
        f"--{boundary}--\r\n".encode(),
    ]
    return post(
        "/v1/ingest/document",
        b"".join(pieces),
        f"multipart/form-data; boundary={boundary}",
    )


def post(path: str, body: bytes, content_type: str) -> dict:
    request = Request(
        f"{BASE_URL}{path}",
        data=body,
        headers={"Content-Type": content_type},
        method="POST",
    )
    try:
        with urlopen(request, timeout=120) as response:
            return json.loads(response.read())
    except HTTPError as exc:
        detail = exc.read().decode(errors="replace")
        raise RuntimeError(f"{path} returned HTTP {exc.code}: {detail}") from exc


def main() -> None:
    documents = [
        ("p2p_sop.txt", "p2p_sop.metadata.json"),
        ("p2p_policy.md", "p2p_policy.metadata.json"),
        ("p2p.bpmn", "p2p_bpmn.metadata.json"),
    ]
    for filename, metadata_filename in documents:
        file_path = ROOT / "sample_data" / filename
        metadata = (ROOT / "sample_data" / metadata_filename).read_text()
        print(json.dumps(post_multipart(file_path, metadata), indent=2))

    journeys = (ROOT / "sample_data" / "journeys.json").read_bytes()
    print(json.dumps(post("/v1/ingest/journeys", journeys, "application/json"), indent=2))


if __name__ == "__main__":
    main()
