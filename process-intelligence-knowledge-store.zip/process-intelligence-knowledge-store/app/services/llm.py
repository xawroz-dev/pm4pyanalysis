import hashlib
import json
import math
import re
from typing import Any

import httpx

from app.config import Settings
from app.domain.models import ExtractionResult, OpenExtractionResult


class LLMClient:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.client = httpx.AsyncClient(timeout=90.0)

    async def close(self) -> None:
        await self.client.aclose()

    async def json_completion(
        self, system: str, user: str, schema_name: str, schema: dict[str, Any]
    ) -> dict[str, Any]:
        if self.settings.llm_provider != "openai" or not self.settings.llm_api_key:
            raise RuntimeError("LLM provider is not configured")
        response = await self.client.post(
            f"{self.settings.llm_base_url.rstrip('/')}/chat/completions",
            headers={
                "Authorization": f"Bearer {self.settings.llm_api_key}",
                "Content-Type": "application/json",
            },
            json={
                "model": self.settings.llm_model,
                "temperature": 0,
                "messages": [
                    {"role": "system", "content": system},
                    {"role": "user", "content": user},
                ],
                "response_format": {
                    "type": "json_schema",
                    "json_schema": {"name": schema_name, "strict": True, "schema": schema},
                },
            },
        )
        response.raise_for_status()
        content = response.json()["choices"][0]["message"]["content"]
        return json.loads(content)

    async def text_completion(self, system: str, user: str) -> str:
        if self.settings.llm_provider != "openai" or not self.settings.llm_api_key:
            raise RuntimeError("LLM provider is not configured")
        response = await self.client.post(
            f"{self.settings.llm_base_url.rstrip('/')}/chat/completions",
            headers={"Authorization": f"Bearer {self.settings.llm_api_key}"},
            json={
                "model": self.settings.llm_model,
                "temperature": 0,
                "messages": [
                    {"role": "system", "content": system},
                    {"role": "user", "content": user},
                ],
            },
        )
        response.raise_for_status()
        return response.json()["choices"][0]["message"]["content"].strip()


class Embedder:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.client = httpx.AsyncClient(timeout=90.0)

    async def close(self) -> None:
        await self.client.aclose()

    async def embed(self, texts: list[str]) -> list[list[float]]:
        if self.settings.embedding_provider == "openai":
            if not self.settings.llm_api_key:
                raise RuntimeError("LLM_API_KEY is required for OpenAI embeddings")
            response = await self.client.post(
                f"{self.settings.llm_base_url.rstrip('/')}/embeddings",
                headers={"Authorization": f"Bearer {self.settings.llm_api_key}"},
                json={"model": self.settings.embedding_model, "input": texts},
            )
            response.raise_for_status()
            return [item["embedding"] for item in response.json()["data"]]
        return [hash_embedding(text, self.settings.embedding_dimensions) for text in texts]


def hash_embedding(text: str, dimensions: int) -> list[float]:
    """Deterministic feature hashing for an offline demo; not a production semantic model."""
    vector = [0.0] * dimensions
    tokens = re.findall(r"[a-z0-9][a-z0-9_-]+", text.lower())
    for token in tokens:
        digest = hashlib.sha256(token.encode()).digest()
        index = int.from_bytes(digest[:4], "big") % dimensions
        sign = 1.0 if digest[4] % 2 == 0 else -1.0
        vector[index] += sign * (1.0 + math.log1p(len(token)))
    norm = math.sqrt(sum(value * value for value in vector)) or 1.0
    return [value / norm for value in vector]


def constrained_schema() -> dict[str, Any]:
    schema = ExtractionResult.model_json_schema()
    return _strictify_schema(schema)


def open_schema() -> dict[str, Any]:
    schema = OpenExtractionResult.model_json_schema()
    return _strictify_schema(schema)


def _strictify_schema(value: Any) -> Any:
    if isinstance(value, dict):
        result = {key: _strictify_schema(item) for key, item in value.items()}
        if result.get("type") == "object":
            result["additionalProperties"] = False
            result["required"] = list(result.get("properties", {}).keys())
        return result
    if isinstance(value, list):
        return [_strictify_schema(item) for item in value]
    return value
