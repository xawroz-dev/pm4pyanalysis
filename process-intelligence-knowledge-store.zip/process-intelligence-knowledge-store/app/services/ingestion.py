import uuid
from pathlib import Path

from app.config import Settings
from app.domain.models import (
    DocumentMetadata,
    IngestionResult,
    JourneyBatch,
)
from app.repositories.neo4j import Neo4jRepository
from app.repositories.vector import QdrantRepository
from app.services.chunking import chunk_document
from app.services.extraction import EntityExtractor
from app.services.llm import Embedder
from app.services.parsing import parse_document

DOCUMENT_VERSION_NAMESPACE = uuid.UUID("a767e39a-94d1-4578-8bbc-aa97985e50f1")


def make_document_version_id(document_id: str, version: str | None, checksum: str) -> str:
    fingerprint = f"{document_id}:{version or 'unversioned'}:{checksum}"
    return f"{document_id}:version:{uuid.uuid5(DOCUMENT_VERSION_NAMESPACE, fingerprint)}"


class IngestionService:
    def __init__(
        self,
        settings: Settings,
        graph: Neo4jRepository,
        vectors: QdrantRepository,
        extractor: EntityExtractor,
        embedder: Embedder,
    ):
        self.settings = settings
        self.graph = graph
        self.vectors = vectors
        self.extractor = extractor
        self.embedder = embedder

    async def ingest(
        self, content: bytes, filename: str, media_type: str, metadata: DocumentMetadata
    ) -> IngestionResult:
        if len(content) > self.settings.max_upload_mb * 1024 * 1024:
            raise ValueError(f"File exceeds {self.settings.max_upload_mb} MB upload limit")
        parsed = parse_document(content, filename, media_type, metadata)
        document_id = metadata.document_id or f"doc:{parsed.checksum[:24]}"
        current = await self.graph.get_current_version(document_id)
        existing_checksum = current["checksum"] if current else None
        previous_version_id = current["document_version_id"] if current else None
        document_version_id = make_document_version_id(
            document_id, metadata.version, parsed.checksum
        )
        if existing_checksum == parsed.checksum:
            return IngestionResult(
                ingestion_id=str(uuid.uuid4()),
                status="skipped",
                process_id=metadata.process.process_id,
                document_id=document_id,
                document_version_id=previous_version_id or document_version_id,
                checksum=parsed.checksum,
                chunks_indexed=0,
                entities_upserted=0,
                relationships_upserted=0,
                assertions_upserted=0,
                warnings=["Idempotent skip: document_id and checksum already exist."],
            )

        extraction = await self.extractor.extract(parsed.text, metadata)
        chunks = chunk_document(
            parsed,
            document_id,
            document_version_id,
            self.settings.chunk_size,
            self.settings.chunk_overlap,
        )
        vectors = await self.embedder.embed([chunk.text for chunk in chunks])

        warnings = list(extraction.warnings)
        staged = False
        entities = 0
        assertions = 0
        try:
            await self.graph.stage_document_version(
                parsed, document_id, document_version_id, chunks
            )
            staged = True
            await self.vectors.upsert(chunks, vectors)
            entities, assertions = await self.graph.upsert_extraction(
                metadata.process.process_id,
                document_version_id,
                extraction,
                chunks,
            )
            if Path(filename).suffix.lower() in {".bpmn", ".xml"}:
                activities, flows = await self.graph.upsert_bpmn(
                    parsed, document_id, document_version_id, content
                )
                warnings.append(f"BPMN structure loaded: {activities} activities, {flows} flows.")

            # Activate the graph lineage first, then atomically switch the vector payload flags.
            # A compensating rollback restores the previous version if Qdrant activation fails.
            await self.graph.activate_document_version(document_id, document_version_id)
            await self.vectors.set_document_active(document_id, False)
            await self.vectors.set_version_active(document_version_id, True)
        except Exception as exc:
            if staged:
                await self.graph.rollback_document_version(
                    document_id,
                    document_version_id,
                    previous_version_id,
                    str(exc),
                )
            await self.vectors.delete_version(document_version_id)
            if previous_version_id:
                await self.vectors.set_version_active(previous_version_id, True)
            raise

        return IngestionResult(
            ingestion_id=str(uuid.uuid4()),
            status="updated" if existing_checksum else "created",
            process_id=metadata.process.process_id,
            document_id=document_id,
            document_version_id=document_version_id,
            checksum=parsed.checksum,
            chunks_indexed=len(chunks),
            entities_upserted=entities,
            relationships_upserted=assertions,
            assertions_upserted=assertions,
            warnings=warnings,
        )

    async def ingest_journeys(self, batch: JourneyBatch) -> dict[str, int | str]:
        counts = await self.graph.upsert_journeys(batch)
        return {"process_id": batch.process.process_id, **counts}
