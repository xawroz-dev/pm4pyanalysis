import re
from collections import defaultdict

from app.config import Settings
from app.domain.models import (
    DocumentMetadata,
    ExtractedEntity,
    ExtractedRelationship,
    ExtractionResult,
    NoiseComparison,
    OpenExtractionEntity,
    OpenExtractionRelationship,
    OpenExtractionResult,
)
from app.domain.ontology import NodeType, RelationshipType
from app.services.llm import LLMClient, constrained_schema, open_schema

ENTITY_RELATIONSHIP = {
    NodeType.MARKET: RelationshipType.OPERATES_IN,
    NodeType.BUSINESS_UNIT: RelationshipType.OWNED_BY,
    NodeType.CONTROL: RelationshipType.GOVERNED_BY,
    NodeType.SYSTEM: RelationshipType.USES_SYSTEM,
}


class EntityExtractor:
    def __init__(self, settings: Settings, llm: LLMClient):
        self.settings = settings
        self.llm = llm

    async def extract(
        self, text: str, metadata: DocumentMetadata, open_ontology: bool = False
    ) -> ExtractionResult | OpenExtractionResult:
        if open_ontology:
            return await self._extract_open(text)
        if self.settings.llm_provider == "openai" and self.settings.llm_api_key:
            result = await self._extract_constrained_llm(text, metadata)
        else:
            result = self._extract_from_metadata(metadata, text)
        return govern_extraction(result, self.settings.min_extraction_confidence)

    async def _extract_constrained_llm(
        self, text: str, metadata: DocumentMetadata
    ) -> ExtractionResult:
        system = """You extract enterprise process-intelligence facts into ontology version 2.0.
You may create ONLY Market, BusinessUnit, Control, and System entities.
You may create ONLY these process relationships:
Process-OPERATES_IN-Market, Process-OWNED_BY-BusinessUnit,
Process-GOVERNED_BY-Control, Process-USES_SYSTEM-System.
The source_ref for every relationship must be the supplied process_id. target_ref must equal
the entity canonical_name or external_id. Extract only explicit facts. Preserve a short exact
evidence span. Do not invent IDs, types, relationships, or inferred facts."""
        user = (
            f"PROCESS_ID: {metadata.process.process_id}\n"
            f"PROCESS_NAME: {metadata.process.name}\n"
            f"DOCUMENT_TYPE: {metadata.document_type}\n"
            f"METADATA: {metadata.model_dump_json()}\n\n"
            f"DOCUMENT:\n{text[:60000]}"
        )
        raw = await self.llm.json_completion(
            system, user, "constrained_process_extraction", constrained_schema()
        )
        return ExtractionResult.model_validate(raw)

    async def _extract_open(self, text: str) -> OpenExtractionResult:
        if self.settings.llm_provider == "openai" and self.settings.llm_api_key:
            raw = await self.llm.json_completion(
                "Extract any entities and any relationships you notice. Create labels freely.",
                text[:60000],
                "open_ontology_extraction",
                open_schema(),
            )
            return OpenExtractionResult.model_validate(raw)
        return noisy_offline_extraction(text)

    def _extract_from_metadata(self, metadata: DocumentMetadata, text: str) -> ExtractionResult:
        sources = {
            NodeType.MARKET: metadata.markets,
            NodeType.BUSINESS_UNIT: metadata.business_units,
            NodeType.CONTROL: metadata.controls,
            NodeType.SYSTEM: metadata.systems,
        }
        entities: list[ExtractedEntity] = []
        relationships: list[ExtractedRelationship] = []
        for entity_type, names in sources.items():
            for name in names:
                evidence = find_evidence(text, name) or f"Declared in metadata: {name}"
                entity = ExtractedEntity(
                    entity_type=entity_type,
                    canonical_name=name.strip(),
                    confidence=1.0,
                    evidence=evidence,
                )
                entities.append(entity)
                relationships.append(
                    ExtractedRelationship(
                        source_type=NodeType.PROCESS,
                        source_ref=metadata.process.process_id,
                        relationship_type=ENTITY_RELATIONSHIP[entity_type],
                        target_type=entity_type,
                        target_ref=name.strip(),
                        confidence=1.0,
                        evidence=evidence,
                    )
                )
        warning = (
            "Offline metadata extraction used. Set LLM_PROVIDER=openai and LLM_API_KEY "
            "to extract governed facts from document text."
        )
        return ExtractionResult(entities=entities, relationships=relationships, warnings=[warning])


def govern_extraction(result: ExtractionResult, min_confidence: float) -> ExtractionResult:
    entity_by_key: dict[tuple[NodeType, str], ExtractedEntity] = {}
    for entity in result.entities:
        entity.canonical_name = normalize_name(entity.canonical_name)
        if entity.confidence < min_confidence:
            continue
        key = (entity.entity_type, entity.canonical_name.casefold())
        previous = entity_by_key.get(key)
        if not previous or entity.confidence > previous.confidence:
            entity_by_key[key] = entity

    allowed_targets = {
        (entity.entity_type, (entity.external_id or entity.canonical_name).casefold())
        for entity in entity_by_key.values()
    } | {
        (entity.entity_type, entity.canonical_name.casefold()) for entity in entity_by_key.values()
    }
    relationship_by_key: dict[tuple, ExtractedRelationship] = {}
    warnings = list(result.warnings)
    for relationship in result.relationships:
        try:
            relationship.validate_ontology()
        except ValueError as exc:
            warnings.append(str(exc))
            continue
        if relationship.confidence < min_confidence:
            continue
        if (relationship.target_type, relationship.target_ref.casefold()) not in allowed_targets:
            warnings.append(
                f"Dropped relationship with unresolved target: {relationship.target_ref}"
            )
            continue
        key = (
            relationship.source_type,
            relationship.source_ref.casefold(),
            relationship.relationship_type,
            relationship.target_type,
            relationship.target_ref.casefold(),
        )
        previous = relationship_by_key.get(key)
        if not previous or relationship.confidence > previous.confidence:
            relationship_by_key[key] = relationship
    return ExtractionResult(
        entities=list(entity_by_key.values()),
        relationships=list(relationship_by_key.values()),
        warnings=warnings,
    )


def normalize_name(name: str) -> str:
    return re.sub(r"\s+", " ", name).strip(" \t\r\n,.;:")


def find_evidence(text: str, needle: str, window: int = 180) -> str | None:
    index = text.casefold().find(needle.casefold())
    if index < 0:
        return None
    start = max(0, index - window // 2)
    end = min(len(text), index + len(needle) + window // 2)
    return text[start:end].replace("\n", " ").strip()


def noisy_offline_extraction(text: str) -> OpenExtractionResult:
    """Intentionally permissive heuristic used only by the comparison endpoint."""
    entities: list[OpenExtractionEntity] = []
    relationships: list[OpenExtractionRelationship] = []
    labels = ["Actor", "Team", "Application", "Rule", "Region", "Task", "Artifact", "Concept"]
    candidates = re.findall(r"\b(?:[A-Z][A-Za-z0-9&/-]+(?:\s+[A-Z][A-Za-z0-9&/-]+){0,3})\b", text)
    for index, name in enumerate(dict.fromkeys(candidates[:80])):
        label = labels[index % len(labels)]
        entities.append(OpenExtractionEntity(label=label, name=name))
        if index:
            relationships.append(
                OpenExtractionRelationship(
                    source=entities[index - 1].name,
                    relationship=["USES", "REFERENCES", "RELATES_TO", "REQUIRES"][index % 4],
                    target=name,
                )
            )
    return OpenExtractionResult(entities=entities, relationships=relationships)


def compare_noise(
    constrained: ExtractionResult, open_result: OpenExtractionResult
) -> NoiseComparison:
    constrained_entity_types = sorted({entity.entity_type.value for entity in constrained.entities})
    constrained_relationship_types = sorted(
        {relationship.relationship_type.value for relationship in constrained.relationships}
    )
    open_entity_types = sorted({entity.label for entity in open_result.entities})
    open_relationship_types = sorted(
        {relationship.relationship for relationship in open_result.relationships}
    )
    by_normalized: dict[str, set[str]] = defaultdict(set)
    for entity in open_result.entities:
        by_normalized[re.sub(r"[^a-z0-9]", "", entity.name.casefold())].add(entity.label)
    examples = [
        {"name_key": key, "competing_labels": ", ".join(sorted(labels))}
        for key, labels in by_normalized.items()
        if len(labels) > 1
    ][:10]
    return NoiseComparison(
        constrained_entity_types=constrained_entity_types,
        constrained_relationship_types=constrained_relationship_types,
        open_entity_types=open_entity_types,
        open_relationship_types=open_relationship_types,
        open_entity_type_count=len(open_entity_types),
        open_relationship_type_count=len(open_relationship_types),
        normalization_examples=examples,
    )
