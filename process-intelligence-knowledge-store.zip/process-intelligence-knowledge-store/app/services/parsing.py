import hashlib
import io
import re
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET

from docx import Document as WordDocument
from pypdf import PdfReader

from app.domain.models import DocumentMetadata, ParsedDocument

SUPPORTED_EXTENSIONS = {".txt", ".md", ".pdf", ".docx", ".bpmn", ".xml"}


def parse_document(
    content: bytes, filename: str, media_type: str, metadata: DocumentMetadata
) -> ParsedDocument:
    suffix = Path(filename).suffix.lower()
    if suffix not in SUPPORTED_EXTENSIONS:
        raise ValueError(f"Unsupported file type {suffix}; allowed: {sorted(SUPPORTED_EXTENSIONS)}")

    if suffix in {".txt", ".md"}:
        text = content.decode("utf-8", errors="replace")
    elif suffix == ".pdf":
        text = "\n".join(page.extract_text() or "" for page in PdfReader(io.BytesIO(content)).pages)
    elif suffix == ".docx":
        document = WordDocument(io.BytesIO(content))
        text = "\n".join(paragraph.text for paragraph in document.paragraphs)
    else:
        text = bpmn_to_text(content)

    text = normalize_text(text)
    if not text:
        raise ValueError("No extractable text found in uploaded file")
    return ParsedDocument(
        metadata=metadata,
        text=text,
        checksum=hashlib.sha256(content).hexdigest(),
        media_type=media_type or "application/octet-stream",
        original_filename=filename,
    )


def normalize_text(text: str) -> str:
    text = text.replace("\x00", " ")
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def _local_name(tag: str) -> str:
    return tag.rsplit("}", 1)[-1]


def bpmn_to_text(content: bytes) -> str:
    root = ET.fromstring(content)
    lines: list[str] = []
    for element in root.iter():
        kind = _local_name(element.tag)
        name = element.attrib.get("name")
        element_id = element.attrib.get("id")
        if kind == "process":
            lines.append(f"BPMN Process: {name or element_id}")
        elif kind in {
            "task",
            "userTask",
            "serviceTask",
            "manualTask",
            "businessRuleTask",
            "sendTask",
            "receiveTask",
            "startEvent",
            "endEvent",
            "exclusiveGateway",
            "parallelGateway",
        }:
            lines.append(f"{kind}: {name or element_id} ({element_id})")
        elif kind == "sequenceFlow":
            lines.append(
                "Sequence: "
                f"{element.attrib.get('sourceRef')} -> {element.attrib.get('targetRef')}"
                + (f" [{name}]" if name else "")
            )
        elif kind in {"documentation", "text"} and element.text:
            lines.append(element.text.strip())
    return "\n".join(lines)


def parse_bpmn_structure(content: bytes) -> dict:
    root = ET.fromstring(content)
    process_element = next((e for e in root.iter() if _local_name(e.tag) == "process"), None)
    if process_element is None:
        raise ValueError("BPMN XML has no process element")

    nodes: list[dict] = []
    flows: list[dict] = []
    supported_nodes = {
        "task",
        "userTask",
        "serviceTask",
        "manualTask",
        "businessRuleTask",
        "sendTask",
        "receiveTask",
        "startEvent",
        "endEvent",
        "exclusiveGateway",
        "parallelGateway",
    }
    for element in process_element:
        kind = _local_name(element.tag)
        if kind in supported_nodes:
            nodes.append(
                {
                    "activity_id": element.attrib["id"],
                    "name": element.attrib.get("name") or element.attrib["id"],
                    "activity_type": kind,
                }
            )
        elif kind == "sequenceFlow":
            flows.append(
                {
                    "flow_id": element.attrib["id"],
                    "source_id": element.attrib["sourceRef"],
                    "target_id": element.attrib["targetRef"],
                    "name": element.attrib.get("name"),
                }
            )
    return {
        "bpmn_process_id": process_element.attrib.get("id"),
        "name": process_element.attrib.get("name"),
        "activities": nodes,
        "flows": flows,
    }


def safe_docx_xml_names(content: bytes) -> list[str]:
    """Small diagnostic helper used to reject malformed OOXML archives."""
    with zipfile.ZipFile(io.BytesIO(content)) as archive:
        return archive.namelist()
