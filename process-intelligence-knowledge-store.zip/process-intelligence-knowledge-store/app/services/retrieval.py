import re
from enum import StrEnum
from typing import Any

from app.domain.models import ChatRequest, Citation
from app.repositories.neo4j import Neo4jRepository
from app.repositories.vector import CLASSIFICATION_ACCESS, QdrantRepository
from app.services.llm import Embedder


class Intent(StrEnum):
    PROCESS_OVERVIEW = "process_overview"
    CONTROLS = "controls"
    SYSTEMS = "systems"
    OWNERSHIP = "ownership"
    MARKETS = "markets"
    DOCUMENTS = "documents"
    EVIDENCE_LINEAGE = "evidence_lineage"
    BPMN_FLOW = "bpmn_flow"
    VARIANTS = "variants"
    JOURNEYS = "journeys"
    GENERIC_EVIDENCE = "generic_evidence"


INTENT_PATTERNS: list[tuple[Intent, tuple[str, ...]]] = [
    (Intent.CONTROLS, ("control", "risk", "compliance", "policy requirement")),
    (Intent.SYSTEMS, ("system", "application", "platform", "technology")),
    (Intent.OWNERSHIP, ("owner", "business unit", "team", "responsible")),
    (Intent.MARKETS, ("market", "country", "region", "geography")),
    (Intent.EVIDENCE_LINEAGE, ("chunk", "lineage", "provenance", "supports this fact")),
    (Intent.DOCUMENTS, ("document", "sop", "policy", "source", "evidence")),
    (Intent.BPMN_FLOW, ("bpmn", "flow", "activity", "step", "diagram", "sequence")),
    (Intent.VARIANTS, ("variant", "path", "most common", "longest")),
    (Intent.JOURNEYS, ("journey", "case", "instance", "execution")),
    (Intent.PROCESS_OVERVIEW, ("overview", "about", "describe", "summary")),
]


GRAPH_QUERIES: dict[Intent, str] = {
    Intent.PROCESS_OVERVIEW: """
        MATCH (p:Process {process_id: $process_id})
        OPTIONAL MATCH (p)-[r:OPERATES_IN|OWNED_BY|GOVERNED_BY|USES_SYSTEM]->(n)
        WHERE n IS NULL OR EXISTS {
            MATCH (v:DocumentVersion {active: true})-[:HAS_ASSERTION]->
                  (a:Assertion {active: true, status: 'APPROVED'})-[:SUBJECT]->(p)
            MATCH (a)-[:OBJECT]->(n)
            WHERE a.predicate = type(r)
              AND v.classification IN $allowed_classifications
        }
        WITH p, collect(CASE WHEN n IS NULL THEN null ELSE {
            relationship: type(r), entity_type: labels(n)[0],
            entity_id: coalesce(n.market_id, n.business_unit_id, n.control_id, n.system_id),
            name: n.name, confidence: r.confidence
        } END) AS governed_facts
        OPTIONAL MATCH (p)-[:HAS_DOCUMENT]->(d:Document)-[:HAS_VERSION]->
                       (v:DocumentVersion {active: true})
        WHERE v.classification IN $allowed_classifications
        RETURN p.process_id AS process_id, p.name AS process_name,
               p.description AS description, p.owner AS owner, p.status AS status,
               governed_facts,
               collect(DISTINCT {
                   document_id: d.document_id, title: d.title,
                   document_version_id: v.document_version_id,
                   version: v.version, classification: v.classification
               }) AS active_documents
    """,
    Intent.CONTROLS: """
        MATCH (p:Process {process_id: $process_id})-[r:GOVERNED_BY]->(c:Control)
        MATCH (a:Assertion {active: true, status: 'APPROVED', predicate: 'GOVERNED_BY'})
              -[:SUBJECT]->(p)
        MATCH (a)-[:OBJECT]->(c)
        MATCH (v:DocumentVersion {active: true})-[:HAS_ASSERTION]->(a)
        WHERE v.classification IN $allowed_classifications
        OPTIONAL MATCH (chunk:Chunk {active: true})-[:SUPPORTS]->(a)
        RETURN c.control_id AS id, c.name AS name, c.description AS description,
               r.confidence AS confidence, count(DISTINCT a) AS assertion_count,
               collect(DISTINCT v.document_version_id) AS evidence_version_ids,
               collect(DISTINCT chunk.chunk_id) AS evidence_chunk_ids
        ORDER BY c.name
    """,
    Intent.SYSTEMS: """
        MATCH (p:Process {process_id: $process_id})-[r:USES_SYSTEM]->(s:System)
        MATCH (a:Assertion {active: true, status: 'APPROVED', predicate: 'USES_SYSTEM'})
              -[:SUBJECT]->(p)
        MATCH (a)-[:OBJECT]->(s)
        MATCH (v:DocumentVersion {active: true})-[:HAS_ASSERTION]->(a)
        WHERE v.classification IN $allowed_classifications
        OPTIONAL MATCH (chunk:Chunk {active: true})-[:SUPPORTS]->(a)
        RETURN s.system_id AS id, s.name AS name, s.description AS description,
               r.confidence AS confidence, count(DISTINCT a) AS assertion_count,
               collect(DISTINCT v.document_version_id) AS evidence_version_ids,
               collect(DISTINCT chunk.chunk_id) AS evidence_chunk_ids
        ORDER BY s.name
    """,
    Intent.OWNERSHIP: """
        MATCH (p:Process {process_id: $process_id})-[r:OWNED_BY]->(b:BusinessUnit)
        MATCH (a:Assertion {active: true, status: 'APPROVED', predicate: 'OWNED_BY'})
              -[:SUBJECT]->(p)
        MATCH (a)-[:OBJECT]->(b)
        MATCH (v:DocumentVersion {active: true})-[:HAS_ASSERTION]->(a)
        WHERE v.classification IN $allowed_classifications
        OPTIONAL MATCH (chunk:Chunk {active: true})-[:SUPPORTS]->(a)
        RETURN b.business_unit_id AS id, b.name AS name, b.description AS description,
               r.confidence AS confidence, count(DISTINCT a) AS assertion_count,
               collect(DISTINCT v.document_version_id) AS evidence_version_ids,
               collect(DISTINCT chunk.chunk_id) AS evidence_chunk_ids
        ORDER BY b.name
    """,
    Intent.MARKETS: """
        MATCH (p:Process {process_id: $process_id})-[r:OPERATES_IN]->(m:Market)
        MATCH (a:Assertion {active: true, status: 'APPROVED', predicate: 'OPERATES_IN'})
              -[:SUBJECT]->(p)
        MATCH (a)-[:OBJECT]->(m)
        MATCH (v:DocumentVersion {active: true})-[:HAS_ASSERTION]->(a)
        WHERE v.classification IN $allowed_classifications
        OPTIONAL MATCH (chunk:Chunk {active: true})-[:SUPPORTS]->(a)
        RETURN m.market_id AS id, m.name AS name, m.description AS description,
               r.confidence AS confidence, count(DISTINCT a) AS assertion_count,
               collect(DISTINCT v.document_version_id) AS evidence_version_ids,
               collect(DISTINCT chunk.chunk_id) AS evidence_chunk_ids
        ORDER BY m.name
    """,
    Intent.DOCUMENTS: """
        MATCH (p:Process {process_id: $process_id})-[:HAS_DOCUMENT]->(d:Document)
              -[:HAS_VERSION]->(v:DocumentVersion {active: true})
        WHERE v.classification IN $allowed_classifications
        OPTIONAL MATCH (v)-[:HAS_CHUNK]->(c:Chunk {active: true})
        RETURN d.document_id AS id, d.title AS title, d.document_type AS document_type,
               v.document_version_id AS document_version_id, v.version AS version,
               v.effective_date AS effective_date, v.classification AS classification,
               d.source_uri AS source_uri, count(c) AS chunk_count
        ORDER BY d.document_type, d.title
    """,
    Intent.EVIDENCE_LINEAGE: """
        MATCH (p:Process {process_id: $process_id})-[:HAS_DOCUMENT]->(d:Document)
              -[:HAS_VERSION]->(v:DocumentVersion {active: true})-[:HAS_CHUNK]->
              (c:Chunk {active: true})
        WHERE v.classification IN $allowed_classifications
        OPTIONAL MATCH (c)-[:SUPPORTS]->(a:Assertion {active: true})-[:OBJECT]->(target)
        RETURN d.document_id AS document_id, d.title AS document,
               v.document_version_id AS document_version_id, v.version AS version,
               c.chunk_id AS chunk_id, c.ordinal AS ordinal, c.section AS section,
               collect(CASE WHEN a IS NULL THEN null ELSE {
                   assertion_id: a.assertion_id, predicate: a.predicate,
                   target_type: a.target_type, target_name: target.name,
                   confidence: a.confidence
               } END) AS supported_assertions
        ORDER BY document, ordinal
        LIMIT 200
    """,
    Intent.BPMN_FLOW: """
        MATCH (p:Process {process_id: $process_id})-[:HAS_DOCUMENT]->(:Document)
              -[:HAS_VERSION]->(v:DocumentVersion {active: true})-[:REPRESENTED_BY]->
              (b:BPMNModel)
        WHERE v.classification IN $allowed_classifications
        MATCH (b)-[:DEFINES_ACTIVITY]->(a:Activity)
        OPTIONAL MATCH (a)-[r:NEXT_ACTIVITY]->(next:Activity)
        RETURN b.name AS model, v.document_version_id AS document_version_id,
               a.activity_id AS activity_id, a.name AS activity,
               a.activity_type AS activity_type, next.name AS next_activity,
               r.name AS condition
        ORDER BY activity
    """,
    Intent.VARIANTS: """
        MATCH (p:Process {process_id: $process_id})-[:HAS_VARIANT]->(v:Variant)
        OPTIONAL MATCH (j:Journey)-[:FOLLOWS_VARIANT]->(v)
        RETURN v.variant_id AS variant_id, v.activity_ids AS activity_ids,
               count(j) AS journey_count, avg(j.duration_seconds) AS avg_duration_seconds
        ORDER BY journey_count DESC, avg_duration_seconds DESC LIMIT 20
    """,
    Intent.JOURNEYS: """
        MATCH (p:Process {process_id: $process_id})-[:HAS_JOURNEY]->(j:Journey)
        OPTIONAL MATCH (j)-[:FOLLOWS_VARIANT]->(v:Variant)
        RETURN j.journey_id AS journey_id, v.variant_id AS variant_id,
               j.started_at AS started_at, j.ended_at AS ended_at,
               j.duration_seconds AS duration_seconds, j.outcome AS outcome
        ORDER BY j.started_at DESC LIMIT 50
    """,
    Intent.GENERIC_EVIDENCE: """
        MATCH (p:Process {process_id: $process_id})
              -[r:OPERATES_IN|OWNED_BY|GOVERNED_BY|USES_SYSTEM]->(n)
        OPTIONAL MATCH (a:Assertion {active: true, status: 'APPROVED'})-[:SUBJECT]->(p)
        WHERE a.predicate = type(r)
        OPTIONAL MATCH (a)-[:OBJECT]->(n)
        OPTIONAL MATCH (v:DocumentVersion {active: true})-[:HAS_ASSERTION]->(a)
        WHERE v IS NULL OR v.classification IN $allowed_classifications
        OPTIONAL MATCH (c:Chunk {active: true})-[:SUPPORTS]->(a)
        RETURN type(r) AS relationship, labels(n)[0] AS entity_type, n.name AS name,
               collect(DISTINCT v.document_version_id) AS evidence_version_ids,
               collect(DISTINCT c.chunk_id) AS evidence_chunk_ids
        ORDER BY relationship, name LIMIT 100
    """,
}


class HybridRetriever:
    def __init__(self, graph: Neo4jRepository, vectors: QdrantRepository, embedder: Embedder):
        self.graph = graph
        self.vectors = vectors
        self.embedder = embedder

    async def retrieve(
        self, request: ChatRequest
    ) -> tuple[Intent, str | None, list[dict[str, Any]], list[Citation]]:
        intent = classify_intent(request.question)
        allowed = CLASSIFICATION_ACCESS[request.classification_clearance]
        query_vector = (await self.embedder.embed([request.question]))[0]

        process_id = request.process_id
        version_scope: list[str] | None = None
        if process_id:
            version_scope = await self.graph.retrieval_scope(process_id, allowed)

        vector_hits = await self.vectors.search(
            query_vector,
            request.top_k,
            process_id,
            request.classification_clearance,
            version_scope,
        )
        if not process_id:
            process_id = infer_process_id(vector_hits)
            if process_id:
                version_scope = await self.graph.retrieval_scope(process_id, allowed)
                vector_hits = await self.vectors.search(
                    query_vector,
                    request.top_k,
                    process_id,
                    request.classification_clearance,
                    version_scope,
                )

        graph_facts: list[dict[str, Any]] = []
        if process_id:
            graph_facts = await self.graph.query(
                GRAPH_QUERIES[intent],
                {
                    "process_id": process_id,
                    "allowed_classifications": allowed,
                },
            )
        citations = [
            Citation(
                document_id=hit["document_id"],
                document_version_id=hit["document_version_id"],
                chunk_id=hit["chunk_id"],
                title=hit["title"],
                section=hit.get("section"),
                page_start=hit.get("page_start"),
                excerpt=compact_excerpt(hit["text"]),
                score=float(hit["score"]),
            )
            for hit in vector_hits
        ]
        return intent, process_id, graph_facts, citations


def classify_intent(question: str) -> Intent:
    normalized = question.casefold()
    for intent, phrases in INTENT_PATTERNS:
        if any(phrase in normalized for phrase in phrases):
            return intent
    return Intent.GENERIC_EVIDENCE


def infer_process_id(hits: list[dict[str, Any]]) -> str | None:
    if not hits:
        return None
    scores: dict[str, float] = {}
    for hit in hits:
        scores[hit["process_id"]] = scores.get(hit["process_id"], 0.0) + float(hit["score"])
    return max(scores, key=scores.get)


def compact_excerpt(text: str, limit: int = 360) -> str:
    text = re.sub(r"\s+", " ", text).strip()
    return text if len(text) <= limit else text[: limit - 1] + "…"
