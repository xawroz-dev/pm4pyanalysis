import json
from contextlib import asynccontextmanager
from typing import Annotated, Literal

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import JSONResponse
from pydantic import ValidationError

from app.config import get_settings
from app.domain.models import (
    ChatRequest,
    ChatResponse,
    DocumentMetadata,
    IngestionResult,
    JourneyBatch,
    NoiseComparison,
)
from app.domain.ontology import ONTOLOGY_VERSION
from app.repositories.neo4j import Neo4jRepository
from app.repositories.vector import CLASSIFICATION_ACCESS, QdrantRepository
from app.services.chat import ChatService
from app.services.extraction import EntityExtractor, compare_noise
from app.services.ingestion import IngestionService
from app.services.llm import Embedder, LLMClient
from app.services.parsing import parse_document
from app.services.retrieval import GRAPH_QUERIES, HybridRetriever, Intent


@asynccontextmanager
async def lifespan(app: FastAPI):
    settings = get_settings()
    graph = Neo4jRepository(settings.neo4j_uri, settings.neo4j_user, settings.neo4j_password)
    vectors = QdrantRepository(
        settings.qdrant_url, settings.qdrant_collection, settings.embedding_dimensions
    )
    llm = LLMClient(settings)
    embedder = Embedder(settings)
    extractor = EntityExtractor(settings, llm)
    retriever = HybridRetriever(graph, vectors, embedder)
    app.state.settings = settings
    app.state.graph = graph
    app.state.vectors = vectors
    app.state.extractor = extractor
    app.state.ingestion = IngestionService(settings, graph, vectors, extractor, embedder)
    app.state.chat = ChatService(settings, retriever, llm)
    app.state.llm = llm
    app.state.embedder = embedder
    await graph.initialize()
    await vectors.initialize()
    yield
    await llm.close()
    await embedder.close()
    await graph.close()
    await vectors.close()


app = FastAPI(
    title="Process Intelligence Knowledge Store",
    version="0.2.0",
    description=(
        "Governed ontology knowledge graph + vector RAG. "
        "The API never accepts or generates arbitrary Cypher for chat."
    ),
    lifespan=lifespan,
)


@app.exception_handler(ValueError)
async def value_error_handler(_, exc: ValueError):
    return JSONResponse(status_code=422, content={"detail": str(exc)})


def parse_metadata(raw: str) -> DocumentMetadata:
    try:
        return DocumentMetadata.model_validate_json(raw)
    except ValidationError as exc:
        raise HTTPException(status_code=422, detail=exc.errors()) from exc
    except json.JSONDecodeError as exc:
        raise HTTPException(status_code=422, detail=f"Invalid metadata JSON: {exc}") from exc


@app.get("/health")
async def health() -> dict:
    graph_ok = False
    vector_ok = False
    try:
        graph_ok = await app.state.graph.ping()
        vector_ok = await app.state.vectors.ping()
    except Exception:
        pass
    return {
        "status": "ok" if graph_ok and vector_ok else "degraded",
        "graph": graph_ok,
        "vector": vector_ok,
        "ontology_version": ONTOLOGY_VERSION,
        "llm_provider": app.state.settings.llm_provider,
        "embedding_provider": app.state.settings.embedding_provider,
    }


@app.post("/v1/ingest/document", response_model=IngestionResult)
async def ingest_document(
    file: Annotated[UploadFile, File(description="TXT, Markdown, PDF, DOCX, BPMN, or XML")],
    metadata: Annotated[str, Form(description="DocumentMetadata JSON")],
):
    content = await file.read()
    return await app.state.ingestion.ingest(
        content,
        file.filename or "upload.bin",
        file.content_type or "application/octet-stream",
        parse_metadata(metadata),
    )


@app.post("/v1/ingest/journeys")
async def ingest_journeys(batch: JourneyBatch) -> dict:
    return await app.state.ingestion.ingest_journeys(batch)


@app.post("/v1/chat", response_model=ChatResponse)
async def chat(request: ChatRequest) -> ChatResponse:
    return await app.state.chat.answer(request)


@app.get("/v1/ontology")
async def ontology() -> dict:
    from app.domain.ontology import ALLOWED_RELATIONSHIPS, NodeType

    return {
        "version": ONTOLOGY_VERSION,
        "node_types": [item.value for item in NodeType],
        "relationship_triples": [
            {
                "source": source.value,
                "relationship": relationship.value,
                "target": target.value,
            }
            for source, relationship, target in sorted(
                ALLOWED_RELATIONSHIPS,
                key=lambda item: (item[0].value, item[1].value, item[2].value),
            )
        ],
        "policy": {
            "llm_can_create_domain_types": [
                "Market",
                "BusinessUnit",
                "Control",
                "System",
            ],
            "deterministic_evidence_types": [
                "Document",
                "DocumentVersion",
                "Chunk",
                "Assertion",
            ],
            "assertion_predicates": [
                "OPERATES_IN",
                "OWNED_BY",
                "GOVERNED_BY",
                "USES_SYSTEM",
            ],
            "arbitrary_labels": False,
            "arbitrary_relationships": False,
            "llm_generated_cypher": False,
        },
    }


@app.get("/v1/graph/chunks/{chunk_id}/lineage")
async def chunk_lineage(
    chunk_id: str,
    classification_clearance: Literal[
        "public", "internal", "confidential", "restricted"
    ] = "internal",
) -> dict:
    lineage = await app.state.graph.chunk_lineage(
        chunk_id, CLASSIFICATION_ACCESS[classification_clearance]
    )
    if lineage is None:
        raise HTTPException(status_code=404, detail="Chunk not found or not accessible")
    return lineage


@app.get("/v1/evidence/chunks/{chunk_id}")
async def get_evidence_chunk(
    chunk_id: str,
    classification_clearance: Literal[
        "public", "internal", "confidential", "restricted"
    ] = "internal",
) -> dict:
    lineage = await app.state.graph.chunk_lineage(
        chunk_id, CLASSIFICATION_ACCESS[classification_clearance]
    )
    if lineage is None:
        raise HTTPException(status_code=404, detail="Chunk not found or not accessible")
    payload = await app.state.vectors.get_chunk(chunk_id)
    if payload is None:
        raise HTTPException(
            status_code=409,
            detail="Graph lineage exists but vector payload is missing; run reconciliation",
        )
    return {"lineage": lineage, "content": payload}


@app.get("/v1/governance/reconciliation/{process_id}")
async def reconcile_process(process_id: str) -> dict:
    graph_ids = set(await app.state.graph.active_chunk_ids(process_id))
    vector_ids = set(await app.state.vectors.active_chunk_ids(process_id))
    graph_only = sorted(graph_ids - vector_ids)
    vector_only = sorted(vector_ids - graph_ids)
    return {
        "process_id": process_id,
        "status": "consistent" if not graph_only and not vector_only else "drift_detected",
        "graph_active_chunks": len(graph_ids),
        "vector_active_chunks": len(vector_ids),
        "graph_only_chunk_ids": graph_only,
        "vector_only_chunk_ids": vector_only,
    }


@app.get("/v1/graph/processes/{process_id}/subgraph")
async def process_subgraph(
    process_id: str,
    classification_clearance: Literal[
        "public", "internal", "confidential", "restricted"
    ] = "internal",
) -> dict:
    return {
        "process_id": process_id,
        "classification_clearance": classification_clearance,
        "edges": await app.state.graph.subgraph(
            process_id, CLASSIFICATION_ACCESS[classification_clearance]
        ),
    }


@app.get("/v1/graph/query-catalog")
async def query_catalog() -> dict:
    return {
        "queries": [
            {
                "intent": intent.value,
                "parameters": ["process_id", "allowed_classifications"],
                "cypher": " ".join(GRAPH_QUERIES[intent].split()),
            }
            for intent in Intent
        ],
        "note": "This catalog is fixed in application code; chat cannot submit arbitrary Cypher.",
    }


@app.post("/v1/demo/compare-open-ontology", response_model=NoiseComparison)
async def compare_open_ontology(
    file: Annotated[UploadFile, File()],
    metadata: Annotated[str, Form(description="DocumentMetadata JSON")],
):
    raw_metadata = parse_metadata(metadata)
    content = await file.read()
    parsed = parse_document(
        content,
        file.filename or "upload.txt",
        file.content_type or "text/plain",
        raw_metadata,
    )
    constrained = await app.state.extractor.extract(parsed.text, raw_metadata)
    open_result = await app.state.extractor.extract(parsed.text, raw_metadata, open_ontology=True)
    return compare_noise(constrained, open_result)
