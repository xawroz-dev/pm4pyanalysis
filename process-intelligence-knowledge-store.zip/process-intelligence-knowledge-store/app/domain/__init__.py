"""Domain contracts and ontology."""
