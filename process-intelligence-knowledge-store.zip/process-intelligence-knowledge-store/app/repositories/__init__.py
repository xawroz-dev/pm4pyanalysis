"""Persistence adapters."""
