import json
import re
import uuid
from typing import Any

from neo4j import AsyncDriver, AsyncGraphDatabase

from app.domain.models import ExtractionResult, JourneyBatch, ParsedDocument, TextChunk
from app.domain.ontology import ID_KEYS, ONTOLOGY_VERSION, NodeType, RelationshipType
from app.services.parsing import parse_bpmn_structure

ENTITY_NAMESPACE = uuid.UUID("3bf6d5a5-e4e0-4e86-83bb-a992619ddf57")
ASSERTION_NAMESPACE = uuid.UUID("c26baea4-44cf-405c-970f-29dd179fe7e6")

MATERIALIZED_RELATIONSHIPS: dict[RelationshipType, tuple[NodeType, str]] = {
    RelationshipType.OPERATES_IN: (NodeType.MARKET, "market_id"),
    RelationshipType.OWNED_BY: (NodeType.BUSINESS_UNIT, "business_unit_id"),
    RelationshipType.GOVERNED_BY: (NodeType.CONTROL, "control_id"),
    RelationshipType.USES_SYSTEM: (NodeType.SYSTEM, "system_id"),
}


def canonical_id(node_type: NodeType, name: str) -> str:
    normalized = re.sub(r"[^a-z0-9]+", "-", name.casefold()).strip("-")
    suffix = str(uuid.uuid5(ENTITY_NAMESPACE, f"{node_type.value}:{name.casefold()}"))[:8]
    return f"{node_type.value.casefold()}:{normalized[:60]}:{suffix}"


def assertion_id(
    document_version_id: str,
    process_id: str,
    predicate: RelationshipType,
    target_type: NodeType,
    target_id: str,
) -> str:
    value = f"{document_version_id}:{process_id}:{predicate.value}:{target_type.value}:{target_id}"
    return f"assertion:{uuid.uuid5(ASSERTION_NAMESPACE, value)}"


def evidence_chunk_ids(
    evidence: str, target_ref: str, chunks: list[TextChunk], limit: int = 3
) -> list[str]:
    """Resolve extracted evidence to deterministic chunks without creating arbitrary mentions."""
    evidence_normalized = re.sub(r"\s+", " ", evidence).strip().casefold()
    target_normalized = target_ref.strip().casefold()
    if evidence_normalized.startswith("declared in metadata:"):
        return [
            chunk.chunk_id
            for chunk in chunks
            if chunk.chunk_kind == "metadata"
            and evidence_normalized in re.sub(r"\s+", " ", chunk.text).casefold()
        ][:limit]

    exact: list[str] = []
    target_matches: list[str] = []
    for chunk in chunks:
        chunk_text = re.sub(r"\s+", " ", chunk.text).casefold()
        if evidence_normalized and evidence_normalized in chunk_text:
            exact.append(chunk.chunk_id)
        elif target_normalized and target_normalized in chunk_text:
            target_matches.append(chunk.chunk_id)
    return (exact or target_matches)[:limit]


class Neo4jRepository:
    def __init__(self, uri: str, user: str, password: str):
        self.driver: AsyncDriver = AsyncGraphDatabase.driver(uri, auth=(user, password))

    async def close(self) -> None:
        await self.driver.close()

    async def ping(self) -> bool:
        await self.driver.verify_connectivity()
        return True

    async def initialize(self) -> None:
        constraints = [
            ("Process", "process_id"),
            ("Document", "document_id"),
            ("DocumentVersion", "document_version_id"),
            ("Chunk", "chunk_id"),
            ("Assertion", "assertion_id"),
            ("BPMNModel", "bpmn_id"),
            ("Activity", "activity_id"),
            ("Journey", "journey_id"),
            ("Variant", "variant_id"),
            ("Market", "market_id"),
            ("BusinessUnit", "business_unit_id"),
            ("Control", "control_id"),
            ("System", "system_id"),
        ]
        async with self.driver.session() as session:
            for label, key in constraints:
                await session.run(
                    f"CREATE CONSTRAINT {label.lower()}_{key} IF NOT EXISTS "
                    f"FOR (n:{label}) REQUIRE n.{key} IS UNIQUE"
                )
            await session.run("CREATE INDEX process_name IF NOT EXISTS FOR (n:Process) ON (n.name)")
            await session.run(
                "CREATE INDEX document_version_checksum IF NOT EXISTS "
                "FOR (n:DocumentVersion) ON (n.checksum)"
            )
            await session.run(
                "CREATE INDEX chunk_process_active IF NOT EXISTS "
                "FOR (n:Chunk) ON (n.process_id, n.active)"
            )
            await session.run(
                "CREATE INDEX assertion_active_predicate IF NOT EXISTS "
                "FOR (n:Assertion) ON (n.active, n.predicate)"
            )

    async def get_current_version(self, document_id: str) -> dict[str, Any] | None:
        records, _, _ = await self.driver.execute_query(
            """
            MATCH (d:Document {document_id: $document_id})
            OPTIONAL MATCH (d)-[:HAS_VERSION]->(v:DocumentVersion {active: true})
            RETURN d.current_version_id AS document_version_id, v.checksum AS checksum
            """,
            document_id=document_id,
            routing_="r",
        )
        if not records or records[0]["document_version_id"] is None:
            return None
        return records[0].data()

    async def stage_document_version(
        self,
        document: ParsedDocument,
        document_id: str,
        document_version_id: str,
        chunks: list[TextChunk],
    ) -> None:
        metadata = document.metadata
        chunk_rows = [
            {
                "chunk_id": chunk.chunk_id,
                "ordinal": chunk.ordinal,
                "chunk_kind": chunk.chunk_kind,
                "content_hash": chunk.content_hash,
                "section": chunk.section,
                "char_start": chunk.char_start,
                "char_end": chunk.char_end,
                "page_start": chunk.page_start,
                "page_end": chunk.page_end,
                "classification": chunk.classification,
            }
            for chunk in chunks
        ]
        await self.driver.execute_query(
            """
            MERGE (p:Process {process_id: $process_id})
            ON CREATE SET p.created_at = datetime()
            SET p.name = $process_name, p.description = $description, p.owner = $owner,
                p.status = $process_status, p.criticality = $criticality, p.tags = $tags,
                p.ontology_version = $ontology_version, p.updated_at = datetime()
            MERGE (d:Document {document_id: $document_id})
            ON CREATE SET d.created_at = datetime()
            SET d.title = $title, d.document_type = $document_type,
                d.source_uri = $source_uri, d.original_filename = $original_filename,
                d.updated_at = datetime()
            MERGE (v:DocumentVersion {document_version_id: $document_version_id})
            ON CREATE SET v.created_at = datetime()
            SET v.document_id = $document_id, v.version = $version,
                v.effective_date = $effective_date, v.classification = $classification,
                v.checksum = $checksum, v.media_type = $media_type,
                v.status = 'STAGED', v.active = false, v.updated_at = datetime()
            MERGE (p)-[:HAS_DOCUMENT]->(d)
            MERGE (d)-[:HAS_VERSION]->(v)
            WITH v
            UNWIND $chunks AS row
            MERGE (c:Chunk {chunk_id: row.chunk_id})
            ON CREATE SET c.created_at = datetime()
            SET c.document_id = $document_id,
                c.document_version_id = $document_version_id,
                c.process_id = $process_id,
                c.ordinal = row.ordinal,
                c.chunk_kind = row.chunk_kind,
                c.content_hash = row.content_hash,
                c.section = row.section,
                c.char_start = row.char_start,
                c.char_end = row.char_end,
                c.page_start = row.page_start,
                c.page_end = row.page_end,
                c.classification = row.classification,
                c.vector_status = 'PENDING',
                c.active = false,
                c.updated_at = datetime()
            MERGE (v)-[:HAS_CHUNK]->(c)
            """,
            process_id=metadata.process.process_id,
            process_name=metadata.process.name,
            description=metadata.process.description,
            owner=metadata.process.owner,
            process_status=metadata.process.status,
            criticality=metadata.process.criticality,
            tags=metadata.process.tags,
            ontology_version=ONTOLOGY_VERSION,
            document_id=document_id,
            title=metadata.title,
            document_type=metadata.document_type,
            source_uri=metadata.source_uri,
            original_filename=document.original_filename,
            document_version_id=document_version_id,
            version=metadata.version or "unversioned",
            effective_date=(
                metadata.effective_date.isoformat() if metadata.effective_date else None
            ),
            classification=metadata.classification,
            checksum=document.checksum,
            media_type=document.media_type,
            chunks=chunk_rows,
        )

    async def mark_version_failed(self, document_version_id: str, error: str) -> None:
        await self.driver.execute_query(
            """
            MATCH (v:DocumentVersion {document_version_id: $document_version_id})
            SET v.status = 'FAILED', v.active = false,
                v.error = left($error, 1000), v.updated_at = datetime()
            WITH v
            OPTIONAL MATCH (v)-[:HAS_CHUNK]->(c:Chunk)
            SET c.active = false, c.vector_status = 'FAILED', c.updated_at = datetime()
            """,
            document_version_id=document_version_id,
            error=error,
        )

    async def upsert_extraction(
        self,
        process_id: str,
        document_version_id: str,
        extraction: ExtractionResult,
        chunks: list[TextChunk],
    ) -> tuple[int, int]:
        entity_lookup: dict[tuple[NodeType, str], str] = {}
        for entity in extraction.entities:
            node_id = entity.external_id or canonical_id(entity.entity_type, entity.canonical_name)
            entity_lookup[(entity.entity_type, entity.canonical_name.casefold())] = node_id
            if entity.external_id:
                entity_lookup[(entity.entity_type, entity.external_id.casefold())] = node_id
            label = entity.entity_type.value
            id_key = ID_KEYS[entity.entity_type]
            await self.driver.execute_query(
                f"""
                MERGE (n:{label} {{{id_key}: $node_id}})
                ON CREATE SET n.created_at = datetime()
                SET n.name = $name, n.description = coalesce($description, n.description),
                    n.aliases = $aliases, n.updated_at = datetime(),
                    n.ontology_version = $ontology_version
                """,
                node_id=node_id,
                name=entity.canonical_name,
                description=entity.description,
                aliases=entity.aliases,
                ontology_version=ONTOLOGY_VERSION,
            )

        assertions_written = 0
        for relationship in extraction.relationships:
            relationship.validate_ontology()
            target_id = entity_lookup.get(
                (relationship.target_type, relationship.target_ref.casefold())
            )
            if not target_id:
                continue
            target_label = relationship.target_type.value
            target_key = ID_KEYS[relationship.target_type]
            current_assertion_id = assertion_id(
                document_version_id,
                process_id,
                relationship.relationship_type,
                relationship.target_type,
                target_id,
            )
            supporting_chunks = evidence_chunk_ids(
                relationship.evidence, relationship.target_ref, chunks
            )
            if not supporting_chunks:
                continue
            await self.driver.execute_query(
                f"""
                MATCH (p:Process {{process_id: $process_id}})
                MATCH (t:{target_label} {{{target_key}: $target_id}})
                MATCH (v:DocumentVersion {{document_version_id: $document_version_id}})
                MERGE (a:Assertion {{assertion_id: $assertion_id}})
                ON CREATE SET a.created_at = datetime()
                SET a.document_version_id = $document_version_id,
                    a.process_id = $process_id,
                    a.predicate = $predicate,
                    a.target_type = $target_type,
                    a.target_id = $target_id,
                    a.confidence = $confidence,
                    a.evidence = $evidence,
                    a.status = 'STAGED',
                    a.active = false,
                    a.ontology_version = $ontology_version,
                    a.updated_at = datetime()
                MERGE (a)-[:SUBJECT]->(p)
                MERGE (a)-[:OBJECT]->(t)
                MERGE (v)-[:HAS_ASSERTION]->(a)
                WITH a
                UNWIND $chunk_ids AS chunk_id
                MATCH (c:Chunk {{chunk_id: chunk_id}})
                MERGE (c)-[:SUPPORTS]->(a)
                """,
                process_id=process_id,
                target_id=target_id,
                document_version_id=document_version_id,
                assertion_id=current_assertion_id,
                predicate=relationship.relationship_type.value,
                target_type=relationship.target_type.value,
                confidence=relationship.confidence,
                evidence=relationship.evidence,
                ontology_version=ONTOLOGY_VERSION,
                chunk_ids=supporting_chunks,
            )
            assertions_written += 1
        return len(extraction.entities), assertions_written

    async def activate_document_version(self, document_id: str, document_version_id: str) -> None:
        records, _, _ = await self.driver.execute_query(
            """
            MATCH (d:Document {document_id: $document_id})
            MATCH (d)-[:HAS_VERSION]->(selected:DocumentVersion {
                document_version_id: $document_version_id
            })
            OPTIONAL MATCH (d)-[:HAS_VERSION]->(other:DocumentVersion)
            WHERE other <> selected
            SET other.active = false,
                other.status = CASE
                    WHEN other.status = 'FAILED' THEN other.status ELSE 'SUPERSEDED'
                END,
                other.updated_at = datetime()
            WITH d, selected
            OPTIONAL MATCH (d)-[:HAS_VERSION]->(:DocumentVersion)-[:HAS_CHUNK]->(old_chunk:Chunk)
            SET old_chunk.active = false
            WITH d, selected
            OPTIONAL MATCH (d)-[:HAS_VERSION]->(:DocumentVersion)-[:HAS_ASSERTION]->
                           (old_assertion:Assertion)
            SET old_assertion.active = false,
                old_assertion.status = CASE
                    WHEN old_assertion.status = 'REJECTED'
                    THEN old_assertion.status ELSE 'SUPERSEDED'
                END
            WITH d, selected
            SET d.current_version_id = selected.document_version_id,
                d.updated_at = datetime(),
                selected.active = true,
                selected.status = 'ACTIVE',
                selected.activated_at = datetime(),
                selected.updated_at = datetime()
            WITH selected
            OPTIONAL MATCH (selected)-[:HAS_CHUNK]->(chunk:Chunk)
            SET chunk.active = true, chunk.vector_status = 'INDEXED', chunk.updated_at = datetime()
            WITH selected
            OPTIONAL MATCH (selected)-[:HAS_ASSERTION]->(assertion:Assertion)
            SET assertion.active = true, assertion.status = 'APPROVED',
                assertion.updated_at = datetime()
            RETURN selected.document_version_id AS document_version_id
            """,
            document_id=document_id,
            document_version_id=document_version_id,
        )
        if not records:
            raise ValueError(f"Cannot activate missing version {document_version_id}")
        await self.refresh_materialized_relationships()

    async def rollback_document_version(
        self,
        document_id: str,
        failed_version_id: str,
        previous_version_id: str | None,
        error: str,
    ) -> None:
        await self.mark_version_failed(failed_version_id, error)
        if previous_version_id:
            await self.activate_document_version(document_id, previous_version_id)
        else:
            await self.driver.execute_query(
                """
                MATCH (d:Document {document_id: $document_id})
                REMOVE d.current_version_id
                """,
                document_id=document_id,
            )
            await self.refresh_materialized_relationships()

    async def refresh_materialized_relationships(self) -> None:
        await self.driver.execute_query(
            """
            MATCH (:Process)-[r:OPERATES_IN|OWNED_BY|GOVERNED_BY|USES_SYSTEM]->()
            WHERE r.materialized = true
            DELETE r
            """
        )
        for predicate, (target_type, target_key) in MATERIALIZED_RELATIONSHIPS.items():
            target_label = target_type.value
            await self.driver.execute_query(
                f"""
                MATCH (a:Assertion {{active: true, status: 'APPROVED',
                                    predicate: $predicate}})-[:SUBJECT]->(p:Process)
                MATCH (a)-[:OBJECT]->(t:{target_label})
                WITH p, t, count(a) AS assertion_count, max(a.confidence) AS confidence
                MERGE (p)-[r:{predicate.value}]->(t)
                SET r.materialized = true,
                    r.assertion_count = assertion_count,
                    r.confidence = confidence,
                    r.updated_at = datetime(),
                    r.ontology_version = $ontology_version,
                    r.target_key = t.{target_key}
                """,
                predicate=predicate.value,
                ontology_version=ONTOLOGY_VERSION,
            )

    async def retrieval_scope(
        self, process_id: str, allowed_classifications: list[str]
    ) -> list[str]:
        records = await self.query(
            """
            MATCH (:Process {process_id: $process_id})-[:HAS_DOCUMENT]->(:Document)
                  -[:HAS_VERSION]->(v:DocumentVersion {active: true})
            WHERE v.classification IN $allowed_classifications
            RETURN v.document_version_id AS document_version_id
            ORDER BY document_version_id
            """,
            {
                "process_id": process_id,
                "allowed_classifications": allowed_classifications,
            },
        )
        return [row["document_version_id"] for row in records]

    async def chunk_lineage(
        self, chunk_id: str, allowed_classifications: list[str]
    ) -> dict[str, Any] | None:
        rows = await self.query(
            """
            MATCH (p:Process)-[:HAS_DOCUMENT]->(d:Document)-[:HAS_VERSION]->
                  (v:DocumentVersion)-[:HAS_CHUNK]->(c:Chunk {chunk_id: $chunk_id})
            WHERE v.classification IN $allowed_classifications
            OPTIONAL MATCH (c)-[:SUPPORTS]->(a:Assertion)-[:OBJECT]->(target)
            RETURN p.process_id AS process_id, p.name AS process_name,
                   d.document_id AS document_id, d.title AS document_title,
                   v.document_version_id AS document_version_id, v.version AS version,
                   v.classification AS classification, v.active AS version_active,
                   c.chunk_id AS chunk_id, c.ordinal AS ordinal,
                   c.chunk_kind AS chunk_kind, c.section AS section,
                   c.page_start AS page_start, c.page_end AS page_end,
                   collect(CASE WHEN a IS NULL THEN null ELSE {
                       assertion_id: a.assertion_id,
                       predicate: a.predicate,
                       target_type: a.target_type,
                       target_name: target.name,
                       confidence: a.confidence,
                       active: a.active
                   } END) AS assertions
            """,
            {
                "chunk_id": chunk_id,
                "allowed_classifications": allowed_classifications,
            },
        )
        return rows[0] if rows else None

    async def active_chunk_ids(self, process_id: str) -> list[str]:
        rows = await self.query(
            """
            MATCH (:Process {process_id: $process_id})-[:HAS_DOCUMENT]->(:Document)
                  -[:HAS_VERSION]->(:DocumentVersion {active: true})-[:HAS_CHUNK]->
                  (c:Chunk {active: true})
            RETURN c.chunk_id AS chunk_id
            ORDER BY chunk_id
            """,
            {"process_id": process_id},
        )
        return [row["chunk_id"] for row in rows]

    async def upsert_bpmn(
        self,
        document: ParsedDocument,
        document_id: str,
        document_version_id: str,
        raw_content: bytes,
    ) -> tuple[int, int]:
        structure = parse_bpmn_structure(raw_content)
        bpmn_id = f"bpmn:{document_version_id}"
        process_id = document.metadata.process.process_id
        await self.driver.execute_query(
            """
            MATCH (p:Process {process_id: $process_id})
            MATCH (v:DocumentVersion {document_version_id: $document_version_id})
            MERGE (b:BPMNModel {bpmn_id: $bpmn_id})
            ON CREATE SET b.created_at = datetime()
            SET b.name = $name, b.bpmn_process_id = $bpmn_process_id,
                b.source_document_id = $document_id,
                b.source_document_version_id = $document_version_id,
                b.checksum = $checksum, b.updated_at = datetime()
            MERGE (p)-[:MODELED_BY]->(b)
            MERGE (v)-[:REPRESENTED_BY]->(b)
            """,
            process_id=process_id,
            document_version_id=document_version_id,
            bpmn_id=bpmn_id,
            name=structure["name"] or document.metadata.title,
            bpmn_process_id=structure["bpmn_process_id"],
            document_id=document_id,
            checksum=document.checksum,
        )
        for activity in structure["activities"]:
            activity_id = f"{bpmn_id}:{activity['activity_id']}"
            await self.driver.execute_query(
                """
                MATCH (b:BPMNModel {bpmn_id: $bpmn_id})
                MERGE (a:Activity {activity_id: $activity_id})
                SET a.bpmn_element_id = $element_id, a.name = $name,
                    a.activity_type = $activity_type, a.updated_at = datetime()
                MERGE (b)-[:DEFINES_ACTIVITY]->(a)
                """,
                bpmn_id=bpmn_id,
                activity_id=activity_id,
                element_id=activity["activity_id"],
                name=activity["name"],
                activity_type=activity["activity_type"],
            )
        for flow in structure["flows"]:
            await self.driver.execute_query(
                """
                MATCH (a:Activity {activity_id: $source_id})
                MATCH (b:Activity {activity_id: $target_id})
                MERGE (a)-[r:NEXT_ACTIVITY {bpmn_id: $bpmn_id, flow_id: $flow_id}]->(b)
                SET r.name = $name
                """,
                source_id=f"{bpmn_id}:{flow['source_id']}",
                target_id=f"{bpmn_id}:{flow['target_id']}",
                bpmn_id=bpmn_id,
                flow_id=flow["flow_id"],
                name=flow["name"],
            )
        return len(structure["activities"]), len(structure["flows"])

    async def upsert_journeys(self, batch: JourneyBatch) -> dict[str, int]:
        process = batch.process
        await self.driver.execute_query(
            """
            MERGE (p:Process {process_id: $process_id})
            ON CREATE SET p.created_at = datetime()
            SET p.name = $name, p.description = $description, p.updated_at = datetime(),
                p.ontology_version = $ontology_version
            """,
            process_id=process.process_id,
            name=process.name,
            description=process.description,
            ontology_version=ONTOLOGY_VERSION,
        )
        variants: set[str] = set()
        event_count = 0
        for journey in batch.journeys:
            variants.add(journey.variant_id)
            duration_seconds = (
                (journey.ended_at - journey.started_at).total_seconds()
                if journey.ended_at
                else None
            )
            activity_ids = [event.activity_id for event in journey.events]
            await self.driver.execute_query(
                """
                MATCH (p:Process {process_id: $process_id})
                MERGE (v:Variant {variant_id: $variant_id})
                SET v.process_id = $process_id, v.activity_ids = $activity_ids,
                    v.updated_at = datetime()
                MERGE (j:Journey {journey_id: $journey_id})
                SET j.started_at = datetime($started_at),
                    j.ended_at = CASE WHEN $ended_at IS NULL THEN null ELSE datetime($ended_at) END,
                    j.duration_seconds = $duration_seconds, j.outcome = $outcome,
                    j.attributes_json = $attributes_json, j.events_json = $events_json,
                    j.updated_at = datetime()
                MERGE (p)-[:HAS_VARIANT]->(v)
                MERGE (p)-[:HAS_JOURNEY]->(j)
                MERGE (j)-[:FOLLOWS_VARIANT]->(v)
                """,
                process_id=process.process_id,
                variant_id=f"{process.process_id}:{journey.variant_id}",
                journey_id=f"{process.process_id}:{journey.journey_id}",
                activity_ids=activity_ids,
                started_at=journey.started_at.isoformat(),
                ended_at=journey.ended_at.isoformat() if journey.ended_at else None,
                duration_seconds=duration_seconds,
                outcome=journey.outcome,
                attributes_json=json.dumps(journey.attributes),
                events_json=json.dumps([event.model_dump(mode="json") for event in journey.events]),
            )
            event_count += len(journey.events)
        return {"journeys": len(batch.journeys), "variants": len(variants), "events": event_count}

    async def query(self, cypher: str, parameters: dict[str, Any]) -> list[dict[str, Any]]:
        records, _, _ = await self.driver.execute_query(
            cypher, parameters_=parameters, routing_="r"
        )
        return [record.data() for record in records]

    async def subgraph(
        self, process_id: str, allowed_classifications: list[str]
    ) -> list[dict[str, Any]]:
        return await self.query(
            """
            MATCH (p:Process {process_id: $process_id})-[:HAS_DOCUMENT]->(d:Document)
                  -[:HAS_VERSION]->(v:DocumentVersion {active: true})
            WHERE v.classification IN $allowed_classifications
            OPTIONAL MATCH (v)-[:HAS_CHUNK]->(c:Chunk {active: true})
            OPTIONAL MATCH (c)-[:SUPPORTS]->(a:Assertion {active: true})-[:OBJECT]->(target)
            RETURN p.process_id AS process_id, p.name AS process_name,
                   d.document_id AS document_id, d.title AS document_title,
                   v.document_version_id AS document_version_id, v.version AS version,
                   c.chunk_id AS chunk_id, c.ordinal AS chunk_ordinal,
                   a.assertion_id AS assertion_id, a.predicate AS predicate,
                   labels(target)[0] AS target_type, target.name AS target_name
            ORDER BY document_id, chunk_ordinal, predicate, target_name
            LIMIT 1000
            """,
            {
                "process_id": process_id,
                "allowed_classifications": allowed_classifications,
            },
        )
