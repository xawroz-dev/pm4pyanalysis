from typing import Any

from qdrant_client import AsyncQdrantClient, models

from app.domain.models import TextChunk

CLASSIFICATION_ACCESS = {
    "public": ["public"],
    "internal": ["public", "internal"],
    "confidential": ["public", "internal", "confidential"],
    "restricted": ["public", "internal", "confidential", "restricted"],
}


class QdrantRepository:
    def __init__(self, url: str, collection: str, dimensions: int):
        self.client = AsyncQdrantClient(url=url)
        self.collection = collection
        self.dimensions = dimensions

    async def close(self) -> None:
        await self.client.close()

    async def ping(self) -> bool:
        await self.client.get_collections()
        return True

    async def initialize(self) -> None:
        collections = await self.client.get_collections()
        if self.collection not in {item.name for item in collections.collections}:
            await self.client.create_collection(
                collection_name=self.collection,
                vectors_config=models.VectorParams(
                    size=self.dimensions, distance=models.Distance.COSINE
                ),
            )
        indexes = {
            "process_id": models.PayloadSchemaType.KEYWORD,
            "classification": models.PayloadSchemaType.KEYWORD,
            "document_version_id": models.PayloadSchemaType.KEYWORD,
            "active": models.PayloadSchemaType.BOOL,
        }
        for field_name, field_schema in indexes.items():
            await self.client.create_payload_index(
                collection_name=self.collection,
                field_name=field_name,
                field_schema=field_schema,
                wait=True,
            )

    async def upsert(self, chunks: list[TextChunk], vectors: list[list[float]]) -> None:
        points = [
            models.PointStruct(
                id=chunk.chunk_id,
                vector=vector,
                payload=chunk.model_dump(mode="json"),
            )
            for chunk, vector in zip(chunks, vectors, strict=True)
        ]
        if points:
            await self.client.upsert(collection_name=self.collection, points=points, wait=True)

    async def set_document_active(self, document_id: str, active: bool) -> None:
        await self.client.set_payload(
            collection_name=self.collection,
            payload={"active": active},
            points=models.Filter(
                must=[
                    models.FieldCondition(
                        key="document_id",
                        match=models.MatchValue(value=document_id),
                    )
                ]
            ),
            wait=True,
        )

    async def set_version_active(self, document_version_id: str, active: bool) -> None:
        await self.client.set_payload(
            collection_name=self.collection,
            payload={"active": active},
            points=models.Filter(
                must=[
                    models.FieldCondition(
                        key="document_version_id",
                        match=models.MatchValue(value=document_version_id),
                    )
                ]
            ),
            wait=True,
        )

    async def delete_version(self, document_version_id: str) -> None:
        await self.client.delete(
            collection_name=self.collection,
            points_selector=models.Filter(
                must=[
                    models.FieldCondition(
                        key="document_version_id",
                        match=models.MatchValue(value=document_version_id),
                    )
                ]
            ),
            wait=True,
        )

    async def search(
        self,
        vector: list[float],
        top_k: int,
        process_id: str | None,
        clearance: str,
        document_version_ids: list[str] | None = None,
    ) -> list[dict[str, Any]]:
        conditions: list[models.FieldCondition] = [
            models.FieldCondition(
                key="classification",
                match=models.MatchAny(any=CLASSIFICATION_ACCESS[clearance]),
            ),
            models.FieldCondition(key="active", match=models.MatchValue(value=True)),
        ]
        if process_id:
            conditions.append(
                models.FieldCondition(key="process_id", match=models.MatchValue(value=process_id))
            )
        if document_version_ids is not None:
            if not document_version_ids:
                return []
            conditions.append(
                models.FieldCondition(
                    key="document_version_id",
                    match=models.MatchAny(any=document_version_ids),
                )
            )
        result = await self.client.query_points(
            collection_name=self.collection,
            query=vector,
            query_filter=models.Filter(must=conditions),
            limit=top_k,
            with_payload=True,
        )
        return [{"score": point.score, **(point.payload or {})} for point in result.points]

    async def active_chunk_ids(self, process_id: str) -> list[str]:
        point_ids: list[str] = []
        offset = None
        query_filter = models.Filter(
            must=[
                models.FieldCondition(key="process_id", match=models.MatchValue(value=process_id)),
                models.FieldCondition(key="active", match=models.MatchValue(value=True)),
            ]
        )
        while True:
            points, offset = await self.client.scroll(
                collection_name=self.collection,
                scroll_filter=query_filter,
                limit=256,
                offset=offset,
                with_payload=False,
                with_vectors=False,
            )
            point_ids.extend(str(point.id) for point in points)
            if offset is None:
                break
        return sorted(point_ids)

    async def get_chunk(self, chunk_id: str) -> dict[str, Any] | None:
        points = await self.client.retrieve(
            collection_name=self.collection,
            ids=[chunk_id],
            with_payload=True,
            with_vectors=False,
        )
        if not points:
            return None
        return dict(points[0].payload or {})
