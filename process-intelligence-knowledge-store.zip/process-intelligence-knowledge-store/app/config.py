from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    app_env: str = "development"
    neo4j_uri: str = "bolt://localhost:7687"
    neo4j_user: str = "neo4j"
    neo4j_password: str = "change-me-enterprise"
    qdrant_url: str = "http://localhost:6333"
    qdrant_collection: str = "process_intelligence_chunks"

    embedding_provider: str = "hash"
    embedding_dimensions: int = 384
    embedding_model: str = "text-embedding-3-small"

    llm_provider: str = "metadata"
    llm_base_url: str = "https://api.openai.com/v1"
    llm_api_key: str = ""
    llm_model: str = "gpt-4.1-mini"

    max_upload_mb: int = 25
    chunk_size: int = 1200
    chunk_overlap: int = 180
    min_extraction_confidence: float = 0.72


@lru_cache
def get_settings() -> Settings:
    return Settings()
