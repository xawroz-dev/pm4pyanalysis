"""Process intelligence knowledge store."""
