// 1. Governed process neighborhood. Paste into Neo4j Browser.
MATCH path=(p:Process {process_id: "P2P-001"})-[r]->(n)
RETURN path;

// 2. BPMN process flow.
MATCH (p:Process {process_id: "P2P-001"})-[:MODELED_BY]->(b:BPMNModel)
MATCH path=(b)-[:DEFINES_ACTIVITY]->(a:Activity)-[:NEXT_ACTIVITY*0..12]->(next:Activity)
RETURN path
LIMIT 100;

// 3. Documents and the semantic relationships they evidence.
MATCH (p:Process {process_id: "P2P-001"})-[r]->(entity)
WHERE r.evidence_document_ids IS NOT NULL
UNWIND r.evidence_document_ids AS document_id
MATCH (p)-[:HAS_DOCUMENT]->(d:Document {document_id: document_id})
RETURN p, r, entity, d;

// 4. Variant frequency and average duration.
MATCH (p:Process {process_id: "P2P-001"})-[:HAS_VARIANT]->(v:Variant)
OPTIONAL MATCH (j:Journey)-[:FOLLOWS_VARIANT]->(v)
RETURN v.variant_id AS variant,
       count(j) AS journeys,
       round(avg(j.duration_seconds), 1) AS avg_duration_seconds
ORDER BY journeys DESC, avg_duration_seconds DESC;

// 5. Governance coverage: find processes missing a governed relationship.
MATCH (p:Process)
RETURN p.process_id AS process_id,
       p.name AS process,
       EXISTS { MATCH (p)-[:GOVERNED_BY]->(:Control) } AS has_controls,
       EXISTS { MATCH (p)-[:USES_SYSTEM]->(:System) } AS has_systems,
       EXISTS { MATCH (p)-[:OWNED_BY]->(:BusinessUnit) } AS has_owner_unit,
       EXISTS { MATCH (p)-[:OPERATES_IN]->(:Market) } AS has_market
ORDER BY process;

// 6. Relationship cardinality check: semantic edges are one per process/entity pair.
MATCH (p:Process)-[r]->(n)
RETURN type(r) AS relationship_type,
       labels(n)[0] AS target_type,
       count(r) AS relationship_count,
       count(DISTINCT n) AS distinct_targets
ORDER BY relationship_count DESC;

