from typing import Any

from qdrant_client import AsyncQdrantClient, models

from app.domain.models import TextChunk

CLASSIFICATION_ACCESS = {
    "public": ["public"],
    "internal": ["public", "internal"],
    "confidential": ["public", "internal", "confidential"],
    "restricted": ["public", "internal", "confidential", "restricted"],
}


class QdrantRepository:
    def __init__(self, url: str, collection: str, dimensions: int):
        self.client = AsyncQdrantClient(url=url)
        self.collection = collection
        self.dimensions = dimensions

    async def close(self) -> None:
        await self.client.close()

    async def ping(self) -> bool:
        await self.client.get_collections()
        return True

    async def initialize(self) -> None:
        collections = await self.client.get_collections()
        if self.collection not in {item.name for item in collections.collections}:
            await self.client.create_collection(
                collection_name=self.collection,
                vectors_config=models.VectorParams(
                    size=self.dimensions, distance=models.Distance.COSINE
                ),
            )
            await self.client.create_payload_index(
                collection_name=self.collection,
                field_name="process_id",
                field_schema=models.PayloadSchemaType.KEYWORD,
            )
            await self.client.create_payload_index(
                collection_name=self.collection,
                field_name="classification",
                field_schema=models.PayloadSchemaType.KEYWORD,
            )

    async def upsert(self, chunks: list[TextChunk], vectors: list[list[float]]) -> None:
        points = [
            models.PointStruct(
                id=chunk.chunk_id,
                vector=vector,
                payload=chunk.model_dump(mode="json"),
            )
            for chunk, vector in zip(chunks, vectors, strict=True)
        ]
        if points:
            await self.client.upsert(collection_name=self.collection, points=points, wait=True)

    async def delete_document(self, document_id: str) -> None:
        await self.client.delete(
            collection_name=self.collection,
            points_selector=models.FilterSelector(
                filter=models.Filter(
                    must=[
                        models.FieldCondition(
                            key="document_id",
                            match=models.MatchValue(value=document_id),
                        )
                    ]
                )
            ),
            wait=True,
        )

    async def search(
        self,
        vector: list[float],
        top_k: int,
        process_id: str | None,
        clearance: str,
    ) -> list[dict[str, Any]]:
        conditions: list[models.FieldCondition] = [
            models.FieldCondition(
                key="classification",
                match=models.MatchAny(any=CLASSIFICATION_ACCESS[clearance]),
            )
        ]
        if process_id:
            conditions.append(
                models.FieldCondition(key="process_id", match=models.MatchValue(value=process_id))
            )
        result = await self.client.query_points(
            collection_name=self.collection,
            query=vector,
            query_filter=models.Filter(must=conditions),
            limit=top_k,
            with_payload=True,
        )
        return [{"score": point.score, **(point.payload or {})} for point in result.points]
