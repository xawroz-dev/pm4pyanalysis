import json
import re
import uuid
from typing import Any

from neo4j import AsyncDriver, AsyncGraphDatabase

from app.domain.models import (
    ExtractionResult,
    JourneyBatch,
    ParsedDocument,
)
from app.domain.ontology import ID_KEYS, NodeType
from app.services.parsing import parse_bpmn_structure

ENTITY_NAMESPACE = uuid.UUID("3bf6d5a5-e4e0-4e86-83bb-a992619ddf57")


def canonical_id(node_type: NodeType, name: str) -> str:
    normalized = re.sub(r"[^a-z0-9]+", "-", name.casefold()).strip("-")
    suffix = str(uuid.uuid5(ENTITY_NAMESPACE, f"{node_type.value}:{name.casefold()}"))[:8]
    return f"{node_type.value.casefold()}:{normalized[:60]}:{suffix}"


class Neo4jRepository:
    def __init__(self, uri: str, user: str, password: str):
        self.driver: AsyncDriver = AsyncGraphDatabase.driver(uri, auth=(user, password))

    async def close(self) -> None:
        await self.driver.close()

    async def ping(self) -> bool:
        await self.driver.verify_connectivity()
        return True

    async def initialize(self) -> None:
        constraints = [
            ("Process", "process_id"),
            ("Document", "document_id"),
            ("BPMNModel", "bpmn_id"),
            ("Activity", "activity_id"),
            ("Journey", "journey_id"),
            ("Variant", "variant_id"),
            ("Market", "market_id"),
            ("BusinessUnit", "business_unit_id"),
            ("Control", "control_id"),
            ("System", "system_id"),
        ]
        async with self.driver.session() as session:
            for label, key in constraints:
                await session.run(
                    f"CREATE CONSTRAINT {label.lower()}_{key} IF NOT EXISTS "
                    f"FOR (n:{label}) REQUIRE n.{key} IS UNIQUE"
                )
            await session.run("CREATE INDEX process_name IF NOT EXISTS FOR (n:Process) ON (n.name)")
            await session.run(
                "CREATE INDEX document_checksum IF NOT EXISTS FOR (n:Document) ON (n.checksum)"
            )

    async def get_document_checksum(self, document_id: str) -> str | None:
        records, _, _ = await self.driver.execute_query(
            "MATCH (d:Document {document_id: $document_id}) RETURN d.checksum AS checksum",
            document_id=document_id,
            routing_="r",
        )
        return records[0]["checksum"] if records else None

    async def upsert_document(self, document: ParsedDocument, document_id: str) -> None:
        metadata = document.metadata
        await self.driver.execute_query(
            """
            MERGE (p:Process {process_id: $process_id})
            ON CREATE SET p.created_at = datetime()
            SET p.name = $process_name, p.description = $description, p.owner = $owner,
                p.status = $status, p.criticality = $criticality, p.tags = $tags,
                p.ontology_version = '1.0', p.updated_at = datetime()
            MERGE (d:Document {document_id: $document_id})
            ON CREATE SET d.created_at = datetime()
            SET d.title = $title, d.document_type = $document_type, d.version = $version,
                d.effective_date = $effective_date, d.source_uri = $source_uri,
                d.classification = $classification, d.checksum = $checksum,
                d.media_type = $media_type, d.original_filename = $original_filename,
                d.updated_at = datetime()
            MERGE (p)-[r:HAS_DOCUMENT]->(d)
            ON CREATE SET r.first_seen_at = datetime()
            SET r.last_seen_at = datetime()
            """,
            process_id=metadata.process.process_id,
            process_name=metadata.process.name,
            description=metadata.process.description,
            owner=metadata.process.owner,
            status=metadata.process.status,
            criticality=metadata.process.criticality,
            tags=metadata.process.tags,
            document_id=document_id,
            title=metadata.title,
            document_type=metadata.document_type,
            version=metadata.version,
            effective_date=(
                metadata.effective_date.isoformat() if metadata.effective_date else None
            ),
            source_uri=metadata.source_uri,
            classification=metadata.classification,
            checksum=document.checksum,
            media_type=document.media_type,
            original_filename=document.original_filename,
        )

    async def remove_document_evidence(self, document_id: str) -> None:
        await self.driver.execute_query(
            """
            MATCH ()-[r]->()
            WHERE r.evidence_document_ids IS NOT NULL
              AND $document_id IN r.evidence_document_ids
            WITH r, [id IN r.evidence_document_ids WHERE id <> $document_id] AS remaining
            SET r.evidence_document_ids = remaining
            WITH r, remaining
            WHERE size(remaining) = 0
            DELETE r
            """,
            document_id=document_id,
        )

    async def upsert_extraction(
        self, process_id: str, document_id: str, extraction: ExtractionResult
    ) -> tuple[int, int]:
        entity_lookup: dict[tuple[NodeType, str], str] = {}
        for entity in extraction.entities:
            node_id = entity.external_id or canonical_id(entity.entity_type, entity.canonical_name)
            entity_lookup[(entity.entity_type, entity.canonical_name.casefold())] = node_id
            if entity.external_id:
                entity_lookup[(entity.entity_type, entity.external_id.casefold())] = node_id
            label = entity.entity_type.value
            id_key = ID_KEYS[entity.entity_type]
            await self.driver.execute_query(
                f"""
                MERGE (n:{label} {{{id_key}: $node_id}})
                ON CREATE SET n.created_at = datetime()
                SET n.name = $name, n.description = coalesce($description, n.description),
                    n.aliases = $aliases, n.updated_at = datetime(), n.ontology_version = '1.0'
                """,
                node_id=node_id,
                name=entity.canonical_name,
                description=entity.description,
                aliases=entity.aliases,
            )

        relationships_written = 0
        for relationship in extraction.relationships:
            target_id = entity_lookup.get(
                (relationship.target_type, relationship.target_ref.casefold())
            )
            if not target_id:
                continue
            relationship.validate_ontology()
            target_label = relationship.target_type.value
            target_key = ID_KEYS[relationship.target_type]
            rel_type = relationship.relationship_type.value
            await self.driver.execute_query(
                f"""
                MATCH (p:Process {{process_id: $process_id}})
                MATCH (t:{target_label} {{{target_key}: $target_id}})
                MERGE (p)-[r:{rel_type}]->(t)
                ON CREATE SET r.first_seen_at = datetime(), r.evidence_document_ids = []
                SET r.last_seen_at = datetime(),
                    r.confidence = CASE WHEN r.confidence IS NULL OR $confidence > r.confidence
                                        THEN $confidence ELSE r.confidence END,
                    r.evidence_document_ids =
                      CASE WHEN $document_id IN r.evidence_document_ids
                           THEN r.evidence_document_ids
                           ELSE r.evidence_document_ids + $document_id END,
                    r.latest_evidence = $evidence
                """,
                process_id=process_id,
                target_id=target_id,
                confidence=relationship.confidence,
                document_id=document_id,
                evidence=relationship.evidence,
            )
            relationships_written += 1
        return len(extraction.entities), relationships_written

    async def upsert_bpmn(
        self, document: ParsedDocument, document_id: str, raw_content: bytes
    ) -> tuple[int, int]:
        structure = parse_bpmn_structure(raw_content)
        bpmn_id = f"bpmn:{document_id}"
        process_id = document.metadata.process.process_id
        await self.driver.execute_query(
            """
            MATCH (p:Process {process_id: $process_id})
            MERGE (b:BPMNModel {bpmn_id: $bpmn_id})
            ON CREATE SET b.created_at = datetime()
            SET b.name = $name, b.bpmn_process_id = $bpmn_process_id,
                b.source_document_id = $document_id, b.checksum = $checksum,
                b.updated_at = datetime()
            MERGE (p)-[:MODELED_BY]->(b)
            """,
            process_id=process_id,
            bpmn_id=bpmn_id,
            name=structure["name"] or document.metadata.title,
            bpmn_process_id=structure["bpmn_process_id"],
            document_id=document_id,
            checksum=document.checksum,
        )
        for activity in structure["activities"]:
            activity_id = f"{process_id}:{activity['activity_id']}"
            await self.driver.execute_query(
                """
                MATCH (b:BPMNModel {bpmn_id: $bpmn_id})
                MERGE (a:Activity {activity_id: $activity_id})
                SET a.bpmn_element_id = $element_id, a.name = $name,
                    a.activity_type = $activity_type, a.updated_at = datetime()
                MERGE (b)-[:DEFINES_ACTIVITY]->(a)
                """,
                bpmn_id=bpmn_id,
                activity_id=activity_id,
                element_id=activity["activity_id"],
                name=activity["name"],
                activity_type=activity["activity_type"],
            )
        for flow in structure["flows"]:
            await self.driver.execute_query(
                """
                MATCH (a:Activity {activity_id: $source_id})
                MATCH (b:Activity {activity_id: $target_id})
                MERGE (a)-[r:NEXT_ACTIVITY {bpmn_id: $bpmn_id, flow_id: $flow_id}]->(b)
                SET r.name = $name
                """,
                source_id=f"{process_id}:{flow['source_id']}",
                target_id=f"{process_id}:{flow['target_id']}",
                bpmn_id=bpmn_id,
                flow_id=flow["flow_id"],
                name=flow["name"],
            )
        return len(structure["activities"]), len(structure["flows"])

    async def upsert_journeys(self, batch: JourneyBatch) -> dict[str, int]:
        process = batch.process
        await self.driver.execute_query(
            """
            MERGE (p:Process {process_id: $process_id})
            ON CREATE SET p.created_at = datetime()
            SET p.name = $name, p.description = $description, p.updated_at = datetime()
            """,
            process_id=process.process_id,
            name=process.name,
            description=process.description,
        )
        variants: set[str] = set()
        event_count = 0
        for journey in batch.journeys:
            variants.add(journey.variant_id)
            duration_seconds = (
                (journey.ended_at - journey.started_at).total_seconds()
                if journey.ended_at
                else None
            )
            activity_ids = [event.activity_id for event in journey.events]
            await self.driver.execute_query(
                """
                MATCH (p:Process {process_id: $process_id})
                MERGE (v:Variant {variant_id: $variant_id})
                SET v.process_id = $process_id, v.activity_ids = $activity_ids,
                    v.updated_at = datetime()
                MERGE (j:Journey {journey_id: $journey_id})
                SET j.started_at = datetime($started_at),
                    j.ended_at = CASE WHEN $ended_at IS NULL THEN null ELSE datetime($ended_at) END,
                    j.duration_seconds = $duration_seconds, j.outcome = $outcome,
                    j.attributes_json = $attributes_json, j.events_json = $events_json,
                    j.updated_at = datetime()
                MERGE (p)-[:HAS_VARIANT]->(v)
                MERGE (p)-[:HAS_JOURNEY]->(j)
                MERGE (j)-[:FOLLOWS_VARIANT]->(v)
                """,
                process_id=process.process_id,
                variant_id=f"{process.process_id}:{journey.variant_id}",
                journey_id=f"{process.process_id}:{journey.journey_id}",
                activity_ids=activity_ids,
                started_at=journey.started_at.isoformat(),
                ended_at=journey.ended_at.isoformat() if journey.ended_at else None,
                duration_seconds=duration_seconds,
                outcome=journey.outcome,
                attributes_json=json.dumps(journey.attributes),
                events_json=json.dumps([event.model_dump(mode="json") for event in journey.events]),
            )
            event_count += len(journey.events)
        return {"journeys": len(batch.journeys), "variants": len(variants), "events": event_count}

    async def query(self, cypher: str, parameters: dict[str, Any]) -> list[dict[str, Any]]:
        records, _, _ = await self.driver.execute_query(
            cypher, parameters_=parameters, routing_="r"
        )
        return [record.data() for record in records]

    async def subgraph(
        self, process_id: str, allowed_classifications: list[str]
    ) -> list[dict[str, Any]]:
        return await self.query(
            """
            MATCH (p:Process {process_id: $process_id})-[r]->(n)
            WHERE (n:Document AND n.classification IN $allowed_classifications)
               OR n:Journey OR n:Variant
               OR (n:BPMNModel AND EXISTS {
                    MATCH (d:Document {document_id: n.source_document_id})
                    WHERE d.classification IN $allowed_classifications
               })
               OR (r.evidence_document_ids IS NOT NULL AND EXISTS {
                    MATCH (d:Document)
                    WHERE d.document_id IN r.evidence_document_ids
                      AND d.classification IN $allowed_classifications
               })
            RETURN labels(p)[0] AS source_type, p.process_id AS source_id, p.name AS source_name,
                   type(r) AS relationship, labels(n)[0] AS target_type,
                   coalesce(n.document_id, n.bpmn_id, n.journey_id, n.variant_id,
                            n.market_id, n.business_unit_id, n.control_id, n.system_id,
                            n.process_id) AS target_id,
                   coalesce(n.name, n.title, n.journey_id, n.variant_id) AS target_name
            ORDER BY relationship, target_name
            """,
            {
                "process_id": process_id,
                "allowed_classifications": allowed_classifications,
            },
        )
