import re
import uuid

from app.domain.models import ParsedDocument, TextChunk

CHUNK_NAMESPACE = uuid.UUID("16f7b5ea-8f24-4ec2-9f68-1f58868d555c")


def chunk_document(
    document: ParsedDocument, document_id: str, chunk_size: int, overlap: int
) -> list[TextChunk]:
    if overlap >= chunk_size:
        raise ValueError("chunk overlap must be smaller than chunk size")

    paragraphs = [p.strip() for p in re.split(r"\n\s*\n", document.text) if p.strip()]
    chunks: list[str] = []
    current = ""
    for paragraph in paragraphs:
        if len(current) + len(paragraph) + 2 <= chunk_size:
            current = f"{current}\n\n{paragraph}".strip()
            continue
        if current:
            chunks.append(current)
        carry = current[-overlap:] if current else ""
        if len(paragraph) > chunk_size:
            start = 0
            while start < len(paragraph):
                piece = f"{carry}\n{paragraph[start : start + chunk_size - len(carry)]}".strip()
                chunks.append(piece)
                carry = piece[-overlap:]
                start += max(1, chunk_size - overlap)
            current = ""
        else:
            current = f"{carry}\n{paragraph}".strip()
    if current:
        chunks.append(current)

    return [
        TextChunk(
            chunk_id=str(uuid.uuid5(CHUNK_NAMESPACE, f"{document_id}:{ordinal}:{text}")),
            document_id=document_id,
            process_id=document.metadata.process.process_id,
            ordinal=ordinal,
            text=text,
            title=document.metadata.title,
            document_type=document.metadata.document_type,
            classification=document.metadata.classification,
            metadata={
                "version": document.metadata.version,
                "effective_date": (
                    document.metadata.effective_date.isoformat()
                    if document.metadata.effective_date
                    else None
                ),
                "source_uri": document.metadata.source_uri,
            },
        )
        for ordinal, text in enumerate(chunks)
    ]
