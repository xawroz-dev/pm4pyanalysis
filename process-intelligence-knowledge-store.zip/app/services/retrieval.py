import re
from enum import StrEnum
from typing import Any

from app.domain.models import ChatRequest, Citation
from app.repositories.neo4j import Neo4jRepository
from app.repositories.vector import CLASSIFICATION_ACCESS, QdrantRepository
from app.services.llm import Embedder


class Intent(StrEnum):
    PROCESS_OVERVIEW = "process_overview"
    CONTROLS = "controls"
    SYSTEMS = "systems"
    OWNERSHIP = "ownership"
    MARKETS = "markets"
    DOCUMENTS = "documents"
    BPMN_FLOW = "bpmn_flow"
    VARIANTS = "variants"
    JOURNEYS = "journeys"
    GENERIC_EVIDENCE = "generic_evidence"


INTENT_PATTERNS: list[tuple[Intent, tuple[str, ...]]] = [
    (Intent.CONTROLS, ("control", "risk", "compliance", "policy requirement")),
    (Intent.SYSTEMS, ("system", "application", "platform", "technology")),
    (Intent.OWNERSHIP, ("owner", "business unit", "team", "responsible")),
    (Intent.MARKETS, ("market", "country", "region", "geography")),
    (Intent.DOCUMENTS, ("document", "sop", "policy", "source", "evidence")),
    (Intent.BPMN_FLOW, ("bpmn", "flow", "activity", "step", "diagram", "sequence")),
    (Intent.VARIANTS, ("variant", "path", "most common", "longest")),
    (Intent.JOURNEYS, ("journey", "case", "instance", "execution")),
    (Intent.PROCESS_OVERVIEW, ("overview", "about", "describe", "summary")),
]


GRAPH_QUERIES: dict[Intent, str] = {
    Intent.PROCESS_OVERVIEW: """
        MATCH (p:Process {process_id: $process_id})
        OPTIONAL MATCH (p)-[r]->(n)
        WHERE n IS NULL
           OR (n:Document AND n.classification IN $allowed_classifications)
           OR n:Journey OR n:Variant
           OR (n:BPMNModel AND EXISTS {
                MATCH (d:Document {document_id: n.source_document_id})
                WHERE d.classification IN $allowed_classifications
           })
           OR (r.evidence_document_ids IS NOT NULL AND EXISTS {
                MATCH (d:Document)
                WHERE d.document_id IN r.evidence_document_ids
                  AND d.classification IN $allowed_classifications
           })
        RETURN p.process_id AS process_id, p.name AS process_name,
               p.description AS description, p.owner AS owner, p.status AS status,
               type(r) AS relationship, labels(n)[0] AS related_type,
               coalesce(n.name, n.title, n.journey_id, n.variant_id) AS related_name
        LIMIT 100
    """,
    Intent.CONTROLS: """
        MATCH (p:Process {process_id: $process_id})-[r:GOVERNED_BY]->(c:Control)
        UNWIND r.evidence_document_ids AS evidence_document_id
        MATCH (d:Document {document_id: evidence_document_id})
        WHERE d.classification IN $allowed_classifications
        RETURN c.control_id AS id, c.name AS name, c.description AS description,
               r.confidence AS confidence,
               collect(DISTINCT d.document_id) AS evidence_document_ids
        ORDER BY c.name
    """,
    Intent.SYSTEMS: """
        MATCH (p:Process {process_id: $process_id})-[r:USES_SYSTEM]->(s:System)
        UNWIND r.evidence_document_ids AS evidence_document_id
        MATCH (d:Document {document_id: evidence_document_id})
        WHERE d.classification IN $allowed_classifications
        RETURN s.system_id AS id, s.name AS name, s.description AS description,
               r.confidence AS confidence,
               collect(DISTINCT d.document_id) AS evidence_document_ids
        ORDER BY s.name
    """,
    Intent.OWNERSHIP: """
        MATCH (p:Process {process_id: $process_id})-[r:OWNED_BY]->(b:BusinessUnit)
        UNWIND r.evidence_document_ids AS evidence_document_id
        MATCH (d:Document {document_id: evidence_document_id})
        WHERE d.classification IN $allowed_classifications
        RETURN b.business_unit_id AS id, b.name AS name, b.description AS description,
               r.confidence AS confidence,
               collect(DISTINCT d.document_id) AS evidence_document_ids
        ORDER BY b.name
    """,
    Intent.MARKETS: """
        MATCH (p:Process {process_id: $process_id})-[r:OPERATES_IN]->(m:Market)
        UNWIND r.evidence_document_ids AS evidence_document_id
        MATCH (d:Document {document_id: evidence_document_id})
        WHERE d.classification IN $allowed_classifications
        RETURN m.market_id AS id, m.name AS name, m.description AS description,
               r.confidence AS confidence,
               collect(DISTINCT d.document_id) AS evidence_document_ids
        ORDER BY m.name
    """,
    Intent.DOCUMENTS: """
        MATCH (p:Process {process_id: $process_id})-[:HAS_DOCUMENT]->(d:Document)
        WHERE d.classification IN $allowed_classifications
        RETURN d.document_id AS id, d.title AS title, d.document_type AS document_type,
               d.version AS version, d.effective_date AS effective_date,
               d.classification AS classification, d.source_uri AS source_uri
        ORDER BY d.document_type, d.title
    """,
    Intent.BPMN_FLOW: """
        MATCH (p:Process {process_id: $process_id})-[:MODELED_BY]->(b:BPMNModel)
        MATCH (d:Document {document_id: b.source_document_id})
        WHERE d.classification IN $allowed_classifications
        MATCH (b)-[:DEFINES_ACTIVITY]->(a:Activity)
        OPTIONAL MATCH (a)-[r:NEXT_ACTIVITY]->(next:Activity)
        RETURN b.name AS model, a.activity_id AS activity_id, a.name AS activity,
               a.activity_type AS activity_type, next.name AS next_activity, r.name AS condition
        ORDER BY activity
    """,
    Intent.VARIANTS: """
        MATCH (p:Process {process_id: $process_id})-[:HAS_VARIANT]->(v:Variant)
        OPTIONAL MATCH (j:Journey)-[:FOLLOWS_VARIANT]->(v)
        RETURN v.variant_id AS variant_id, v.activity_ids AS activity_ids,
               count(j) AS journey_count, avg(j.duration_seconds) AS avg_duration_seconds
        ORDER BY journey_count DESC, avg_duration_seconds DESC LIMIT 20
    """,
    Intent.JOURNEYS: """
        MATCH (p:Process {process_id: $process_id})-[:HAS_JOURNEY]->(j:Journey)
        OPTIONAL MATCH (j)-[:FOLLOWS_VARIANT]->(v:Variant)
        RETURN j.journey_id AS journey_id, v.variant_id AS variant_id,
               j.started_at AS started_at, j.ended_at AS ended_at,
               j.duration_seconds AS duration_seconds, j.outcome AS outcome
        ORDER BY j.started_at DESC LIMIT 50
    """,
    Intent.GENERIC_EVIDENCE: """
        MATCH (p:Process {process_id: $process_id})-[r]->(n)
        WHERE (n:Document AND n.classification IN $allowed_classifications)
           OR n:Journey OR n:Variant
           OR (n:BPMNModel AND EXISTS {
                MATCH (d:Document {document_id: n.source_document_id})
                WHERE d.classification IN $allowed_classifications
           })
           OR (r.evidence_document_ids IS NOT NULL AND EXISTS {
                MATCH (d:Document)
                WHERE d.document_id IN r.evidence_document_ids
                  AND d.classification IN $allowed_classifications
           })
        RETURN type(r) AS relationship, labels(n)[0] AS entity_type,
               coalesce(n.name, n.title, n.journey_id, n.variant_id) AS name
        ORDER BY relationship, name LIMIT 100
    """,
}


class HybridRetriever:
    def __init__(self, graph: Neo4jRepository, vectors: QdrantRepository, embedder: Embedder):
        self.graph = graph
        self.vectors = vectors
        self.embedder = embedder

    async def retrieve(
        self, request: ChatRequest
    ) -> tuple[Intent, str | None, list[dict[str, Any]], list[Citation]]:
        intent = classify_intent(request.question)
        query_vector = (await self.embedder.embed([request.question]))[0]
        vector_hits = await self.vectors.search(
            query_vector,
            request.top_k,
            request.process_id,
            request.classification_clearance,
        )
        process_id = request.process_id or infer_process_id(vector_hits)
        graph_facts: list[dict[str, Any]] = []
        if process_id:
            graph_facts = await self.graph.query(
                GRAPH_QUERIES[intent],
                {
                    "process_id": process_id,
                    "allowed_classifications": CLASSIFICATION_ACCESS[
                        request.classification_clearance
                    ],
                },
            )
        citations = [
            Citation(
                document_id=hit["document_id"],
                chunk_id=hit["chunk_id"],
                title=hit["title"],
                excerpt=compact_excerpt(hit["text"]),
                score=float(hit["score"]),
            )
            for hit in vector_hits
        ]
        return intent, process_id, graph_facts, citations


def classify_intent(question: str) -> Intent:
    normalized = question.casefold()
    for intent, phrases in INTENT_PATTERNS:
        if any(phrase in normalized for phrase in phrases):
            return intent
    return Intent.GENERIC_EVIDENCE


def infer_process_id(hits: list[dict[str, Any]]) -> str | None:
    if not hits:
        return None
    scores: dict[str, float] = {}
    for hit in hits:
        scores[hit["process_id"]] = scores.get(hit["process_id"], 0.0) + float(hit["score"])
    return max(scores, key=scores.get)


def compact_excerpt(text: str, limit: int = 360) -> str:
    text = re.sub(r"\s+", " ", text).strip()
    return text if len(text) <= limit else text[: limit - 1] + "…"
