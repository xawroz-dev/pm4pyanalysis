import json

from app.config import Settings
from app.domain.models import ChatRequest, ChatResponse
from app.services.llm import LLMClient
from app.services.retrieval import HybridRetriever, Intent


class ChatService:
    def __init__(self, settings: Settings, retriever: HybridRetriever, llm: LLMClient):
        self.settings = settings
        self.retriever = retriever
        self.llm = llm

    async def answer(self, request: ChatRequest) -> ChatResponse:
        intent, process_id, graph_facts, citations = await self.retriever.retrieve(request)
        if self.settings.llm_provider == "openai" and self.settings.llm_api_key:
            answer = await self._llm_answer(request, intent, graph_facts, citations)
        else:
            answer = deterministic_answer(intent, graph_facts, citations)
        return ChatResponse(
            answer=answer,
            intent=intent.value,
            process_id=process_id,
            citations=citations,
            graph_facts=graph_facts,
            retrieval={
                "strategy": "vector_top_k_plus_fixed_intent_graph_query",
                "vector_hits": len(citations),
                "graph_rows": len(graph_facts),
                "llm_generated_cypher": False,
            },
        )

    async def _llm_answer(self, request, intent, graph_facts, citations) -> str:
        context = {
            "intent": intent.value,
            "graph_facts": graph_facts,
            "document_evidence": [
                {
                    "citation": f"[{item.document_id}#{item.chunk_id}]",
                    "title": item.title,
                    "excerpt": item.excerpt,
                }
                for item in citations
            ],
        }
        return await self.llm.text_completion(
            """Answer only from supplied graph facts and document evidence.
Prefer graph facts for exact relationships and document chunks for narrative detail.
Cite document claims inline as [document_id#chunk_id]. If evidence is insufficient, say so.
Never invent graph relationships or Cypher results.""",
            f"QUESTION:\n{request.question}\n\nCONTEXT:\n{json.dumps(context, default=str)}",
        )


def deterministic_answer(intent: Intent, facts: list[dict], citations: list) -> str:
    if facts:
        if intent in {Intent.CONTROLS, Intent.SYSTEMS, Intent.OWNERSHIP, Intent.MARKETS}:
            names = [str(row.get("name")) for row in facts if row.get("name")]
            return f"Graph result ({intent.value}): " + ", ".join(names) + "."
        if intent == Intent.DOCUMENTS:
            names = [str(row.get("title")) for row in facts if row.get("title")]
            return "Documents linked to this process: " + ", ".join(names) + "."
        if intent == Intent.BPMN_FLOW:
            flows = [
                f"{row.get('activity')} → {row.get('next_activity')}"
                for row in facts
                if row.get("next_activity")
            ]
            return "BPMN flow: " + "; ".join(flows[:20]) + "."
        return f"Found {len(facts)} governed graph facts for {intent.value}."
    if citations:
        refs = ", ".join(f"[{c.document_id}#{c.chunk_id}]" for c in citations[:3])
        return (
            f"No matching graph fact was found. Relevant document evidence is available in {refs}."
        )
    return (
        "I could not find governed graph facts or accessible document evidence for this question."
    )
