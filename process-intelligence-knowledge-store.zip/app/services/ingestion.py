import uuid
from pathlib import Path

from app.config import Settings
from app.domain.models import (
    DocumentMetadata,
    IngestionResult,
    JourneyBatch,
)
from app.repositories.neo4j import Neo4jRepository
from app.repositories.vector import QdrantRepository
from app.services.chunking import chunk_document
from app.services.extraction import EntityExtractor
from app.services.llm import Embedder
from app.services.parsing import parse_document


class IngestionService:
    def __init__(
        self,
        settings: Settings,
        graph: Neo4jRepository,
        vectors: QdrantRepository,
        extractor: EntityExtractor,
        embedder: Embedder,
    ):
        self.settings = settings
        self.graph = graph
        self.vectors = vectors
        self.extractor = extractor
        self.embedder = embedder

    async def ingest(
        self, content: bytes, filename: str, media_type: str, metadata: DocumentMetadata
    ) -> IngestionResult:
        if len(content) > self.settings.max_upload_mb * 1024 * 1024:
            raise ValueError(f"File exceeds {self.settings.max_upload_mb} MB upload limit")
        parsed = parse_document(content, filename, media_type, metadata)
        document_id = metadata.document_id or f"doc:{parsed.checksum[:24]}"
        existing_checksum = await self.graph.get_document_checksum(document_id)
        if existing_checksum == parsed.checksum:
            return IngestionResult(
                ingestion_id=str(uuid.uuid4()),
                status="skipped",
                process_id=metadata.process.process_id,
                document_id=document_id,
                checksum=parsed.checksum,
                chunks_indexed=0,
                entities_upserted=0,
                relationships_upserted=0,
                warnings=["Idempotent skip: document_id and checksum already exist."],
            )

        if existing_checksum:
            await self.graph.remove_document_evidence(document_id)
            await self.vectors.delete_document(document_id)
        await self.graph.upsert_document(parsed, document_id)
        extraction = await self.extractor.extract(parsed.text, metadata)
        entities, relationships = await self.graph.upsert_extraction(
            metadata.process.process_id, document_id, extraction
        )

        chunks = chunk_document(
            parsed, document_id, self.settings.chunk_size, self.settings.chunk_overlap
        )
        vectors = await self.embedder.embed([chunk.text for chunk in chunks])
        await self.vectors.upsert(chunks, vectors)

        warnings = list(extraction.warnings)
        if Path(filename).suffix.lower() in {".bpmn", ".xml"}:
            activities, flows = await self.graph.upsert_bpmn(parsed, document_id, content)
            warnings.append(f"BPMN structure loaded: {activities} activities, {flows} flows.")

        return IngestionResult(
            ingestion_id=str(uuid.uuid4()),
            status="updated" if existing_checksum else "created",
            process_id=metadata.process.process_id,
            document_id=document_id,
            checksum=parsed.checksum,
            chunks_indexed=len(chunks),
            entities_upserted=entities,
            relationships_upserted=relationships,
            warnings=warnings,
        )

    async def ingest_journeys(self, batch: JourneyBatch) -> dict[str, int | str]:
        counts = await self.graph.upsert_journeys(batch)
        return {"process_id": batch.process.process_id, **counts}
