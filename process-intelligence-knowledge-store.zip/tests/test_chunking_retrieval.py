from pathlib import Path

from app.domain.models import DocumentMetadata
from app.services.chunking import chunk_document
from app.services.llm import hash_embedding
from app.services.parsing import parse_document
from app.services.retrieval import Intent, classify_intent

ROOT = Path(__file__).resolve().parents[1]


def test_chunks_have_stable_ids_and_process_metadata():
    content = (ROOT / "sample_data/p2p_sop.txt").read_bytes()
    metadata = DocumentMetadata.model_validate_json(
        (ROOT / "sample_data/p2p_sop.metadata.json").read_text()
    )
    parsed = parse_document(content, "p2p_sop.txt", "text/plain", metadata)
    first = chunk_document(parsed, "DOC-1", chunk_size=240, overlap=30)
    second = chunk_document(parsed, "DOC-1", chunk_size=240, overlap=30)
    assert [item.chunk_id for item in first] == [item.chunk_id for item in second]
    assert {item.process_id for item in first} == {"P2P-001"}


def test_hash_embeddings_are_deterministic_and_normalized():
    first = hash_embedding("three way match control", 32)
    second = hash_embedding("three way match control", 32)
    assert first == second
    assert abs(sum(value * value for value in first) - 1.0) < 1e-9


def test_intent_router_is_fixed_and_predictable():
    assert classify_intent("Which systems support this process?") == Intent.SYSTEMS
    assert classify_intent("Show the BPMN activity sequence") == Intent.BPMN_FLOW
    assert classify_intent("Tell me something unusual") == Intent.GENERIC_EVIDENCE
