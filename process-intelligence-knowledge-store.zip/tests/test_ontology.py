import pytest

from app.domain.ontology import NodeType, RelationshipType, validate_relationship


def test_allowed_relationship_is_accepted():
    validate_relationship(NodeType.PROCESS, RelationshipType.GOVERNED_BY, NodeType.CONTROL)


def test_unlisted_relationship_is_rejected():
    with pytest.raises(ValueError):
        validate_relationship(NodeType.CONTROL, RelationshipType.USES_SYSTEM, NodeType.SYSTEM)
