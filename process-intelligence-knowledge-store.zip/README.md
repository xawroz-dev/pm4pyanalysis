# Process Intelligence Knowledge Store

A runnable enterprise reference implementation combining a governed Neo4j knowledge graph
with Qdrant vector retrieval and a hybrid chat API.

The central design decision is deliberate: the LLM is an extractor, **not an ontology
designer and not a Cypher author**. It can propose only approved entity types and relationship
triples. Application validation rejects everything outside ontology version `1.0`.

## What it demonstrates

- Metadata-aware ingestion of TXT, Markdown, PDF, DOCX, BPMN/XML.
- Structural BPMN parsing into models, activities, and ordered flow edges.
- Strict LLM extraction for `Market`, `BusinessUnit`, `Control`, and `System`.
- Idempotent Neo4j upserts; repeated mentions enrich one semantic edge with provenance.
- Qdrant vector chunks with process and document-classification filters.
- Fixed-intent, parameterized Cypher plus vector evidence for hybrid RAG.
- Live process journeys and variants linked to the same central `Process`.
- A comparison endpoint that shows the type/relationship proliferation of open extraction.
- Sample documents, BPMN, journey data, visualization queries, and tests.

## Architecture

```mermaid
flowchart LR
  U["SOP / policy / BPMN + metadata"] --> P["Parse, normalize, checksum"]
  P --> X["Strict LLM extraction"]
  X --> G["Ontology validator + canonicalizer"]
  G --> N[("Neo4j governed graph")]
  P --> C["Metadata-aware chunks"]
  C --> E["Embedding provider"]
  E --> Q[("Qdrant vector store")]
  J["Live journeys / variants"] --> N
  A["Chat API"] --> I["Fixed intent router"]
  I --> F["Approved parameterized Cypher"]
  F --> N
  I --> Q
  N --> R["Evidence-grounded answer"]
  Q --> R
```

The vector store holds retrieval infrastructure. Chunks are not promoted to domain entities.
The graph holds stable business meaning. This prevents chunk count, document revisions, or
repeated wording from multiplying semantic edges.

## Governed ontology

`Process` is the aggregate root.

| Source | Relationship | Target | Purpose |
|---|---|---|---|
| Process | `HAS_DOCUMENT` | Document | SOP, policy, or other evidence |
| Process | `MODELED_BY` | BPMNModel | Approved process diagram |
| BPMNModel | `DEFINES_ACTIVITY` | Activity | BPMN nodes |
| Activity | `NEXT_ACTIVITY` | Activity | BPMN sequence |
| Process | `HAS_JOURNEY` | Journey | Observed case execution |
| Process | `HAS_VARIANT` | Variant | Stable path grouping |
| Journey | `FOLLOWS_VARIANT` | Variant | Case-to-path link |
| Process | `OPERATES_IN` | Market | Governed domain entity |
| Process | `OWNED_BY` | BusinessUnit | Governed domain entity |
| Process | `GOVERNED_BY` | Control | Governed domain entity |
| Process | `USES_SYSTEM` | System | Governed domain entity |
| Activity | `PERFORMED_BY` | BusinessUnit | Optional activity detail |
| Activity | `USES_SYSTEM` | System | Optional activity detail |
| Activity | `ENFORCES_CONTROL` | Control | Optional activity detail |

Only the four domain rows from `Process` may be created by document LLM extraction in v1.
Artifacts, BPMN structure, journeys, and variants come from deterministic parsers/APIs. This
separation is important: the LLM cannot turn arbitrary nouns into operational graph types.

### Edge cardinality and provenance

Neo4j uses `MERGE` for `(Process)-[TYPE]->(canonical entity)`. A repeated fact does not create
another edge. Instead, the existing relationship maintains:

- `confidence`: highest accepted confidence;
- `evidence_document_ids`: unique list of supporting documents;
- `latest_evidence`: short evidence text;
- `first_seen_at` and `last_seen_at`.

For a larger production system, move evidence history to an immutable assertion/event store
while retaining this single materialized semantic edge for retrieval.

## Run locally

Requirements: Docker Compose, or Podman with a Compose provider.

```bash
cp .env.example .env
docker compose up --build -d
curl http://localhost:8000/health
python3 scripts/load_sample.py
```

With Podman:

```bash
podman compose up --build -d
curl http://localhost:8000/health
python3 scripts/load_sample.py
```

Services:

- API and Swagger: <http://localhost:8000/docs>
- Neo4j Browser: <http://localhost:7474> (`neo4j` / configured password)
- Qdrant dashboard: <http://localhost:6333/dashboard>

The default is a no-secret offline demonstration:

- `LLM_PROVIDER=metadata`: governed entity lists come from supplied metadata.
- `EMBEDDING_PROVIDER=hash`: deterministic lexical feature hashing.

This proves the data and retrieval architecture without sending enterprise data externally.
For semantic production behavior, set `LLM_PROVIDER=openai`,
`EMBEDDING_PROVIDER=openai`, and `LLM_API_KEY`. The LLM endpoint is OpenAI-compatible and
configured by `LLM_BASE_URL`.

## Ingest a document

Every artifact must arrive with metadata. This is intentional: process identity, version,
classification, and document ownership should not be guessed from prose.

```bash
curl -X POST http://localhost:8000/v1/ingest/document \
  -F 'file=@sample_data/p2p_sop.txt' \
  -F 'metadata=<sample_data/p2p_sop.metadata.json'
```

Re-uploading the same `document_id` and checksum is skipped. A changed checksum updates the
document, re-runs extraction, and deterministically upserts chunk IDs.

Load observed journeys:

```bash
curl -X POST http://localhost:8000/v1/ingest/journeys \
  -H 'Content-Type: application/json' \
  --data-binary @sample_data/journeys.json
```

## Ask hybrid questions

```bash
curl -X POST http://localhost:8000/v1/chat \
  -H 'Content-Type: application/json' \
  -d '{
    "process_id": "P2P-001",
    "question": "Which controls govern this process and what evidence supports them?",
    "classification_clearance": "confidential"
  }'
```

Useful demo questions:

1. `Which controls govern this process and what evidence supports them?`
2. `Which systems support Procure to Pay?`
3. `Show the BPMN activity sequence.`
4. `Which variants are most common and which take longest?`
5. `List recent live journeys and outcomes.`
6. `Which policy and SOP documents are linked to the process?`
7. `Which markets and business units are associated with it?`

Retrieval works as follows:

1. A deterministic router maps the question to one of ten governed intents.
2. The API runs only the corresponding parameterized query from
   `app/services/retrieval.py`.
3. Qdrant returns accessible document chunks, filtered by process and clearance.
4. The answer model receives graph facts plus chunk citations.
5. The response exposes the chosen intent, graph rows, citations, and retrieval diagnostics.

The API never executes Cypher supplied by a user or generated by an LLM.

## Visualize and query the graph

Paste queries from `schema/visualization_queries.cypher` into Neo4j Browser. A compact
API-friendly edge list is also available:

```bash
curl http://localhost:8000/v1/graph/processes/P2P-001/subgraph
```

The subgraph and chat APIs default to `internal` clearance. Pass
`?classification_clearance=confidential` only after deriving that value from authenticated
authorization claims in production.

The approved chat query catalog is inspectable:

```bash
curl http://localhost:8000/v1/graph/query-catalog
```

Example:

```cypher
MATCH path=(p:Process {process_id: "P2P-001"})-[r]->(n)
RETURN path;
```

## Demonstrate why unrestricted extraction is noisy

The comparison endpoint runs the same artifact through:

- the production constrained extractor; and
- an intentionally open extractor allowed to invent labels and relationships.

```bash
curl -X POST http://localhost:8000/v1/demo/compare-open-ontology \
  -F 'file=@sample_data/p2p_sop.txt' \
  -F 'metadata=<sample_data/p2p_sop.metadata.json'
```

The response compares unique entity and relationship types and reports conflicting
normalization examples. The open result is **never persisted**. This keeps the primary
knowledge store clean while giving you an evidence-based demonstration.

Why fixed ontology performs better:

- stable query plans and indexes;
- predictable entity resolution and deduplication;
- bounded relationship cardinality;
- consistent access control and provenance;
- measurable coverage and data-quality rules;
- easier evaluation of extraction and retrieval;
- less ambiguity for the answer model.

An open ontology can still be useful in a quarantined discovery workflow. Candidate types
should be reviewed, measured across a corpus, mapped to a business question, approved,
versioned, and only then introduced through an ontology migration.

## Tests

```bash
python -m pip install -e '.[dev]'
pytest -q
ruff check app tests
```

Tests cover ontology rejection, BPMN parsing, stable chunk IDs, deterministic embeddings,
extraction governance, and fixed intent routing.

## Enterprise production checklist

This is a working reference implementation, not a substitute for your platform controls.
Before production:

- Put the API behind SSO/OIDC and derive classification clearance from signed claims.
- Use a secrets manager and TLS/mTLS for Neo4j, Qdrant, and model endpoints.
- Add tenant IDs to every node, vector payload, uniqueness key, and query filter.
- Store source binaries in immutable object storage; retain checksum and URI in the graph.
- Add malware scanning, OCR, document size/page limits, and parser sandboxing.
- Introduce a canonical entity registry/MDM mapping rather than name-derived IDs.
- Add extraction review queues for confidence thresholds and entity-resolution conflicts.
- Version prompts, ontology, embeddings, chunks, and ingestion runs.
- Add delete/tombstone and legal-hold workflows across graph, vector, and object stores.
- Capture audit logs for document access, retrieval, generated answers, and admin changes.
- Evaluate extraction precision/recall and answer faithfulness against a labeled corpus.
- Use backups, HA, retention policies, rate limits, tracing, and dead-letter retry queues.
- Replace in-process ingestion with an event-driven worker for large files and bulk loads.

## Repository map

```text
app/domain/ontology.py       fixed labels and allowed relationship triples
app/services/extraction.py  strict extraction and open-ontology comparison
app/services/parsing.py     document and BPMN parsing
app/repositories/neo4j.py   constraints and idempotent graph upserts
app/repositories/vector.py  Qdrant indexing and classification filters
app/services/retrieval.py   fixed intents and approved Cypher
app/services/chat.py        grounded answer composition
schema/                     DBA constraints and visualization queries
sample_data/                SOP, policy, BPMN, metadata, and journeys
tests/                      unit tests for governance-critical behavior
```
