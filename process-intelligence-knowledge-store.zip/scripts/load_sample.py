import asyncio
import json
import os
from pathlib import Path

import httpx

ROOT = Path(__file__).resolve().parents[1]
BASE_URL = os.getenv("PROCESS_INTELLIGENCE_API_URL", "http://localhost:8000")


async def main() -> None:
    documents = [
        ("p2p_sop.txt", "p2p_sop.metadata.json"),
        ("p2p_policy.md", "p2p_policy.metadata.json"),
        ("p2p.bpmn", "p2p_bpmn.metadata.json"),
    ]
    async with httpx.AsyncClient(timeout=120) as client:
        for filename, metadata_filename in documents:
            file_path = ROOT / "sample_data" / filename
            metadata = (ROOT / "sample_data" / metadata_filename).read_text()
            with file_path.open("rb") as handle:
                response = await client.post(
                    f"{BASE_URL}/v1/ingest/document",
                    files={"file": (filename, handle)},
                    data={"metadata": metadata},
                )
            response.raise_for_status()
            print(json.dumps(response.json(), indent=2))

        journeys = json.loads((ROOT / "sample_data" / "journeys.json").read_text())
        response = await client.post(f"{BASE_URL}/v1/ingest/journeys", json=journeys)
        response.raise_for_status()
        print(json.dumps(response.json(), indent=2))


if __name__ == "__main__":
    asyncio.run(main())
