const $=(s,r=document)=>r.querySelector(s), $$=(s,r=document)=>[...r.querySelectorAll(s)];
const state={process:"Card Dispute Resolution",pending:false,lastQuestion:"",focus:null};
const esc=v=>String(v).replace(/[&<>'"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;","'":"&#39;",'"':"&quot;"}[c]));
const processVariants={"Card Dispute Resolution":[
    {name:"Variant 1",label:"Auto-resolved fraud claim",journeys:3880,share:36.2,duration:5.4,change:8.7},
    {name:"Variant 5",label:"Merchant evidence review",journeys:2430,share:22.7,duration:38.2,change:14.1},
    {name:"Variant 8",label:"Provisional credit",journeys:1390,share:13.0,duration:18.6,change:3.2},
    {name:"Variant 11",label:"Customer document request",journeys:820,share:7.7,duration:44.5,change:11.8},
    {name:"Variant 16",label:"Network arbitration",journeys:360,share:3.4,duration:96.0,change:-2.9}
  ]};
const currentVariants=()=>processVariants["Card Dispute Resolution"];
const activityDurations={"Card Dispute Resolution":[["Review merchant evidence",28.2],["Analyst review",14.6],["Verify transaction",3.1],["Issue credit",0.8],["Notify customer",0.1]]};
function resolveLevel(q){const m=q.match(/(?:level\s*|l)([123])/i);if(m)return Number(m[1]);if(/activity|activities|event|detailed/i.test(q))return 3;if(/high.level|overview|summary/i.test(q))return 1;return 2}
function resolveTimeRange(q){
  if(/this week/i.test(q)&&/last week/i.test(q))return "This week vs last week";
  if(/last friday/i.test(q))return "Last Friday";
  if(/yesterday/i.test(q))return "Yesterday";
  const fixed=q.match(/(?:jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|jul(?:y)?|aug(?:ust)?|sep(?:tember)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)\s+\d{1,2}(?:,\s*\d{4})?/i);
  if(fixed)return fixed[0].replace(/\b\w/g,c=>c.toUpperCase());
  if(/this week/i.test(q))return "This week";
  if(/last week/i.test(q))return "Last week";
  return "This month";
}
function timePhrase(range){return /vs/i.test(range)?range:range.startsWith("This")||range.startsWith("Last")||range==="Yesterday"?range.toLowerCase():`on ${range}`}

function toast(text){const el=$("#toast");el.textContent=text;el.classList.add("show");clearTimeout(toast.t);toast.t=setTimeout(()=>el.classList.remove("show"),1800)}
function scrollBottom(){requestAnimationFrame(()=>$("#chat").scrollTo({top:$("#chat").scrollHeight,behavior:"smooth"}))}
function money(n){return n.toLocaleString("en-US")}
function variantByName(name){return currentVariants().find(v=>v.name.toLowerCase()===String(name).toLowerCase())}
function isContextRef(q){return /\b(this|that|the same|behind it|like this)\b/i.test(q)}

function planResponse(question){
  const q=question.toLowerCase(), data=currentVariants(), top=data[0], slow=[...data].sort((a,b)=>b.duration-a.duration)[0];
  const base={question,intent:"unsupported_or_ambiguous",process:state.process,time_range:resolveTimeRange(question),abstraction_level:resolveLevel(question),tools:[],presentation_reason:"Narrative is sufficient for this answer.",blocks:[]};
  const when=timePhrase(base.time_range);
  if(isContextRef(question)&&state.focus?.type==="variant"){
    const v=variantByName(state.focus.name)||slow;
    if(q.includes("journey")){
      return {...base,intent:"contextual_variant_journeys",tools:["get_variant_journeys"],title:`Journeys behind ${v.name} — ${v.label}.`,summary:`Using the previous answer as context, I kept the focus on <strong>${v.name}</strong>.`,blocks:[{type:"journey_table",variant:v.name}],focus:{type:"variant",name:v.name,label:v.label}};
    }
    if(q.includes("activit")||q.includes("step")){
      const rows=v.name==="Variant 16"?[["Network arbitration",42.8],["Analyst review",22.4],["Merchant evidence review",18.2],["Issue decision",7.5]]:activityDurations[state.process];
      return {...base,intent:"contextual_variant_activities",tools:["get_variant_activity_duration"],title:`Activities contributing to ${v.name}'s duration.`,summary:`I kept the focus on <strong>${v.name}</strong> from the previous answer.`,blocks:[{type:"activity_bars",items:rows}],focus:{type:"variant",name:v.name,label:v.label}};
    }
    return {...base,intent:"contextual_variant_summary",tools:["get_snapshot_variant_summary"],title:`${v.name} is the current variant in context.`,summary:`${v.label} averages <strong>${v.duration} hours</strong> across <strong>${money(v.journeys)} journeys</strong>.`,blocks:[{type:"duration_bars"}],focus:{type:"variant",name:v.name,label:v.label}};
  }
  if(isContextRef(question)&&state.focus?.type==="activity"){
    if(q.includes("journey")){
      return {...base,intent:"contextual_activity_journeys",tools:["get_journeys_by_activity"],title:`Journeys affected by ${state.focus.name}.`,summary:"I used the previous activity as context and returned journeys from the matching path.",blocks:[{type:"journey_table",variant:"Variant 5"}],focus:{type:"variant",name:"Variant 5",label:"Merchant evidence review"}};
    }
    return {...base,intent:"contextual_activity_variants",tools:["find_variants_by_activity"],title:`Variants containing ${state.focus.name} ${when}.`,summary:"I used the previous activity as the context for this follow-up.",blocks:[{type:"variant_activity_table",activity:state.focus.name}],focus:state.focus};
  }
  if(isContextRef(question)&&state.focus?.type==="journey"){
    if(q.includes("variant")||q.includes("path")){
      return {...base,intent:"contextual_journey_variant",tools:["get_journey_variant"],title:`${state.focus.id} follows Variant 5.`,summary:"This journey is part of the <strong>merchant evidence review</strong> path.",blocks:[{type:"variant_compare",time:base.time_range}],focus:{type:"variant",name:"Variant 5",label:"Merchant evidence review"}};
    }
    if(q.includes("longest")||q.includes("step")||q.includes("activity")){
      return {...base,intent:"contextual_journey_step",tools:["get_journey_details"],title:`Merchant response was the longest wait in ${state.focus.id}.`,summary:"The journey spent <strong>18.4 hours</strong> waiting for merchant evidence before returning to analyst review.",blocks:[{type:"journey_timeline",id:state.focus.id}],focus:state.focus};
    }
    return {...base,intent:"contextual_journey_neighbors",tools:["find_similar_journeys"],title:`Similar journeys to ${state.focus.id}.`,summary:"These journeys follow the same merchant-evidence review path.",blocks:[{type:"journey_table",variant:"Variant 5"}],focus:{type:"variant",name:"Variant 5",label:"Merchant evidence review"}};
  }
  if(q.includes("variant")&&q.includes("got slower")){
    const v=variantByName("Variant 16");
    return {...base,intent:"variant_duration_regression",tools:["compare_variant_duration_windows"],title:"Variant 16 got slower this week.",summary:"Network arbitration increased from <strong>92.6 to 96.0 hours</strong>, a <strong>3.4 hour</strong> increase.",blocks:[{type:"variant_period_bars"}],focus:{type:"variant",name:v.name,label:v.label}};
  }
  if(q.includes("variant")&&q.includes("improved most")){
    const v=variantByName("Variant 5");
    return {...base,intent:"variant_duration_improvement",tools:["compare_variant_duration_windows"],title:"Variant 5 improved the most this week.",summary:"Merchant evidence review decreased from <strong>45.8 to 38.2 hours</strong>, a <strong>7.6 hour</strong> improvement.",blocks:[{type:"variant_period_bars"}],focus:{type:"variant",name:v.name,label:v.label}};
  }
  if(q.includes("compare")&&q.includes("variant")&&q.includes("duration")&&q.includes("this week")&&q.includes("last week")){
    return {...base,intent:"variant_duration_period_comparison",tools:["compare_variant_duration_windows"],title:"Variant duration improved across most paths this week.",summary:"Variant 5 improved the most, decreasing from <strong>45.8 to 38.2 hours</strong>.",presentation_reason:"Paired bars make week-over-week duration differences easy to compare.",blocks:[{type:"variant_period_bars"}],focus:{type:"period_comparison",period:"This week vs last week"}};
  }
  if(q.includes("activit")&&(q.includes("longest")||q.includes("slowest")||q.includes("duration")||q.includes("taking the longest"))){
    const activities=activityDurations[state.process];
    return {...base,intent:"activity_duration_ranking",tools:["get_snapshot_activity_duration"],title:`${activities[0][0]} is taking the longest.`,summary:`Its average duration is <strong>${activities[0][1]} hours</strong>.`,presentation_reason:"A ranked bar chart directly compares activity duration.",blocks:[{type:"activity_bars",items:activities}],focus:{type:"activity",name:activities[0][0]}};
  }
  if(q.includes("variant")&&(q.includes("include")||q.includes("contain")||q.includes("have")||q.includes("with"))){
    const activity=q.includes("merchant")||q.includes("evidence")?"Merchant evidence review":q.includes("provisional")?"Provisional credit":"the requested activity";
    const valid=activity!=="the requested activity";
    if(!valid)return {...base,intent:"variants_containing_activity",tools:["find_variants_by_activity"],title:`No ${state.process} variants include ${activity}.`,summary:"No matching variant paths were found.",blocks:[]};
    return {...base,intent:"variants_containing_activity",tools:["find_variants_by_activity"],title:`Variants containing ${activity} ${when}.`,summary:"The matching variant flows are listed below.",presentation_reason:"A compact table shows exactly where the activity appears.",blocks:[{type:"variant_activity_table",activity}],focus:{type:"activity",name:activity}};
  }
  if((q.includes("percentage")||q.includes("percentile")||q.includes("percent"))&&!q.includes("variant 1")){
    const result=q.includes("provisional")?["13.0%","provisional credit"]:["22.7%","merchant evidence review"];
    return {...base,intent:"activity_prevalence",tools:["get_snapshot_activity_prevalence"],title:`${result[0]} of journeys included ${result[1]} ${when}.`,summary:"",presentation_reason:"A single percentage answers the question directly.",blocks:[{type:"hero_metric",value:result[0],label:`of journeys included ${result[1]}`,detail:base.time_range}],focus:{type:"activity",name:result[1]}};
  }
  if((q.includes("show")||q.includes("display"))&&q.includes("flow")){
    return {...base,intent:"process_flow",tools:["get_variant_path"],title:"Card Dispute Resolution flow.",summary:"",presentation_reason:"A process diagram directly presents the requested flow.",blocks:[{type:"process_map"}],focus:{type:"flow",name:"Analyst review path"}};
  }
  if(q.includes("journey")&&(q.includes("exceeded")||q.includes("over 48")||q.includes("sla")||q.includes("breach"))){
    return {...base,intent:"sla_breach_journeys",tools:["get_journeys_by_duration"],title:`Four dispute journeys exceeded 48 hours ${when}.`,summary:"The matching journeys are listed from longest to shortest.",presentation_reason:"A table makes the individual cases available for drill-down.",blocks:[{type:"journey_table",mode:"sla"}]};
  }
  if(q.includes("compare")&&q.includes("variant 5")&&q.includes("variant 8")){
    return {...base,intent:"variant_comparison",tools:["compare_variants"],title:`Variant 5 took longer than Variant 8 ${when}.`,summary:"Merchant evidence review adds <strong>19.6 hours</strong> on average and introduces two additional activities.",presentation_reason:"A side-by-side table makes the journey and activity differences clear.",blocks:[{type:"variant_compare",time:base.time_range}],focus:{type:"variant",name:"Variant 5",label:"Merchant evidence review"}};
  }
  if(q.includes("open journey")||/DSP-\d+/i.test(q)){
    const id=(question.match(/DSP-\d+/i)||["DSP-10482"])[0].toUpperCase();
    return {...base,intent:"journey_detail",tools:["get_journey_details"],title:`${id} spent 18.4 hours waiting for merchant evidence ${when}.`,summary:"The dispute paused while evidence was requested, then returned to analyst review after an incomplete response.",presentation_reason:"A journey timeline best explains sequence and waiting time.",blocks:[{type:"journey_timeline",id}],focus:{type:"journey",id}};
  }
  if(q.includes("journeys")&&(q.includes("variant 5")||q.includes("evidence")||q.includes("affected"))){
    return {...base,intent:"variant_journey_list",tools:["resolve_variant","get_variant_journeys"],title:"Journeys in the merchant-evidence review path.",summary:"The requested journeys are listed below.",presentation_reason:"A table directly presents the requested journey list.",blocks:[{type:"journey_table"}]};
  }
  if((q.includes("why")&&(q.includes("manual")||q.includes("review")||q.includes("approval")||q.includes("document")))||q.includes("process flow")||q.includes("diagram")||q.includes("rework loop")||q.includes("review loop")||q.includes("document loop")||q.includes("explain variant")){
    return {...base,intent:"variant_explanation",tools:["resolve_variant","get_variant_path"],title:"Incomplete merchant evidence returns disputes to analyst review.",summary:"The evidence recheck creates the extra review loop shown below.",presentation_reason:"A process map directly shows the loop described in the answer.",blocks:[{type:"process_map"}]};
  }
  if(q.includes("percentage")&&q.includes("variant 1")){
    return {...base,intent:"variant_percentage",tools:["resolve_variant","get_snapshot_variant_summary"],title:`Variant 1 represents ${top.share.toFixed(1)}% of journeys this month.`,summary:`This is the <strong>${top.label.toLowerCase()}</strong> path.`,presentation_reason:"A single proportion answers the question directly.",blocks:[{type:"hero_metric",value:`${top.share.toFixed(1)}%`,label:"of journeys followed Variant 1",detail:top.label}],focus:{type:"variant",name:top.name,label:top.label}};
  }
  if(q.includes("longest")||q.includes("slowest")||q.includes("duration")||q.includes("bottleneck")){
    return {...base,intent:"variant_duration_ranking",tools:["get_snapshot_variant_duration"],title:`${slow.name} — ${slow.label} — was the slowest path ${when}.`,summary:`Its average resolution time was <strong>${slow.duration} hours</strong>.`,presentation_reason:"A ranked bar chart directly compares the requested durations.",blocks:[{type:"duration_bars"}],focus:{type:"variant",name:slow.name,label:slow.label}};
  }
  if(q.includes("common")||q.includes("distribution")||q.includes("variant mix")||q.includes("top variant")||(q.includes("variant")&&/level\s*[123]|\bl[123]\b/i.test(q))){
    return {...base,intent:"variant_distribution",tools:["get_snapshot_variant_summary"],title:`${top.name} is the most common path.`,summary:`The ${top.label.toLowerCase()} path has <strong>${money(top.journeys)} journeys</strong>.`,presentation_reason:"A ranked bar chart shows only the requested variant counts.",blocks:[{type:"variant_bars"}],focus:{type:"variant",name:top.name,label:top.label}};
  }
  if(q.includes("changed")||q.includes("compare")||q.includes("week")){
    return {...base,intent:"process_period_comparison",time_range:"This week vs last week",tools:["compare_snapshot_windows"],title:"Completed journeys increased and resolution time decreased.",summary:"Completed dispute journeys rose <strong>8.2%</strong> and average resolution time fell <strong>11.2%</strong>.",presentation_reason:"Two metrics and a comparison chart answer the requested period comparison.",blocks:[{type:"metric_strip",items:[{label:"Completed journeys",value:"10.7k",delta:"↑ 8.2%",tone:"good",note:"vs last week"},{label:"Avg. resolution time",value:"31.4h",delta:"↓ 11.2%",tone:"good",note:"vs last week"}]},{type:"comparison_line"}]};
  }
  return {...base,intent:"general_process_question",tools:["query_process_data"],title:`Here is what I found for ${state.process}.`,summary:"This POC can answer questions about variant duration, activities within variants, activity frequency, process flows, and individual journey histories. Use one of the example questions or include a variant, activity, or journey ID in your question.",blocks:[]};
}

function blockHead(kicker,title,meta=""){return `<div class="block-head"><div><label>${kicker}</label><h3>${title}</h3></div><small>${meta}</small></div>`}
function renderDataTable(headers,rows,caption="Table view"){
  return `<div class="companion-table"><div class="table-caption">${caption}</div><div class="table-wrap"><table class="result-table"><thead><tr>${headers.map(h=>`<th>${esc(h)}</th>`).join("")}</tr></thead><tbody>${rows.map(r=>`<tr>${r.map(c=>`<td>${esc(c)}</td>`).join("")}</tr>`).join("")}</tbody></table></div></div>`;
}
function renderMetricStrip(b){
  const rows=b.items.map(x=>[x.label,x.value,x.delta,x.note]);
  return `<section class="block">${blockHead("KEY SIGNALS","At a glance","Current vs comparison period")}<div class="metric-strip" style="--cols:${b.items.length}">${b.items.map(x=>`<div class="metric"><label>${x.label}</label><strong>${x.value}</strong><em class="${x.tone}">${x.delta}</em><small>${x.note}</small></div>`).join("")}</div>${renderDataTable(["Metric","Value","Change","Comparison"],rows)}</section>`
}
function renderHeroMetric(b){const pct=parseFloat(b.value)||40;return `<section class="block hero-metric"><div><strong>${b.value}</strong><span>${b.label}</span><small>${b.detail}</small></div><svg viewBox="0 0 120 120"><circle cx="60" cy="60" r="45" class="ring-bg"/><circle cx="60" cy="60" r="45" class="ring-value" pathLength="100" stroke-dasharray="${pct} ${100-pct}"/><text x="60" y="64">${b.value}</text></svg>${renderDataTable(["Measure","Value","Period"],[[b.label,b.value,b.detail]])}</section>`}
function renderComparison(){const rows=[["Wed","1,280","1,190"],["Thu","1,430","1,260"],["Fri","1,520","1,350"],["Sat","1,650","1,460"],["Sun","1,610","1,390"],["Mon","1,820","1,540"],["Tue","2,390","1,710"]];return `<section class="block">${blockHead("PERIOD COMPARISON","Completed dispute journeys by day")}<div class="chart-area"><div class="chart-legend"><span><i class="now"></i>This week</span><span><i class="before"></i>Last week</span></div><svg class="line-svg" viewBox="0 0 700 210" preserveAspectRatio="none"><defs><linearGradient id="areaFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#6b55d7" stop-opacity=".19"/><stop offset="1" stop-color="#6b55d7" stop-opacity="0"/></linearGradient></defs><g class="grid"><line x1="0" y1="25" x2="700" y2="25"/><line x1="0" y1="75" x2="700" y2="75"/><line x1="0" y1="125" x2="700" y2="125"/><line x1="0" y1="175" x2="700" y2="175"/></g><path class="area" d="M0 157 C45 149 72 119 116 125 S188 142 233 104 S301 66 350 82 S423 122 466 89 S540 35 583 56 S655 36 700 23 L700 190 L0 190Z"/><path class="baseline" d="M0 171 C47 164 70 144 116 151 S191 154 233 137 S310 104 350 115 S419 143 466 126 S540 87 583 97 S657 79 700 73"/><path class="mainline" d="M0 157 C45 149 72 119 116 125 S188 142 233 104 S301 66 350 82 S423 122 466 89 S540 35 583 56 S655 36 700 23"/><g><circle cx="0" cy="157" r="4"/><circle cx="116" cy="125" r="4"/><circle cx="233" cy="104" r="4"/><circle cx="350" cy="82" r="4"/><circle cx="466" cy="89" r="4"/><circle cx="583" cy="56" r="4"/><circle cx="700" cy="23" r="4"/></g><text x="0" y="205">Wed</text><text x="112" y="205">Thu</text><text x="228" y="205">Fri</text><text x="345" y="205">Sat</text><text x="462" y="205">Sun</text><text x="578" y="205">Mon</text><text x="685" y="205">Tue</text></svg></div>${renderDataTable(["Day","This week","Last week"],rows)}</section>`}
function renderVariantBars(){const data=currentVariants(),max=data[0].journeys;return `<section class="block">${blockHead("VARIANT DISTRIBUTION","Most common variants")}<div class="bars">${data.map(v=>`<div class="bar compact"><div class="bar-name"><strong>${v.name}</strong><small>${v.label}</small></div><div class="track"><i style="width:${v.journeys/max*100}%"></i></div><b>${money(v.journeys)}</b></div>`).join("")}</div>${renderDataTable(["Variant","Path","Journeys","Share","Avg. duration"],data.map(v=>[v.name,v.label,money(v.journeys),`${v.share}%`,`${v.duration}h`]))}</section>`}
function renderDurationBars(){const list=[...currentVariants()].sort((a,b)=>b.duration-a.duration),max=list[0].duration;return `<section class="block">${blockHead("DURATION RANKING","Average decision time by variant")}<div class="bars">${list.map((v,i)=>`<div class="bar compact"><div class="bar-name"><strong>${i+1}. ${v.name}</strong><small>${v.label}</small></div><div class="track"><i style="width:${v.duration/max*100}%;background:linear-gradient(90deg,#c96955,#e39a87)"></i></div><b>${v.duration}h</b></div>`).join("")}</div>${renderDataTable(["Rank","Variant","Path","Avg. duration","Journeys"],list.map((v,i)=>[i+1,v.name,v.label,`${v.duration}h`,money(v.journeys)]))}</section>`}
function renderVariantPeriodBars(){const rows=[["Variant 1",5.4,6.1],["Variant 5",38.2,45.8],["Variant 8",18.6,20.4],["Variant 11",44.5,47.1],["Variant 16",96.0,92.6]],max=96;return `<section class="block">${blockHead("WEEKLY COMPARISON","Average duration by variant","Hours")}<div class="paired-legend"><span><i class="current"></i>This week</span><span><i class="previous"></i>Last week</span></div><div class="paired-bars">${rows.map(r=>`<div class="paired-row"><strong>${r[0]}</strong><div><span style="width:${r[1]/max*100}%"><b>${r[1]}h</b></span><em style="width:${r[2]/max*100}%"><b>${r[2]}h</b></em></div></div>`).join("")}</div>${renderDataTable(["Variant","This week","Last week","Change"],rows.map(r=>[r[0],`${r[1]}h`,`${r[2]}h`,`${(r[1]-r[2]).toFixed(1)}h`]))}</section>`}
function renderActivityBars(b){const max=b.items[0][1];return `<section class="block">${blockHead("ACTIVITY DURATION","Average duration by activity")}<div class="bars">${b.items.map((a,i)=>`<div class="bar compact"><div class="bar-name"><strong>${i+1}. ${a[0]}</strong></div><div class="track"><i style="width:${a[1]/max*100}%;background:linear-gradient(90deg,#c96955,#e39a87)"></i></div><b>${a[1]}h</b></div>`).join("")}</div>${renderDataTable(["Rank","Activity","Avg. duration"],b.items.map((a,i)=>[i+1,a[0],`${a[1]}h`]))}</section>`}
function renderVariantActivityTable(b){const rows=[["Variant 5","File dispute → Verify transaction → Merchant evidence review → Decision"],["Variant 11","File dispute → Request documents → Merchant evidence review → Analyst review"]];return `<section class="block">${blockHead("VARIANT LOOKUP",`Variants with ${b.activity}`)}<div class="table-wrap"><table class="result-table"><thead><tr><th>Variant</th><th>Flow</th></tr></thead><tbody>${rows.map(r=>`<tr><td>${r[0]}</td><td>${r[1]}</td></tr>`).join("")}</tbody></table></div></section>`}
function renderProcessMap(b={}){
  const f={title:"Analyst review path",nodes:["File dispute","Verify transaction","Review evidence","Issue decision","Notify customer"],loop:"Evidence recheck"}, positions=[15,175,350,525,680];
  const nodes=f.nodes.map((n,i)=>`<g class="${i===2?'warn':''}" transform="translate(${positions[i]} 96)"><rect width="125" height="68" rx="14"/><text x="13" y="38">${n}</text></g>`).join("");
  const tableRows=f.nodes.map((n,i)=>[i+1,n,i===2?"Evidence can loop back for recheck":"Main path"]);
  return `<section class="block">${blockHead("PROCESS EXPLANATION",f.title)}<div class="map-wrap"><svg class="process-svg" viewBox="0 0 820 250"><defs><marker id="arrow" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="5" markerHeight="5" orient="auto"><path d="M0 0L10 5L0 10Z" fill="#adb3ad"/></marker><marker id="redarrow" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="5" markerHeight="5" orient="auto"><path d="M0 0L10 5L0 10Z" fill="#c96955"/></marker></defs><path class="edge" d="M140 130H175" marker-end="url(#arrow)"/><path class="edge" d="M300 130H350" marker-end="url(#arrow)"/><path class="edge" d="M475 130H525" marker-end="url(#arrow)"/><path class="edge" d="M650 130H680" marker-end="url(#arrow)"/><path class="loop" d="M412 166C405 222 238 222 235 166" marker-end="url(#redarrow)"/><text class="edge-label" x="325" y="215">${f.loop}</text>${nodes}</svg></div>${renderDataTable(["Step","Activity","Note"],tableRows)}</section>`
}
function renderJourneyTable(b={}){
  const byVariant={
    "Variant 16":[["DSP-11934","96.0h","Breached"],["DSP-11827","88.6h","In arbitration"],["DSP-11702","71.4h","Breached"],["DSP-11588","58.7h","Breached"]],
    "Variant 5":[["DSP-10482","38.2h","In review"],["DSP-10811","34.7h","SLA risk"],["DSP-10993","30.2h","Complete"],["DSP-11204","27.9h","Complete"]],
    "Variant 1":[["DSP-10104","5.4h","Complete"],["DSP-10127","4.9h","Complete"],["DSP-10218","4.6h","Complete"],["DSP-10302","4.1h","Complete"]]
  };
  const rows=b.mode==="sla"?[["DSP-11934","96.0h","Breached"],["DSP-11702","71.4h","Breached"],["DSP-11588","58.7h","Breached"],["DSP-11041","49.2h","Breached"]]:(byVariant[b.variant]||byVariant["Variant 5"]);
  const title=b.mode==="sla"?"Journeys over the 48-hour target":`Journeys following ${b.variant||"Variant 5"}`;
  return `<section class="block">${blockHead("JOURNEY DRILL-DOWN",title)}<div class="table-wrap"><table class="result-table"><thead><tr><th>Journey</th><th>Elapsed</th><th>Status</th></tr></thead><tbody>${rows.map(r=>`<tr><td><button data-prompt="Open journey ${r[0]}">${r[0]}</button></td><td>${r[1]}</td><td>${r[2]==="Complete"?r[2]:`<span class="status">${r[2]}</span>`}</td></tr>`).join("")}</tbody></table></div></section>`
}
function renderVariantCompare(b={}){const rows=[["Journeys","2,430","1,390"],["Average duration","38.2h","18.6h"],["Activities in path","7","5"],["Longest activity","Merchant evidence review · 28.2h","Provisional credit approval · 6.4h"]];return `<section class="block">${blockHead("VARIANT COMPARISON","Variant 5 vs Variant 8",b.time||"This week")}<div class="table-wrap"><table class="result-table"><thead><tr><th>Metric</th><th>Variant 5</th><th>Variant 8</th></tr></thead><tbody>${rows.map(r=>`<tr><td>${r[0]}</td><td>${r[1]}</td><td>${r[2]}</td></tr>`).join("")}</tbody></table></div></section>`}
function renderTimeline(b){const steps=[["Dispute filed","Jul 1 · 09:42"],["Verify transaction","+22m"],["Request evidence","+3.1h"],["Merchant response","+18.4h","alert"],["Analyst review","+12.2h","alert"],["Issue credit","+4.1h"],["Notify customer","Complete"]];return `<section class="block">${blockHead("JOURNEY DETAIL",`${b.id} · Full activity path`,`${steps.length} activities`)}<div class="journey-meta"><div><label>Status</label><strong>Complete</strong></div><div><label>Elapsed</label><strong>38.2 hours</strong></div><div><label>Variant</label><strong>Variant 5</strong></div><div><label>Owner</label><strong>Disputes Operations</strong></div></div><div class="timeline">${steps.map(s=>`<div class="step ${s[2]||''}"><i></i><strong>${s[0]}</strong><small>${s[1]}</small></div>`).join("")}</div>${renderDataTable(["Step","Activity","Elapsed / timestamp","Flag"],steps.map((s,i)=>[i+1,s[0],s[1],s[2]==="alert"?"Delay point":""]))}</section>`}
function renderBlock(b){return ({metric_strip:renderMetricStrip,hero_metric:renderHeroMetric,comparison_line:renderComparison,variant_bars:renderVariantBars,duration_bars:renderDurationBars,variant_period_bars:renderVariantPeriodBars,activity_bars:renderActivityBars,variant_activity_table:renderVariantActivityTable,process_map:renderProcessMap,journey_table:renderJourneyTable,variant_compare:renderVariantCompare,journey_timeline:renderTimeline}[b.type]||(()=>""))(b)}

function followupQuestions(schema){
  const map={
    variant_duration_ranking:["Show journeys behind this variant","Which activities make this variant long?","Compare variant duration this week with last week"],
    contextual_variant_journeys:["Open journey DSP-11934","Which activities make this variant long?","Which variant got slower this week?"],
    contextual_variant_activities:["Show journeys behind this variant","Compare variant duration this week with last week","Which variants included merchant evidence review yesterday?"],
    activity_duration_ranking:["Which variants include this activity?","Show journeys affected by this activity","Compare completed journeys this week with last week"],
    variants_containing_activity:["Show journeys affected by this activity","What percentage of journeys included merchant evidence review this week?","Which activities are taking the longest?"],
    variant_duration_period_comparison:["Which variant improved most?","Which variant got slower this week?","Show journeys behind Variant 5"],
    variant_duration_improvement:["Show journeys behind this variant","Which activities make this variant long?","Compare Variant 5 and Variant 8 this week"],
    variant_duration_regression:["Show journeys behind this variant","Which activities make this variant long?","Open journey DSP-11934"],
    process_period_comparison:["Compare variant duration this week with last week","Which variants took the longest this week?","Which journeys exceeded 48 hours this week?"],
    journey_detail:["Which step took the longest in this journey?","Find other journeys like this","Which variant does this journey follow?"],
    contextual_journey_step:["Find other journeys like this","Which variants included merchant evidence review yesterday?","Which journeys exceeded 48 hours this week?"],
    contextual_journey_neighbors:["Open journey DSP-10811","Which activities make this variant long?","Compare Variant 5 and Variant 8 this week"],
    contextual_activity_journeys:["Open journey DSP-10482","Which activities make this variant long?","Compare Variant 5 and Variant 8 this week"],
    contextual_journey_variant:["Show journeys behind this variant","Which activities make this variant long?","Compare Variant 5 and Variant 8 this week"],
    variant_comparison:["Show journeys behind this variant","Which activities make this variant long?","Compare variant duration this week with last week"],
    sla_breach_journeys:["Open journey DSP-11934","Which variants took the longest this week?","Compare variant duration this week with last week"]
  };
  return map[schema.intent]||[];
}
function renderFollowups(schema){
  const items=followupQuestions(schema).slice(0,3);
  if(!items.length)return "";
  return `<div class="followups"><label>Follow-up questions</label>${items.map(q=>`<button data-prompt="${esc(q)}">${esc(q)}</button>`).join("")}</div>`;
}
function renderAnswer(schema){const blocks=schema.blocks.map(renderBlock).join("");return `<article class="message assistant-message"><div class="assistant-avatar">✦</div><div class="assistant-content"><div class="assistant-head"><strong>PI-copilot</strong><time>Now</time></div><div class="answer"><h2>${schema.title}</h2>${schema.summary?`<p>${schema.summary}</p>`:""}</div>${blocks}${renderFollowups(schema)}</div></article>`}
function userMessage(q){return `<article class="message user-message"><div class="user-bubble">${esc(q)}</div></article>`}
function bindResponse(root){$$('[data-prompt]',root).forEach(b=>b.addEventListener('click',()=>ask(b.dataset.prompt)))}

async function ask(question){
  const q=question.trim();if(!q||state.pending)return;state.pending=true;$('#emptyState').hidden=true;$('#messages').classList.add('active');$('#headerTitle').textContent=q.length>42?q.slice(0,42)+'…':q;$('#messages').insertAdjacentHTML('beforeend',userMessage(q));$('#chatInput').value='';$('#thinking').hidden=false;scrollBottom();
  const phases=["Understanding your question…","Selecting the right process data…","Collecting snapshot evidence…","Choosing the clearest presentation…"];let i=0;$('#thinkingText').textContent=phases[0];const timer=setInterval(()=>{$('#thinkingText').textContent=phases[Math.min(++i,phases.length-1)]},360);
  await new Promise(r=>setTimeout(r,700));clearInterval(timer);$('#thinking').hidden=true;const schema=planResponse(q);state.lastQuestion=q;if(schema.focus)state.focus=schema.focus;$('#messages').insertAdjacentHTML('beforeend',renderAnswer(schema));bindResponse($('#messages').lastElementChild);state.pending=false;scrollBottom();
}

$('#chatForm').addEventListener('submit',e=>{e.preventDefault();ask($('#chatInput').value)});$('#chatInput').addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();ask(e.target.value)}});$('#chatInput').addEventListener('input',e=>{e.target.style.height='auto';e.target.style.height=Math.min(e.target.scrollHeight,120)+'px'});$$('[data-prompt]',$('#emptyState')).forEach(b=>b.addEventListener('click',()=>ask(b.dataset.prompt)));
$('#newChat').addEventListener('click',()=>{$('#messages').innerHTML='';$('#messages').classList.remove('active');$('#emptyState').hidden=false;$('#headerTitle').textContent='New conversation';$('#chat').scrollTo({top:0,behavior:'smooth'});$('#chatInput').focus()});
$$('.process').forEach(b=>b.addEventListener('click',()=>$('#rail').classList.remove('open')));
$('#menuBtn').addEventListener('click',()=>$('#rail').classList.toggle('open'));document.addEventListener('keydown',e=>{if((e.metaKey||e.ctrlKey)&&e.key.toLowerCase()==='k'){e.preventDefault();$('#chatInput').focus()}if(e.key==='Escape')$('#rail').classList.remove('open')});
