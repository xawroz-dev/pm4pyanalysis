const $=(s,r=document)=>r.querySelector(s), $$=(s,r=document)=>[...r.querySelectorAll(s)];
const state={process:"Credit Limit Increase",pending:false,lastSchema:null};
const processIds={"Credit Limit Increase":"p_credit_limit_increase","Customer Onboarding":"p_customer_onboarding","Card Dispute Resolution":"p_card_dispute_resolution"};
const esc=v=>String(v).replace(/[&<>'"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;","'":"&#39;",'"':"&quot;"}[c]));
const processVariants={
  "Credit Limit Increase":[
    {name:"Variant 1",label:"Straight-through approval",journeys:4968,share:40.0,duration:2.4,change:9.1},
    {name:"Variant 4",label:"Income verification",journeys:2126,share:17.1,duration:11.8,change:13.2},
    {name:"Variant 7",label:"Manual credit review",journeys:1484,share:11.9,duration:31.6,change:22.8},
    {name:"Variant 9",label:"Additional documents",journeys:902,share:7.3,duration:18.2,change:-1.7},
    {name:"Variant 12",label:"Risk escalation",journeys:621,share:5.0,duration:26.7,change:-14.9}
  ],
  "Customer Onboarding":[
    {name:"Variant 1",label:"Digital straight-through",journeys:5320,share:42.8,duration:1.6,change:12.4},
    {name:"Variant 3",label:"Enhanced KYC",journeys:2180,share:17.5,duration:15.2,change:6.8},
    {name:"Variant 7",label:"Missing documents",journeys:1405,share:11.3,duration:41.8,change:19.6},
    {name:"Variant 9",label:"Manual identity review",journeys:980,share:7.9,duration:29.4,change:8.1},
    {name:"Variant 14",label:"Sanctions escalation",journeys:430,share:3.5,duration:52.6,change:-4.2}
  ],
  "Card Dispute Resolution":[
    {name:"Variant 1",label:"Auto-resolved fraud claim",journeys:3880,share:36.2,duration:5.4,change:8.7},
    {name:"Variant 5",label:"Merchant evidence review",journeys:2430,share:22.7,duration:38.2,change:14.1},
    {name:"Variant 8",label:"Provisional credit",journeys:1390,share:13.0,duration:18.6,change:3.2},
    {name:"Variant 11",label:"Customer document request",journeys:820,share:7.7,duration:44.5,change:11.8},
    {name:"Variant 16",label:"Network arbitration",journeys:360,share:3.4,duration:96.0,change:-2.9}
  ]
};
const currentVariants=()=>processVariants[state.process]||processVariants["Credit Limit Increase"];

function toast(text){const el=$("#toast");el.textContent=text;el.classList.add("show");clearTimeout(toast.t);toast.t=setTimeout(()=>el.classList.remove("show"),1800)}
function scrollBottom(){requestAnimationFrame(()=>$("#chat").scrollTo({top:$("#chat").scrollHeight,behavior:"smooth"}))}
function money(n){return n.toLocaleString("en-US")}

function planResponse(question){
  const q=question.toLowerCase(), data=currentVariants(), top=data[0], slow=[...data].sort((a,b)=>b.duration-a.duration)[0];
  const onboarding=state.process==="Customer Onboarding", dispute=state.process==="Card Dispute Resolution";
  const journeyPrefix=onboarding?"ONB":dispute?"DSP":"LIM";
  const base={question,intent:"unsupported_or_ambiguous",process:state.process,time_range:"This month",abstraction_level:2,tools:[],presentation_reason:"Narrative is sufficient for this answer.",blocks:[],followups:[]};
  if(q.includes("open journey")||/(?:LIM|ONB|DSP)-\d+/i.test(q)){
    const id=(question.match(/(?:LIM|ONB|DSP)-\d+/i)||[`${journeyPrefix}-10482`])[0].toUpperCase();
    const issue=onboarding?"a missing-document loop":dispute?"merchant evidence waiting":"a repeated manual credit review";
    return {...base,intent:"journey_detail",tools:["get_journey_details"],title:`${id} lost 18.6 hours in ${issue}.`,summary:onboarding?"The application failed automated identity verification, requested a new proof of address, and then waited for manual KYC review.":dispute?"The dispute paused while merchant evidence was requested, then returned to analyst review after an incomplete response.":"The request moved from <strong>risk assessment</strong> to <strong>manual review</strong>, then required a second bureau check. That loop explains most of its delay versus straight-through approval.",presentation_reason:"A journey timeline best explains sequence and waiting time.",blocks:[{type:"journey_timeline",id}],followups:["Find journeys with the same loop","Compare this journey with Variant 1"]};
  }
  if(q.includes("journeys")&&(q.includes("variant 7")||q.includes("manual")||q.includes("affected"))){
    return {...base,intent:"variant_journey_list",tools:["resolve_variant","get_variant_journeys"],title:`Journeys in the ${onboarding?"document-review":"manual-review"} path.`,summary:"The requested journeys are listed below.",presentation_reason:"A table directly presents the requested journey list.",blocks:[{type:"journey_table"}]};
  }
  if((q.includes("why")&&(q.includes("manual")||q.includes("review")||q.includes("approval")||q.includes("document")))||q.includes("process flow")||q.includes("diagram")||q.includes("rework loop")||q.includes("review loop")||q.includes("document loop")||q.includes("explain variant")){
    const title=onboarding?"Failed address verification is driving extra KYC review.":dispute?"Incomplete merchant evidence is driving analyst rework.":"A second bureau check is driving manual credit review.";
    const summary=onboarding?"Applications that fail address verification enter a second document-collection cycle.":dispute?"Incomplete merchant evidence returns disputes to analyst review.":"Income or employment edits trigger a second bureau check and manual credit review.";
    return {...base,intent:"variant_comparison",tools:["resolve_variant","compare_snapshot_windows"],title,summary,presentation_reason:"A process map directly shows the loop described in the answer.",blocks:[{type:"process_map"}]};
  }
  if(q.includes("percentage")&&q.includes("variant 1")){
    return {...base,intent:"variant_percentage",tools:["resolve_variant","get_snapshot_variant_summary"],title:`Variant 1 represents ${top.share.toFixed(1)}% of journeys this month.`,summary:`This is the <strong>${top.label.toLowerCase()}</strong> path.`,presentation_reason:"A single proportion answers the question directly.",blocks:[{type:"hero_metric",value:`${top.share.toFixed(1)}%`,label:"of journeys followed Variant 1",detail:top.label}]};
  }
  if(q.includes("longest")||q.includes("slowest")||q.includes("duration")||q.includes("bottleneck")){
    return {...base,intent:"variant_duration_ranking",tools:["get_snapshot_variant_duration"],title:`${slow.name} — ${slow.label} — is the slowest path.`,summary:`Its average decision time is <strong>${slow.duration} hours</strong>.`,presentation_reason:"A ranked bar chart directly compares the requested durations.",blocks:[{type:"duration_bars"}]};
  }
  if(q.includes("common")||q.includes("distribution")||q.includes("variant mix")||q.includes("top variant")){
    return {...base,intent:"variant_distribution",tools:["get_snapshot_variant_summary"],title:`${top.name} is the most common path.`,summary:`The ${top.label.toLowerCase()} path has <strong>${money(top.journeys)} journeys</strong>.`,presentation_reason:"A ranked bar chart shows only the requested variant counts.",blocks:[{type:"variant_bars"}]};
  }
  if(q.includes("changed")||q.includes("compare")||q.includes("week")){
    const cycle=onboarding?"7.8h":dispute?"31.4h":"9.6h";
    return {...base,intent:"process_period_comparison",time_range:"This week vs last week",tools:["compare_snapshot_windows"],title:"Completed journeys increased and decision time decreased.",summary:`Completed ${state.process.toLowerCase()} journeys rose <strong>8.2%</strong> and average decision time fell <strong>11.2%</strong>.`,presentation_reason:"Two metrics and a comparison chart answer the requested period comparison.",blocks:[{type:"metric_strip",items:[{label:"Completed journeys",value:onboarding?"12.4k":dispute?"10.7k":"12.4k",delta:"↑ 8.2%",tone:"good",note:"vs last week"},{label:"Avg. decision time",value:cycle,delta:"↓ 11.2%",tone:"good",note:"vs last week"}]},{type:"comparison_line"}]};
  }
  return {...base,title:"I can investigate that, but I need one detail.",summary:`Should I answer “${esc(question)}” for <strong>${state.process}</strong> over this month, or use a different time range?`,blocks:[],followups:["Use this month","Use the last 90 days"]};
}

function blockHead(kicker,title,meta=""){return `<div class="block-head"><div><label>${kicker}</label><h3>${title}</h3></div><small>${meta}</small></div>`}
function renderMetricStrip(b){return `<section class="block">${blockHead("KEY SIGNALS","At a glance","Current vs comparison period")}<div class="metric-strip" style="--cols:${b.items.length}">${b.items.map(x=>`<div class="metric"><label>${x.label}</label><strong>${x.value}</strong><em class="${x.tone}">${x.delta}</em><small>${x.note}</small></div>`).join("")}</div></section>`}
function renderHeroMetric(b){const pct=parseFloat(b.value)||40;return `<section class="block hero-metric"><div><strong>${b.value}</strong><span>${b.label}</span><small>${b.detail}</small></div><svg viewBox="0 0 120 120"><circle cx="60" cy="60" r="45" class="ring-bg"/><circle cx="60" cy="60" r="45" class="ring-value" pathLength="100" stroke-dasharray="${pct} ${100-pct}"/><text x="60" y="64">${b.value}</text></svg></section>`}
function renderComparison(){return `<section class="block">${blockHead("PERIOD COMPARISON",state.process==="Credit Limit Increase"?"Completed limit decisions by day":"Completed journeys by day")}<div class="chart-area"><div class="chart-legend"><span><i class="now"></i>This week</span><span><i class="before"></i>Last week</span></div><svg class="line-svg" viewBox="0 0 700 210" preserveAspectRatio="none"><defs><linearGradient id="areaFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#6b55d7" stop-opacity=".19"/><stop offset="1" stop-color="#6b55d7" stop-opacity="0"/></linearGradient></defs><g class="grid"><line x1="0" y1="25" x2="700" y2="25"/><line x1="0" y1="75" x2="700" y2="75"/><line x1="0" y1="125" x2="700" y2="125"/><line x1="0" y1="175" x2="700" y2="175"/></g><path class="area" d="M0 157 C45 149 72 119 116 125 S188 142 233 104 S301 66 350 82 S423 122 466 89 S540 35 583 56 S655 36 700 23 L700 190 L0 190Z"/><path class="baseline" d="M0 171 C47 164 70 144 116 151 S191 154 233 137 S310 104 350 115 S419 143 466 126 S540 87 583 97 S657 79 700 73"/><path class="mainline" d="M0 157 C45 149 72 119 116 125 S188 142 233 104 S301 66 350 82 S423 122 466 89 S540 35 583 56 S655 36 700 23"/><g><circle cx="0" cy="157" r="4"/><circle cx="116" cy="125" r="4"/><circle cx="233" cy="104" r="4"/><circle cx="350" cy="82" r="4"/><circle cx="466" cy="89" r="4"/><circle cx="583" cy="56" r="4"/><circle cx="700" cy="23" r="4"/></g><text x="0" y="205">Wed</text><text x="112" y="205">Thu</text><text x="228" y="205">Fri</text><text x="345" y="205">Sat</text><text x="462" y="205">Sun</text><text x="578" y="205">Mon</text><text x="685" y="205">Tue</text></svg></div></section>`}
function renderVariantBars(){const data=currentVariants(),max=data[0].journeys;return `<section class="block">${blockHead("VARIANT DISTRIBUTION","Most common variants")}<div class="bars">${data.map(v=>`<div class="bar compact"><div class="bar-name"><strong>${v.name}</strong><small>${v.label}</small></div><div class="track"><i style="width:${v.journeys/max*100}%"></i></div><b>${money(v.journeys)}</b></div>`).join("")}</div></section>`}
function renderDurationBars(){const list=[...currentVariants()].sort((a,b)=>b.duration-a.duration),max=list[0].duration;return `<section class="block">${blockHead("DURATION RANKING","Average decision time by variant")}<div class="bars">${list.map((v,i)=>`<div class="bar compact"><div class="bar-name"><strong>${i+1}. ${v.name}</strong><small>${v.label}</small></div><div class="track"><i style="width:${v.duration/max*100}%;background:linear-gradient(90deg,#c96955,#e39a87)"></i></div><b>${v.duration}h</b></div>`).join("")}</div></section>`}
function renderProcessMap(){
  const flows={
    "Credit Limit Increase":{title:"Manual credit review path",nodes:["Submit request","Fetch bureau data","Assess eligibility","Approve limit","Notify customer"],loop:"Second bureau check"},
    "Customer Onboarding":{title:"Document review path",nodes:["Submit application","Verify identity","Run KYC / AML","Open account","Send welcome"],loop:"Document recheck"},
    "Card Dispute Resolution":{title:"Analyst review path",nodes:["File dispute","Verify transaction","Review evidence","Issue decision","Notify customer"],loop:"Evidence recheck"}
  };
  const f=flows[state.process]||flows["Credit Limit Increase"], positions=[15,175,350,525,680];
  const nodes=f.nodes.map((n,i)=>`<g class="${i===2?'warn':''}" transform="translate(${positions[i]} 96)"><rect width="125" height="68" rx="14"/><text x="13" y="38">${n}</text></g>`).join("");
  return `<section class="block">${blockHead("PROCESS EXPLANATION",f.title)}<div class="map-wrap"><svg class="process-svg" viewBox="0 0 820 250"><defs><marker id="arrow" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="5" markerHeight="5" orient="auto"><path d="M0 0L10 5L0 10Z" fill="#adb3ad"/></marker><marker id="redarrow" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="5" markerHeight="5" orient="auto"><path d="M0 0L10 5L0 10Z" fill="#c96955"/></marker></defs><path class="edge" d="M140 130H175" marker-end="url(#arrow)"/><path class="edge" d="M300 130H350" marker-end="url(#arrow)"/><path class="edge" d="M475 130H525" marker-end="url(#arrow)"/><path class="edge" d="M650 130H680" marker-end="url(#arrow)"/><path class="loop" d="M412 166C405 222 238 222 235 166" marker-end="url(#redarrow)"/><text class="edge-label" x="325" y="215">${f.loop}</text>${nodes}</svg></div></section>`
}
function renderJourneyTable(){const prefix=state.process==="Customer Onboarding"?"ONB":state.process==="Card Dispute Resolution"?"DSP":"LIM";const rows=[[`${prefix}-10482`,"31.6h","In review"],[`${prefix}-10811`,"29.7h","SLA risk"],[`${prefix}-10993`,"27.2h","Complete"],[`${prefix}-11204`,"24.9h","Complete"],[`${prefix}-11328`,"23.6h","Complete"]];return `<section class="block">${blockHead("JOURNEY DRILL-DOWN","Journeys following Variant 7")}<div class="table-wrap"><table class="result-table"><thead><tr><th>Journey</th><th>Elapsed</th><th>Status</th></tr></thead><tbody>${rows.map(r=>`<tr><td><button data-prompt="Open journey ${r[0]}">${r[0]}</button></td><td>${r[1]}</td><td>${r[2]==="Complete"?r[2]:`<span class="status">${r[2]}</span>`}</td></tr>`).join("")}</tbody></table></div></section>`}
function renderTimeline(b){const onboarding=state.process==="Customer Onboarding",dispute=state.process==="Card Dispute Resolution";const steps=onboarding?[["Application submitted","Jul 1 · 09:42"],["Identity check","+12m"],["KYC screen","+1.8h"],["Request document","+4.2h","alert"],["Document received","+13.6h","alert"],["Account opened","+18.6h"],["Welcome sent","Complete"]]:dispute?[["Dispute filed","Jul 1 · 09:42"],["Verify transaction","+22m"],["Request evidence","+3.1h"],["Merchant response","+18.4h","alert"],["Analyst review","+12.2h","alert"],["Issue credit","+4.1h"],["Notify customer","Complete"]]:[["Request submitted","Jul 1 · 09:42"],["Identity verified","+8m"],["Bureau data pulled","+18m"],["Risk assessed","+2.4h"],["Manual review","+18.6h","alert"],["Limit approved","+10.2h"],["Customer notified","Complete"]];const owner=onboarding?"KYC Operations":dispute?"Disputes Operations":"Credit Risk Operations";return `<section class="block">${blockHead("JOURNEY DETAIL",`${b.id} · Full activity path`,`${steps.length} activities`)}<div class="journey-meta"><div><label>Status</label><strong>Complete</strong></div><div><label>Elapsed</label><strong>31.6 hours</strong></div><div><label>Variant</label><strong>Variant 7</strong></div><div><label>Owner</label><strong>${owner}</strong></div></div><div class="timeline">${steps.map(s=>`<div class="step ${s[2]||''}"><i></i><strong>${s[0]}</strong><small>${s[1]}</small></div>`).join("")}</div></section>`}
function renderBlock(b){return ({metric_strip:renderMetricStrip,hero_metric:renderHeroMetric,comparison_line:renderComparison,variant_bars:renderVariantBars,duration_bars:renderDurationBars,process_map:renderProcessMap,journey_table:renderJourneyTable,journey_timeline:renderTimeline}[b.type]||(()=>""))(b)}

function renderAnswer(schema){
  schema.blocks=schema.blocks.filter(block=>block.type!=="callout");
  delete schema.followups;
  state.lastSchema=schema;
  const blocks=schema.blocks.map(renderBlock).join("");
  const sources=schema.tools.length?schema.tools.join(" → "):"No data tool called";
  return `<article class="message assistant-message"><div class="assistant-avatar">✦</div><div class="assistant-content"><div class="assistant-head"><strong>PI-copilot</strong><span class="grounded">✓ Grounded in process data</span><time>Now</time></div><div class="answer"><h2>${schema.title}</h2><p>${schema.summary}</p></div>${schema.blocks.length?`<div class="render-note"><span>✦</span>Presentation chosen for this question: ${esc(schema.presentation_reason)}</div>`:""}${blocks}<details class="provenance"><summary>How this answer was created</summary><div class="trace-grid"><div class="trace-card"><label>Intent & retrieval</label><strong>${schema.intent}</strong><p>${sources}</p></div><div class="trace-card"><label>Scope</label><strong>${schema.process} · ${schema.time_range}</strong></div></div><button class="schema-button">View LLM response schema <span>{ }</span></button></details><div class="message-actions"><button>♧ Helpful</button><button>♢ Not quite</button><button>⧉ Copy</button><button>↗ Share</button></div></div></article>`;
}
function userMessage(q){return `<article class="message user-message"><div class="user-bubble">${esc(q)}</div><div class="avatar user-avatar">AM</div></article>`}
function bindResponse(root){$$('[data-prompt]',root).forEach(b=>b.addEventListener('click',()=>ask(b.dataset.prompt)));const sb=$('.schema-button',root);if(sb)sb.addEventListener('click',showSchema);$$('.message-actions button',root).forEach(b=>b.addEventListener('click',()=>toast(b.textContent.includes('Copy')?'Answer copied':b.textContent.includes('Share')?'Share link copied':'Thanks for the feedback')))}
function showSchema(){if(!state.lastSchema)return;$('#schemaContent').textContent=JSON.stringify(state.lastSchema,null,2);$('#schemaModal').hidden=false}

async function ask(question){
  const q=question.trim();if(!q||state.pending)return;state.pending=true;$('#emptyState').hidden=true;$('#messages').classList.add('active');$('#headerTitle').textContent=q.length>42?q.slice(0,42)+'…':q;$('#messages').insertAdjacentHTML('beforeend',userMessage(q));$('#chatInput').value='';$('#thinking').hidden=false;scrollBottom();
  const phases=["Understanding your question…","Selecting the right process data…","Collecting snapshot evidence…","Choosing the clearest presentation…"];let i=0;$('#thinkingText').textContent=phases[0];const timer=setInterval(()=>{$('#thinkingText').textContent=phases[Math.min(++i,phases.length-1)]},360);
  await new Promise(r=>setTimeout(r,1250));clearInterval(timer);$('#thinking').hidden=true;const schema=planResponse(q);$('#messages').insertAdjacentHTML('beforeend',renderAnswer(schema));bindResponse($('#messages').lastElementChild);state.pending=false;scrollBottom();
}

$('#chatForm').addEventListener('submit',e=>{e.preventDefault();ask($('#chatInput').value)});$('#chatInput').addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();ask(e.target.value)}});$('#chatInput').addEventListener('input',e=>{e.target.style.height='auto';e.target.style.height=Math.min(e.target.scrollHeight,120)+'px'});$$('[data-prompt]',$('#emptyState')).forEach(b=>b.addEventListener('click',()=>ask(b.dataset.prompt)));
$('#newChat').addEventListener('click',()=>{$('#messages').innerHTML='';$('#messages').classList.remove('active');$('#emptyState').hidden=false;$('#headerTitle').textContent='New conversation';$('#chat').scrollTo({top:0,behavior:'smooth'});$('#chatInput').focus()});
$$('.process').forEach(b=>b.addEventListener('click',()=>{$$('.process').forEach(x=>{x.classList.toggle('active',x===b);$('b',x).textContent=x===b?'✓':''});state.process=b.dataset.process;$('#processName').textContent=state.process;$('#heroProcess').textContent=state.process+'?';$('#drawerProcess').textContent=state.process;$('.selected-process small').textContent=processIds[state.process];$('.selected-process .process-icon').textContent=state.process==="Credit Limit Increase"?'LI':state.process==="Customer Onboarding"?'CO':'DR';$('#messages').innerHTML='';$('#messages').classList.remove('active');$('#emptyState').hidden=false;$('#headerTitle').textContent='New conversation';$('#chat').scrollTo({top:0,behavior:'smooth'});$('#rail').classList.remove('open');toast(state.process+' is now in context')}));
$('#contextBtn').addEventListener('click',()=>$('#contextDrawer').classList.add('open'));$('#closeContext').addEventListener('click',()=>$('#contextDrawer').classList.remove('open'));$('#menuBtn').addEventListener('click',()=>$('#rail').classList.toggle('open'));$('#shareBtn').addEventListener('click',()=>toast('Share link copied'));$$('.segments button').forEach(b=>b.addEventListener('click',()=>{$$('.segments button').forEach(x=>x.classList.toggle('active',x===b));toast('Abstraction '+b.textContent+' selected')}));
$('#closeSchema').addEventListener('click',()=>$('#schemaModal').hidden=true);$('#schemaModal').addEventListener('click',e=>{if(e.target===$('#schemaModal'))$('#schemaModal').hidden=true});$('#copySchema').addEventListener('click',async()=>{try{await navigator.clipboard.writeText($('#schemaContent').textContent);toast('Schema copied')}catch{toast('Copy unavailable')}});document.addEventListener('keydown',e=>{if((e.metaKey||e.ctrlKey)&&e.key.toLowerCase()==='k'){e.preventDefault();$('#chatInput').focus()}if(e.key==='Escape'){$('#schemaModal').hidden=true;$('#contextDrawer').classList.remove('open');$('#rail').classList.remove('open')}});
