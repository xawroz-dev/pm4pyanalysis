# PI-copilot — Process Intelligence POC

A dependency-free, chat-first proof of concept for the snapshot-first process-mining assistant described in the implementation plan. The POC uses a generative response schema: each question produces an intent, controlled tool plan, and a dynamic set of presentation blocks selected for that answer.

## Run locally

```bash
python3 -m http.server 4173
```

Then open `http://localhost:4173`.

## What to try

- Ask “What changed this week compared with last week?” for concise metrics and a comparison chart.
- Ask “Show me the most common variants this month” for a distribution chart and exact-value table.
- Ask “Which variants are taking the longest?” for a ranked duration view and metric caveat.
- Ask “Why is approval rework increasing?” for a process diagram selected by the response planner.
- Ask “Show me journeys for Variant 7,” then open a journey for its timeline.
- Expand “How this answer was created” and inspect the LLM response schema.

The data and LLM behavior are scripted for the POC. `planResponse()` simulates the structured LLM output; `renderBlock()` is the generic UI renderer. Replacing the planner with a real structured-output LLM and backend tool calls does not require changing the interaction model.

Responses intentionally stop after answering the user’s question and showing evidence. The POC does not auto-generate follow-up questions, recommendations, or “what deserves attention” analysis.

The included credit-card examples cover Credit Limit Increase, Customer Onboarding, and Card Dispute Resolution, with process-specific variants, journey tables, causal diagrams, and activity timelines.
