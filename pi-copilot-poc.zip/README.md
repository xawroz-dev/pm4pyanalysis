# PI-copilot — Process Intelligence POC

A dependency-free, chat-first proof of concept for the snapshot-first process-mining assistant described in the implementation plan. The POC uses a generative response schema: each question produces an intent, controlled tool plan, and a dynamic set of presentation blocks selected for that answer.

## Run locally

```bash
python3 -m http.server 4173
```

Then open `http://localhost:4173`.

## What to try

- Ask “Which variants are taking the longest?” for a ranked duration chart.
- Ask “Which variants include merchant evidence review?” for matching paths.
- Ask “What percentage of journeys include provisional credit?” for a focused metric.
- Ask “Show journey DSP-10482” for the complete activity timeline.
- Ask “Which journeys exceeded 48 hours?” for an SLA-breach drill-down.
- Ask “Compare Variant 5 and Variant 8” for a side-by-side operational comparison.

The data and LLM behavior are scripted for the POC. `planResponse()` simulates the structured LLM output; `renderBlock()` is the generic UI renderer. Replacing the planner with a real structured-output LLM and backend tool calls does not require changing the interaction model.

Responses intentionally stop after answering the user’s question. The POC does not auto-generate follow-up questions, recommendations, or “what deserves attention” analysis.

Each intent requests and renders only the fields needed for that question. Totals, percentages, snapshot counts, secondary metrics, and duplicate tables are omitted unless the user explicitly asks for them.

The POC is intentionally focused on Card Dispute Resolution. Abstraction level and presentation type are inferred from the question rather than selected in the interface.
